/*    */ package fun.rockstarity.api.helpers.secure;
/*    */ 
/*    */ import fun.rockstarity.api.secure.Debugger;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.security.MessageDigest;
/*    */ import java.security.NoSuchAlgorithmException;
/*    */ import java.util.Arrays;
/*    */ import java.util.Base64;
/*    */ import javax.crypto.Cipher;
/*    */ import javax.crypto.spec.SecretKeySpec;
/*    */ import ru.kotopushka.antiautistleak.obfuscator.includes.annotations.compile.ReleaseCompileToNativeCalls;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ReleaseCompileToNativeCalls
/*    */ public class Crypt
/*    */ {
/*    */   private static byte[] key;
/*    */   private static SecretKeySpec secretKey;
/*    */   
/*    */   public static String encrypt(String strToEncrypt) {
/*    */     try {
/* 31 */       setKey("PassWorld");
/* 32 */       Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
/* 33 */       cipher.init(1, secretKey);
/*    */       
/* 35 */       return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes("UTF-8")));
/*    */     }
/* 37 */     catch (Exception e) {
/*    */       
/* 39 */       Debugger.print(e);
/*    */       
/* 41 */       return null;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static String decrypt(String strToDecrypt) {
/*    */     try {
/* 48 */       setKey("PassWorld");
/* 49 */       Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
/* 50 */       cipher.init(2, secretKey);
/*    */       
/* 52 */       return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
/*    */     }
/* 54 */     catch (Exception e) {
/*    */       
/* 56 */       Debugger.print(e);
/*    */       
/* 58 */       return null;
/*    */     } 
/*    */   }
/*    */   
/*    */   public static void setKey(String myKey) {
/* 63 */     MessageDigest sha = null;
/*    */     try {
/* 65 */       key = myKey.getBytes("UTF-8");
/* 66 */       sha = MessageDigest.getInstance("SHA-1");
/* 67 */       key = sha.digest(key);
/* 68 */       key = Arrays.copyOf(key, 16);
/* 69 */       secretKey = new SecretKeySpec(key, "AES");
/*    */     }
/* 71 */     catch (NoSuchAlgorithmException e) {
/* 72 */       Debugger.print(e);
/*    */     }
/* 74 */     catch (UnsupportedEncodingException e) {
/* 75 */       Debugger.print(e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\secure\Crypt.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */