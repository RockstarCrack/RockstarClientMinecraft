/*     */ package fun.rockstarity.api.helpers.secure;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.time.ZoneId;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.util.Base64;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.spec.IvParameterSpec;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyGeneration
/*     */ {
/*     */   private static long startTime;
/*     */   private static long timeDiff;
/*     */   
/*     */   public static String encrypt(String data) {
/*     */     try {
/*  42 */       byte[] key = getAdjustedKey();
/*  43 */       Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
/*  44 */       byte[] iv = secret().getBytes("UTF-8");
/*  45 */       IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
/*  46 */       SecretKeySpec secretKeySpec = new SecretKeySpec(key, "AES");
/*     */       
/*  48 */       cipher.init(1, secretKeySpec, ivParameterSpec);
/*  49 */       byte[] encrypted = cipher.doFinal(data.getBytes("UTF-8"));
/*     */       
/*  51 */       return Base64.getEncoder().encodeToString(encrypted);
/*  52 */     } catch (Exception e) {
/*  53 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static String decrypt(String encryptedData) throws Exception {
/*  59 */     byte[] key = getAdjustedKey();
/*  60 */     byte[] iv = secret().getBytes("UTF-8");
/*  61 */     byte[] decoded = Base64.getDecoder().decode(encryptedData.getBytes("UTF-8"));
/*     */     
/*  63 */     IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
/*  64 */     SecretKeySpec secretKeySpec = new SecretKeySpec(key, "AES");
/*     */     
/*  66 */     Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
/*  67 */     cipher.init(2, secretKeySpec, ivParameterSpec);
/*  68 */     byte[] decrypted = cipher.doFinal(decoded);
/*     */     
/*  70 */     return new String(decrypted, "UTF-8");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String staticDecrypt(String encryptedData) {
/*     */     try {
/*  79 */       byte[] key = getStaticKey();
/*  80 */       byte[] iv = staticSecret().getBytes("UTF-8");
/*  81 */       byte[] decoded = Base64.getDecoder().decode(encryptedData.getBytes("UTF-8"));
/*     */       
/*  83 */       IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
/*  84 */       SecretKeySpec secretKeySpec = new SecretKeySpec(key, "AES");
/*     */       
/*  86 */       Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
/*  87 */       cipher.init(2, secretKeySpec, ivParameterSpec);
/*  88 */       byte[] decrypted = cipher.doFinal(decoded);
/*     */       
/*  90 */       return new String(decrypted, "UTF-8");
/*  91 */     } catch (Exception e) {
/*  92 */       e.printStackTrace();
/*  93 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void initialize() {
/*  98 */     long startTime = System.currentTimeMillis() / 1000L;
/*  99 */     ZonedDateTime nowInMoscow = ZonedDateTime.now(ZoneId.of("Europe/Moscow"));
/* 100 */     ZonedDateTime epochInMoscow = ZonedDateTime.ofInstant(Instant.ofEpochSecond(0L), ZoneId.of("Europe/Moscow"));
/* 101 */     long sec = Duration.between(epochInMoscow, nowInMoscow).toSeconds();
/* 102 */     timeDiff = sec - startTime;
/*     */   }
/*     */   
/*     */   private static String secret() {
/* 106 */     ZonedDateTime nowInMoscow = ZonedDateTime.now(ZoneId.of("Europe/Moscow"));
/* 107 */     ZonedDateTime epochInMoscow = ZonedDateTime.ofInstant(Instant.ofEpochSecond(0L), ZoneId.of("Europe/Moscow"));
/* 108 */     long sec = Duration.between(epochInMoscow, nowInMoscow).toSeconds() - timeDiff;
/* 109 */     long time = Math.round(sec / 60.0D);
/*     */     
/* 111 */     String keyStr = "r30cka6f" + time;
/*     */ 
/*     */     
/* 114 */     return keyStr;
/*     */   }
/*     */   
/*     */   private static String staticSecret() {
/* 118 */     return "71s3k9sc4f3b4b8a";
/*     */   }
/*     */   
/*     */   private static byte[] getStaticKey() {
/*     */     try {
/* 123 */       byte[] key = staticSecret().getBytes("UTF-8");
/* 124 */       byte[] adjustedKey = new byte[32];
/* 125 */       for (int i = 0; i < adjustedKey.length; i++) {
/* 126 */         adjustedKey[i] = (i < key.length) ? key[i] : 0;
/*     */       }
/* 128 */       return adjustedKey;
/* 129 */     } catch (Exception e) {
/* 130 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static byte[] getAdjustedKey() {
/*     */     try {
/* 136 */       byte[] key = secret().getBytes("UTF-8");
/* 137 */       byte[] adjustedKey = new byte[32];
/* 138 */       for (int i = 0; i < adjustedKey.length; i++) {
/* 139 */         adjustedKey[i] = (i < key.length) ? key[i] : 0;
/*     */       }
/* 141 */       return adjustedKey;
/* 142 */     } catch (Exception e) {
/* 143 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\secure\KeyGeneration.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */