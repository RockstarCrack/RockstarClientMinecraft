/*     */ package fun.rockstarity.api.helpers.secure;
/*     */ 
/*     */ import fun.rockstarity.api.secure.Debugger;
/*     */ import fun.rockstarity.api.secure.nativeapi.NativeHelper;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontFormatException;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.net.URLEncoder;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Map;
/*     */ import javax.net.ssl.HttpsURLConnection;
/*     */ import ru.kotopushka.antiautistleak.obfuscator.includes.annotations.compile.ReleaseCompileToNativeCalls;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ReleaseCompileToNativeCalls
/*     */ public final class Web
/*     */ {
/*     */   private Web() {
/*  35 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*     */   }
/*     */   public static String protectedRead(String url) {
/*  38 */     StringBuilder stringBuilder = new StringBuilder();
/*     */     
/*     */     try {
/*  41 */       HttpsURLConnection httpsClient = (HttpsURLConnection)(new URL(url)).openConnection();
/*  42 */       httpsClient.setRequestProperty("User-Agent", KeyGeneration.encrypt("RockAgent").replace("/", "").replace("=", "").replace("+", "") + "/1.0");
/*  43 */       httpsClient.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
/*  44 */       httpsClient.setRequestProperty("Content-Length", Integer.toString(("Крякер иди нахуй".getBytes()).length));
/*  45 */       httpsClient.setRequestProperty("Content-Language", "en-US");
/*  46 */       httpsClient.setUseCaches(false);
/*  47 */       httpsClient.setDoOutput(true);
/*     */       
/*  49 */       BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpsClient.getInputStream(), "UTF-8"));
/*     */       String line;
/*  51 */       while ((line = bufferedReader.readLine()) != null) {
/*  52 */         stringBuilder.append(line).append('\n');
/*     */       }
/*  54 */       bufferedReader.close();
/*  55 */     } catch (Exception e) {
/*  56 */       Debugger.print(e);
/*     */     } 
/*     */     
/*  59 */     return stringBuilder.toString();
/*     */   }
/*     */   
/*     */   public static String read(String url) {
/*  63 */     StringBuilder stringBuilder = new StringBuilder();
/*     */     
/*     */     try {
/*  66 */       HttpsURLConnection httpsClient = (HttpsURLConnection)(new URL(url)).openConnection();
/*  67 */       httpsClient.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36");
/*  68 */       httpsClient.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
/*  69 */       httpsClient.setRequestProperty("Content-Length", Integer.toString(("Крякер иди нахуй".getBytes()).length));
/*  70 */       httpsClient.setRequestProperty("Content-Language", "en-US");
/*  71 */       httpsClient.setUseCaches(false);
/*  72 */       httpsClient.setDoOutput(true);
/*     */       
/*  74 */       BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpsClient.getInputStream()));
/*     */       String line;
/*  76 */       while ((line = bufferedReader.readLine()) != null) {
/*  77 */         stringBuilder.append(line).append('\n');
/*     */       }
/*  79 */     } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */     
/*  83 */     return stringBuilder.toString();
/*     */   }
/*     */   
/*     */   public static boolean openWebpage(String url) {
/*  87 */     String os = System.getProperty("os.name").toLowerCase();
/*     */     
/*     */     try {
/*  90 */       if (os.contains("win")) {
/*     */         
/*  92 */         Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + url);
/*  93 */       } else if (os.contains("mac")) {
/*     */         
/*  95 */         Runtime.getRuntime().exec("open " + url);
/*  96 */       } else if (os.contains("nix") || os.contains("nux") || os.contains("mac")) {
/*     */         
/*  98 */         Runtime.getRuntime().exec("xdg-open " + url);
/*     */       }
/*     */     
/* 101 */     } catch (IOException iOException) {}
/*     */     
/* 103 */     return false;
/*     */   }
/*     */   
/*     */   public static String protectedPostRequest(Map<String, String> params, String url) {
/*     */     try {
/* 108 */       HttpURLConnection httpURLConnection = (HttpURLConnection)(new URL(url)).openConnection();
/* 109 */       httpURLConnection.setRequestProperty("User-Agent", KeyGeneration.encrypt("RockAgent").replace("/", "").replace("=", "").replace("+", "") + "/1.0");
/* 110 */       httpURLConnection.setRequestMethod("POST");
/* 111 */       httpURLConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
/* 112 */       byte[] postData = getParamsString(params).getBytes(StandardCharsets.UTF_8);
/* 113 */       httpURLConnection.setRequestProperty("Content-Length", Integer.toString(postData.length));
/*     */       
/* 115 */       httpURLConnection.setUseCaches(false);
/* 116 */       httpURLConnection.setDoOutput(true);
/*     */       
/* 118 */       DataOutputStream wr = new DataOutputStream(httpURLConnection.getOutputStream()); 
/* 119 */       try { wr.write(postData);
/* 120 */         wr.close(); } catch (Throwable throwable) { try { wr.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */          throw throwable; }
/* 122 */        StringBuilder response = new StringBuilder();
/* 123 */       BufferedReader buffer = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream())); 
/*     */       try { String line;
/* 125 */         while ((line = buffer.readLine()) != null) {
/* 126 */           response.append(line);
/*     */         }
/* 128 */         buffer.close(); } catch (Throwable throwable) { try { buffer.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */          throw throwable; }
/* 130 */        return response.toString();
/* 131 */     } catch (Exception e) {
/* 132 */       Debugger.print(e);
/*     */       
/* 134 */       return "";
/*     */     } 
/*     */   }
/*     */   public static void downloadFile(String fileUrl, String destinationPath) {
/*     */     
/* 139 */     try { URL url = new URL(fileUrl);
/* 140 */       HttpURLConnection connection = (HttpURLConnection)url.openConnection();
/* 141 */       connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36");
/*     */       
/* 143 */       InputStream inputStream = connection.getInputStream(); 
/* 144 */       try { FileOutputStream outputStream = new FileOutputStream(destinationPath); 
/* 145 */         try { byte[] buffer = new byte[4096];
/*     */           int bytesRead;
/* 147 */           while ((bytesRead = inputStream.read(buffer)) != -1) {
/* 148 */             outputStream.write(buffer, 0, bytesRead);
/*     */           }
/* 150 */           outputStream.close(); } catch (Throwable throwable) { try { outputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  if (inputStream != null) inputStream.close();  } catch (Throwable throwable) { if (inputStream != null)
/* 151 */           try { inputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException e)
/* 152 */     { e.printStackTrace(); }
/*     */   
/*     */   }
/*     */   
/*     */   public static String postRequest(Map<String, String> params, String url) {
/*     */     try {
/* 158 */       HttpURLConnection httpURLConnection = (HttpURLConnection)(new URL(url)).openConnection();
/* 159 */       httpURLConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36");
/* 160 */       httpURLConnection.setRequestMethod("POST");
/* 161 */       httpURLConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
/* 162 */       byte[] postData = getParamsString(params).getBytes(StandardCharsets.UTF_8);
/* 163 */       httpURLConnection.setRequestProperty("Content-Length", Integer.toString(postData.length));
/*     */       
/* 165 */       httpURLConnection.setUseCaches(false);
/* 166 */       httpURLConnection.setDoOutput(true);
/*     */       
/* 168 */       DataOutputStream wr = new DataOutputStream(httpURLConnection.getOutputStream()); 
/* 169 */       try { wr.write(postData);
/* 170 */         wr.close(); } catch (Throwable throwable) { try { wr.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */          throw throwable; }
/* 172 */        StringBuilder response = new StringBuilder();
/* 173 */       BufferedReader buffer = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream())); 
/*     */       try { String line;
/* 175 */         while ((line = buffer.readLine()) != null) {
/* 176 */           response.append(line);
/*     */         }
/* 178 */         buffer.close(); } catch (Throwable throwable) { try { buffer.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */          throw throwable; }
/* 180 */        return response.toString();
/* 181 */     } catch (Exception e) {
/* 182 */       Debugger.print(e);
/*     */       
/* 184 */       return "";
/*     */     } 
/*     */   }
/*     */   public static final Font getFont(String name, int style, int size) {
/* 188 */     Font font = null;
/*     */     
/* 190 */     try { InputStream fontStream = Web.class.getResourceAsStream(NativeHelper.getFontResource(name)); 
/* 191 */       try { if (fontStream == null)
/* 192 */         { Debugger.print(new IOException("Font not found: " + name));
/* 193 */           Font font1 = null;
/*     */ 
/*     */ 
/*     */           
/* 197 */           if (fontStream != null) fontStream.close();  return font1; }  font = Font.createFont(0, fontStream).deriveFont(style, size); if (fontStream != null) fontStream.close();  } catch (Throwable throwable) { if (fontStream != null) try { fontStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (FontFormatException|IOException e)
/* 198 */     { Debugger.print(e); }
/*     */ 
/*     */     
/* 201 */     return font;
/*     */   }
/*     */   
/*     */   public static final Font getFullFont(String link, int style, int size) {
/* 205 */     Font font = null;
/*     */     
/* 207 */     try { InputStream fontStream = Web.class.getResourceAsStream("/assets/minecraft/rockstar/files/fonts/" + link); 
/* 208 */       try { if (fontStream == null)
/* 209 */         { Debugger.print(new IOException("Font not found: " + link));
/* 210 */           Font font1 = null;
/*     */ 
/*     */ 
/*     */           
/* 214 */           if (fontStream != null) fontStream.close();  return font1; }  font = Font.createFont(0, fontStream).deriveFont(style, size); if (fontStream != null) fontStream.close();  } catch (Throwable throwable) { if (fontStream != null) try { fontStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (FontFormatException|IOException e)
/* 215 */     { Debugger.print(e); }
/*     */ 
/*     */     
/* 218 */     return font;
/*     */   }
/*     */   
/*     */   public static String getParamsString(Map<String, String> params) {
/* 222 */     StringBuilder result = new StringBuilder();
/*     */     
/* 224 */     params.forEach((name, value) -> {
/*     */           try {
/*     */             result.append(URLEncoder.encode(name, "UTF-8"));
/*     */             result.append('=');
/*     */             result.append(URLEncoder.encode(value, "UTF-8"));
/*     */             result.append('&');
/* 230 */           } catch (UnsupportedEncodingException e) {
/*     */             Debugger.print(e);
/*     */           } 
/*     */         });
/*     */     
/* 235 */     String resultString = result.toString();
/* 236 */     return !resultString.isEmpty() ? resultString.substring(0, resultString.length() - 1) : resultString;
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\secure\Web.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */