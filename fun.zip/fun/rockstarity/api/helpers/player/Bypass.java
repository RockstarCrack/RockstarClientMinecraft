/*    */ package fun.rockstarity.api.helpers.player;
/*    */ 
/*    */ import com.viaversion.viaversion.api.protocol.version.ProtocolVersion;
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.via.ViaLoadingBase;
/*    */ import net.minecraft.network.IPacket;
/*    */ import net.minecraft.network.play.client.CPlayerPacket;
/*    */ import net.minecraft.network.play.client.CPlayerTryUseItemPacket;
/*    */ import net.minecraft.util.Hand;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Bypass
/*    */   implements IAccess
/*    */ {
/*    */   private Bypass() {
/* 18 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*    */   }
/*    */   public static boolean via() {
/* 21 */     return ViaLoadingBase.getInstance().getTargetVersion().isNewerThanOrEqualTo(ProtocolVersion.v1_17);
/*    */   }
/*    */   
/*    */   public static void send(float yaw, float pitch) {
/* 25 */     send(mc.player.getPosX(), mc.player.getPosY(), mc.player.getPosZ(), yaw, pitch, mc.player.isOnGround());
/*    */   }
/*    */   
/*    */   public static void send(double x, double y, double z, float yaw, float pitch, boolean ground) {
/* 29 */     mc.player.connection.sendPacket((IPacket)new CPlayerPacket.PositionRotationPacket(x, y, z, yaw, pitch, ground));
/* 30 */     mc.player.connection.sendPacket((IPacket)new CPlayerTryUseItemPacket(Hand.MAIN_HAND));
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\player\Bypass.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */