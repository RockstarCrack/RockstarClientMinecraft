/*    */ package fun.rockstarity.api.helpers.player;
/*    */ 
/*    */ import fun.rockstarity.api.events.list.player.EventMotionMove;
/*    */ import net.minecraft.client.entity.player.ClientPlayerEntity;
/*    */ import net.minecraft.potion.Effects;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ 
/*    */ public class StrafeMovement implements IAccess {
/*    */   private double oldSpeed;
/*    */   private double contextFriction;
/*    */   private boolean needSwap;
/*    */   
/* 13 */   public void setOldSpeed(double oldSpeed) { this.oldSpeed = oldSpeed; } private boolean needSprintState; private int counter; private int noSlowTicks; public void setContextFriction(double contextFriction) { this.contextFriction = contextFriction; } public void setNeedSwap(boolean needSwap) { this.needSwap = needSwap; } public void setNeedSprintState(boolean needSprintState) { this.needSprintState = needSprintState; } public void setCounter(int counter) { this.counter = counter; } public void setNoSlowTicks(int noSlowTicks) { this.noSlowTicks = noSlowTicks; }
/*    */   
/* 15 */   public double getOldSpeed() { return this.oldSpeed; } public double getContextFriction() { return this.contextFriction; }
/* 16 */   public boolean isNeedSwap() { return this.needSwap; }
/* 17 */   public boolean isNeedSprintState() { return this.needSprintState; }
/* 18 */   public int getCounter() { return this.counter; } public int getNoSlowTicks() { return this.noSlowTicks; }
/*    */ 
/*    */   
/*    */   public double calculateSpeed(EventMotionMove move, boolean damageBoost, boolean hasTime, boolean autoJump, float damageSpeed) {
/*    */     float n8;
/* 23 */     boolean fromGround = mc.player.isOnGround();
/* 24 */     boolean toGround = move.isToGround();
/* 25 */     boolean jump = ((move.getMotion()).y > 0.0D);
/* 26 */     float speedAttributes = getAIMoveSpeed(mc.player);
/* 27 */     float frictionFactor = getFrictionFactor(mc.player, move);
/* 28 */     float n6 = (mc.player.isPotionActive(Effects.JUMP_BOOST) && mc.player.isHandActive()) ? 0.88F : 0.91F;
/*    */     
/* 30 */     if (fromGround) {
/* 31 */       n6 = frictionFactor;
/*    */     }
/* 33 */     float n7 = 0.16277136F / n6 * n6 * n6;
/*    */     
/* 35 */     if (fromGround) {
/* 36 */       n8 = speedAttributes * n7;
/* 37 */       if (jump) {
/* 38 */         n8 += 0.2F;
/*    */       }
/*    */     } else {
/* 41 */       n8 = (damageBoost && hasTime && (autoJump || mc.gameSettings.keyBindJump.isKeyDown())) ? damageSpeed : 0.0255F;
/*    */     } 
/* 43 */     boolean noslow = false;
/* 44 */     double max2 = this.oldSpeed + n8;
/* 45 */     double max = 0.0D;
/* 46 */     if (mc.player.isHandActive() && !jump) {
/* 47 */       double n10 = this.oldSpeed + n8 * 0.25D;
/* 48 */       double motionY2 = (move.getMotion()).y;
/* 49 */       if (motionY2 != 0.0D && Math.abs(motionY2) < 0.08D) {
/* 50 */         n10 += 0.055D;
/*    */       }
/* 52 */       if (max2 > (max = Math.max(0.043D, n10))) {
/* 53 */         noslow = true;
/* 54 */         this.noSlowTicks++;
/*    */       } else {
/* 56 */         this.noSlowTicks = Math.max(this.noSlowTicks - 1, 0);
/*    */       } 
/*    */     } else {
/* 59 */       this.noSlowTicks = 0;
/*    */     } 
/* 61 */     if (this.noSlowTicks > 3) {
/* 62 */       max2 = max - ((mc.player.isPotionActive(Effects.JUMP_BOOST) && mc.player.isHandActive()) ? 0.3D : 0.019D);
/*    */     } else {
/* 64 */       max2 = Math.max(noslow ? 0.0D : 0.25D, max2) - ((this.counter++ % 2 == 0) ? 0.001D : 0.002D);
/*    */     } 
/* 66 */     this.contextFriction = n6;
/* 67 */     if (!toGround && !fromGround) {
/* 68 */       this.needSwap = true;
/*    */     }
/* 70 */     if (!fromGround && !toGround) {
/* 71 */       this.needSprintState = !mc.player.serverSprintState;
/*    */     }
/* 73 */     if (toGround && fromGround) {
/* 74 */       this.needSprintState = false;
/*    */     }
/* 76 */     return max2;
/*    */   }
/*    */   
/*    */   public void postMove(double horizontal) {
/* 80 */     this.oldSpeed = horizontal * this.contextFriction;
/*    */   }
/*    */   
/*    */   private float getAIMoveSpeed(ClientPlayerEntity contextPlayer) {
/* 84 */     boolean prevSprinting = contextPlayer.isSprinting();
/* 85 */     contextPlayer.setSprinting(false);
/* 86 */     float speed = contextPlayer.getAIMoveSpeed() * 1.3F;
/* 87 */     contextPlayer.setSprinting(prevSprinting);
/* 88 */     return speed;
/*    */   }
/*    */   
/*    */   private float getFrictionFactor(ClientPlayerEntity contextPlayer, EventMotionMove move) {
/* 92 */     BlockPos.Mutable blockpos$mutable = new BlockPos.Mutable();
/* 93 */     blockpos$mutable.setPos((move.getFrom()).x, (move.getAabbFrom()).minY - 1.0D, (move.getFrom()).z);
/*    */     
/* 95 */     return (contextPlayer.world.getBlockState((BlockPos)blockpos$mutable).getBlock()).slipperiness * 0.91F;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\player\StrafeMovement.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */