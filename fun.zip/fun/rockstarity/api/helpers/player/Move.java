/*     */ package fun.rockstarity.api.helpers.player;
/*     */ 
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.events.list.player.EventMotionMove;
/*     */ import fun.rockstarity.client.modules.render.FreeLook;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Move
/*     */   implements IAccess
/*     */ {
/*     */   private static int airTicks;
/*     */   
/*     */   private Move() {
/*  19 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*     */   } public static int getAirTicks() {
/*  21 */     return airTicks;
/*     */   }
/*     */   
/*     */   public static void updateAirTicks() {
/*  25 */     if (!mc.player.isOnGround()) {
/*  26 */       airTicks++;
/*     */     } else {
/*  28 */       airTicks = 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void setMoveMotion(EventMotionMove move, double motion) {
/*  33 */     double forward = mc.player.movementInput.moveForward;
/*  34 */     double strafe = mc.player.movementInput.moveStrafe;
/*  35 */     FreeLook freelook = (FreeLook)rock.getModules().get(FreeLook.class);
/*  36 */     float yaw = freelook.get() ? (freelook.getRotation()).x : mc.player.rotationYaw;
/*  37 */     if (forward == 0.0D && strafe == 0.0D) {
/*  38 */       (move.getMotion()).x = 0.0D;
/*  39 */       (move.getMotion()).z = 0.0D;
/*     */     } else {
/*  41 */       if (forward != 0.0D) {
/*  42 */         if (strafe > 0.0D) {
/*  43 */           yaw += ((forward > 0.0D) ? -45 : 45);
/*  44 */         } else if (strafe < 0.0D) {
/*  45 */           yaw += ((forward > 0.0D) ? 45 : -45);
/*     */         } 
/*  47 */         strafe = 0.0D;
/*  48 */         if (forward > 0.0D) {
/*  49 */           forward = 1.0D;
/*  50 */         } else if (forward < 0.0D) {
/*  51 */           forward = -1.0D;
/*     */         } 
/*     */       } 
/*  54 */       (move.getMotion())
/*  55 */         .x = forward * motion * MathHelper.cos((float)Math.toRadians((yaw + 90.0F))) + strafe * motion * MathHelper.sin((float)Math.toRadians((yaw + 90.0F)));
/*  56 */       (move.getMotion())
/*  57 */         .z = forward * motion * MathHelper.sin((float)Math.toRadians((yaw + 90.0F))) - strafe * motion * MathHelper.cos((float)Math.toRadians((yaw + 90.0F)));
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean isMoving() {
/*  62 */     return (mc.player.movementInput.moveForward != 0.0F || mc.player.movementInput.moveStrafe != 0.0F);
/*     */   }
/*     */   
/*     */   public static double getSpeed() {
/*  66 */     return Math.hypot((mc.player.getMotion()).x, (mc.player.getMotion()).z);
/*     */   }
/*     */   
/*     */   public static double getSpeed(Entity entity) {
/*  70 */     return Math.hypot((entity.getMotion()).x, (entity.getMotion()).z);
/*     */   }
/*     */   
/*     */   public static void setSpeed(double moveSpeed) {
/*  74 */     FreeLook freelook = (FreeLook)rock.getModules().get(FreeLook.class);
/*  75 */     setSpeed(moveSpeed, freelook.get() ? (freelook.getRotation()).x : mc.player.rotationYaw, mc.player.movementInput.moveStrafe, mc.player.movementInput.moveForward);
/*     */   }
/*     */   
/*     */   public static void setSpeed(double moveSpeed, float yaw, double strafe, double forward) {
/*  79 */     if (forward != 0.0D) {
/*  80 */       yaw += (strafe > 0.0D) ? ((forward > 0.0D) ? -45 : 45) : ((strafe < 0.0D) ? ((forward > 0.0D) ? 45 : -45) : false);
/*  81 */       strafe = 0.0D;
/*  82 */       forward = (forward > 0.0D) ? 1.01D : ((forward < 0.0D) ? -1.01D : 0.0D);
/*     */     } 
/*  84 */     strafe = (strafe > 0.0D) ? 1.0D : ((strafe < 0.0D) ? -1.0D : 0.0D);
/*  85 */     double mx = Math.cos(Math.toRadians((yaw + 90.0F))), mz = Math.sin(Math.toRadians((yaw + 90.0F)));
/*  86 */     (mc.player.getMotion()).x = forward * moveSpeed * mx + strafe * moveSpeed * mz;
/*  87 */     (mc.player.getMotion()).z = forward * moveSpeed * mz - strafe * moveSpeed * mx;
/*     */   }
/*     */   
/*     */   public static double[] getSpeed(double speed) {
/*  91 */     float moveForward = mc.player.movementInput.moveForward;
/*  92 */     float moveStrafe = mc.player.movementInput.moveStrafe;
/*  93 */     float rotationYaw = mc.player.prevRotationYaw + (mc.player.rotationYaw - mc.player.prevRotationYaw) * mc.getRenderPartialTicks();
/*  94 */     if (moveForward != 0.0F) {
/*  95 */       rotationYaw += (moveStrafe > 0.0F) ? ((moveForward > 0.0F) ? -45 : 45) : ((moveStrafe < 0.0F) ? ((moveForward > 0.0F) ? 45 : -45) : 0.0F);
/*  96 */       moveStrafe = 0.0F;
/*  97 */       moveForward = (moveForward > 0.0F) ? (moveForward = 1.0F) : -1.0F;
/*     */     } 
/*  99 */     double rotationRadians = Math.toRadians(rotationYaw);
/* 100 */     double sinRotation = Math.sin(rotationRadians);
/* 101 */     double cosRotation = Math.cos(rotationRadians);
/*     */     
/* 103 */     double posX = moveForward * speed * -sinRotation + moveStrafe * speed * cosRotation;
/* 104 */     double posZ = moveForward * speed * cosRotation - moveStrafe * speed * -sinRotation;
/* 105 */     return new double[] { posX, posZ };
/*     */   }
/*     */   
/*     */   public static double direction(float rotationYaw, double moveForward, double moveStrafing) {
/* 109 */     if (moveForward < 0.0D) rotationYaw += 180.0F;
/*     */     
/* 111 */     float forward = 1.0F;
/*     */     
/* 113 */     if (moveForward < 0.0D) { forward = -0.5F; }
/* 114 */     else if (moveForward > 0.0D) { forward = 0.5F; }
/*     */     
/* 116 */     if (moveStrafing > 0.0D) rotationYaw -= 90.0F * forward; 
/* 117 */     if (moveStrafing < 0.0D) rotationYaw += 90.0F * forward;
/*     */     
/* 119 */     return Math.toRadians(rotationYaw);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\player\Move.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */