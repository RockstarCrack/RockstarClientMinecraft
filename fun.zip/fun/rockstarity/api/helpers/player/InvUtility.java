/*     */ package fun.rockstarity.api.helpers.player;
/*     */ 
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.events.Event;
/*     */ import fun.rockstarity.api.events.list.game.packet.EventReceivePacket;
/*     */ import fun.rockstarity.api.helpers.game.Server;
/*     */ import fun.rockstarity.api.helpers.math.TimerUtility;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.network.IPacket;
/*     */ import net.minecraft.network.play.client.CHeldItemChangePacket;
/*     */ import net.minecraft.network.play.client.CPlayerTryUseItemPacket;
/*     */ import net.minecraft.network.play.server.SHeldItemChangePacket;
/*     */ import net.minecraft.util.Hand;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class InvUtility
/*     */   implements IAccess
/*     */ {
/*     */   private static Task current;
/*     */   
/*     */   private InvUtility() {
/*  39 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*     */   }
/*  41 */   private static final TimerUtility timer = new TimerUtility();
/*     */   
/*     */   public static void use(Item item) {
/*  44 */     use(item, Server.isHW());
/*     */   }
/*     */   
/*     */   public static void use(Item item, boolean smooth) {
/*  48 */     int slot = Inventory.findItemNoChanges(44, item);
/*     */     
/*  50 */     if (slot == -1 || mc.currentScreen != null)
/*     */       return; 
/*  52 */     if (mc.player.getHeldItemOffhand().getItem() == item) {
/*  53 */       mc.player.connection.sendPacket((IPacket)new CPlayerTryUseItemPacket(Hand.OFF_HAND));
/*     */       
/*     */       return;
/*     */     } 
/*  57 */     boolean inHotbar = (slot <= 8);
/*     */     
/*  59 */     if (smooth) {
/*  60 */       current = new Task(slot);
/*     */     }
/*  62 */     else if (inHotbar) {
/*  63 */       mc.player.connection.sendPacket((IPacket)new CHeldItemChangePacket(slot));
/*  64 */       mc.player.connection.sendPacket((IPacket)new CPlayerTryUseItemPacket(Hand.MAIN_HAND));
/*  65 */       mc.player.connection.sendPacket((IPacket)new CHeldItemChangePacket(mc.player.inventory.currentItem));
/*     */     } else {
/*  67 */       mc.playerController.pickItem(slot);
/*  68 */       mc.player.connection.sendPacket((IPacket)new CPlayerTryUseItemPacket(Hand.MAIN_HAND));
/*  69 */       mc.playerController.pickItem(slot);
/*  70 */       timer.reset();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void onEvent(Event event) {
/*  76 */     if (event instanceof EventReceivePacket) { EventReceivePacket e = (EventReceivePacket)event;
/*  77 */       IPacket iPacket = e.getPacket(); if (iPacket instanceof SHeldItemChangePacket) { SHeldItemChangePacket packet = (SHeldItemChangePacket)iPacket; if (!timer.passed(500L)) {
/*     */ 
/*     */           
/*  80 */           mc.player.connection.sendPacket((IPacket)new CHeldItemChangePacket(mc.player.inventory.currentItem % 8 + 1));
/*  81 */           mc.player.connection.sendPacket((IPacket)new CHeldItemChangePacket(mc.player.inventory.currentItem));
/*  82 */           e.cancel();
/*     */         }  }
/*     */        }
/*     */     
/*  86 */     if (event instanceof fun.rockstarity.api.events.list.player.EventUpdate && current != null) {
/*  87 */       current.stage++;
/*     */       
/*  89 */       if (current.slot < 9) {
/*  90 */         switch (current.stage) {
/*     */           case 1:
/*  92 */             mc.player.connection.sendPacket((IPacket)new CHeldItemChangePacket(current.slot));
/*     */             break;
/*     */           case 2:
/*  95 */             mc.player.connection.sendPacket((IPacket)new CPlayerTryUseItemPacket(Hand.MAIN_HAND));
/*     */             break;
/*     */           case 3:
/*  98 */             mc.player.connection.sendPacket((IPacket)new CHeldItemChangePacket(mc.player.inventory.currentItem));
/*     */             break;
/*     */         } 
/*     */       } else {
/* 102 */         switch (current.stage) {
/*     */           case 1:
/*     */           case 3:
/* 105 */             mc.playerController.pickItem(current.slot);
/*     */             break;
/*     */           case 2:
/* 108 */             mc.player.connection.sendPacket((IPacket)new CPlayerTryUseItemPacket(Hand.MAIN_HAND));
/*     */             break;
/*     */         } 
/*     */       
/*     */       } 
/* 113 */       if (current.stage > 3) current = null; 
/*     */     } 
/*     */   }
/*     */   static class Task { public Task(int slot) {
/* 117 */       this.slot = slot;
/*     */     }
/*     */     
/*     */     final int slot;
/*     */     int stage; }
/*     */ 
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\player\InvUtility.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */