/*    */ package fun.rockstarity.api.helpers.player;
/*    */ 
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import net.minecraft.entity.player.PlayerEntity;
/*    */ import net.minecraft.inventory.EquipmentSlotType;
/*    */ import net.minecraft.inventory.container.ClickType;
/*    */ import net.minecraft.item.ArmorItem;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.item.Items;
/*    */ import net.minecraft.network.IPacket;
/*    */ import net.minecraft.network.play.client.CClickWindowPacket;
/*    */ import net.minecraft.network.play.client.CHeldItemChangePacket;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Inventory
/*    */   implements IAccess
/*    */ {
/*    */   private static boolean sprint;
/*    */   
/*    */   private Inventory() {
/* 24 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*    */   }
/*    */ 
/*    */   
/*    */   public static void moveItem(int one, int two) {
/* 29 */     moveItem(one, two, false);
/*    */   }
/*    */   
/*    */   public static void moveItem(int one, int two, boolean swap) {
/* 33 */     mc.playerController.windowClick(0, one, 0, ClickType.PICKUP, (PlayerEntity)mc.player);
/* 34 */     mc.playerController.windowClick(0, two, 0, ClickType.PICKUP, (PlayerEntity)mc.player);
/* 35 */     if (swap)
/* 36 */       mc.playerController.windowClick(0, one, 0, ClickType.PICKUP, (PlayerEntity)mc.player); 
/*    */   }
/*    */   
/*    */   public static int findItem(int endSlot, Item item) {
/* 40 */     for (int i = 0; i < endSlot; i++) {
/* 41 */       if (mc.player.inventory.getStackInSlot(i).getItem() == item) {
/* 42 */         return (i < 9) ? (36 + i) : i;
/*    */       }
/*    */     } 
/* 45 */     return -1;
/*    */   }
/*    */   
/*    */   public static int findItemNoChanges(int endSlot, Item item) {
/* 49 */     for (int i = 0; i < endSlot; i++) {
/* 50 */       if (mc.player.inventory.getStackInSlot(i).getItem() == item) {
/* 51 */         return i;
/*    */       }
/*    */     } 
/* 54 */     return -1;
/*    */   }
/*    */   
/*    */   public static void clickSlotId(int slotId, int buttonId, ClickType clickType, boolean packet) {
/* 58 */     clickSlotId(mc.player.openContainer.windowId, slotId, buttonId, clickType, packet);
/*    */   }
/*    */   
/*    */   public static void clickSlotId(int windowId, int slotId, int buttonId, ClickType clickType, boolean packet) {
/* 62 */     if (packet) {
/* 63 */       mc.player.connection.sendPacket((IPacket)new CClickWindowPacket(windowId, slotId, buttonId, clickType, ItemStack.EMPTY, mc.player.openContainer.getNextTransactionID(mc.player.inventory)));
/*    */     } else {
/* 65 */       mc.playerController.windowClick(windowId, slotId, buttonId, clickType, (PlayerEntity)mc.player);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static void swap(int slot) {
/* 70 */     mc.player.connection.sendPacket((IPacket)new CHeldItemChangePacket(slot));
/*    */   }
/*    */   
/*    */   public static int getFirework() {
/* 74 */     for (int i = 0; i < 9; i++) {
/* 75 */       if (mc.player.inventory.getStackInSlot(i).getItem() == Items.FIREWORK_ROCKET) {
/* 76 */         return i;
/*    */       }
/*    */     } 
/* 79 */     return -1;
/*    */   }
/*    */   
/*    */   public static ItemStack getItem(int item) {
/* 83 */     return mc.player.inventory.getStackInSlot(item);
/*    */   }
/*    */   
/*    */   public static int getChestplate() {
/* 87 */     for (int i = 0; i < 45; i++) {
/* 88 */       ItemStack itemStack = mc.player.inventory.getStackInSlot(i);
/* 89 */       if (itemStack.getItem() instanceof ArmorItem && (
/* 90 */         (ArmorItem)itemStack.getItem()).getEquipmentSlot() == EquipmentSlotType.CHEST)
/* 91 */         return (i == 40) ? 45 : ((i < 9) ? (36 + i) : i); 
/*    */     } 
/* 93 */     return -1;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\player\Inventory.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */