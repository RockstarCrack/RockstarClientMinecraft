/*     */ package fun.rockstarity.api.helpers.player;
/*     */ 
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.events.list.player.EventMotionMove;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MoveEvent
/*     */ {
/*     */   public static void setMoveMotion(EventMotionMove move, double motion) {
/* 102 */     double forward = IAccess.mc.player.movementInput.moveForward;
/* 103 */     double strafe = IAccess.mc.player.movementInput.moveStrafe;
/* 104 */     float yaw = IAccess.mc.player.rotationYaw;
/* 105 */     if (forward == 0.0D && strafe == 0.0D) {
/* 106 */       (move.getMotion()).x = 0.0D;
/* 107 */       (move.getMotion()).z = 0.0D;
/*     */     } else {
/* 109 */       if (forward != 0.0D) {
/* 110 */         if (strafe > 0.0D) {
/* 111 */           yaw += ((forward > 0.0D) ? -45 : 45);
/* 112 */         } else if (strafe < 0.0D) {
/* 113 */           yaw += ((forward > 0.0D) ? 45 : -45);
/*     */         } 
/* 115 */         strafe = 0.0D;
/* 116 */         if (forward > 0.0D) {
/* 117 */           forward = 1.0D;
/* 118 */         } else if (forward < 0.0D) {
/* 119 */           forward = -1.0D;
/*     */         } 
/*     */       } 
/* 122 */       (move.getMotion())
/* 123 */         .x = forward * motion * MathHelper.cos((float)Math.toRadians((yaw + 90.0F))) + strafe * motion * MathHelper.sin((float)Math.toRadians((yaw + 90.0F)));
/* 124 */       (move.getMotion())
/* 125 */         .z = forward * motion * MathHelper.sin((float)Math.toRadians((yaw + 90.0F))) - strafe * motion * MathHelper.cos((float)Math.toRadians((yaw + 90.0F)));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\player\MoveUtils$MoveEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */