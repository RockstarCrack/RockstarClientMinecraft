/*     */ package fun.rockstarity.api.helpers.player;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.events.list.game.inputs.EventInput;
/*     */ import fun.rockstarity.api.events.list.player.EventMotionMove;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ 
/*     */ public final class MoveUtils implements IAccess {
/*     */   private MoveUtils() {
/*  11 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*     */   } public static boolean isMoving() {
/*  13 */     return (mc.player.movementInput.moveForward != 0.0F || mc.player.movementInput.moveStrafe != 0.0F);
/*     */   }
/*     */   
/*     */   public static void fixMovement(EventInput event, float yaw) {
/*  17 */     float forward = event.getForward();
/*  18 */     float strafe = event.getStrafe();
/*     */     
/*  20 */     double angle = MathHelper.wrapDegrees(Math.toDegrees(direction(mc.player.isElytraFlying() ? yaw : mc.player.rotationYaw, forward, strafe)));
/*     */     
/*  22 */     if (forward == 0.0F && strafe == 0.0F) {
/*     */       return;
/*     */     }
/*     */     
/*  26 */     float closestForward = 0.0F, closestStrafe = 0.0F, closestDifference = Float.MAX_VALUE;
/*     */     float predictedForward;
/*  28 */     for (predictedForward = -1.0F; predictedForward <= 1.0F; predictedForward++) {
/*  29 */       float predictedStrafe; for (predictedStrafe = -1.0F; predictedStrafe <= 1.0F; predictedStrafe++) {
/*  30 */         if (predictedStrafe != 0.0F || predictedForward != 0.0F) {
/*     */           
/*  32 */           double predictedAngle = MathHelper.wrapDegrees(Math.toDegrees(direction(yaw, predictedForward, predictedStrafe)));
/*  33 */           double difference = Math.abs(angle - predictedAngle);
/*     */           
/*  35 */           if (difference < closestDifference) {
/*  36 */             closestDifference = (float)difference;
/*  37 */             closestForward = predictedForward;
/*  38 */             closestStrafe = predictedStrafe;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*  43 */     event.setForward(closestForward);
/*  44 */     event.setStrafe(closestStrafe);
/*     */   }
/*     */   
/*     */   public static double direction(float rotationYaw, double moveForward, double moveStrafing) {
/*  48 */     if (moveForward < 0.0D) rotationYaw += 180.0F;
/*     */     
/*  50 */     float forward = 1.0F;
/*     */     
/*  52 */     if (moveForward < 0.0D) { forward = -0.5F; }
/*  53 */     else if (moveForward > 0.0D) { forward = 0.5F; }
/*     */     
/*  55 */     if (moveStrafing > 0.0D) rotationYaw -= 90.0F * forward; 
/*  56 */     if (moveStrafing < 0.0D) rotationYaw += 90.0F * forward;
/*     */     
/*  58 */     return Math.toRadians(rotationYaw);
/*     */   }
/*     */   
/*     */   public static double getMotion() {
/*  62 */     return Math.hypot((mc.player.getMotion()).x, (mc.player.getMotion()).z);
/*     */   }
/*     */   
/*     */   public static void setMotion(double speed) {
/*  66 */     if (!isMoving()) {
/*     */       return;
/*     */     }
/*  69 */     double yaw = getDirection(true);
/*  70 */     mc.player.setMotion(-Math.sin(yaw) * speed, (mc.player.getMotion()).y, Math.cos(yaw) * speed);
/*     */   }
/*     */   
/*     */   public static boolean isBlockUnder(float under) {
/*  74 */     if (mc.player.getPosY() < 0.0D) {
/*  75 */       return false;
/*     */     }
/*  77 */     AxisAlignedBB aab = mc.player.getBoundingBox().offset(0.0D, -under, 0.0D);
/*  78 */     return mc.world.getCollisionShapes((Entity)mc.player, aab).toList().isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public static double getDirection(boolean toRadians) {
/*  83 */     float rotationYaw = mc.player.rotationYaw;
/*  84 */     if (mc.player.moveForward < 0.0F)
/*  85 */       rotationYaw += 180.0F; 
/*  86 */     float forward = 1.0F;
/*  87 */     if (mc.player.moveForward < 0.0F) {
/*  88 */       forward = -0.5F;
/*  89 */     } else if (mc.player.moveForward > 0.0F) {
/*  90 */       forward = 0.5F;
/*     */     } 
/*  92 */     if (mc.player.moveStrafing > 0.0F)
/*  93 */       rotationYaw -= 90.0F * forward; 
/*  94 */     if (mc.player.moveStrafing < 0.0F) {
/*  95 */       rotationYaw += 90.0F * forward;
/*     */     }
/*  97 */     return toRadians ? Math.toRadians(rotationYaw) : rotationYaw;
/*     */   }
/*     */   
/*     */   public static class MoveEvent {
/*     */     public static void setMoveMotion(EventMotionMove move, double motion) {
/* 102 */       double forward = IAccess.mc.player.movementInput.moveForward;
/* 103 */       double strafe = IAccess.mc.player.movementInput.moveStrafe;
/* 104 */       float yaw = IAccess.mc.player.rotationYaw;
/* 105 */       if (forward == 0.0D && strafe == 0.0D) {
/* 106 */         (move.getMotion()).x = 0.0D;
/* 107 */         (move.getMotion()).z = 0.0D;
/*     */       } else {
/* 109 */         if (forward != 0.0D) {
/* 110 */           if (strafe > 0.0D) {
/* 111 */             yaw += ((forward > 0.0D) ? -45 : 45);
/* 112 */           } else if (strafe < 0.0D) {
/* 113 */             yaw += ((forward > 0.0D) ? 45 : -45);
/*     */           } 
/* 115 */           strafe = 0.0D;
/* 116 */           if (forward > 0.0D) {
/* 117 */             forward = 1.0D;
/* 118 */           } else if (forward < 0.0D) {
/* 119 */             forward = -1.0D;
/*     */           } 
/*     */         } 
/* 122 */         (move.getMotion())
/* 123 */           .x = forward * motion * MathHelper.cos((float)Math.toRadians((yaw + 90.0F))) + strafe * motion * MathHelper.sin((float)Math.toRadians((yaw + 90.0F)));
/* 124 */         (move.getMotion())
/* 125 */           .z = forward * motion * MathHelper.sin((float)Math.toRadians((yaw + 90.0F))) - strafe * motion * MathHelper.cos((float)Math.toRadians((yaw + 90.0F)));
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\player\MoveUtils.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */