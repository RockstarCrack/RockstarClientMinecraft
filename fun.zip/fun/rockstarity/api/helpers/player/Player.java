/*     */ package fun.rockstarity.api.helpers.player;
/*     */ 
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.events.Event;
/*     */ import fun.rockstarity.api.events.list.game.inputs.EventInput;
/*     */ import fun.rockstarity.api.events.list.player.EventJump;
/*     */ import fun.rockstarity.api.events.list.player.EventMotion;
/*     */ import fun.rockstarity.api.events.list.player.EventMove;
/*     */ import fun.rockstarity.api.events.list.player.EventTrace;
/*     */ import fun.rockstarity.api.helpers.math.aura.Rotation;
/*     */ import fun.rockstarity.client.modules.combat.Aura;
/*     */ import java.util.OptionalInt;
/*     */ import java.util.stream.IntStream;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.Blocks;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.LivingEntity;
/*     */ import net.minecraft.entity.player.PlayerEntity;
/*     */ import net.minecraft.inventory.EquipmentSlotType;
/*     */ import net.minecraft.inventory.container.ClickType;
/*     */ import net.minecraft.item.BlockItem;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.Items;
/*     */ import net.minecraft.item.UseAction;
/*     */ import net.minecraft.network.IPacket;
/*     */ import net.minecraft.network.play.client.CClickWindowPacket;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.BlockRayTraceResult;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.util.math.vector.Vector3d;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TranslationTextComponent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Player
/*     */   implements IAccess
/*     */ {
/*     */   private Player() {
/*  44 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*     */   }
/*     */   public static void overlay(Object msg) {
/*  47 */     mc.ingameGUI.setOverlayMessage((ITextComponent)new TranslationTextComponent(msg.toString()), false);
/*     */   }
/*     */   
/*     */   public static void overlay(ITextComponent comp) {
/*  51 */     mc.ingameGUI.setOverlayMessage(comp, false);
/*     */   }
/*     */   
/*     */   public static boolean isBlockUnderWithMotion() {
/*  55 */     AxisAlignedBB aab = mc.player.getBoundingBox().offset((mc.player.getMotion()).x, -0.1D, (mc.player.getMotion()).z);
/*  56 */     return mc.world.getCollisionShapes((Entity)mc.player, aab).toList().isEmpty();
/*     */   }
/*     */   
/*     */   public static boolean isFalling() {
/*  60 */     return (mc.player.fallDistance > 1.3F || (mc.player.fallDistance > 0.0F && getBlock(0.0D, -1.0D, 0.0D) == Blocks.AIR));
/*     */   }
/*     */   
/*     */   public static boolean collisionPredict(Vector3d to) {
/*     */     try {
/*  65 */       boolean prevCollision = mc.world.getCollisionShapes((Entity)mc.player, mc.player.getBoundingBox().shrink(0.0625D)).toList().isEmpty();
/*  66 */       Vector3d backUp = new Vector3d(mc.player.getPosX(), mc.player.getPosY(), mc.player.getPosZ());
/*  67 */       mc.player.setPosition(to.x, to.y, to.z);
/*  68 */       boolean collision = (mc.world.getCollisionShapes((Entity)mc.player, mc.player.getBoundingBox().shrink(0.0625D)).toList().isEmpty() && prevCollision);
/*  69 */       mc.player.setPosition(backUp.x, backUp.y, backUp.z);
/*  70 */       return collision;
/*  71 */     } catch (Exception e) {
/*  72 */       e.printStackTrace();
/*  73 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean collideWith(LivingEntity entity) {
/*  78 */     return collideWith(entity, 0.0F);
/*     */   }
/*     */   
/*     */   public static boolean collideWith(LivingEntity entity, float grow) {
/*  82 */     AxisAlignedBB box = mc.player.getBoundingBox();
/*  83 */     AxisAlignedBB targetbox = entity.getBoundingBox().grow(grow, 0.0D, grow);
/*     */     
/*  85 */     if (box.maxX > targetbox.minX && box.maxY > targetbox.minY && box.maxZ > targetbox.minZ && box.minX < targetbox.maxX && box.minY < targetbox.maxY && box.minZ < targetbox.maxZ)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/*  90 */       return true;
/*     */     }
/*  92 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean isLookEvent(Event event) {
/*  96 */     return (event instanceof EventTrace || event instanceof EventMotion || event instanceof EventMove || event instanceof EventInput || event instanceof EventJump);
/*     */   }
/*     */   
/*     */   public static void look(Event event, float yaw, float pitch, boolean visual) {
/* 100 */     look(event, yaw, pitch, visual, 2, yaw);
/*     */   }
/*     */   
/*     */   public static void look(Event event, float yaw, float pitch, boolean visual, int correction, float visualYaw) {
/* 104 */     if (event instanceof EventTrace) { EventTrace eventTrace = (EventTrace)event;
/* 105 */       eventTrace.setYaw(yaw);
/* 106 */       eventTrace.setPitch(pitch);
/* 107 */       eventTrace.cancel(); }
/*     */ 
/*     */     
/* 110 */     if (event instanceof EventMotion) { EventMotion eventMotion = (EventMotion)event;
/* 111 */       Aura aura = (Aura)rock.getModules().get(Aura.class);
/*     */ 
/*     */       
/* 114 */       eventMotion.setYaw(yaw);
/* 115 */       eventMotion.setPitch(pitch);
/* 116 */       if (visual) {
/* 117 */         mc.player.renderYawOffset = visualYaw;
/* 118 */         mc.player.rotationYawHead = visualYaw;
/* 119 */         mc.player.rotationPitchHead = pitch;
/*     */       }  }
/*     */ 
/*     */ 
/*     */     
/* 124 */     if (event instanceof EventMove) { EventMove eventMoveFix = (EventMove)event; if (correction > 0) {
/* 125 */         eventMoveFix.setYaw(yaw);
/* 126 */         eventMoveFix.setPitch(pitch);
/*     */       }  }
/*     */     
/* 129 */     if (event instanceof EventInput) { EventInput e = (EventInput)event; if (correction == 1) {
/* 130 */         e.setYaw(yaw);
/*     */       } }
/*     */     
/* 133 */     if (event instanceof EventInput) { EventInput e = (EventInput)event; if (correction == 3 && ((Aura)rock.getModules().get(Aura.class)).getTarget() != null) {
/* 134 */         e.setYaw(yaw, (Rotation.get(((Aura)rock.getModules().get(Aura.class)).getTarget().getPositionVec())).x);
/*     */       } }
/*     */     
/* 137 */     if (event instanceof EventJump) { EventJump eventJump = (EventJump)event;
/* 138 */       eventJump.setYaw(yaw); }
/*     */   
/*     */   }
/*     */   
/*     */   private static boolean isBlock(ItemStack stack) {
/* 143 */     return (stack != null && stack.getItem() instanceof BlockItem);
/*     */   }
/*     */   
/*     */   public static int findBestBlockSlotInHotBar() {
/* 147 */     for (int i = 0; i < 9; i++) {
/* 148 */       if (isBlock(mc.player.inventory.getStackInSlot(i))) {
/* 149 */         return i;
/*     */       }
/*     */     } 
/* 152 */     return -1;
/*     */   }
/*     */   
/*     */   public static int findBestToolSlotInHotBar() {
/* 156 */     RayTraceResult rayTraceResult = mc.objectMouseOver; if (rayTraceResult instanceof BlockRayTraceResult) { BlockRayTraceResult blockRayTraceResult = (BlockRayTraceResult)rayTraceResult;
/* 157 */       Block block = mc.world.getBlockState(blockRayTraceResult.getPos()).getBlock();
/*     */       
/* 159 */       int bestSlot = -1;
/* 160 */       float bestSpeed = 1.0F;
/*     */       
/* 162 */       for (int slot = 0; slot < 9; slot++) {
/* 163 */         float speed = mc.player.inventory.getStackInSlot(slot).getDestroySpeed(block.getDefaultState());
/*     */         
/* 165 */         if (speed > bestSpeed) {
/* 166 */           bestSpeed = speed;
/* 167 */           bestSlot = slot;
/*     */         } 
/*     */       } 
/* 170 */       return bestSlot; }
/*     */     
/* 172 */     return -1;
/*     */   }
/*     */   
/*     */   public static boolean isBlockSolid(BlockPos pos) {
/* 176 */     return block(pos).getDefaultState().getMaterial().isSolid();
/*     */   }
/*     */   
/*     */   public static boolean isBlockSolid(double x, double y, double z) {
/* 180 */     return block(new BlockPos(x, y, z)).getDefaultState().getMaterial().isSolid();
/*     */   }
/*     */   
/*     */   public static Block block(BlockPos pos) {
/* 184 */     return mc.world.getBlockState(pos).getBlock();
/*     */   }
/*     */   
/*     */   public static Block block(double x, double y, double z) {
/* 188 */     return mc.world.getBlockState(new BlockPos(x, y, z)).getBlock();
/*     */   }
/*     */ 
/*     */   
/*     */   public static void moveItemOld(int one, int two, boolean swap) {
/* 193 */     mc.playerController.windowClick(0, one, 0, ClickType.PICKUP, (PlayerEntity)mc.player);
/* 194 */     mc.playerController.windowClick(0, two, 0, ClickType.PICKUP, (PlayerEntity)mc.player);
/* 195 */     if (swap) {
/* 196 */       mc.playerController.windowClick(0, one, 0, ClickType.PICKUP, (PlayerEntity)mc.player);
/*     */     }
/*     */   }
/*     */   
/*     */   public static int findItemInInv(int endSlot, Item ofType) {
/* 201 */     return IntStream.range(0, endSlot).filter(i -> (mc.player.inventory.getStackInSlot(i).getItem() == ofType)).map(i -> (i == 40) ? 45 : ((i < 9) ? (36 + i) : i)).findFirst().orElse(-1);
/*     */   }
/*     */   
/*     */   public static void moveItem(int one, int two, boolean swap) {
/* 205 */     mc.playerController.windowClick(0, one, 0, ClickType.PICKUP, (PlayerEntity)mc.player);
/* 206 */     mc.playerController.windowClick(0, two, 0, ClickType.PICKUP, (PlayerEntity)mc.player);
/* 207 */     if (swap) {
/* 208 */       mc.playerController.windowClick(0, one, 0, ClickType.PICKUP, (PlayerEntity)mc.player);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void packetMove(int one, int two, boolean swap) {
/* 213 */     packetClick(0, one, 0, ClickType.PICKUP, (PlayerEntity)mc.player);
/* 214 */     packetClick(0, two, 0, ClickType.PICKUP, (PlayerEntity)mc.player);
/* 215 */     if (swap) {
/* 216 */       packetClick(0, one, 0, ClickType.PICKUP, (PlayerEntity)mc.player);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void packetClick(int windowId, int slotId, int mouseButton, ClickType type, PlayerEntity player) {
/* 222 */     short short1 = player.openContainer.getNextTransactionID(player.inventory);
/* 223 */     mc.player.connection.sendPacket((IPacket)new CClickWindowPacket(windowId, slotId, mouseButton, type, find(slotId), short1));
/*     */   }
/*     */   
/*     */   public static boolean isInGame() {
/* 227 */     return (mc.world != null && mc.player != null);
/*     */   }
/*     */   
/*     */   public static Block getBlock() {
/* 231 */     return getBlock(0.0D, 0.0D, 0.0D);
/*     */   }
/*     */   
/*     */   public static Block getBlock(double x, double y, double z) {
/* 235 */     return !isInGame() ? Blocks.AIR : mc.world.getBlockState(mc.player.getPosition().add(x, y, z)).getBlock();
/*     */   }
/*     */   
/*     */   public static float getAngle(Entity entity) {
/* 239 */     double diffX = entity.getPosX() - mc.player.getPosX();
/* 240 */     double diffZ = entity.getPosZ() - mc.player.getPosZ();
/* 241 */     return (float)Math.abs(MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0D - mc.player.rotationYaw));
/*     */   }
/*     */   
/*     */   public static float getAngle(Entity entity, float rotation) {
/* 245 */     double diffX = entity.getPosX() - mc.player.getPosX();
/* 246 */     double diffZ = entity.getPosZ() - mc.player.getPosZ();
/* 247 */     return (float)Math.abs(MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0D - rotation));
/*     */   }
/*     */   
/*     */   public static float getFOV(Entity entity) {
/* 251 */     double diffX = entity.getPosX() - mc.player.getPosX();
/* 252 */     double diffY = entity.getPosY() + entity.getEyeHeight() - mc.player.getPosY() + mc.player.getEyeHeight();
/* 253 */     double diffZ = entity.getPosZ() - mc.player.getPosZ();
/* 254 */     double dist = MathHelper.sqrt(diffX * diffX + diffZ * diffZ);
/*     */ 
/*     */     
/* 257 */     float yaw = (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0D - mc.player.rotationYaw);
/*     */     
/* 259 */     float pitch = (float)MathHelper.wrapDegrees(-Math.toDegrees(Math.atan2(diffY, dist)) - mc.player.rotationPitch);
/*     */     
/* 261 */     return (float)Math.sqrt((Math.abs(yaw) * Math.abs(yaw) + Math.abs(pitch) * Math.abs(pitch)));
/*     */   }
/*     */   
/*     */   public static boolean isInWeb() {
/* 265 */     return (mc.player.getMotionMultiplier().lengthSquared() > 1.0E-7D);
/*     */   }
/*     */   
/*     */   public static boolean targetIsInWeb() {
/* 269 */     Aura aura = (Aura)rock.getModules().get(Aura.class);
/* 270 */     return (aura.getTarget().getMotionMultiplier().lengthSquared() > 1.0E-7D);
/*     */   }
/*     */   
/*     */   public static int findItem(Item input) {
/* 274 */     return IntStream.range(0, 9).filter(i -> (mc.player.inventory.getStackInSlot(i).getItem() == input)).findFirst()
/* 275 */       .orElse(-1);
/*     */   }
/*     */   
/*     */   public static int findItemDefault(int endSlot, Item ofType) {
/* 279 */     int slot = -1;
/*     */     
/* 281 */     for (int i = 0; i < endSlot; i++) {
/* 282 */       if (mc.player.inventory.getStackInSlot(i).getItem() == ofType) {
/* 283 */         slot = i;
/*     */       }
/*     */     } 
/* 286 */     return slot;
/*     */   }
/*     */   
/*     */   public static int findItem(int endSlot, Item ofType) {
/* 290 */     int slot = -1;
/*     */     
/* 292 */     for (int i = 0; i < endSlot; i++) {
/* 293 */       if (mc.player.inventory.getStackInSlot(i).getItem() == ofType) {
/* 294 */         slot = (i == 40) ? 45 : ((i < 9) ? (36 + i) : i);
/*     */       }
/*     */     } 
/* 297 */     return slot;
/*     */   }
/*     */   
/*     */   public static int findItem(int maxSlots, Item item, int startSlot) {
/* 301 */     for (int i = startSlot; i < maxSlots; i++) {
/* 302 */       ItemStack stack = mc.player.inventory.getStackInSlot(i);
/* 303 */       if (stack.getItem() == item) {
/* 304 */         return (i == 40) ? 45 : ((i < 9) ? (36 + i) : i);
/*     */       }
/*     */     } 
/* 307 */     return -1;
/*     */   }
/*     */   
/*     */   public static int shulkerCount() {
/* 311 */     int count = 0;
/* 312 */     for (int i = 0; i < 45; i++) {
/* 313 */       ItemStack stack = mc.player.inventory.getStackInSlot(i);
/* 314 */       Item item = stack.getItem(); if (item instanceof BlockItem) { BlockItem blockItem = (BlockItem)item; if (blockItem.getBlock() instanceof net.minecraft.block.ShulkerBoxBlock)
/* 315 */           count += stack.getCount();  }
/*     */     
/*     */     } 
/* 318 */     return count;
/*     */   }
/*     */   
/*     */   public static int count(Item item) {
/* 322 */     int count = 0;
/* 323 */     for (int i = 0; i < 45; i++) {
/* 324 */       ItemStack stack = mc.player.inventory.getStackInSlot(i);
/* 325 */       if (stack.getItem() == item) {
/* 326 */         count += stack.getCount();
/*     */       }
/*     */     } 
/* 329 */     return count;
/*     */   }
/*     */   
/*     */   public static int stackSize(Item item) {
/* 333 */     int count = 0;
/* 334 */     for (int i = 0; i < 45; i++) {
/* 335 */       ItemStack stack = mc.player.inventory.getStackInSlot(i);
/* 336 */       if (stack.getItem() == item) {
/* 337 */         count++;
/*     */       }
/*     */     } 
/* 340 */     return count;
/*     */   }
/*     */   
/*     */   public static ItemStack find(int slot) {
/* 344 */     return mc.player.inventory.getStackInSlot(slot);
/*     */   }
/*     */   
/*     */   public static void dropAllItems() {
/* 348 */     IntStream.range(0, mc.player.container.getInventory().size()).forEach(i -> {
/*     */           mc.playerController.windowClick(0, i, 0, ClickType.PICKUP, (PlayerEntity)mc.player);
/*     */           mc.playerController.windowClick(0, -999, 0, ClickType.PICKUP, (PlayerEntity)mc.player);
/*     */         });
/*     */   }
/*     */   
/*     */   public static int findEatInHotbar() {
/* 355 */     return IntStream.range(0, 9)
/* 356 */       .filter(slot -> (mc.player.inventory.getStackInSlot(slot).getUseAction() == UseAction.EAT)).findFirst()
/* 357 */       .orElse(-1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int findEatInInventory() {
/* 365 */     OptionalInt slot = IntStream.range(9, 36).filter(i -> { ItemStack stack = mc.player.inventory.getStackInSlot(i); return (stack.getItem().getFood() != null); }).findFirst();
/* 366 */     return slot.orElse(-1);
/*     */   }
/*     */   
/*     */   public static int findBlock() {
/* 370 */     return IntStream.range(0, 9)
/* 371 */       .filter(i -> {
/*     */           ItemStack stack = mc.player.inventory.getStackInSlot(i);
/*     */           return stack.getItem() instanceof BlockItem;
/* 374 */         }).findFirst()
/* 375 */       .orElse(-1);
/*     */   }
/*     */   
/*     */   public static int findBlockSolid() {
/* 379 */     return IntStream.range(0, 9)
/* 380 */       .filter(i -> {
/*     */           ItemStack stack = mc.player.inventory.getStackInSlot(i);
/*     */           
/*     */           if (!(stack.getItem() instanceof BlockItem)) {
/*     */             return false;
/*     */           }
/*     */           
/*     */           Block block = ((BlockItem)stack.getItem()).getBlock();
/*     */           return block.getDefaultState().isSolid();
/* 389 */         }).findFirst()
/* 390 */       .orElse(-1);
/*     */   }
/*     */   
/*     */   public static boolean isElytraEquiped() {
/* 394 */     return (mc.player.getItemStackFromSlot(EquipmentSlotType.CHEST).getItem() == Items.ELYTRA);
/*     */   }
/*     */   
/*     */   public static Item getChest() {
/* 398 */     return mc.player.getItemStackFromSlot(EquipmentSlotType.CHEST).getItem();
/*     */   }
/*     */   
/*     */   public static int getDurability(ItemStack stack) {
/* 402 */     return (int)((stack.getMaxDamage() - stack.getDamage()) / Math.max(0.1D, stack.getMaxDamage()) * 100.0D);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\player\Player.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */