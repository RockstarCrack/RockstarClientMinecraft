/*    */ package fun.rockstarity.api.helpers.player;
/*    */ 
/*    */ import net.minecraft.client.entity.player.ClientPlayerEntity;
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ import net.minecraft.util.math.vector.Vector3d;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FallingPlayer
/*    */ {
/*    */   private final ClientPlayerEntity player;
/*    */   private double x;
/*    */   private double y;
/*    */   private double z;
/*    */   
/*    */   public FallingPlayer(ClientPlayerEntity player, double x, double y, double z, double motionX, double motionY, double motionZ, float yaw) {
/* 18 */     this.player = player;
/* 19 */     this.x = x;
/* 20 */     this.y = y;
/* 21 */     this.z = z;
/* 22 */     this.motionX = motionX;
/* 23 */     this.motionY = motionY;
/* 24 */     this.motionZ = motionZ;
/* 25 */     this.yaw = yaw;
/* 26 */     this.simulatedTicks = 0;
/*    */   }
/*    */   private double motionX; private double motionY; private double motionZ; private final float yaw; private int simulatedTicks;
/*    */   public static FallingPlayer fromPlayer(ClientPlayerEntity player) {
/* 30 */     return new FallingPlayer(player, player
/*    */         
/* 32 */         .getPositionVec().getX(), player
/* 33 */         .getPositionVec().getY(), player
/* 34 */         .getPositionVec().getZ(), 
/* 35 */         (player.getMotion()).x, 
/* 36 */         (player.getMotion()).y, 
/* 37 */         (player.getMotion()).z, player.rotationYaw);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean findFall(float fallDist) {
/* 43 */     Vector3d rotationVec = this.player.getLookVec();
/* 44 */     double tempMotionX = this.motionX;
/* 45 */     double tempMotionY = this.motionY;
/* 46 */     double tempMotionZ = this.motionZ;
/*    */     
/* 48 */     double d = 0.08D;
/* 49 */     float n = MathHelper.cos(this.player.rotationPitch * 0.017453292F);
/* 50 */     n = (float)((n * n) * Math.min(rotationVec.length() / 0.4D, 1.0D));
/*    */     
/* 52 */     Vector3d vec3d = (new Vector3d(tempMotionX, tempMotionY, tempMotionZ)).add(0.0D, d * (-1.0D + n * 0.75D), 0.0D);
/* 53 */     tempMotionY = vec3d.y * 0.9800000190734863D;
/*    */     
/* 55 */     return (tempMotionY < fallDist);
/*    */   }
/*    */   
/*    */   public boolean findFall(float fallDist, int ticks) {
/* 59 */     Vector3d rotationVec = this.player.getLookVec();
/* 60 */     double tempMotionX = this.motionX;
/* 61 */     double tempMotionY = this.motionY;
/* 62 */     double tempMotionZ = this.motionZ;
/*    */     
/* 64 */     double d = 0.08D;
/* 65 */     float n = MathHelper.cos(this.player.rotationPitch * 0.017453292F);
/* 66 */     n = (float)((n * n) * Math.min(rotationVec.length() / 0.4D, 1.0D));
/*    */     
/* 68 */     for (int i = 0; i < ticks; i++) {
/* 69 */       Vector3d vec3d = (new Vector3d(tempMotionX, tempMotionY, tempMotionZ)).add(0.0D, d * (-1.0D + n * 0.75D), 0.0D);
/* 70 */       tempMotionY = vec3d.y * 0.9800000190734863D;
/*    */       
/* 72 */       if (tempMotionY >= fallDist) {
/* 73 */         return false;
/*    */       }
/*    */     } 
/*    */     
/* 77 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\player\FallingPlayer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */