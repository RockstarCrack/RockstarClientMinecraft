/*    */ package fun.rockstarity.api.helpers.player;
/*    */ 
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.events.list.game.packet.EventReceivePacket;
/*    */ import fun.rockstarity.api.events.list.player.EventDamageReceive;
/*    */ import fun.rockstarity.api.helpers.math.TimerUtility;
/*    */ import net.minecraft.network.IPacket;
/*    */ import net.minecraft.network.play.server.SEntityStatusPacket;
/*    */ import net.minecraft.potion.Effects;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class DamagePlayerUtil
/*    */   implements IAccess {
/* 14 */   private final TimerUtility timeTracker = new TimerUtility(); private boolean normalDamage; public boolean isNormalDamage() {
/* 15 */     return this.normalDamage;
/*    */   }
/*    */   private boolean fallDamage;
/*    */   private boolean explosionDamage;
/*    */   private boolean arrowDamage;
/*    */   private boolean pearlDamage;
/*    */   
/*    */   public void onPacketEvent(EventReceivePacket eventPacket) {
/* 23 */     boolean isDamage = (this.fallDamage || this.arrowDamage || this.explosionDamage || this.pearlDamage);
/*    */     
/* 25 */     if (isBadEffects()) {
/*    */       return;
/*    */     }
/* 28 */     if (eventPacket.getPacket() instanceof net.minecraft.network.play.server.SExplosionPacket) {
/* 29 */       this.explosionDamage = true;
/*    */     }
/* 31 */     if (!isDamage) {
/* 32 */       IPacket<?> packet = eventPacket.getPacket();
/* 33 */       if (packet instanceof SEntityStatusPacket) { SEntityStatusPacket statusPacket = (SEntityStatusPacket)packet;
/* 34 */         if (statusPacket.getOpCode() == 2 && statusPacket.getEntity((World)mc.world) == mc.player) {
/* 35 */           this.normalDamage = true;
/*    */         } }
/*    */     
/* 38 */     } else if (mc.player.hurtTime > 0) {
/* 39 */       this.normalDamage = false;
/* 40 */       reset();
/*    */     } 
/*    */   }
/*    */   
/*    */   public boolean time(long time) {
/* 45 */     if (this.normalDamage) {
/* 46 */       if (this.timeTracker.passed(time)) {
/* 47 */         this.normalDamage = false;
/* 48 */         this.timeTracker.reset();
/* 49 */         return true;
/*    */       } 
/*    */     } else {
/* 52 */       this.timeTracker.reset();
/*    */     } 
/* 54 */     return false;
/*    */   }
/*    */   
/*    */   public void processDamage(EventDamageReceive damageEvent) {
/* 58 */     switch (damageEvent.getDamageType()) { case FALL:
/* 59 */         this.fallDamage = true; break;
/* 60 */       case ARROW: this.arrowDamage = true; break;
/* 61 */       case ENDER_PEARL: this.pearlDamage = true; break; }
/*    */     
/* 63 */     this.normalDamage = false;
/*    */   }
/*    */   
/*    */   public void resetDamages() {
/* 67 */     this.normalDamage = false;
/* 68 */     reset();
/* 69 */     this.timeTracker.reset();
/*    */   }
/*    */   
/*    */   private void reset() {
/* 73 */     this.fallDamage = false;
/* 74 */     this.explosionDamage = false;
/* 75 */     this.arrowDamage = false;
/* 76 */     this.pearlDamage = false;
/*    */   }
/*    */   
/*    */   private boolean isBadEffects() {
/* 80 */     if (mc.player == null) {
/* 81 */       return false;
/*    */     }
/* 83 */     return (mc.player.isPotionActive(Effects.POISON) || mc.player.isPotionActive(Effects.WITHER) || mc.player
/* 84 */       .isPotionActive(Effects.INSTANT_DAMAGE));
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\player\DamagePlayerUtil.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */