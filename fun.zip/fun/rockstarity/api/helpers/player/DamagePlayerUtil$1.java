/*    */ package fun.rockstarity.api.helpers.player;
/*    */ 
/*    */ import fun.rockstarity.api.events.list.player.EventDamageReceive;
/*    */ 


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\player\DamagePlayerUtil$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */