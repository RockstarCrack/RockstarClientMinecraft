/*    */ package fun.rockstarity.api.helpers.math;
/*    */ 
/*    */ import com.mojang.datafixers.util.Pair;
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.helpers.game.Server;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ import net.minecraft.scoreboard.Score;
/*    */ import net.minecraft.util.text.ITextComponent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class EntityHealthHelper
/*    */   implements IAccess
/*    */ {
/*    */   private EntityHealthHelper() {
/* 22 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*    */   }
/*    */   public static float getHealth(LivingEntity entity) {
/* 25 */     if (Server.isServerForHPFix()) {
/* 26 */       return entity.getRealHealth();
/*    */     }
/*    */     
/* 29 */     return entity.getHealth();
/*    */   }
/*    */   
/*    */   public static float getMaxHealth(LivingEntity entity) {
/* 33 */     return Server.isServerForHPFix() ? 20.0F : entity.getMaxHealth();
/*    */   }
/*    */   
/*    */   public static float getGoldenHealth(LivingEntity entity) {
/* 37 */     return Server.isFT() ? 0.0F : entity.getAbsorptionAmount();
/*    */   }
/*    */   
/*    */   public static void handle(Pair<Score, ITextComponent> pair) {
/* 41 */     if (!Server.isRW())
/*    */       return; 
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\EntityHealthHelper.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */