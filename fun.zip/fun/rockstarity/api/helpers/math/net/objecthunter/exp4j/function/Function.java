/*     */ package fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.function;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Function
/*     */ {
/*     */   private final String name;
/*     */   protected final int numArguments;
/*     */   
/*     */   public Function(String name, int numArguments) {
/*  35 */     if (numArguments < 0) {
/*  36 */       throw new IllegalArgumentException("The number of function arguments can not be less than 0 for '" + name + "'");
/*     */     }
/*     */     
/*  39 */     if (!isValidFunctionName(name)) {
/*  40 */       throw new IllegalArgumentException("The function name '" + name + "' is invalid");
/*     */     }
/*  42 */     this.name = name;
/*  43 */     this.numArguments = numArguments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Function(String name) {
/*  53 */     this(name, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  62 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumArguments() {
/*  71 */     return this.numArguments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract double apply(double... paramVarArgs);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static char[] getAllowedFunctionCharacters() {
/*  90 */     char[] chars = new char[53];
/*  91 */     int count = 0; int i;
/*  92 */     for (i = 65; i < 91; i++) {
/*  93 */       chars[count++] = (char)i;
/*     */     }
/*  95 */     for (i = 97; i < 123; i++) {
/*  96 */       chars[count++] = (char)i;
/*     */     }
/*  98 */     chars[count] = '_';
/*  99 */     return chars;
/*     */   }
/*     */   
/*     */   public static boolean isValidFunctionName(String name) {
/* 103 */     if (name == null) {
/* 104 */       return false;
/*     */     }
/*     */     
/* 107 */     int size = name.length();
/*     */     
/* 109 */     if (size == 0) {
/* 110 */       return false;
/*     */     }
/*     */     
/* 113 */     for (int i = 0; i < size; i++) {
/* 114 */       char c = name.charAt(i);
/* 115 */       if (!Character.isLetter(c) && c != '_')
/*     */       {
/* 117 */         if (!Character.isDigit(c) || i <= 0)
/*     */         {
/*     */           
/* 120 */           return false; }  } 
/*     */     } 
/* 122 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\net\objecthunter\exp4j\function\Function.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */