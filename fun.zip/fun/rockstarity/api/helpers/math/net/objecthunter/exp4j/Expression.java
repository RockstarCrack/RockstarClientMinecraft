/*     */ package fun.rockstarity.api.helpers.math.net.objecthunter.exp4j;
/*     */ 
/*     */ import fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.function.Function;
/*     */ import fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.function.Functions;
/*     */ import fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.operator.Operator;
/*     */ import fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.tokenizer.FunctionToken;
/*     */ import fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.tokenizer.NumberToken;
/*     */ import fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.tokenizer.OperatorToken;
/*     */ import fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.tokenizer.Token;
/*     */ import fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.tokenizer.VariableToken;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Future;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Expression
/*     */ {
/*     */   private final Token[] tokens;
/*     */   private final Map<String, Double> variables;
/*     */   private final Set<String> userFunctionNames;
/*     */   
/*     */   private static Map<String, Double> createDefaultVariables() {
/*  47 */     Map<String, Double> vars = new HashMap<>(4);
/*  48 */     vars.put("pi", Double.valueOf(Math.PI));
/*  49 */     vars.put("π", Double.valueOf(Math.PI));
/*  50 */     vars.put("φ", Double.valueOf(1.61803398874D));
/*  51 */     vars.put("e", Double.valueOf(Math.E));
/*  52 */     return vars;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression(Expression existing) {
/*  61 */     this.tokens = Arrays.<Token>copyOf(existing.tokens, existing.tokens.length);
/*  62 */     this.variables = new HashMap<>();
/*  63 */     this.variables.putAll(existing.variables);
/*  64 */     this.userFunctionNames = new HashSet<>(existing.userFunctionNames);
/*     */   }
/*     */   
/*     */   Expression(Token[] tokens) {
/*  68 */     this.tokens = tokens;
/*  69 */     this.variables = createDefaultVariables();
/*  70 */     this.userFunctionNames = Collections.emptySet();
/*     */   }
/*     */   
/*     */   Expression(Token[] tokens, Set<String> userFunctionNames) {
/*  74 */     this.tokens = tokens;
/*  75 */     this.variables = createDefaultVariables();
/*  76 */     this.userFunctionNames = userFunctionNames;
/*     */   }
/*     */   
/*     */   public Expression setVariable(String name, double value) {
/*  80 */     checkVariableName(name);
/*  81 */     this.variables.put(name, Double.valueOf(value));
/*  82 */     return this;
/*     */   }
/*     */   
/*     */   private void checkVariableName(String name) {
/*  86 */     if (this.userFunctionNames.contains(name) || Functions.getBuiltinFunction(name) != null) {
/*  87 */       throw new IllegalArgumentException("The variable name '" + name + "' is invalid. Since there exists a function with the same name");
/*     */     }
/*     */   }
/*     */   
/*     */   public Expression setVariables(Map<String, Double> variables) {
/*  92 */     for (Map.Entry<String, Double> v : variables.entrySet()) {
/*  93 */       setVariable(v.getKey(), ((Double)v.getValue()).doubleValue());
/*     */     }
/*  95 */     return this;
/*     */   }
/*     */   
/*     */   public Expression clearVariables() {
/*  99 */     this.variables.clear();
/* 100 */     return this;
/*     */   }
/*     */   
/*     */   public Set<String> getVariableNames() {
/* 104 */     Set<String> variables = new HashSet<>();
/* 105 */     for (Token t : this.tokens) {
/* 106 */       if (t.getType() == 6)
/* 107 */         variables.add(((VariableToken)t).getName()); 
/*     */     } 
/* 109 */     return variables;
/*     */   }
/*     */   
/*     */   public ValidationResult validate(boolean checkVariablesSet) {
/* 113 */     List<String> errors = new ArrayList<>(0);
/* 114 */     if (checkVariablesSet)
/*     */     {
/* 116 */       for (Token t : this.tokens) {
/* 117 */         if (t.getType() == 6) {
/* 118 */           String var = ((VariableToken)t).getName();
/* 119 */           if (!this.variables.containsKey(var)) {
/* 120 */             errors.add("The setVariable '" + var + "' has not been set");
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 132 */     int count = 0;
/* 133 */     for (Token tok : this.tokens) {
/* 134 */       Function func; int argsNum; Operator op; switch (tok.getType()) {
/*     */         case 1:
/*     */         case 6:
/* 137 */           count++;
/*     */           break;
/*     */         case 3:
/* 140 */           func = ((FunctionToken)tok).getFunction();
/* 141 */           argsNum = func.getNumArguments();
/* 142 */           if (argsNum > count) {
/* 143 */             errors.add("Not enough arguments for '" + func.getName() + "'");
/*     */           }
/* 145 */           if (argsNum > 1) {
/* 146 */             count -= argsNum - 1; break;
/* 147 */           }  if (argsNum == 0)
/*     */           {
/* 149 */             count++;
/*     */           }
/*     */           break;
/*     */         case 2:
/* 153 */           op = ((OperatorToken)tok).getOperator();
/* 154 */           if (op.getNumOperands() == 2) {
/* 155 */             count--;
/*     */           }
/*     */           break;
/*     */       } 
/* 159 */       if (count < 1) {
/* 160 */         errors.add("Too many operators");
/* 161 */         return new ValidationResult(false, errors);
/*     */       } 
/*     */     } 
/* 164 */     if (count > 1) {
/* 165 */       errors.add("Too many operands");
/*     */     }
/* 167 */     return (errors.size() == 0) ? ValidationResult.SUCCESS : new ValidationResult(false, errors);
/*     */   }
/*     */ 
/*     */   
/*     */   public ValidationResult validate() {
/* 172 */     return validate(true);
/*     */   }
/*     */   
/*     */   public Future<Double> evaluateAsync(ExecutorService executor) {
/* 176 */     return executor.submit(this::evaluate);
/*     */   }
/*     */   
/*     */   public double evaluate() {
/* 180 */     ArrayStack output = new ArrayStack();
/* 181 */     for (Token t : this.tokens) {
/* 182 */       if (t.getType() == 1) {
/* 183 */         output.push(((NumberToken)t).getValue());
/* 184 */       } else if (t.getType() == 6) {
/* 185 */         String name = ((VariableToken)t).getName();
/* 186 */         Double value = this.variables.get(name);
/* 187 */         if (value == null) {
/* 188 */           throw new IllegalArgumentException("No value has been set for the setVariable '" + name + "'.");
/*     */         }
/* 190 */         output.push(value.doubleValue());
/* 191 */       } else if (t.getType() == 2) {
/* 192 */         OperatorToken op = (OperatorToken)t;
/* 193 */         if (output.size() < op.getOperator().getNumOperands()) {
/* 194 */           throw new IllegalArgumentException("Invalid number of operands available for '" + op.getOperator().getSymbol() + "' operator");
/*     */         }
/* 196 */         if (op.getOperator().getNumOperands() == 2) {
/*     */           
/* 198 */           double rightArg = output.pop();
/* 199 */           double leftArg = output.pop();
/* 200 */           output.push(op.getOperator().apply(new double[] { leftArg, rightArg }));
/* 201 */         } else if (op.getOperator().getNumOperands() == 1) {
/*     */           
/* 203 */           double arg = output.pop();
/* 204 */           output.push(op.getOperator().apply(new double[] { arg }));
/*     */         } 
/* 206 */       } else if (t.getType() == 3) {
/* 207 */         FunctionToken func = (FunctionToken)t;
/* 208 */         int numArguments = func.getFunction().getNumArguments();
/* 209 */         if (output.size() < numArguments) {
/* 210 */           throw new IllegalArgumentException("Invalid number of arguments available for '" + func.getFunction().getName() + "' function");
/*     */         }
/*     */         
/* 213 */         double[] args = new double[numArguments];
/* 214 */         for (int j = numArguments - 1; j >= 0; j--) {
/* 215 */           args[j] = output.pop();
/*     */         }
/* 217 */         output.push(func.getFunction().apply(args));
/*     */       } 
/*     */     } 
/* 220 */     if (output.size() > 1) {
/* 221 */       throw new IllegalArgumentException("Invalid number of items on the output queue. Might be caused by an invalid number of arguments for a function.");
/*     */     }
/* 223 */     return output.pop();
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\net\objecthunter\exp4j\Expression.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */