/*     */ package fun.rockstarity.api.helpers.math.net.objecthunter.exp4j;
/*     */ 
/*     */ import fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.function.Function;
/*     */ import fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.function.Functions;
/*     */ import fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.operator.Operator;
/*     */ import fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.shuntingyard.ShuntingYard;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExpressionBuilder
/*     */ {
/*     */   private final String expression;
/*     */   private final Map<String, Function> userFunctions;
/*     */   private final Map<String, Operator> userOperators;
/*     */   private final Set<String> variableNames;
/*     */   private boolean implicitMultiplication = true;
/*     */   
/*     */   public ExpressionBuilder(String expression) {
/*  53 */     if (expression == null || expression.trim().length() == 0) {
/*  54 */       throw new IllegalArgumentException("Expression can not be empty");
/*     */     }
/*  56 */     this.expression = expression;
/*  57 */     this.userOperators = new HashMap<>(4);
/*  58 */     this.userFunctions = new HashMap<>(4);
/*  59 */     this.variableNames = new HashSet<>(4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExpressionBuilder function(Function function) {
/*  69 */     this.userFunctions.put(function.getName(), function);
/*  70 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExpressionBuilder functions(Function... functions) {
/*  80 */     for (Function f : functions) {
/*  81 */       this.userFunctions.put(f.getName(), f);
/*     */     }
/*  83 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExpressionBuilder functions(List<Function> functions) {
/*  93 */     for (Function f : functions) {
/*  94 */       this.userFunctions.put(f.getName(), f);
/*     */     }
/*  96 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExpressionBuilder variables(Set<String> variableNames) {
/* 106 */     this.variableNames.addAll(variableNames);
/* 107 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExpressionBuilder variables(String... variableNames) {
/* 117 */     Collections.addAll(this.variableNames, variableNames);
/* 118 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExpressionBuilder variable(String variableName) {
/* 128 */     this.variableNames.add(variableName);
/* 129 */     return this;
/*     */   }
/*     */   
/*     */   public ExpressionBuilder implicitMultiplication(boolean enabled) {
/* 133 */     this.implicitMultiplication = enabled;
/* 134 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExpressionBuilder operator(Operator operator) {
/* 144 */     checkOperatorSymbol(operator);
/* 145 */     this.userOperators.put(operator.getSymbol(), operator);
/* 146 */     return this;
/*     */   }
/*     */   
/*     */   private void checkOperatorSymbol(Operator op) {
/* 150 */     String name = op.getSymbol();
/* 151 */     for (char ch : name.toCharArray()) {
/* 152 */       if (!Operator.isAllowedOperatorChar(ch)) {
/* 153 */         throw new IllegalArgumentException("The operator symbol '" + name + "' is invalid");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExpressionBuilder operator(Operator... operators) {
/* 165 */     for (Operator o : operators) {
/* 166 */       operator(o);
/*     */     }
/* 168 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExpressionBuilder operator(List<Operator> operators) {
/* 178 */     for (Operator o : operators) {
/* 179 */       operator(o);
/*     */     }
/* 181 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression build() {
/* 190 */     if (this.expression.length() == 0) {
/* 191 */       throw new IllegalArgumentException("The expression can not be empty");
/*     */     }
/*     */ 
/*     */     
/* 195 */     this.variableNames.add("pi");
/* 196 */     this.variableNames.add("π");
/* 197 */     this.variableNames.add("e");
/* 198 */     this.variableNames.add("φ");
/*     */ 
/*     */     
/* 201 */     for (String var : this.variableNames) {
/* 202 */       if (Functions.getBuiltinFunction(var) != null || this.userFunctions.containsKey(var)) {
/* 203 */         throw new IllegalArgumentException("A variable can not have the same name as a function [" + var + "]");
/*     */       }
/*     */     } 
/*     */     
/* 207 */     return new Expression(ShuntingYard.convertToRPN(this.expression, this.userFunctions, this.userOperators, this.variableNames, this.implicitMultiplication), this.userFunctions
/* 208 */         .keySet());
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\net\objecthunter\exp4j\ExpressionBuilder.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */