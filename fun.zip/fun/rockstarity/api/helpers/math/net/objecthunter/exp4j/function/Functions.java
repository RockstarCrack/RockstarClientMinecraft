/*     */ package fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.function;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Functions
/*     */ {
/*     */   private static final int INDEX_SIN = 0;
/*     */   private static final int INDEX_COS = 1;
/*     */   private static final int INDEX_TAN = 2;
/*     */   private static final int INDEX_CSC = 3;
/*     */   private static final int INDEX_SEC = 4;
/*     */   private static final int INDEX_COT = 5;
/*     */   private static final int INDEX_SINH = 6;
/*     */   private static final int INDEX_COSH = 7;
/*     */   private static final int INDEX_TANH = 8;
/*     */   private static final int INDEX_CSCH = 9;
/*     */   private static final int INDEX_SECH = 10;
/*     */   private static final int INDEX_COTH = 11;
/*     */   private static final int INDEX_ASIN = 12;
/*     */   private static final int INDEX_ACOS = 13;
/*     */   private static final int INDEX_ATAN = 14;
/*     */   private static final int INDEX_SQRT = 15;
/*     */   private static final int INDEX_CBRT = 16;
/*     */   private static final int INDEX_ABS = 17;
/*     */   private static final int INDEX_CEIL = 18;
/*     */   private static final int INDEX_FLOOR = 19;
/*     */   private static final int INDEX_POW = 20;
/*     */   private static final int INDEX_EXP = 21;
/*     */   private static final int INDEX_EXPM1 = 22;
/*     */   private static final int INDEX_LOG10 = 23;
/*     */   private static final int INDEX_LOG2 = 24;
/*     */   private static final int INDEX_LOG = 25;
/*     */   private static final int INDEX_LOG1P = 26;
/*     */   private static final int INDEX_LOGB = 27;
/*     */   private static final int INDEX_SGN = 28;
/*     */   private static final int INDEX_TO_RADIAN = 29;
/*     */   private static final int INDEX_TO_DEGREE = 30;
/*  55 */   private static final Function[] BUILT_IN_FUNCTIONS = new Function[31];
/*     */   
/*     */   static {
/*  58 */     BUILT_IN_FUNCTIONS[0] = new Function("sin")
/*     */       {
/*     */         public double apply(double... args) {
/*  61 */           return Math.sin(args[0]);
/*     */         }
/*     */       };
/*  64 */     BUILT_IN_FUNCTIONS[1] = new Function("cos")
/*     */       {
/*     */         public double apply(double... args) {
/*  67 */           return Math.cos(args[0]);
/*     */         }
/*     */       };
/*  70 */     BUILT_IN_FUNCTIONS[2] = new Function("tan")
/*     */       {
/*     */         public double apply(double... args) {
/*  73 */           return Math.tan(args[0]);
/*     */         }
/*     */       };
/*  76 */     BUILT_IN_FUNCTIONS[5] = new Function("cot")
/*     */       {
/*     */         public double apply(double... args) {
/*  79 */           double tan = Math.tan(args[0]);
/*  80 */           if (tan == 0.0D) {
/*  81 */             throw new ArithmeticException("Division by zero in cotangent!");
/*     */           }
/*  83 */           return 1.0D / tan;
/*     */         }
/*     */       };
/*  86 */     BUILT_IN_FUNCTIONS[25] = new Function("log")
/*     */       {
/*     */         public double apply(double... args) {
/*  89 */           return Math.log(args[0]);
/*     */         }
/*     */       };
/*  92 */     BUILT_IN_FUNCTIONS[24] = new Function("log2")
/*     */       {
/*     */         public double apply(double... args) {
/*  95 */           return Math.log(args[0]) / Math.log(2.0D);
/*     */         }
/*     */       };
/*  98 */     BUILT_IN_FUNCTIONS[23] = new Function("log10")
/*     */       {
/*     */         public double apply(double... args) {
/* 101 */           return Math.log10(args[0]);
/*     */         }
/*     */       };
/* 104 */     BUILT_IN_FUNCTIONS[26] = new Function("log1p")
/*     */       {
/*     */         public double apply(double... args) {
/* 107 */           return Math.log1p(args[0]);
/*     */         }
/*     */       };
/* 110 */     BUILT_IN_FUNCTIONS[17] = new Function("abs")
/*     */       {
/*     */         public double apply(double... args) {
/* 113 */           return Math.abs(args[0]);
/*     */         }
/*     */       };
/* 116 */     BUILT_IN_FUNCTIONS[13] = new Function("acos")
/*     */       {
/*     */         public double apply(double... args) {
/* 119 */           return Math.acos(args[0]);
/*     */         }
/*     */       };
/* 122 */     BUILT_IN_FUNCTIONS[12] = new Function("asin")
/*     */       {
/*     */         public double apply(double... args) {
/* 125 */           return Math.asin(args[0]);
/*     */         }
/*     */       };
/* 128 */     BUILT_IN_FUNCTIONS[14] = new Function("atan")
/*     */       {
/*     */         public double apply(double... args) {
/* 131 */           return Math.atan(args[0]);
/*     */         }
/*     */       };
/* 134 */     BUILT_IN_FUNCTIONS[16] = new Function("cbrt")
/*     */       {
/*     */         public double apply(double... args) {
/* 137 */           return Math.cbrt(args[0]);
/*     */         }
/*     */       };
/* 140 */     BUILT_IN_FUNCTIONS[19] = new Function("floor")
/*     */       {
/*     */         public double apply(double... args) {
/* 143 */           return Math.floor(args[0]);
/*     */         }
/*     */       };
/* 146 */     BUILT_IN_FUNCTIONS[6] = new Function("sinh")
/*     */       {
/*     */         public double apply(double... args) {
/* 149 */           return Math.sinh(args[0]);
/*     */         }
/*     */       };
/* 152 */     BUILT_IN_FUNCTIONS[15] = new Function("sqrt")
/*     */       {
/*     */         public double apply(double... args) {
/* 155 */           return Math.sqrt(args[0]);
/*     */         }
/*     */       };
/* 158 */     BUILT_IN_FUNCTIONS[8] = new Function("tanh")
/*     */       {
/*     */         public double apply(double... args) {
/* 161 */           return Math.tanh(args[0]);
/*     */         }
/*     */       };
/* 164 */     BUILT_IN_FUNCTIONS[7] = new Function("cosh")
/*     */       {
/*     */         public double apply(double... args) {
/* 167 */           return Math.cosh(args[0]);
/*     */         }
/*     */       };
/* 170 */     BUILT_IN_FUNCTIONS[18] = new Function("ceil")
/*     */       {
/*     */         public double apply(double... args) {
/* 173 */           return Math.ceil(args[0]);
/*     */         }
/*     */       };
/* 176 */     BUILT_IN_FUNCTIONS[20] = new Function("pow", 2)
/*     */       {
/*     */         public double apply(double... args) {
/* 179 */           return Math.pow(args[0], args[1]);
/*     */         }
/*     */       };
/* 182 */     BUILT_IN_FUNCTIONS[21] = new Function("exp", 1)
/*     */       {
/*     */         public double apply(double... args) {
/* 185 */           return Math.exp(args[0]);
/*     */         }
/*     */       };
/* 188 */     BUILT_IN_FUNCTIONS[22] = new Function("expm1", 1)
/*     */       {
/*     */         public double apply(double... args) {
/* 191 */           return Math.expm1(args[0]);
/*     */         }
/*     */       };
/* 194 */     BUILT_IN_FUNCTIONS[28] = new Function("signum", 1)
/*     */       {
/*     */         public double apply(double... args) {
/* 197 */           if (args[0] > 0.0D)
/* 198 */             return 1.0D; 
/* 199 */           if (args[0] < 0.0D) {
/* 200 */             return -1.0D;
/*     */           }
/* 202 */           return 0.0D;
/*     */         }
/*     */       };
/*     */     
/* 206 */     BUILT_IN_FUNCTIONS[3] = new Function("csc")
/*     */       {
/*     */         public double apply(double... args) {
/* 209 */           double sin = Math.sin(args[0]);
/* 210 */           if (sin == 0.0D) {
/* 211 */             throw new ArithmeticException("Division by zero in cosecant!");
/*     */           }
/* 213 */           return 1.0D / sin;
/*     */         }
/*     */       };
/* 216 */     BUILT_IN_FUNCTIONS[4] = new Function("sec")
/*     */       {
/*     */         public double apply(double... args) {
/* 219 */           double cos = Math.cos(args[0]);
/* 220 */           if (cos == 0.0D) {
/* 221 */             throw new ArithmeticException("Division by zero in secant!");
/*     */           }
/* 223 */           return 1.0D / cos;
/*     */         }
/*     */       };
/* 226 */     BUILT_IN_FUNCTIONS[9] = new Function("csch")
/*     */       {
/*     */         public double apply(double... args)
/*     */         {
/* 230 */           if (args[0] == 0.0D) {
/* 231 */             return 0.0D;
/*     */           }
/*     */           
/* 234 */           return 1.0D / Math.sinh(args[0]);
/*     */         }
/*     */       };
/* 237 */     BUILT_IN_FUNCTIONS[10] = new Function("sech")
/*     */       {
/*     */         public double apply(double... args) {
/* 240 */           return 1.0D / Math.cosh(args[0]);
/*     */         }
/*     */       };
/* 243 */     BUILT_IN_FUNCTIONS[11] = new Function("coth")
/*     */       {
/*     */         public double apply(double... args) {
/* 246 */           return Math.cosh(args[0]) / Math.sinh(args[0]);
/*     */         }
/*     */       };
/* 249 */     BUILT_IN_FUNCTIONS[27] = new Function("logb", 2)
/*     */       {
/*     */         public double apply(double... args) {
/* 252 */           return Math.log(args[1]) / Math.log(args[0]);
/*     */         }
/*     */       };
/* 255 */     BUILT_IN_FUNCTIONS[29] = new Function("toradian")
/*     */       {
/*     */         public double apply(double... args) {
/* 258 */           return Math.toRadians(args[0]);
/*     */         }
/*     */       };
/* 261 */     BUILT_IN_FUNCTIONS[30] = new Function("todegree")
/*     */       {
/*     */         public double apply(double... args) {
/* 264 */           return Math.toDegrees(args[0]);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Function getBuiltinFunction(String name) {
/* 278 */     switch (name) {
/*     */       case "sin":
/* 280 */         return BUILT_IN_FUNCTIONS[0];
/*     */       case "cos":
/* 282 */         return BUILT_IN_FUNCTIONS[1];
/*     */       case "tan":
/* 284 */         return BUILT_IN_FUNCTIONS[2];
/*     */       case "cot":
/* 286 */         return BUILT_IN_FUNCTIONS[5];
/*     */       case "asin":
/* 288 */         return BUILT_IN_FUNCTIONS[12];
/*     */       case "acos":
/* 290 */         return BUILT_IN_FUNCTIONS[13];
/*     */       case "atan":
/* 292 */         return BUILT_IN_FUNCTIONS[14];
/*     */       case "sinh":
/* 294 */         return BUILT_IN_FUNCTIONS[6];
/*     */       case "cosh":
/* 296 */         return BUILT_IN_FUNCTIONS[7];
/*     */       case "tanh":
/* 298 */         return BUILT_IN_FUNCTIONS[8];
/*     */       case "abs":
/* 300 */         return BUILT_IN_FUNCTIONS[17];
/*     */       case "log":
/* 302 */         return BUILT_IN_FUNCTIONS[25];
/*     */       case "log10":
/* 304 */         return BUILT_IN_FUNCTIONS[23];
/*     */       case "log2":
/* 306 */         return BUILT_IN_FUNCTIONS[24];
/*     */       case "log1p":
/* 308 */         return BUILT_IN_FUNCTIONS[26];
/*     */       case "ceil":
/* 310 */         return BUILT_IN_FUNCTIONS[18];
/*     */       case "floor":
/* 312 */         return BUILT_IN_FUNCTIONS[19];
/*     */       case "sqrt":
/* 314 */         return BUILT_IN_FUNCTIONS[15];
/*     */       case "cbrt":
/* 316 */         return BUILT_IN_FUNCTIONS[16];
/*     */       case "pow":
/* 318 */         return BUILT_IN_FUNCTIONS[20];
/*     */       case "exp":
/* 320 */         return BUILT_IN_FUNCTIONS[21];
/*     */       case "expm1":
/* 322 */         return BUILT_IN_FUNCTIONS[22];
/*     */       case "signum":
/* 324 */         return BUILT_IN_FUNCTIONS[28];
/*     */       case "csc":
/* 326 */         return BUILT_IN_FUNCTIONS[3];
/*     */       case "sec":
/* 328 */         return BUILT_IN_FUNCTIONS[4];
/*     */       case "csch":
/* 330 */         return BUILT_IN_FUNCTIONS[9];
/*     */       case "sech":
/* 332 */         return BUILT_IN_FUNCTIONS[10];
/*     */       case "coth":
/* 334 */         return BUILT_IN_FUNCTIONS[11];
/*     */       case "toradian":
/* 336 */         return BUILT_IN_FUNCTIONS[29];
/*     */       case "todegree":
/* 338 */         return BUILT_IN_FUNCTIONS[30];
/*     */     } 
/* 340 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\net\objecthunter\exp4j\function\Functions.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */