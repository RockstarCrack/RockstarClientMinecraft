/*    */ package fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.operator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends Operator
/*    */ {
/*    */   null(String symbol, int numberOfOperands, boolean leftAssociative, int precedence) {
/* 61 */     super(symbol, numberOfOperands, leftAssociative, precedence);
/*    */   }
/*    */   public double apply(double... args) {
/* 64 */     if (args[1] == 0.0D) {
/* 65 */       throw new ArithmeticException("Division by zero!");
/*    */     }
/* 67 */     return args[0] / args[1];
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\net\objecthunter\exp4j\operator\Operators$6.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */