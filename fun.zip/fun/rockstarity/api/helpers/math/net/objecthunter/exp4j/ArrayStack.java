/*    */ package fun.rockstarity.api.helpers.math.net.objecthunter.exp4j;
/*    */ 
/*    */ import java.util.EmptyStackException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ArrayStack
/*    */ {
/*    */   private double[] data;
/*    */   private int idx;
/*    */   
/*    */   ArrayStack() {
/* 33 */     this(5);
/*    */   }
/*    */   
/*    */   ArrayStack(int initialCapacity) {
/* 37 */     if (initialCapacity <= 0) {
/* 38 */       throw new IllegalArgumentException("Stack's capacity must be positive");
/*    */     }
/*    */ 
/*    */     
/* 42 */     this.data = new double[initialCapacity];
/* 43 */     this.idx = -1;
/*    */   }
/*    */   
/*    */   void push(double value) {
/* 47 */     if (this.idx + 1 == this.data.length) {
/* 48 */       double[] temp = new double[(int)(this.data.length * 1.2D) + 1];
/* 49 */       System.arraycopy(this.data, 0, temp, 0, this.data.length);
/* 50 */       this.data = temp;
/*    */     } 
/*    */     
/* 53 */     this.data[++this.idx] = value;
/*    */   }
/*    */   
/*    */   double peek() {
/* 57 */     if (this.idx == -1) {
/* 58 */       throw new EmptyStackException();
/*    */     }
/* 60 */     return this.data[this.idx];
/*    */   }
/*    */   
/*    */   double pop() {
/* 64 */     if (this.idx == -1) {
/* 65 */       throw new EmptyStackException();
/*    */     }
/* 67 */     return this.data[this.idx--];
/*    */   }
/*    */   
/*    */   boolean isEmpty() {
/* 71 */     return (this.idx == -1);
/*    */   }
/*    */   
/*    */   int size() {
/* 75 */     return this.idx + 1;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\net\objecthunter\exp4j\ArrayStack.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */