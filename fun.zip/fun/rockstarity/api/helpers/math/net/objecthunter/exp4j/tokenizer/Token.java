/*    */ package fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.tokenizer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Token
/*    */ {
/*    */   public static final short TOKEN_NUMBER = 1;
/*    */   public static final short TOKEN_OPERATOR = 2;
/*    */   public static final short TOKEN_FUNCTION = 3;
/*    */   public static final short TOKEN_PARENTHESES_OPEN = 4;
/*    */   public static final short TOKEN_PARENTHESES_CLOSE = 5;
/*    */   public static final short TOKEN_VARIABLE = 6;
/*    */   public static final short TOKEN_SEPARATOR = 7;
/*    */   private final int type;
/*    */   
/*    */   Token(int type) {
/* 33 */     this.type = type;
/*    */   }
/*    */   
/*    */   public int getType() {
/* 37 */     return this.type;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\net\objecthunter\exp4j\tokenizer\Token.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */