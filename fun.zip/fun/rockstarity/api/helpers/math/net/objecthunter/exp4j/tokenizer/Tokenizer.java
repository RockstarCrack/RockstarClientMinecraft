/*     */ package fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.tokenizer;
/*     */ 
/*     */ import fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.function.Function;
/*     */ import fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.function.Functions;
/*     */ import fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.operator.Operator;
/*     */ import fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.operator.Operators;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Tokenizer
/*     */ {
/*     */   private final char[] expression;
/*     */   private final int expressionLength;
/*     */   private final Map<String, Function> userFunctions;
/*     */   private final Map<String, Operator> userOperators;
/*     */   private final Set<String> variableNames;
/*     */   private final boolean implicitMultiplication;
/*  40 */   private int pos = 0;
/*     */ 
/*     */   
/*     */   private Token lastToken;
/*     */ 
/*     */   
/*     */   public Tokenizer(String expression, Map<String, Function> userFunctions, Map<String, Operator> userOperators, Set<String> variableNames, boolean implicitMultiplication) {
/*  47 */     this.expression = expression.trim().toCharArray();
/*  48 */     this.expressionLength = this.expression.length;
/*  49 */     this.userFunctions = userFunctions;
/*  50 */     this.userOperators = userOperators;
/*  51 */     this.variableNames = variableNames;
/*  52 */     this.implicitMultiplication = implicitMultiplication;
/*     */   }
/*     */ 
/*     */   
/*     */   public Tokenizer(String expression, Map<String, Function> userFunctions, Map<String, Operator> userOperators, Set<String> variableNames) {
/*  57 */     this.expression = expression.trim().toCharArray();
/*  58 */     this.expressionLength = this.expression.length;
/*  59 */     this.userFunctions = userFunctions;
/*  60 */     this.userOperators = userOperators;
/*  61 */     this.variableNames = variableNames;
/*  62 */     this.implicitMultiplication = true;
/*     */   }
/*     */   
/*     */   public boolean hasNext() {
/*  66 */     return (this.expression.length > this.pos);
/*     */   }
/*     */   
/*     */   public Token nextToken() {
/*  70 */     char ch = this.expression[this.pos];
/*  71 */     while (Character.isWhitespace(ch)) {
/*  72 */       ch = this.expression[++this.pos];
/*     */     }
/*  74 */     if (Character.isDigit(ch) || ch == '.') {
/*  75 */       if (this.lastToken != null) {
/*  76 */         if (this.lastToken.getType() == 1)
/*  77 */           throw new IllegalArgumentException("Unable to parse char '" + ch + "' (Code:" + ch + ") at [" + this.pos + "]"); 
/*  78 */         if (this.implicitMultiplication && this.lastToken.getType() != 2 && this.lastToken
/*  79 */           .getType() != 4 && this.lastToken
/*  80 */           .getType() != 3 && this.lastToken
/*  81 */           .getType() != 7) {
/*     */           
/*  83 */           this.lastToken = new OperatorToken(Operators.getBuiltinOperator('*', 2));
/*  84 */           return this.lastToken;
/*     */         } 
/*     */       } 
/*  87 */       return parseNumberToken(ch);
/*  88 */     }  if (isArgumentSeparator(ch))
/*  89 */       return parseArgumentSeparatorToken(); 
/*  90 */     if (isOpenParentheses(ch)) {
/*  91 */       if (this.lastToken != null && this.implicitMultiplication && this.lastToken
/*  92 */         .getType() != 2 && this.lastToken
/*  93 */         .getType() != 4 && this.lastToken
/*  94 */         .getType() != 3 && this.lastToken
/*  95 */         .getType() != 7) {
/*     */         
/*  97 */         this.lastToken = new OperatorToken(Operators.getBuiltinOperator('*', 2));
/*  98 */         return this.lastToken;
/*     */       } 
/* 100 */       return parseParentheses(true);
/* 101 */     }  if (isCloseParentheses(ch))
/* 102 */       return parseParentheses(false); 
/* 103 */     if (Operator.isAllowedOperatorChar(ch))
/* 104 */       return parseOperatorToken(ch); 
/* 105 */     if (isAlphabetic(ch) || ch == '_') {
/*     */       
/* 107 */       if (this.lastToken != null && this.implicitMultiplication && this.lastToken
/* 108 */         .getType() != 2 && this.lastToken
/* 109 */         .getType() != 4 && this.lastToken
/* 110 */         .getType() != 3 && this.lastToken
/* 111 */         .getType() != 7) {
/*     */         
/* 113 */         this.lastToken = new OperatorToken(Operators.getBuiltinOperator('*', 2));
/* 114 */         return this.lastToken;
/*     */       } 
/* 116 */       return parseFunctionOrVariable();
/*     */     } 
/*     */     
/* 119 */     throw new IllegalArgumentException("Unable to parse char '" + ch + "' (Code:" + ch + ") at [" + this.pos + "]");
/*     */   }
/*     */   
/*     */   private Token parseArgumentSeparatorToken() {
/* 123 */     this.pos++;
/* 124 */     this.lastToken = new ArgumentSeparatorToken();
/* 125 */     return this.lastToken;
/*     */   }
/*     */   
/*     */   private boolean isArgumentSeparator(char ch) {
/* 129 */     return (ch == ',');
/*     */   }
/*     */   
/*     */   private Token parseParentheses(boolean open) {
/* 133 */     if (open) {
/* 134 */       this.lastToken = new OpenParenthesesToken();
/*     */     } else {
/* 136 */       this.lastToken = new CloseParenthesesToken();
/*     */     } 
/* 138 */     this.pos++;
/* 139 */     return this.lastToken;
/*     */   }
/*     */   
/*     */   private boolean isOpenParentheses(char ch) {
/* 143 */     return (ch == '(' || ch == '{' || ch == '[');
/*     */   }
/*     */   
/*     */   private boolean isCloseParentheses(char ch) {
/* 147 */     return (ch == ')' || ch == '}' || ch == ']');
/*     */   }
/*     */   
/*     */   private Token parseFunctionOrVariable() {
/* 151 */     int offset = this.pos;
/*     */     
/* 153 */     int lastValidLen = 1;
/* 154 */     Token lastValidToken = null;
/* 155 */     int len = 1;
/* 156 */     if (isEndOfExpression(offset)) {
/* 157 */       this.pos++;
/*     */     }
/* 159 */     int testPos = offset + len - 1;
/* 160 */     while (!isEndOfExpression(testPos) && 
/* 161 */       isVariableOrFunctionCharacter(this.expression[testPos])) {
/* 162 */       String name = new String(this.expression, offset, len);
/* 163 */       if (this.variableNames != null && this.variableNames.contains(name)) {
/* 164 */         lastValidLen = len;
/* 165 */         lastValidToken = new VariableToken(name);
/*     */       } else {
/* 167 */         Function f = getFunction(name);
/* 168 */         if (f != null) {
/* 169 */           lastValidLen = len;
/* 170 */           lastValidToken = new FunctionToken(f);
/*     */         } 
/*     */       } 
/* 173 */       len++;
/* 174 */       testPos = offset + len - 1;
/*     */     } 
/* 176 */     if (lastValidToken == null) {
/* 177 */       throw new UnknownFunctionOrVariableException(new String(this.expression), this.pos, len);
/*     */     }
/* 179 */     this.pos += lastValidLen;
/* 180 */     this.lastToken = lastValidToken;
/* 181 */     return this.lastToken;
/*     */   }
/*     */   
/*     */   private Function getFunction(String name) {
/* 185 */     Function f = null;
/* 186 */     if (this.userFunctions != null) {
/* 187 */       f = this.userFunctions.get(name);
/*     */     }
/* 189 */     if (f == null) {
/* 190 */       f = Functions.getBuiltinFunction(name);
/*     */     }
/* 192 */     return f;
/*     */   }
/*     */   
/*     */   private Token parseOperatorToken(char firstChar) {
/* 196 */     int offset = this.pos;
/* 197 */     int len = 1;
/* 198 */     StringBuilder symbol = new StringBuilder();
/* 199 */     Operator lastValid = null;
/* 200 */     symbol.append(firstChar);
/*     */     
/* 202 */     while (!isEndOfExpression(offset + len) && Operator.isAllowedOperatorChar(this.expression[offset + len])) {
/* 203 */       symbol.append(this.expression[offset + len++]);
/*     */     }
/*     */     
/* 206 */     while (symbol.length() > 0) {
/* 207 */       Operator op = getOperator(symbol.toString());
/* 208 */       if (op == null) {
/* 209 */         symbol.setLength(symbol.length() - 1); continue;
/*     */       } 
/* 211 */       lastValid = op;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 216 */     this.pos += symbol.length();
/* 217 */     this.lastToken = new OperatorToken(lastValid);
/* 218 */     return this.lastToken;
/*     */   }
/*     */   
/*     */   private Operator getOperator(String symbol) {
/* 222 */     Operator op = null;
/* 223 */     if (this.userOperators != null) {
/* 224 */       op = this.userOperators.get(symbol);
/*     */     }
/* 226 */     if (op == null && symbol.length() == 1) {
/* 227 */       int argc = 2;
/* 228 */       if (this.lastToken == null) {
/* 229 */         argc = 1;
/*     */       } else {
/* 231 */         int lastTokenType = this.lastToken.getType();
/* 232 */         if (lastTokenType == 4 || lastTokenType == 7) {
/* 233 */           argc = 1;
/* 234 */         } else if (lastTokenType == 2) {
/* 235 */           Operator lastOp = ((OperatorToken)this.lastToken).getOperator();
/* 236 */           if (lastOp.getNumOperands() == 2 || (lastOp.getNumOperands() == 1 && !lastOp.isLeftAssociative())) {
/* 237 */             argc = 1;
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 242 */       op = Operators.getBuiltinOperator(symbol.charAt(0), argc);
/*     */     } 
/* 244 */     return op;
/*     */   }
/*     */   
/*     */   private Token parseNumberToken(char firstChar) {
/* 248 */     int offset = this.pos;
/* 249 */     int len = 1;
/* 250 */     this.pos++;
/* 251 */     if (isEndOfExpression(offset + len)) {
/* 252 */       this.lastToken = new NumberToken(Double.parseDouble(String.valueOf(firstChar)));
/* 253 */       return this.lastToken;
/*     */     } 
/* 255 */     while (!isEndOfExpression(offset + len) && 
/* 256 */       isNumeric(this.expression[offset + len], (this.expression[offset + len - 1] == 'e' || this.expression[offset + len - 1] == 'E'))) {
/*     */       
/* 258 */       len++;
/* 259 */       this.pos++;
/*     */     } 
/*     */     
/* 262 */     if (this.expression[offset + len - 1] == 'e' || this.expression[offset + len - 1] == 'E') {
/*     */       
/* 264 */       len--;
/* 265 */       this.pos--;
/*     */     } 
/* 267 */     this.lastToken = new NumberToken(this.expression, offset, len);
/* 268 */     return this.lastToken;
/*     */   }
/*     */   
/*     */   private static boolean isNumeric(char ch, boolean lastCharE) {
/* 272 */     return (Character.isDigit(ch) || ch == '.' || ch == 'e' || ch == 'E' || (lastCharE && (ch == '-' || ch == '+')));
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isAlphabetic(int codePoint) {
/* 277 */     return Character.isLetter(codePoint);
/*     */   }
/*     */   
/*     */   public static boolean isVariableOrFunctionCharacter(int codePoint) {
/* 281 */     return (isAlphabetic(codePoint) || 
/* 282 */       Character.isDigit(codePoint) || codePoint == 95 || codePoint == 46);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isEndOfExpression(int offset) {
/* 288 */     return (this.expressionLength <= offset);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\net\objecthunter\exp4j\tokenizer\Tokenizer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */