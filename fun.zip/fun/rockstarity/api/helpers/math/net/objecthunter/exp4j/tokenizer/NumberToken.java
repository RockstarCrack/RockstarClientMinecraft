/*    */ package fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.tokenizer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NumberToken
/*    */   extends Token
/*    */ {
/*    */   private final double value;
/*    */   
/*    */   public NumberToken(double value) {
/* 30 */     super(1);
/* 31 */     this.value = value;
/*    */   }
/*    */   
/*    */   NumberToken(char[] expression, int offset, int len) {
/* 35 */     this(Double.parseDouble(String.valueOf(expression, offset, len)));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double getValue() {
/* 44 */     return this.value;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\net\objecthunter\exp4j\tokenizer\NumberToken.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */