/*    */ package fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.tokenizer;
/*    */ 
/*    */ import fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.operator.Operator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OperatorToken
/*    */   extends Token
/*    */ {
/*    */   private final Operator operator;
/*    */   
/*    */   public OperatorToken(Operator op) {
/* 32 */     super(2);
/* 33 */     if (op == null) {
/* 34 */       throw new IllegalArgumentException("Operator is unknown for token.");
/*    */     }
/* 36 */     this.operator = op;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Operator getOperator() {
/* 45 */     return this.operator;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\net\objecthunter\exp4j\tokenizer\OperatorToken.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */