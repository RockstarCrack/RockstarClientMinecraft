/*    */ package fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.tokenizer;
/*    */ 
/*    */ import fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.function.Function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FunctionToken
/*    */   extends Token
/*    */ {
/*    */   private final Function function;
/*    */   
/*    */   public FunctionToken(Function function) {
/* 24 */     super(3);
/* 25 */     this.function = function;
/*    */   }
/*    */   
/*    */   public Function getFunction() {
/* 29 */     return this.function;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\net\objecthunter\exp4j\tokenizer\FunctionToken.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */