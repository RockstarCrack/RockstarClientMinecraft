/*     */ package fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.operator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Operator
/*     */ {
/*     */   public static final int PRECEDENCE_ADDITION = 500;
/*     */   public static final int PRECEDENCE_SUBTRACTION = 500;
/*     */   public static final int PRECEDENCE_MULTIPLICATION = 1000;
/*     */   public static final int PRECEDENCE_DIVISION = 1000;
/*     */   public static final int PRECEDENCE_MODULO = 1000;
/*     */   public static final int PRECEDENCE_POWER = 10000;
/*     */   public static final int PRECEDENCE_UNARY_MINUS = 5000;
/*     */   public static final int PRECEDENCE_UNARY_PLUS = 5000;
/*  58 */   public static final char[] ALLOWED_OPERATOR_CHARS = new char[] { '+', '-', '*', '/', '%', '^', '!', '#', '§', '$', '&', ';', ':', '~', '<', '>', '|', '=', '÷', '√', '∛', '⌈', '⌊' };
/*     */ 
/*     */ 
/*     */   
/*     */   private final int numOperands;
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean leftAssociative;
/*     */ 
/*     */   
/*     */   private final String symbol;
/*     */ 
/*     */   
/*     */   private final int precedence;
/*     */ 
/*     */ 
/*     */   
/*     */   public Operator(String symbol, int numberOfOperands, boolean leftAssociative, int precedence) {
/*  77 */     this.numOperands = numberOfOperands;
/*  78 */     this.leftAssociative = leftAssociative;
/*  79 */     this.symbol = symbol;
/*  80 */     this.precedence = precedence;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAllowedOperatorChar(char ch) {
/*  90 */     for (char allowed : ALLOWED_OPERATOR_CHARS) {
/*  91 */       if (ch == allowed) {
/*  92 */         return true;
/*     */       }
/*     */     } 
/*  95 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLeftAssociative() {
/* 104 */     return this.leftAssociative;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrecedence() {
/* 113 */     return this.precedence;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract double apply(double... paramVarArgs);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSymbol() {
/* 130 */     return this.symbol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumOperands() {
/* 139 */     return this.numOperands;
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\net\objecthunter\exp4j\operator\Operator.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */