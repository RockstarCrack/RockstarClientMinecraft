/*    */ package fun.rockstarity.api.helpers.math.net.objecthunter.exp4j;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValidationResult
/*    */ {
/*    */   private final boolean valid;
/*    */   private final List<String> errors;
/*    */   
/*    */   public ValidationResult(boolean valid, List<String> errors) {
/* 34 */     this.valid = valid;
/* 35 */     this.errors = errors;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isValid() {
/* 44 */     return this.valid;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<String> getErrors() {
/* 53 */     return this.errors;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 59 */   public static final ValidationResult SUCCESS = new ValidationResult(true, null);
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\net\objecthunter\exp4j\ValidationResult.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */