/*     */ package fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.operator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Operators
/*     */ {
/*     */   private static final int INDEX_ADDITION = 0;
/*     */   private static final int INDEX_SUBTRACTION = 1;
/*     */   private static final int INDEX_MULTIPLICATION = 2;
/*     */   private static final int INDEX_DIVISION = 3;
/*     */   private static final int INDEX_POWER = 4;
/*     */   private static final int INDEX_MODULO = 5;
/*     */   private static final int INDEX_UNARY_MINUS = 6;
/*     */   private static final int INDEX_UNARY_PLUS = 7;
/*  28 */   private static final Operator[] BUILT_IN_OPERATORS = new Operator[8];
/*     */   
/*     */   static {
/*  31 */     BUILT_IN_OPERATORS[0] = new Operator("+", 2, true, 500)
/*     */       {
/*     */         public double apply(double... args) {
/*  34 */           return args[0] + args[1];
/*     */         }
/*     */       };
/*  37 */     BUILT_IN_OPERATORS[1] = new Operator("-", 2, true, 500)
/*     */       {
/*     */         public double apply(double... args) {
/*  40 */           return args[0] - args[1];
/*     */         }
/*     */       };
/*  43 */     BUILT_IN_OPERATORS[6] = new Operator("-", 1, false, 5000)
/*     */       {
/*     */         public double apply(double... args) {
/*  46 */           return -args[0];
/*     */         }
/*     */       };
/*  49 */     BUILT_IN_OPERATORS[7] = new Operator("+", 1, false, 5000)
/*     */       {
/*     */         public double apply(double... args) {
/*  52 */           return args[0];
/*     */         }
/*     */       };
/*  55 */     BUILT_IN_OPERATORS[2] = new Operator("*", 2, true, 1000)
/*     */       {
/*     */         public double apply(double... args) {
/*  58 */           return args[0] * args[1];
/*     */         }
/*     */       };
/*  61 */     BUILT_IN_OPERATORS[3] = new Operator("/", 2, true, 1000)
/*     */       {
/*     */         public double apply(double... args) {
/*  64 */           if (args[1] == 0.0D) {
/*  65 */             throw new ArithmeticException("Division by zero!");
/*     */           }
/*  67 */           return args[0] / args[1];
/*     */         }
/*     */       };
/*  70 */     BUILT_IN_OPERATORS[4] = new Operator("^", 2, false, 10000)
/*     */       {
/*     */         public double apply(double... args) {
/*  73 */           return Math.pow(args[0], args[1]);
/*     */         }
/*     */       };
/*  76 */     BUILT_IN_OPERATORS[5] = new Operator("%", 2, true, 1000)
/*     */       {
/*     */         public double apply(double... args) {
/*  79 */           if (args[1] == 0.0D) {
/*  80 */             throw new ArithmeticException("Division by zero!");
/*     */           }
/*  82 */           return args[0] % args[1];
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   public static Operator getBuiltinOperator(char symbol, int numArguments) {
/*  88 */     switch (symbol) {
/*     */       case '+':
/*  90 */         if (numArguments != 1) {
/*  91 */           return BUILT_IN_OPERATORS[0];
/*     */         }
/*     */         
/*  94 */         return BUILT_IN_OPERATORS[7];
/*     */       case '-':
/*  96 */         if (numArguments != 1) {
/*  97 */           return BUILT_IN_OPERATORS[1];
/*     */         }
/*     */         
/* 100 */         return BUILT_IN_OPERATORS[6];
/*     */       case '*':
/* 102 */         return BUILT_IN_OPERATORS[2];
/*     */       case '/':
/*     */       case '÷':
/* 105 */         return BUILT_IN_OPERATORS[3];
/*     */       case '^':
/* 107 */         return BUILT_IN_OPERATORS[4];
/*     */       case '%':
/* 109 */         return BUILT_IN_OPERATORS[5];
/*     */     } 
/* 111 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\net\objecthunter\exp4j\operator\Operators.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */