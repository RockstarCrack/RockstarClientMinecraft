/*     */ package fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.shuntingyard;
/*     */ 
/*     */ import fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.function.Function;
/*     */ import fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.operator.Operator;
/*     */ import fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.tokenizer.OperatorToken;
/*     */ import fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.tokenizer.Token;
/*     */ import fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.tokenizer.Tokenizer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ShuntingYard
/*     */ {
/*     */   public static Token[] convertToRPN(String expression, Map<String, Function> userFunctions, Map<String, Operator> userOperators, Set<String> variableNames, boolean implicitMultiplication) {
/*  47 */     Stack<Token> stack = new Stack<>();
/*  48 */     List<Token> output = new ArrayList<>();
/*     */     
/*  50 */     Tokenizer tokenizer = new Tokenizer(expression, userFunctions, userOperators, variableNames, implicitMultiplication);
/*  51 */     while (tokenizer.hasNext()) {
/*  52 */       Token token = tokenizer.nextToken();
/*  53 */       switch (token.getType()) {
/*     */         case 1:
/*     */         case 6:
/*  56 */           output.add(token);
/*     */           continue;
/*     */         case 3:
/*  59 */           stack.add(token);
/*     */           continue;
/*     */         case 7:
/*  62 */           while (!stack.empty() && ((Token)stack.peek()).getType() != 4) {
/*  63 */             output.add(stack.pop());
/*     */           }
/*  65 */           if (stack.empty() || ((Token)stack.peek()).getType() != 4) {
/*  66 */             throw new IllegalArgumentException("Misplaced function separator ',' or mismatched parentheses");
/*     */           }
/*     */           continue;
/*     */         case 2:
/*  70 */           while (!stack.empty() && ((Token)stack.peek()).getType() == 2) {
/*  71 */             OperatorToken o1 = (OperatorToken)token;
/*  72 */             OperatorToken o2 = (OperatorToken)stack.peek();
/*  73 */             if (o1.getOperator().getNumOperands() == 1 && o2.getOperator().getNumOperands() == 2)
/*     */               break; 
/*  75 */             if ((o1.getOperator().isLeftAssociative() && o1.getOperator().getPrecedence() <= o2.getOperator().getPrecedence()) || o1
/*  76 */               .getOperator().getPrecedence() < o2.getOperator().getPrecedence()) {
/*  77 */               output.add(stack.pop());
/*     */             }
/*     */           } 
/*     */ 
/*     */           
/*  82 */           stack.push(token);
/*     */           continue;
/*     */         case 4:
/*  85 */           stack.push(token);
/*     */           continue;
/*     */         case 5:
/*  88 */           while (((Token)stack.peek()).getType() != 4) {
/*  89 */             output.add(stack.pop());
/*     */           }
/*  91 */           stack.pop();
/*  92 */           if (!stack.isEmpty() && ((Token)stack.peek()).getType() == 3) {
/*  93 */             output.add(stack.pop());
/*     */           }
/*     */           continue;
/*     */       } 
/*  97 */       throw new IllegalArgumentException("Unknown Token type encountered. This should not happen");
/*     */     } 
/*     */     
/* 100 */     while (!stack.empty()) {
/* 101 */       Token t = stack.pop();
/* 102 */       if (t.getType() == 5 || t.getType() == 4) {
/* 103 */         throw new IllegalArgumentException("Mismatched parentheses detected. Please check the expression");
/*     */       }
/* 105 */       output.add(t);
/*     */     } 
/*     */     
/* 108 */     return output.<Token>toArray(new Token[0]);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\net\objecthunter\exp4j\shuntingyard\ShuntingYard.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */