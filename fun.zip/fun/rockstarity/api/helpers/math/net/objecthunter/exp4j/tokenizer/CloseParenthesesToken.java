/*    */ package fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.tokenizer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CloseParenthesesToken
/*    */   extends Token
/*    */ {
/*    */   CloseParenthesesToken() {
/* 27 */     super(5);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\net\objecthunter\exp4j\tokenizer\CloseParenthesesToken.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */