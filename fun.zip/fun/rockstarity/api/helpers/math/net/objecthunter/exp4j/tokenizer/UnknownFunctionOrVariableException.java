/*    */ package fun.rockstarity.api.helpers.math.net.objecthunter.exp4j.tokenizer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class UnknownFunctionOrVariableException
/*    */   extends IllegalArgumentException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final String message;
/*    */   private final String expression;
/*    */   private final String token;
/*    */   private final int position;
/*    */   
/*    */   public UnknownFunctionOrVariableException(String expression, int position, int length) {
/* 21 */     this.expression = expression;
/* 22 */     this.token = token(expression, position, length);
/* 23 */     this.position = position;
/* 24 */     this.message = "Unknown function or variable '" + this.token + "' at pos " + position + " in expression '" + expression + "'";
/*    */   }
/*    */ 
/*    */   
/*    */   private static String token(String expression, int position, int length) {
/* 29 */     int len = expression.length();
/* 30 */     int end = position + length - 1;
/*    */     
/* 32 */     if (len < end) {
/* 33 */       end = len;
/*    */     }
/*    */     
/* 36 */     return expression.substring(position, end);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getMessage() {
/* 41 */     return this.message;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getExpression() {
/* 48 */     return this.expression;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getToken() {
/* 55 */     return this.token;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getPosition() {
/* 62 */     return this.position;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\net\objecthunter\exp4j\tokenizer\UnknownFunctionOrVariableException.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */