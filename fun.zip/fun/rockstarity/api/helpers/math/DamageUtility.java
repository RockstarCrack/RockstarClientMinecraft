/*     */ package fun.rockstarity.api.helpers.math;
/*     */ 
/*     */ import com.google.common.collect.Multimap;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import java.util.Map;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.entity.CreatureAttribute;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.LivingEntity;
/*     */ import net.minecraft.entity.ai.attributes.Attribute;
/*     */ import net.minecraft.entity.ai.attributes.AttributeModifier;
/*     */ import net.minecraft.entity.ai.attributes.Attributes;
/*     */ import net.minecraft.entity.player.PlayerEntity;
/*     */ import net.minecraft.inventory.EquipmentSlotType;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.potion.Effects;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.Hand;
/*     */ import net.minecraft.util.math.vector.Vector3d;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DamageUtility
/*     */   implements IAccess
/*     */ {
/*     */   private DamageUtility() {
/*  51 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated"); } public static float predictDamage(Entity targetEntity) {
/*     */     LivingEntity target;
/*     */     float f1;
/*  54 */     if (targetEntity instanceof LivingEntity) { target = (LivingEntity)targetEntity; }
/*  55 */     else { return 0.0F; }
/*     */ 
/*     */     
/*  58 */     double dmg = 0.0D;
/*     */     
/*  60 */     for (EquipmentSlotType equipmentslottype : EquipmentSlotType.values()) {
/*     */       
/*  62 */       Multimap<Attribute, AttributeModifier> multimap = mc.player.getHeldItemMainhand().getAttributeModifiers(equipmentslottype);
/*     */       
/*  64 */       if (!multimap.isEmpty())
/*     */       {
/*  66 */         for (Map.Entry<Attribute, AttributeModifier> entry : (Iterable<Map.Entry<Attribute, AttributeModifier>>)multimap.entries()) {
/*     */           
/*  68 */           AttributeModifier attributemodifier = entry.getValue();
/*  69 */           double d0 = attributemodifier.getAmount();
/*     */           
/*  71 */           boolean flag = false;
/*     */           
/*  73 */           if (mc.player != null) {
/*     */             
/*  75 */             if (attributemodifier.getID() == Item.ATTACK_DAMAGE_MODIFIER) {
/*     */               
/*  77 */               d0 += mc.player.getBaseAttributeValue(Attributes.ATTACK_DAMAGE);
/*  78 */               d0 += EnchantmentHelper.getModifierForCreature(mc.player.getHeldItemMainhand(), CreatureAttribute.UNDEFINED);
/*  79 */               dmg = d0;
/*     */               
/*  81 */               flag = true; continue;
/*     */             } 
/*  83 */             if (attributemodifier.getID() == Item.ATTACK_SPEED_MODIFIER) {
/*     */               
/*  85 */               d0 += mc.player.getBaseAttributeValue(Attributes.ATTACK_SPEED);
/*  86 */               flag = true;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/*  93 */     float f = (float)((float)mc.player.getAttributeValue(Attributes.ATTACK_DAMAGE) * dmg);
/*     */ 
/*     */ 
/*     */     
/*  97 */     if (targetEntity instanceof LivingEntity) {
/*     */       
/*  99 */       f1 = EnchantmentHelper.getModifierForCreature(mc.player.getHeldItemMainhand(), ((LivingEntity)targetEntity).getCreatureAttribute());
/*     */     }
/*     */     else {
/*     */       
/* 103 */       f1 = EnchantmentHelper.getModifierForCreature(mc.player.getHeldItemMainhand(), CreatureAttribute.UNDEFINED);
/*     */     } 
/*     */     
/* 106 */     float f2 = mc.player.getCooledAttackStrength(0.5F);
/*     */     
/* 108 */     f1 *= f2;
/*     */     
/* 110 */     if (f > 0.0F || f1 > 0.0F) {
/*     */       
/* 112 */       boolean flag = (f2 > 0.9F);
/* 113 */       boolean flag1 = false;
/* 114 */       int i = 0;
/* 115 */       i += EnchantmentHelper.getKnockbackModifier((LivingEntity)mc.player);
/*     */       
/* 117 */       if (mc.player.isSprinting() && flag) {
/*     */         
/* 119 */         i++;
/* 120 */         flag1 = true;
/*     */       } 
/*     */       
/* 123 */       boolean flag2 = (flag && mc.player.fallDistance > 0.0F && !mc.player.isOnGround() && !mc.player.isOnLadder() && !mc.player.isInWater() && !mc.player.isPotionActive(Effects.BLINDNESS) && !mc.player.isPassenger() && targetEntity instanceof LivingEntity);
/* 124 */       flag2 = (flag2 && !mc.player.isSprinting());
/*     */       
/* 126 */       if (flag2)
/*     */       {
/* 128 */         f *= 1.5F;
/*     */       }
/*     */       
/* 131 */       f += f1;
/*     */       
/* 133 */       boolean flag3 = false;
/* 134 */       double d0 = (mc.player.distanceWalkedModified - mc.player.prevDistanceWalkedModified);
/*     */       
/* 136 */       if (flag && !flag2 && !flag1 && mc.player.isOnGround() && d0 < mc.player.getAIMoveSpeed()) {
/*     */         
/* 138 */         ItemStack itemstack = mc.player.getHeldItem(Hand.MAIN_HAND);
/*     */         
/* 140 */         if (itemstack.getItem() instanceof net.minecraft.item.SwordItem)
/*     */         {
/* 142 */           flag3 = true;
/*     */         }
/*     */       } 
/*     */       
/* 146 */       float f4 = 0.0F;
/* 147 */       boolean flag4 = false;
/* 148 */       int j = EnchantmentHelper.getFireAspectModifier((LivingEntity)mc.player);
/*     */       
/* 150 */       Vector3d vector3d = targetEntity.getMotion();
/* 151 */       float damage = simulateAttackFrom(target, DamageSource.causePlayerDamage((PlayerEntity)mc.player), f);
/*     */       
/* 153 */       return damage;
/*     */     } 
/* 155 */     return 0.0F;
/*     */   }
/*     */   
/*     */   private static float simulateAttackFrom(LivingEntity targetEntity, DamageSource source, float amount) {
/* 159 */     if (targetEntity.isInvulnerableTo(source))
/*     */     {
/* 161 */       return 0.0F;
/*     */     }
/* 163 */     if (targetEntity.getShouldBeDead())
/*     */     {
/* 165 */       return 0.0F;
/*     */     }
/* 167 */     if (source.isFireDamage() && targetEntity.isPotionActive(Effects.FIRE_RESISTANCE))
/*     */     {
/* 169 */       return 0.0F;
/*     */     }
/*     */ 
/*     */     
/* 173 */     float f = amount;
/*     */     
/* 175 */     boolean flag = false;
/* 176 */     float f1 = 0.0F;
/*     */     
/* 178 */     if (amount > 0.0F && targetEntity.canBlockDamageSource(source)) {
/*     */       
/* 180 */       f1 = amount;
/* 181 */       amount = 0.0F;
/*     */       
/* 183 */       flag = true;
/*     */     } 
/*     */     
/* 186 */     boolean flag1 = true;
/*     */     
/* 188 */     return simulateDamageEntity(targetEntity, source, amount);
/*     */   }
/*     */ 
/*     */   
/*     */   private static float simulateDamageEntity(LivingEntity target, DamageSource damageSrc, float damageAmount) {
/* 193 */     if (!target.isInvulnerableTo(damageSrc)) {
/*     */       
/* 195 */       damageAmount = target.applyArmorCalculations(damageSrc, damageAmount);
/* 196 */       damageAmount = target.applyPotionDamageCalculations(damageSrc, damageAmount);
/* 197 */       float f2 = Math.max(damageAmount, 0.0F);
/*     */       
/* 199 */       float f = damageAmount - f2;
/*     */       
/* 201 */       if (f2 != 0.0F)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 208 */         return f2 * 1.5F;
/*     */       }
/*     */     } 
/* 211 */     return 0.0F;
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\DamageUtility.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */