/*    */ package fun.rockstarity.api.helpers.math;
/*    */ 
/*    */ import java.util.Random;
/*    */ 
/*    */ public class FastRandom extends Random {
/*    */   private long seed;
/*    */   
/*    */   public FastRandom(long seed) {
/*  9 */     this.seed = seed;
/*    */   }
/*    */   
/*    */   public FastRandom() {
/* 13 */     this(System.nanoTime());
/*    */   }
/*    */ 
/*    */   
/*    */   protected int next(int bits) {
/* 18 */     this.seed ^= this.seed << 13L;
/* 19 */     this.seed ^= this.seed >>> 17L;
/* 20 */     this.seed ^= this.seed << 5L;
/* 21 */     return (int)(this.seed & (1L << bits) - 1L);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\FastRandom.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */