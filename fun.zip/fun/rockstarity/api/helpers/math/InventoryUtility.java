/*     */ package fun.rockstarity.api.helpers.math;
/*     */ 
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.events.Event;
/*     */ import fun.rockstarity.api.events.list.game.packet.EventSendPacket;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.player.PlayerEntity;
/*     */ import net.minecraft.inventory.container.ClickType;
/*     */ import net.minecraft.item.Item;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InventoryUtility
/*     */   implements IAccess
/*     */ {
/*     */   public static InventoryUtility getInstance() {
/*  20 */     return instance;
/*  21 */   } private static InventoryUtility instance = new InventoryUtility();
/*     */ 
/*     */   
/*     */   public static int findEmptySlot(boolean inHotBar) {
/*  25 */     int start = inHotBar ? 0 : 9;
/*  26 */     int end = inHotBar ? 9 : 45;
/*     */     
/*  28 */     for (int i = start; i < end; ) {
/*  29 */       if (!mc.player.inventory.getStackInSlot(i).isEmpty()) {
/*     */         i++;
/*     */         continue;
/*     */       } 
/*  33 */       return i;
/*     */     } 
/*  35 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void moveItem(int from, int to, boolean air) {
/*  40 */     if (from == to)
/*     */       return; 
/*  42 */     pickupItem(from, 0);
/*  43 */     pickupItem(to, 0);
/*  44 */     if (air) {
/*  45 */       pickupItem(from, 0);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void moveItemTime(int from, int to, boolean air, int time) {
/*  50 */     if (from == to)
/*     */       return; 
/*  52 */     pickupItem(from, 0, time);
/*  53 */     pickupItem(to, 0, time);
/*  54 */     if (air)
/*  55 */       pickupItem(from, 0, time); 
/*     */   }
/*     */   
/*     */   public static void moveItem(int from, int to) {
/*  59 */     if (from == to)
/*     */       return; 
/*  61 */     pickupItem(from, 0);
/*  62 */     pickupItem(to, 0);
/*  63 */     pickupItem(from, 0);
/*     */   }
/*     */   
/*     */   public static void pickupItem(int slot, int button) {
/*  67 */     mc.playerController.windowClick(0, slot, button, ClickType.PICKUP, (PlayerEntity)mc.player);
/*     */   }
/*     */   
/*     */   public static void pickupItem(int slot, int button, int time) {
/*  71 */     mc.playerController.windowClickFixed(0, slot, button, ClickType.PICKUP, (PlayerEntity)mc.player, time);
/*     */   }
/*     */   
/*     */   public int getAxeInInventory(boolean inHotBar) {
/*  75 */     int firstSlot = inHotBar ? 0 : 9;
/*  76 */     int lastSlot = inHotBar ? 9 : 36;
/*     */     
/*  78 */     for (int i = firstSlot; i < lastSlot; i++) {
/*  79 */       if (mc.player.inventory.getStackInSlot(i).getItem() instanceof net.minecraft.item.AxeItem) {
/*  80 */         return i;
/*     */       }
/*     */     } 
/*  83 */     return -1;
/*     */   }
/*     */   
/*     */   public int findBestSlotInHotBar() {
/*  87 */     int emptySlot = findEmptySlot();
/*  88 */     if (emptySlot != -1) {
/*  89 */       return emptySlot;
/*     */     }
/*  91 */     return findNonSwordSlot();
/*     */   }
/*     */ 
/*     */   
/*     */   private int findEmptySlot() {
/*  96 */     for (int i = 0; i < 9; i++) {
/*  97 */       if (mc.player.inventory.getStackInSlot(i).isEmpty() && mc.player.inventory.currentItem != i) {
/*  98 */         return i;
/*     */       }
/*     */     } 
/* 101 */     return -1;
/*     */   }
/*     */   
/*     */   private int findNonSwordSlot() {
/* 105 */     for (int i = 0; i < 9; i++) {
/* 106 */       if (!(mc.player.inventory.getStackInSlot(i).getItem() instanceof net.minecraft.item.SwordItem) && !(mc.player.inventory.getStackInSlot(i).getItem() instanceof net.minecraft.item.ElytraItem) && mc.player.inventory.currentItem != i) {
/* 107 */         return i;
/*     */       }
/*     */     } 
/* 110 */     return -1;
/*     */   }
/*     */   
/*     */   public static int getSlotInInventory(Item item) {
/* 114 */     int finalSlot = -1;
/* 115 */     for (int i = 0; i < 36; i++) {
/* 116 */       if (mc.player.inventory.getStackInSlot(i).getItem() == item) {
/* 117 */         finalSlot = i;
/*     */       }
/*     */     } 
/*     */     
/* 121 */     return finalSlot;
/*     */   }
/*     */   
/*     */   public int getSlotInInventoryOrHotbar(Item item, boolean inHotBar) {
/* 125 */     int firstSlot = inHotBar ? 0 : 9;
/* 126 */     int lastSlot = inHotBar ? 9 : 36;
/* 127 */     int finalSlot = -1;
/* 128 */     for (int i = firstSlot; i < lastSlot; i++) {
/* 129 */       if (mc.player.inventory.getStackInSlot(i).getItem() == item) {
/* 130 */         finalSlot = i;
/*     */       }
/*     */     } 
/*     */     
/* 134 */     return finalSlot;
/*     */   }
/*     */   
/*     */   public static int getSlotInInventoryOrHotbar() {
/* 138 */     int firstSlot = 0;
/* 139 */     int lastSlot = 9;
/* 140 */     int finalSlot = -1;
/* 141 */     for (int i = firstSlot; i < lastSlot; i++) {
/*     */       
/* 143 */       if (Block.getBlockFromItem(mc.player.inventory.getStackInSlot(i).getItem()) instanceof net.minecraft.block.SlabBlock) {
/* 144 */         finalSlot = i;
/*     */       }
/*     */     } 
/*     */     
/* 148 */     return finalSlot;
/*     */   }
/*     */   
/*     */   public static boolean doesHotbarHaveItem(Item item) {
/* 152 */     for (int i = 0; i < 9; i++) {
/* 153 */       mc.player.inventory.getStackInSlot(i);
/* 154 */       if (mc.player.inventory.getStackInSlot(i).getItem() == item) {
/* 155 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 159 */     return false;
/*     */   }
/*     */   
/*     */   public static int getItemIndex(Item item) {
/* 163 */     for (int i = 0; i < 45; i++) {
/* 164 */       if ((Minecraft.getInstance()).player.inventory.getStackInSlot(i).getItem() == item) {
/* 165 */         return i;
/*     */       }
/*     */     } 
/*     */     
/* 169 */     return -1;
/*     */   }
/*     */   
/*     */   public static class Hand {
/*     */     public static boolean isEnabled;
/*     */     private boolean isChangingItem;
/* 175 */     private int originalSlot = -1;
/*     */     
/*     */     public void onEvent(Event e) {
/* 178 */       if (e instanceof EventSendPacket) { EventSendPacket event = (EventSendPacket)e;
/* 179 */         if (event.getPacket() instanceof net.minecraft.network.play.server.SHeldItemChangePacket) {
/* 180 */           this.isChangingItem = true;
/*     */         } }
/*     */     
/*     */     }
/*     */     
/*     */     public void handleItemChange(boolean resetItem) {
/* 186 */       if (this.isChangingItem && this.originalSlot != -1) {
/* 187 */         isEnabled = true;
/* 188 */         IAccess.mc.player.inventory.currentItem = this.originalSlot;
/* 189 */         if (resetItem) {
/* 190 */           this.isChangingItem = false;
/* 191 */           this.originalSlot = -1;
/* 192 */           isEnabled = false;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     public void setOriginalSlot(int slot) {
/* 198 */       this.originalSlot = slot;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\InventoryUtility.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */