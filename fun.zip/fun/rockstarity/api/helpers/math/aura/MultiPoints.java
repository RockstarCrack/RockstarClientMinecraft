/*    */ package fun.rockstarity.api.helpers.math.aura;
/*    */ 
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.helpers.math.MathUtility;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Comparator;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ import net.minecraft.util.math.vector.Vector3d;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MultiPoints
/*    */   implements IAccess
/*    */ {
/*    */   private MultiPoints() {
/* 20 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*    */   } public static ArrayList<Vector3d> getPoints() {
/* 22 */     return points;
/* 23 */   } private static final ArrayList<Vector3d> points = new ArrayList<>();
/*    */   
/*    */   public static void update(LivingEntity target) {
/* 26 */     PlayerBox newBox = new PlayerBox(target);
/*    */     
/* 28 */     if (target.getBox() == null || !target.getBox().equals(newBox)) {
/* 29 */       target.setBox(newBox);
/* 30 */       updatePoints(target);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static void updatePoints(LivingEntity target) {
/* 35 */     float step = 0.19F;
/*    */     
/* 37 */     points.clear();
/*    */     
/* 39 */     for (double x = target.getPosX() - (target.getBox().getSize()).x / 2.0D; x < target.getPosX() + (target.getBox().getSize()).x / 2.0D; x += step) {
/* 40 */       double y; for (y = target.getPosY(); y < target.getPosY() + (target.getBox().getSize()).y; y += step) {
/* 41 */         double z; for (z = target.getPosZ() - (target.getBox().getSize()).z / 2.0D; z < target.getPosZ() + (target.getBox().getSize()).z / 2.0D; z += step) {
/* 42 */           points.add((new Vector3d(x, y, z)).subtract(target.getPositionVec()));
/*    */         }
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public static Vector3d getBestPoint(LivingEntity target) {
/* 49 */     if (points.isEmpty()) return null;
/*    */     
/* 51 */     ArrayList<Vector3d> visible = new ArrayList<>();
/*    */     
/* 53 */     for (Vector3d point : points) {
/* 54 */       point = point.add(target.getPositionVec());
/* 55 */       if (MathUtility.canSeen(point)) {
/* 56 */         visible.add(point);
/*    */       }
/*    */     } 
/* 59 */     visible.sort(Comparator.comparingDouble(MathUtility::getDistanceFromEye));
/*    */     
/* 61 */     return visible.isEmpty() ? null : visible.get(0);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\aura\MultiPoints.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */