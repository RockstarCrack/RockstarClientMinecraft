/*     */ package fun.rockstarity.api.helpers.math.aura.modes;
/*     */ 
/*     */ import fun.rockstarity.api.helpers.math.MathUtility;
/*     */ import fun.rockstarity.api.helpers.math.VectorUtility;
/*     */ import fun.rockstarity.api.helpers.math.aura.AuraUtility;
/*     */ import fun.rockstarity.api.helpers.math.aura.Rotation;
/*     */ import fun.rockstarity.api.helpers.math.aura.RotationMode;
/*     */ import fun.rockstarity.api.helpers.player.Player;
/*     */ import fun.rockstarity.api.modules.settings.list.Mode;
/*     */ import fun.rockstarity.client.modules.combat.Aura;
/*     */ import net.minecraft.block.Blocks;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.LivingEntity;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.vector.Vector2f;
/*     */ import net.minecraft.util.math.vector.Vector3d;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpookyRotation
/*     */   extends RotationMode
/*     */ {
/*  41 */   private final Vector2f rotateVector = new Vector2f(0.0F, 0.0F); public Vector2f getRotateVector() { return this.rotateVector; }
/*     */   
/*     */   public SpookyRotation(Mode parent) {
/*  44 */     super(parent, "Альтернативная");
/*     */   }
/*     */ 
/*     */   
/*     */   public void update(LivingEntity target) {
/*  49 */     Aura aura = (Aura)rock.getModules().get(Aura.class);
/*  50 */     if (target != null) {
/*  51 */       Vector3d vec = VectorUtility.getBestVector(target, 0.0F);
/*  52 */       this.rotateVector.x = mc.player.rotationYawHead; this.rotateVector.y = mc.player.rotationPitchHead;
/*     */       
/*  54 */       float shortestYawPath = (float)(((Math.toDegrees(Math.atan2(vec.z, vec.x)) - 90.0D - this.rotation.x) % 360.0D + 540.0D) % 360.0D - 180.0D);
/*  55 */       float yawToTarget = this.rotateVector.x + shortestYawPath;
/*  56 */       float pitchToTarget = (float)-Math.toDegrees(Math.atan2(vec.y, Math.hypot(vec.z, vec.x)));
/*     */       
/*  58 */       float yawDelta = MathHelper.wrapDegrees(yawToTarget - this.rotateVector.x);
/*  59 */       float pitchDelta = MathHelper.wrapDegrees(pitchToTarget - this.rotateVector.y);
/*     */       
/*  61 */       float speed = AuraUtility.getSens(MathUtility.randomNew(0.6D, 0.8D));
/*  62 */       float testCountSpeed = AuraUtility.getSens(MathUtility.randomNew(130.0D, 155.0D));
/*  63 */       float rayCaster = MathUtility.rayTraceWithBlock(aura.getRange().get(), this.rotateVector.x, this.rotateVector.y, (Entity)mc.player, (Entity)target, false) ? 0.4F : 1.0F;
/*     */       
/*  65 */       float clampYaw = Math.min(Math.abs(yawDelta), testCountSpeed) * speed;
/*  66 */       yawDelta = (yawDelta > 0.0F) ? clampYaw : -clampYaw;
/*     */ 
/*     */ 
/*     */       
/*  70 */       boolean check = (Player.collideWith(target) && (stalin(target) || (Player.getBlock(0.0D, 2.0D, 0.0D) != Blocks.AIR && Player.getBlock(0.0D, -1.0D, 0.0D) != Blocks.AIR && Player.getBlock(0.0D, 2.0D, 0.0D) != Blocks.WATER && Player.getBlock(0.0D, -1.0D, 0.0D) != Blocks.WATER)));
/*     */       
/*  72 */       if (check) yawDelta /= 30.0F;
/*     */       
/*  74 */       float clampPitch = Math.min(Math.abs(pitchDelta), MathUtility.random(23.133D, 26.477D)) * speed / testCountSpeed * 90.0F * rayCaster;
/*  75 */       pitchDelta = (pitchDelta > 0.0F) ? clampPitch : -clampPitch;
/*     */       
/*  77 */       if (pitchDelta > 0.0F) pitchDelta += MathUtility.random(-0.826D, 0.459D);
/*     */       
/*  79 */       yawDelta = (AuraUtility.fixDeltaNonVanillaMouse(yawDelta, pitchDelta)).x;
/*  80 */       pitchDelta = (AuraUtility.fixDeltaNonVanillaMouse(yawDelta, pitchDelta)).y;
/*     */       
/*  82 */       float yaw = this.rotateVector.x + yawDelta;
/*  83 */       float pitch = MathHelper.clamp(this.rotateVector.y + pitchDelta, -90.0F, 90.0F);
/*     */       
/*  85 */       yaw = AuraUtility.correctRotation(yaw); pitch = AuraUtility.correctRotation(pitch);
/*     */       
/*  87 */       this.rotation.x = yaw; this.rotation.y = pitch;
/*  88 */       this.rotation = Rotation.correctRotation(this.rotation.x, this.rotation.y);
/*     */     } else {
/*  90 */       this.rotation = new Vector2f(mc.player.rotationYaw, mc.player.rotationPitch);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean stalin(LivingEntity target) {
/*  96 */     Vector3d pos = target.getPositionVec();
/*  97 */     AxisAlignedBB hitbox = target.getBoundingBox();
/*     */     
/*  99 */     float off = 0.05F;
/*     */     
/* 101 */     return (!isAir(hitbox.minX - off, pos.y, hitbox.minZ - off) || 
/* 102 */       !isAir(hitbox.maxX + off, pos.y, hitbox.minZ - off) || 
/* 103 */       !isAir(hitbox.minX - off, pos.y, hitbox.maxZ + off) || 
/* 104 */       !isAir(hitbox.maxX + off, pos.y, hitbox.maxZ + off));
/*     */   }
/*     */   
/*     */   private boolean isAir(double x, double y, double z) {
/* 108 */     return (mc.world.getBlockState(new BlockPos(x, y, z)).getBlock() == Blocks.AIR);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\aura\modes\SpookyRotation.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */