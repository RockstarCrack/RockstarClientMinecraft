/*     */ package fun.rockstarity.api.helpers.math.aura.modes;
/*     */ 
/*     */ import fun.rockstarity.api.helpers.game.Server;
/*     */ import fun.rockstarity.api.helpers.math.MathUtility;
/*     */ import fun.rockstarity.api.helpers.math.aura.IdealHitUtility;
/*     */ import fun.rockstarity.api.helpers.math.aura.Rotation;
/*     */ import fun.rockstarity.api.helpers.math.aura.RotationMode;
/*     */ import fun.rockstarity.api.helpers.player.FallingPlayer;
/*     */ import fun.rockstarity.api.modules.settings.list.Mode;
/*     */ import fun.rockstarity.api.render.animation.Animation;
/*     */ import fun.rockstarity.api.render.animation.Easing;
/*     */ import fun.rockstarity.api.render.animation.infinity.InfinityAnimation;
/*     */ import fun.rockstarity.client.modules.combat.Aura;
/*     */ import net.minecraft.entity.LivingEntity;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.vector.Vector2f;
/*     */ import net.minecraft.util.math.vector.Vector3d;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FunTimeRotation
/*     */   extends RotationMode
/*     */ {
/*  35 */   private final Animation xAnim = (new Animation()).setSpeed(300).setEasing(Easing.BOTH_CIRC); public Animation getXAnim() { return this.xAnim; }
/*  36 */    private final Animation yAnim = (new Animation()).setSpeed(300).setEasing(Easing.BOTH_CIRC); public Animation getYAnim() { return this.yAnim; }
/*     */   
/*  38 */   private final InfinityAnimation pitchAnim = new InfinityAnimation(); public InfinityAnimation getPitchAnim() { return this.pitchAnim; }
/*  39 */    private Vector2f additional = Vector2f.ZERO; public Vector2f getAdditional() { return this.additional; }
/*     */   
/*     */   public FunTimeRotation(Mode parent) {
/*  42 */     super(parent, "FunTime Snap");
/*     */   }
/*     */ 
/*     */   
/*     */   public void update(LivingEntity target) {
/*  47 */     Aura aura = (Aura)rock.getModules().get(Aura.class);
/*     */     
/*  49 */     this.xAnim.setSpeed(700);
/*  50 */     this.yAnim.setSpeed(500);
/*     */     
/*  52 */     this.xAnim.kuni();
/*  53 */     this.yAnim.kuni();
/*     */     
/*  55 */     Vector3d pos = mc.player.getEyePosition(0.0F);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     Vector3d fastPoint = (target == null) ? Vector3d.ZERO : new Vector3d(MathHelper.clamp(pos.x, (target.getBoundingBox()).minX, (target.getBoundingBox()).maxX), MathHelper.clamp(pos.y, (target.getBoundingBox()).minY, (target.getBoundingBox()).maxY), MathHelper.clamp(pos.z, 
/*  67 */           (target.getBoundingBox()).minZ, 
/*  68 */           (target.getBoundingBox()).maxZ));
/*     */ 
/*     */ 
/*     */     
/*  72 */     Vector2f rot = (target == null) ? new Vector2f(0.0F, mc.player.rotationPitch) : get(aura.getMultipoint().get() ? fastPoint : target.getPositionVec().add(0.0D, (target.getHeight() / 2.0F), 0.0D));
/*     */     
/*  74 */     if (target != null) {
/*  75 */       if (!aura.isSnapTick() && (((!FallingPlayer.fromPlayer(mc.player).findFall(IdealHitUtility.getNewFallDistance(target)) || mc.player.isOnGround()) && !aura.canCritical()) || !aura.getAttackTimer().passed(300L))) {
/*  76 */         rot.x = this.xAnim.get() * 40.0F - 20.0F;
/*  77 */         rot.y += this.yAnim.get() * 15.0F - 7.0F;
/*     */       }
/*  79 */       else if (Server.isFT() && aura.isSnapTick()) {
/*  80 */         rot.y += MathUtility.random(5.0D, 30.0D);
/*  81 */         rot.x += MathUtility.random(5.0D, 10.0D);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*  86 */     this.rotation.x = mc.player.rotationYaw + MathUtility.step(this.rotation.x - mc.player.rotationYaw, rot.x, MathUtility.random(80.0D, 85.0D));
/*  87 */     this.rotation.y = this.pitchAnim.animate(rot.y, MathUtility.randomInt(100, 150));
/*  88 */     this.rotation = Rotation.correctRotation(this.rotation.x, this.rotation.y);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector2f get(Vector3d target) {
/*  94 */     Vector3d vec = target;
/*  95 */     double posX = vec.getX() - mc.player.getPosX();
/*  96 */     double posY = vec.getY() - mc.player.getPosY() + mc.player.getEyeHeight();
/*  97 */     double posZ = vec.getZ() - mc.player.getPosZ();
/*  98 */     double sqrt = MathHelper.sqrt(posX * posX + posZ * posZ);
/*  99 */     float yaw = (float)(Math.atan2(posZ, posX) * 180.0D / Math.PI) - 90.0F;
/* 100 */     float pitch = (float)-(Math.atan2(posY, sqrt) * 180.0D / Math.PI);
/*     */     
/* 102 */     float shortestYawPath = ((yaw - mc.player.rotationYaw) % 360.0F + 540.0F) % 360.0F - 180.0F;
/* 103 */     yaw = shortestYawPath;
/*     */     
/* 105 */     return new Vector2f(yaw, pitch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset(int reason) {
/* 117 */     Aura aura = (Aura)rock.getModules().get(Aura.class);
/*     */     
/* 119 */     if (aura.getTarget() != null || reason == 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\aura\modes\FunTimeRotation.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */