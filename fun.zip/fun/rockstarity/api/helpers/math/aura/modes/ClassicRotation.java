/*     */ package fun.rockstarity.api.helpers.math.aura.modes;
/*     */ 
/*     */ import fun.rockstarity.api.binds.Bindable;
/*     */ import fun.rockstarity.api.helpers.math.MathUtility;
/*     */ import fun.rockstarity.api.helpers.math.aura.Rotation;
/*     */ import fun.rockstarity.api.helpers.math.aura.RotationMode;
/*     */ import fun.rockstarity.api.helpers.player.Bypass;
/*     */ import fun.rockstarity.api.modules.settings.list.CheckBox;
/*     */ import fun.rockstarity.api.modules.settings.list.Mode;
/*     */ import fun.rockstarity.api.modules.settings.list.Slider;
/*     */ import fun.rockstarity.api.render.animation.infinity.RotationAnimation;
/*     */ import fun.rockstarity.client.modules.combat.Aura;
/*     */ import net.minecraft.entity.LivingEntity;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.vector.Vector2f;
/*     */ import net.minecraft.util.math.vector.Vector3d;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassicRotation
/*     */   extends RotationMode
/*     */ {
/*  36 */   private final Mode mode = new Mode((Bindable)this, "Наводка"); public Mode getMode() { return this.mode; }
/*  37 */    private final Mode.Element classic = new Mode.Element(this.mode, "Обычная"); public Mode.Element getClassic() { return this.classic; }
/*  38 */    private final Mode.Element snap = new Mode.Element(this.mode, "Снап"); public Mode.Element getSnap() { return this.snap; }
/*     */   
/*  40 */   private final CheckBox fullpacket = (new CheckBox((Bindable)this, "Абуз 1.17+")).hide(() -> Boolean.valueOf((!Bypass.via() || !get() || this.classic.get()))); public CheckBox getFullpacket() { return this.fullpacket; }
/*     */   
/*  42 */   private final Mode speedMode = new Mode((Bindable)this, "Режим скорости"); public Mode getSpeedMode() { return this.speedMode; }
/*  43 */    private final Mode.Element fast = new Mode.Element(this.speedMode, "Моментальная"); public Mode.Element getFast() { return this.fast; }
/*  44 */    private final Mode.Element staticSpeed = new Mode.Element(this.speedMode, "Статичная"); public Mode.Element getStaticSpeed() { return this.staticSpeed; }
/*  45 */    private final Mode.Element formula = new Mode.Element(this.speedMode, "Формула"); public Mode.Element getFormula() { return this.formula; }
/*     */   
/*  47 */   private final Slider speedX = (new Slider((Bindable)this, "Скорость по X")).min(1.0F).max(200.0F).inc(1.0F).set(40.0F).desc("Скорость по yaw/x/горизонтали").hide(() -> Boolean.valueOf((this.fast.get() || this.formula.get()))); public Slider getSpeedX() { return this.speedX; }
/*  48 */    private final Slider speedY = (new Slider((Bindable)this, "Скорость по Y")).min(1.0F).max(200.0F).inc(1.0F).set(40.0F).desc("Скорость по pitch/y/вертикали").hide(() -> Boolean.valueOf(this.fast.get())); public Slider getSpeedY() { return this.speedY; }
/*     */   
/*  50 */   private Vector2f prev = Vector2f.ZERO; public Vector2f getPrev() { return this.prev; }
/*  51 */    private final RotationAnimation interp = new RotationAnimation(); public RotationAnimation getInterp() { return this.interp; }
/*     */   
/*     */   public ClassicRotation(Mode parent) {
/*  54 */     super(parent, "Классическая");
/*     */   }
/*     */ 
/*     */   
/*     */   public void update(LivingEntity target) {
/*  59 */     this.prev = this.rotation.copy();
/*     */     
/*  61 */     Aura aura = (Aura)rock.getModules().get(Aura.class);
/*     */     
/*  63 */     if (target == null || (this.snap.get() && (!aura.canCritical() || !aura.getAttackTimer().passed(300L)))) {
/*  64 */       int speed = 220;
/*  65 */       this.interp.animate(new Vector2f(mc.player.rotationYaw, mc.player.rotationPitch), speed, speed);
/*  66 */       this.rotation = new Vector2f(this.interp.getYaw(), this.interp.getPitch());
/*     */     } else {
/*  68 */       Vector3d pos = mc.player.getEyePosition(0.0F);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  79 */       Vector3d fastPoint = new Vector3d(MathHelper.clamp(pos.x, (target.getBoundingBox()).minX, (target.getBoundingBox()).maxX), MathHelper.clamp(pos.y, (target.getBoundingBox()).minY, (target.getBoundingBox()).maxY), MathHelper.clamp(pos.z, 
/*  80 */             (target.getBoundingBox()).minZ, 
/*  81 */             (target.getBoundingBox()).maxZ));
/*     */ 
/*     */       
/*  84 */       Vector2f rot = Rotation.get((aura.getMultipoint().get() || !aura.getAdditional().get()) ? fastPoint : target.getEyePosition(0.0F));
/*     */       
/*  86 */       if (this.fast.get()) {
/*  87 */         this.rotation = rot;
/*     */       } else {
/*  89 */         float shortestYawPath = ((rot.x - this.interp.getYaw()) % 360.0F + 540.0F) % 360.0F - 180.0F;
/*  90 */         float targetYaw = this.interp.getYaw() + shortestYawPath;
/*  91 */         float targetPitch = rot.y;
/*     */         
/*  93 */         this.rotation = this.interp.animate(new Vector2f(targetYaw, targetPitch), (int)yawSpeed(Math.abs(this.interp.getYaw() - targetYaw)), (int)(100.0F - this.speedY.get()));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private float yawSpeed(float diff) {
/*  99 */     if (this.staticSpeed.get()) {
/* 100 */       return 100.0F - this.speedX.get();
/*     */     }
/*     */     
/* 103 */     return MathHelper.clamp(diff, 
/*     */         
/* 105 */         MathUtility.randomInt(1, 50), 
/* 106 */         MathUtility.randomInt(150, 200));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset(int reason) {
/* 112 */     float shortestYawPath = ((mc.player.rotationYaw - this.rotation.x) % 360.0F + 540.0F) % 360.0F - 180.0F;
/*     */     
/* 114 */     if (reason > 0)
/* 115 */       mc.player.rotationYaw = this.rotation.x + shortestYawPath; 
/* 116 */     this.prev = new Vector2f(mc.player.prevRotationYaw, mc.player.prevRotationPitch);
/*     */     
/* 118 */     super.reset(reason);
/*     */     
/* 120 */     int speed = (reason > 0) ? 240 : 1;
/* 121 */     this.interp.animate(this.rotation, speed, speed);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\aura\modes\ClassicRotation.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */