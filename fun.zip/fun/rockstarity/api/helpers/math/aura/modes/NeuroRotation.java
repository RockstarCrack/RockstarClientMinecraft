/*    */ package fun.rockstarity.api.helpers.math.aura.modes;
/*    */ 
/*    */ import fun.rockstarity.api.binds.Bindable;
/*    */ import fun.rockstarity.api.helpers.math.aura.RotationMode;
/*    */ import fun.rockstarity.api.helpers.math.aura.ai.AIPredictor;
/*    */ import fun.rockstarity.api.modules.settings.list.Mode;
/*    */ import fun.rockstarity.api.modules.settings.list.Slider;
/*    */ import fun.rockstarity.client.modules.combat.Aura;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ import net.minecraft.util.math.vector.Vector2f;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NeuroRotation
/*    */   extends RotationMode
/*    */ {
/* 27 */   private final Mode mode = new Mode((Bindable)this, "Наводка"); public Mode getMode() { return this.mode; }
/* 28 */    private final Mode.Element classic = new Mode.Element(this.mode, "Обычная"); public Mode.Element getClassic() { return this.classic; }
/* 29 */    private final Mode.Element snap = new Mode.Element(this.mode, "Снап"); public Mode.Element getSnap() { return this.snap; }
/*    */   
/* 31 */   private final Mode model = (new Mode((Bindable)this, "Модель")).desc("Выберите модель нейросети"); public Mode getModel() { return this.model; }
/* 32 */    private final Mode.Element all = new Mode.Element(this.model, "Общее"); public Mode.Element getAll() { return this.all; }
/* 33 */    private final Mode.Element artem = new Mode.Element(this.model, "ConeTin"); public Mode.Element getArtem() { return this.artem; }
/* 34 */    private final Mode.Element powen = new Mode.Element(this.model, "Powen"); public Mode.Element getPowen() { return this.powen; }
/* 35 */    private final Mode.Element zahar = new Mode.Element(this.model, "Захар"); public Mode.Element getZahar() { return this.zahar; }
/* 36 */    private final Mode.Element alex = new Mode.Element(this.model, "saintits"); public Mode.Element getAlex() { return this.alex; }
/* 37 */    private final Mode.Element egor = new Mode.Element(this.model, "Егор"); public Mode.Element getEgor() { return this.egor; }
/* 38 */    private final Mode.Element nikita = new Mode.Element(this.model, "Damage"); public Mode.Element getNikita() { return this.nikita; }
/* 39 */    private final Mode.Element akhmedx = new Mode.Element(this.model, "akhmedx"); public Mode.Element getAkhmedx() { return this.akhmedx; }
/* 40 */    private final Mode.Element stas = new Mode.Element(this.model, "Стас"); public Mode.Element getStas() { return this.stas; }
/*    */   
/* 42 */   private final Slider speedX = (new Slider((Bindable)this, "Скорость по X")).min(1.0F).max(100.0F).inc(1.0F).set(40.0F).desc("Скорость по yaw/x"); public Slider getSpeedX() { return this.speedX; }
/* 43 */    private final Slider speedY = (new Slider((Bindable)this, "Скорость по Y")).min(1.0F).max(100.0F).inc(1.0F).set(40.0F).desc("Скорость по pitch/y"); public Slider getSpeedY() { return this.speedY; }
/*    */   
/* 45 */   private Vector2f prev = Vector2f.ZERO; public Vector2f getPrev() { return this.prev; }
/*    */   
/*    */   public NeuroRotation(Mode parent) {
/* 48 */     super(parent, "Нейро");
/*    */   }
/*    */ 
/*    */   
/*    */   public void update(LivingEntity target) {
/* 53 */     this.prev = this.rotation.copy();
/*    */     
/* 55 */     Aura aura = (Aura)rock.getModules().get(Aura.class);
/*    */     
/* 57 */     if (target == null || (this.snap.get() && (!aura.canCritical() || !aura.getAttackTimer().passed(300L)))) {
/* 58 */       int speed = 220;
/* 59 */       AIPredictor.interp.animate(new Vector2f(mc.player.rotationYaw, mc.player.rotationPitch), speed, speed);
/* 60 */       this.rotation = new Vector2f(AIPredictor.interp.getYaw(), AIPredictor.interp.getPitch());
/*    */     } else {
/* 62 */       this.rotation = AIPredictor.predict(target, this.rotation, this.prev, new Vector2f(100.0F - this.speedX.get(), 100.0F - this.speedY.get()));
/*    */     } 
/* 64 */     this.rotation.y = MathHelper.clamp(this.rotation.y, -90.0F, 90.0F);
/*    */   }
/*    */ 
/*    */   
/*    */   public void reset(int reason) {
/* 69 */     float shortestYawPath = ((mc.player.rotationYaw - this.rotation.x) % 360.0F + 540.0F) % 360.0F - 180.0F;
/*    */     
/* 71 */     if (reason > 0)
/* 72 */       mc.player.rotationYaw = this.rotation.x + shortestYawPath; 
/* 73 */     this.prev = new Vector2f(mc.player.prevRotationYaw, mc.player.prevRotationPitch);
/*    */     
/* 75 */     super.reset(reason);
/*    */     
/* 77 */     int speed = (reason > 0) ? 240 : 1;
/* 78 */     AIPredictor.interp.animate(this.rotation, speed, speed);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\aura\modes\NeuroRotation.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */