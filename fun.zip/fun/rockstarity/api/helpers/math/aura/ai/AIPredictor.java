/*     */ package fun.rockstarity.api.helpers.math.aura.ai;
/*     */ 
/*     */ import ai.catboost.CatBoostModel;
/*     */ import ai.catboost.CatBoostPredictions;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.events.Event;
/*     */ import fun.rockstarity.api.events.list.player.EventAttack;
/*     */ import fun.rockstarity.api.helpers.game.Server;
/*     */ import fun.rockstarity.api.helpers.math.MathUtility;
/*     */ import fun.rockstarity.api.helpers.math.TimerUtility;
/*     */ import fun.rockstarity.api.helpers.math.aura.Rotation;
/*     */ import fun.rockstarity.api.helpers.math.aura.modes.NeuroRotation;
/*     */ import fun.rockstarity.api.helpers.player.Player;
/*     */ import fun.rockstarity.api.helpers.render.Converter;
/*     */ import fun.rockstarity.api.helpers.system.ThreadManager;
/*     */ import fun.rockstarity.api.render.animation.infinity.RotationAnimation;
/*     */ import fun.rockstarity.api.render.ui.alerts.Alert;
/*     */ import fun.rockstarity.api.render.ui.alerts.AlertType;
/*     */ import fun.rockstarity.client.modules.combat.Aura;
/*     */ import net.minecraft.block.Blocks;
/*     */ import net.minecraft.client.entity.player.ClientPlayerEntity;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.LivingEntity;
/*     */ import net.minecraft.entity.Pose;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.vector.Vector2f;
/*     */ import net.minecraft.util.math.vector.Vector3d;
/*     */ 
/*     */ public final class AIPredictor implements IAccess {
/*     */   static boolean loading;
/*     */   public static String LAST_MODEL;
/*     */   
/*     */   private AIPredictor() {
/*  36 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*     */   }
/*     */   
/*     */   private static CatBoostModel yawModel;
/*     */   private static CatBoostModel pitchModel;
/*  41 */   private static final TimerUtility timer = new TimerUtility();
/*     */   
/*     */   private static LivingEntity target;
/*  44 */   public static RotationAnimation interp = new RotationAnimation();
/*  45 */   private static final TimerUtility collide = new TimerUtility();
/*     */   
/*     */   public static void updateModel(String model) {
/*  48 */     if ((LAST_MODEL == null || LAST_MODEL != model) && !loading) {
/*  49 */       ThreadManager.run(() -> {
/*     */             loading = true;
/*     */             Alert alert = rock.getAlertHandler().alert("Загружаю модель", AlertType.WAIT);
/*     */             try {
/*     */               String link = "http://localhost/api/v1/files/premium/ai/rotations/" + model + "_";
/*     */               System.out.println(link + "yaw.cbm");
/*     */               yawModel = CatBoostModel.loadModel(Converter.getInputStream(link + "yaw.cbm"));
/*     */               pitchModel = CatBoostModel.loadModel(Converter.getInputStream(link + "pitch.cbm"));
/*     */               LAST_MODEL = model;
/*     */               rock.getAlertHandler().alert("Модель загружена", AlertType.SUCCESS);
/*  59 */             } catch (Exception e) {
/*     */               e.printStackTrace();
/*     */               rock.getAlertHandler().alert("Ошибка при загрузке модели", AlertType.ERROR);
/*     */             } 
/*     */             alert.hide();
/*     */             loading = false;
/*     */           });
/*     */     }
/*     */   }
/*     */   
/*     */   public static void onEvent(Event event) {
/*  70 */     if (event instanceof EventAttack) { EventAttack e = (EventAttack)event;
/*     */       
/*  72 */       timer.reset(); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Vector2f predict(LivingEntity target, Vector2f current, Vector2f prev, Vector2f speed) {
/*     */     try {
/*  92 */       ClientPlayerEntity player = mc.player;
/*  93 */       Aura aura = (Aura)rock.getModules().get(Aura.class);
/*  94 */       NeuroRotation neuro = aura.getNeuro();
/*     */       
/*  96 */       float offsetX = aura.getAdditional().get() ? aura.getOffset().getX() : 0.0F;
/*  97 */       float offsetY = aura.getAdditional().get() ? aura.getOffset().getY() : 0.0F;
/*     */       
/*  99 */       if (neuro.getAll().get()) {
/* 100 */         offsetX += 5.0F;
/* 101 */       } else if (neuro.getArtem().get()) {
/* 102 */         offsetX += 15.0F;
/* 103 */       } else if (neuro.getStas().get() || neuro.getPowen().get()) {
/* 104 */         offsetX += 5.0F;
/* 105 */       } else if (neuro.getZahar().get()) {
/* 106 */         offsetX += mc.player.isOnGround() ? 0.0F : -5.0F;
/* 107 */       } else if (neuro.getAlex().get()) {
/* 108 */         offsetX += -10.0F;
/* 109 */       } else if (neuro.getEgor().get()) {
/* 110 */         offsetX += 5.0F;
/* 111 */       } else if (neuro.getNikita().get()) {
/* 112 */         offsetX += 5.0F;
/* 113 */       } else if (neuro.getAkhmedx().get()) {
/* 114 */         offsetX -= 7.0F;
/*     */       } 
/*     */       
/* 117 */       float yawDiff = MathHelper.wrapDegrees((Rotation.get(target.getPositionVec())).x + offsetX);
/* 118 */       float pitchDiff = MathHelper.clamp((Rotation.get(target.getPositionVec())).y + offsetY, -90.0F, 90.0F);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 128 */       RotationData data = new RotationData(Math.abs(current.x - prev.x), Math.abs(current.y - prev.y), 0.0F, pitchDiff, 2000.0F, player.getDistance((Entity)target), player.isOnGround() ? 1.0F : 0.0F, (player.isElytraFlying() || player.isSwimming()) ? 1.0F : 0.0F, MathHelper.wrapDegrees(current.x) - yawDiff, current.y);
/*     */ 
/*     */       
/* 131 */       float[] features = getCurrentFeatures(data);
/*     */ 
/*     */       
/* 134 */       String[] categoricals = { String.valueOf(data.onGround), String.valueOf(data.miniHitbox) };
/*     */ 
/*     */ 
/*     */       
/* 138 */       CatBoostPredictions predictedYaw = yawModel.predict(features, categoricals);
/* 139 */       CatBoostPredictions predictedPitch = pitchModel.predict(features, categoricals);
/*     */ 
/*     */       
/* 142 */       float shortestYawPath = (float)(((predictedYaw.get(0, 0) + yawDiff - interp.getYaw()) % 360.0D + 540.0D) % 360.0D - 180.0D);
/* 143 */       float targetYaw = interp.getYaw() + shortestYawPath;
/* 144 */       float targetPitch = (float)predictedPitch.get(0, 0);
/*     */       
/* 146 */       if (mc.player.getPosY() > target.getPosY() + target.getHeight()) {
/* 147 */         targetPitch = (Rotation.get(target.getPositionVec().add(0.0D, target.getHeight(), 0.0D))).y;
/*     */       }
/*     */       
/* 150 */       if (mc.player.getPosY() + 1.0D < target.getPosY()) {
/* 151 */         targetPitch = (Rotation.get(target.getPositionVec().add(0.0D, 0.5D, 0.0D))).y;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 166 */       if (Server.is("spooky")) {
/* 167 */         if (Player.getBlock(0.0D, 2.0D, 0.0D) != Blocks.AIR || Player.getBlock(0.0D, 3.0D, 0.0D) != Blocks.AIR || mc.world.getBlock(target.getPosition().add(0, 2, 0)) != Blocks.AIR || mc.world.getBlock(target.getPosition().add(0, 3, 0)) != Blocks.AIR);
/*     */ 
/*     */ 
/*     */         
/* 171 */         targetPitch = (Rotation.get(target.getPositionVec())).y;
/*     */         
/* 173 */         if (Player.collideWith(target, 3.0F)) {
/* 174 */           targetPitch = (target.isOnGround() ? 34 : 24) + (2.3F - mc.player.getDistance((Entity)target)) * 20.0F - mc.player.fallDistance * 40.0F - 5.0F + 10.0F * aura.getRandomFactor();
/* 175 */           if (mc.player.getPosY() + 1.0D < target.getPosY()) {
/* 176 */             targetPitch -= 30.0F;
/*     */           }
/* 178 */           speed.y = MathUtility.random(50.0D, 100.0D) - 10.0F + 20.0F * aura.getRandomFactor();
/*     */         } 
/*     */         
/* 181 */         speed.x = yawSpeed(Math.abs(interp.getYaw() - targetYaw)) / 100.0F * speed.x - 10.0F + 20.0F * aura.getRandomFactor();
/*     */         
/* 183 */         if (!aura.getAttackTimer().passed(200L));
/*     */ 
/*     */ 
/*     */         
/* 187 */         if (mc.player.fallDistance > 0.0F) {
/* 188 */           speed.x *= 2.0F;
/* 189 */           speed.y *= 2.0F;
/*     */         } else {
/* 191 */           speed.y /= 2.0F;
/*     */         } 
/*     */         
/* 194 */         if (Player.collideWith(target));
/*     */ 
/*     */ 
/*     */         
/* 198 */         if (Player.collideWith(target) && (stalin(target) || (Player.getBlock(0.0D, 2.0D, 0.0D) != Blocks.AIR && Player.getBlock(0.0D, -1.0D, 0.0D) != Blocks.AIR && Player.getBlock(0.0D, 2.0D, 0.0D) != Blocks.WATER && Player.getBlock(0.0D, -1.0D, 0.0D) != Blocks.WATER))) {
/*     */           
/* 200 */           targetPitch = (float)(64.0D + (mc.player.getPosY() - (target.getPositionVec()).y + 1.0D) * (5.0D + Math.sin(((mc.player.ticksExisted % 100 / 5) * 1924.12F)) * 35.0D) - 5.0D + (10.0F * aura.getRandomFactor()));
/* 201 */           speed.x *= MathUtility.random(30.0D, 50.0D);
/*     */         } else {
/*     */           
/* 204 */           collide.reset();
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 252 */       if (mc.player.isSwimming()) {
/* 253 */         targetPitch = (Rotation.get(target.getPositionVec().add(0.0D, (target.getHeight() / 2.0F), 0.0D))).y;
/* 254 */         speed = new Vector2f(MathUtility.random(350.0D, 200.0D), MathUtility.random(350.0D, 200.0D));
/*     */       } 
/*     */ 
/*     */       
/* 258 */       if (timer.getElapsed() < 300L && Server.is("spooky")) {
/*     */         
/* 260 */         targetPitch += MathUtility.random(5.0D, 10.0D);
/* 261 */         targetYaw += MathUtility.random(5.0D, 10.0D);
/*     */         
/* 263 */         speed = new Vector2f(speed.x * 1.7F, speed.y * 1.7F);
/*     */       } 
/*     */       
/* 266 */       if (timer.getElapsed() < 300L && Server.isFT()) {
/*     */         
/* 268 */         targetPitch += MathUtility.random(5.0D, 30.0D);
/* 269 */         targetYaw += MathUtility.random(5.0D, 10.0D);
/*     */         
/* 271 */         speed = new Vector2f(speed.x * 1.7F, speed.y * 1.7F);
/*     */       } 
/*     */       
/* 274 */       targetPitch = MathHelper.clamp(targetPitch, -90.0F, 90.0F);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 279 */       interp.animate(new Vector2f(targetYaw, targetPitch), (int)speed.x, (int)speed.y);
/*     */       
/* 281 */       Vector2f rot = Rotation.correctRotation(interp.getYaw(), interp.getPitch());
/* 282 */       rot.y = MathHelper.clamp(rot.y, -90.0F, 90.0F);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 320 */       if (!MathUtility.canSeen(target.getPositionVec()) && Server.is("spooky")) {
/* 321 */         target.setPose(Pose.STANDING);
/* 322 */         target.getPosition().add(MathUtility.random(-0.15000000596046448D, 0.15000000596046448D), target.getBoundingBox().getYSize(), MathUtility.random(-0.15000000596046448D, 0.15000000596046448D));
/*     */         
/* 324 */         Vector3d vec = target.getPositionVec().add(0.0D, MathHelper.clamp(mc.player.getPosYEye() - target.getPosY(), 0.0D, target.getHeight() * mc.player.getEyePosition(0.0F).distanceTo(target.getPositionVec()) / 3.0D), 0.0D).subtract(mc.player.getEyePosition(1.0F));
/*     */         
/* 326 */         float yawToTarget = (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(vec.z, vec.x)) - 90.0D);
/* 327 */         float pitchToTarget = (float)-Math.toDegrees(Math.atan2(vec.y, Math.hypot(vec.x, vec.z)));
/*     */         
/* 329 */         float yawDelta = MathHelper.wrapDegrees(yawToTarget - rot.x);
/* 330 */         float pitchDelta = MathHelper.wrapDegrees(pitchToTarget - rot.y);
/*     */ 
/*     */         
/* 333 */         float clampedYaw = Math.min(Math.max(Math.abs(yawDelta), 1.0F), 90.0F);
/* 334 */         float clampedPitch = Math.min(Math.max(Math.abs(pitchDelta), 1.0F), 90.0F);
/* 335 */         float yaw = rot.x + ((yawDelta > 0.0F) ? clampedYaw : -clampedYaw) + MathUtility.random(-3.0D, 3.0D);
/* 336 */         float pitch = MathHelper.clamp(rot.y + ((pitchDelta > 0.0F) ? clampedPitch : -clampedPitch), -70.0F, 70.0F) + MathUtility.random(-3.0D, 3.0D);
/*     */         
/* 338 */         if (!aura.isSnapTick() && (!aura.canCritical() || !aura.getAttackTimer().passed(300L))) {
/* 339 */           yaw = rot.x + (mc.player.rotationYaw - rot.x) / 2.0F + MathUtility.random(-3.0D, 3.0D);
/* 340 */           pitch = MathHelper.clamp(rot.y + (mc.player.rotationPitch - rot.y) / 2.0F, -70.0F, 70.0F) + MathUtility.random(-3.0D, 3.0D);
/*     */         } 
/*     */         
/* 343 */         float gcd = Rotation.getGCDValue();
/* 344 */         yaw -= (yaw - rot.x) % gcd;
/* 345 */         pitch -= (pitch - rot.y) % gcd;
/* 346 */         pitch += 8.0F;
/*     */         
/* 348 */         rot = new Vector2f(yaw, pitch);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 371 */       return rot;
/* 372 */     } catch (Exception exception) {
/*     */       
/* 374 */       return current;
/*     */     } 
/*     */   }
/*     */   private static float yawSpeed(float diff) {
/* 378 */     return MathHelper.clamp(diff, 
/*     */         
/* 380 */         MathUtility.randomInt(40, 50), 
/* 381 */         MathUtility.randomInt(450, 300));
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean stalin(LivingEntity target) {
/* 386 */     Vector3d pos = target.getPositionVec();
/* 387 */     AxisAlignedBB hitbox = target.getBoundingBox();
/*     */     
/* 389 */     float off = 0.05F;
/*     */     
/* 391 */     return (!isAir(hitbox.minX - off, pos.y, hitbox.minZ - off) || 
/* 392 */       !isAir(hitbox.maxX + off, pos.y, hitbox.minZ - off) || 
/* 393 */       !isAir(hitbox.minX - off, pos.y, hitbox.maxZ + off) || 
/* 394 */       !isAir(hitbox.maxX + off, pos.y, hitbox.maxZ + off));
/*     */   }
/*     */   
/*     */   private static boolean isAir(double x, double y, double z) {
/* 398 */     return (mc.world.getBlockState(new BlockPos(x, y, z)).getBlock() == Blocks.AIR);
/*     */   }
/*     */   
/*     */   private static float[] getCurrentFeatures(RotationData data) {
/* 402 */     return new float[] { data.yawDelta, data.pitchDelta, data.targetYaw, data.targetPitch, data.sinceAttack, data.distance, data.onGround, data.miniHitbox };
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\aura\ai\AIPredictor.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */