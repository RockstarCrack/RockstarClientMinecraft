/*   */ package fun.rockstarity.api.helpers.math.aura.ai;
/*   */ 
/*   */ public class RotationData {
/*   */   public RotationData(float yawDelta, float pitchDelta, float targetYaw, float targetPitch, float sinceAttack, float distance, float onGround, float miniHitbox, float yaw, float pitch) {
/* 5 */     this.yawDelta = yawDelta; this.pitchDelta = pitchDelta; this.targetYaw = targetYaw; this.targetPitch = targetPitch; this.sinceAttack = sinceAttack; this.distance = distance; this.onGround = onGround; this.miniHitbox = miniHitbox; this.yaw = yaw; this.pitch = pitch;
/*   */   }
/*   */   
/*   */   public final float yawDelta;
/*   */   public final float pitchDelta;
/*   */   public final float targetYaw;
/*   */   public final float targetPitch;
/*   */   public final float sinceAttack;
/*   */   public final float distance;
/*   */   public final float onGround;
/*   */   public final float miniHitbox;
/*   */   public final float yaw;
/*   */   public final float pitch;
/*   */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\aura\ai\RotationData.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */