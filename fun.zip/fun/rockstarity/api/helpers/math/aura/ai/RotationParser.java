/*     */ package fun.rockstarity.api.helpers.math.aura.ai;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.GsonBuilder;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParser;
/*     */ import com.google.gson.stream.JsonReader;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.events.Event;
/*     */ import fun.rockstarity.api.events.list.game.packet.EventReceivePacket;
/*     */ import fun.rockstarity.api.events.list.player.EventAttack;
/*     */ import fun.rockstarity.api.helpers.math.TimerUtility;
/*     */ import fun.rockstarity.api.helpers.math.aura.Rotation;
/*     */ import fun.rockstarity.api.helpers.system.ThreadManager;
/*     */ import fun.rockstarity.api.secure.Debugger;
/*     */ import it.unimi.dsi.fastutil.objects.ObjectArrayList;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.LivingEntity;
/*     */ import net.minecraft.network.IPacket;
/*     */ import net.minecraft.network.play.server.SPlaySoundEffectPacket;
/*     */ import net.minecraft.util.SoundEvents;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import org.json.JSONArray;
/*     */ import org.json.JSONException;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RotationParser
/*     */   implements IAccess
/*     */ {
/*     */   private RotationParser() {
/*  45 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 202 */   public static final List<RotationData> rotations = (List<RotationData>)new ObjectArrayList(20);
/*     */   private static LivingEntity target;
/* 204 */   private static final TimerUtility timer = new TimerUtility();
/* 205 */   private static final TimerUtility attackTimer = new TimerUtility();
/*     */   
/*     */   public static void onEvent(Event event) {
/* 208 */     if (event instanceof EventAttack) { EventAttack e = (EventAttack)event;
/* 209 */       target = e.getTarget();
/* 210 */       timer.reset();
/* 211 */       attackTimer.reset(); }
/*     */ 
/*     */     
/* 214 */     if (event instanceof EventReceivePacket) { EventReceivePacket e = (EventReceivePacket)event; IPacket iPacket = e.getPacket(); if (iPacket instanceof SPlaySoundEffectPacket) { SPlaySoundEffectPacket play = (SPlaySoundEffectPacket)iPacket; if (play
/* 215 */           .getSound() == SoundEvents.ENTITY_PLAYER_ATTACK_CRIT || play.getSound() == SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP) {
/* 216 */           ThreadManager.run(() -> {
/*     */                 if (!attackTimer.passed(200L)) {
/*     */                   JSONObject blockData = new JSONObject();
/*     */                   JSONArray rotationDataArray = getObjects((LivingEntity)mc.player);
/*     */                   try {
/*     */                     blockData.put("rotationData", rotationDataArray);
/* 222 */                   } catch (JSONException ex) {
/*     */                     throw new RuntimeException(ex);
/*     */                   }  File pluginFolder = new File("C:/Rockstar/"); if (!pluginFolder.exists())
/*     */                     pluginFolder.mkdirs();  File file = new File(pluginFolder, "rotation_data.json"); JsonObject jsonObject = new JsonObject(); try {
/*     */                     FileReader fileReader = new FileReader(file);
/*     */                     
/*     */                     try { JsonReader reader = new JsonReader(fileReader);
/*     */                       reader.setLenient(true);
/*     */                       JsonElement element = (new JsonParser()).parse(reader);
/*     */                       if (element.isJsonObject())
/*     */                         jsonObject = element.getAsJsonObject(); 
/*     */                       fileReader.close(); }
/* 234 */                     catch (Throwable throwable) { try { fileReader.close(); } catch (Throwable throwable1)
/*     */                       { throwable.addSuppressed(throwable1); }
/*     */ 
/*     */ 
/*     */                       
/*     */                       throw throwable; }
/*     */                   
/* 241 */                   } catch (IOException e2) {
/*     */                     jsonObject = new JsonObject();
/*     */                   }  int blockNumber = jsonObject.size() + 1; jsonObject.add(String.valueOf(blockNumber), (new JsonParser()).parse(blockData.toString())); try {
/*     */                     FileWriter fileWriter = new FileWriter(file); 
/*     */                     try { Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
/*     */                       gson.toJson((JsonElement)jsonObject, fileWriter);
/*     */                       Debugger.overlay("Сохраняю информацию о ротации");
/*     */                       fileWriter.close(); }
/* 249 */                     catch (Throwable throwable) { try { fileWriter.close(); } catch (Throwable throwable1)
/*     */                       { throwable.addSuppressed(throwable1); }
/*     */                        throw throwable; }
/*     */                   
/* 253 */                   } catch (IOException e2) {
/*     */                     e2.printStackTrace();
/*     */                   } 
/*     */                 } 
/*     */                 rotations.clear();
/*     */               });
/*     */         } }
/*     */        }
/*     */     
/* 262 */     if (event instanceof fun.rockstarity.api.events.list.player.EventUpdate && target != null) {
/* 263 */       parse(target);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void parse(LivingEntity player) {
/* 268 */     if (timer.passed(2000L) || player.isDead() || !mc.world.getPlayers().contains(player))
/*     */       return; 
/* 270 */     float yawDiff = MathHelper.wrapDegrees((Rotation.get(target.getPositionVec())).x);
/* 271 */     float pitchDiff = MathHelper.wrapDegrees((Rotation.get(target.getPositionVec())).y);
/*     */     
/* 273 */     rotations.add(new RotationData(
/* 274 */           Math.abs(player.rotationYaw - player.prevRotationYaw), Math.abs(player.rotationPitch - player.prevRotationPitch), yawDiff, pitchDiff, 
/*     */           
/* 276 */           (float)timer.getElapsed(), player
/* 277 */           .getDistance((Entity)target), 
/* 278 */           player.isOnGround() ? 1.0F : 0.0F, 
/* 279 */           (player.isElytraFlying() || player.isSwimming()) ? 1.0F : 0.0F, 
/* 280 */           MathHelper.wrapDegrees(mc.player.rotationYaw), mc.player.rotationPitch));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static JSONArray getObjects(LivingEntity player) {
/* 286 */     JSONArray rotationDataArray = new JSONArray();
/*     */     try {
/* 288 */       for (RotationData data : rotations) {
/* 289 */         JSONObject blockData = new JSONObject();
/* 290 */         blockData.put("yawDelta", data.yawDelta);
/* 291 */         blockData.put("pitchDelta", data.pitchDelta);
/* 292 */         blockData.put("targetYaw", data.targetYaw);
/* 293 */         blockData.put("targetPitch", data.targetPitch);
/* 294 */         blockData.put("sinceAttack", data.sinceAttack);
/* 295 */         blockData.put("distance", data.distance);
/* 296 */         blockData.put("onGround", data.onGround);
/* 297 */         blockData.put("miniHitbox", data.miniHitbox);
/*     */         
/* 299 */         blockData.put("yaw", data.yaw);
/* 300 */         blockData.put("pitch", data.pitch);
/* 301 */         rotationDataArray.put(blockData);
/*     */       } 
/* 303 */     } catch (Exception e) {
/* 304 */       e.printStackTrace();
/*     */     } 
/* 306 */     return rotationDataArray;
/*     */   }
/*     */ 
/*     */   
/*     */   public static float normalizeTo360(float angle) {
/* 311 */     angle %= 360.0F;
/* 312 */     if (angle < 0.0F) {
/* 313 */       angle += 360.0F;
/*     */     }
/* 315 */     return angle;
/*     */   }
/*     */   
/*     */   public static float normalizeTo180(float angle) {
/* 319 */     angle = normalizeTo360(angle);
/* 320 */     if (angle > 180.0F) {
/* 321 */       angle -= 360.0F;
/*     */     }
/* 323 */     return angle;
/*     */   }
/*     */   
/*     */   public static float getAngleDifference(float angle1, float angle2) {
/* 327 */     float normalizedAngle1 = normalizeTo360(angle1);
/* 328 */     float normalizedAngle2 = normalizeTo360(angle2);
/*     */     
/* 330 */     float difference = normalizedAngle1 - normalizedAngle2;
/*     */     
/* 332 */     return normalizeTo180(difference);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\aura\ai\RotationParser.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */