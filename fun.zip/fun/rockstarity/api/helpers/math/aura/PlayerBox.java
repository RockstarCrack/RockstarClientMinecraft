/*    */ package fun.rockstarity.api.helpers.math.aura;
/*    */ 
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraft.util.math.vector.Vector3d;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlayerBox
/*    */ {
/*    */   private final LivingEntity entity;
/*    */   private Vector3d size;
/*    */   
/*    */   public LivingEntity getEntity() {
/* 17 */     return this.entity; } public Vector3d getSize() {
/* 18 */     return this.size;
/*    */   }
/*    */   public PlayerBox(LivingEntity entity) {
/* 21 */     this.entity = entity;
/* 22 */     AxisAlignedBB box = this.entity.getBoundingBox();
/*    */     
/* 24 */     this.size = new Vector3d(box.maxX - box.minX, box.maxY - box.minY, box.maxZ - box.minZ);
/*    */   }
/*    */   
/*    */   public boolean equals(PlayerBox info) {
/* 28 */     if (this == info)
/* 29 */       return true; 
/* 30 */     if (!(info instanceof PlayerBox)) {
/* 31 */       return false;
/*    */     }
/* 33 */     return this.size.equals(info.size);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\aura\PlayerBox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */