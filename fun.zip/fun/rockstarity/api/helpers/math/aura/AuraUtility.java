/*     */ package fun.rockstarity.api.helpers.math.aura;
/*     */ 
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.connection.globals.ClientAPI;
/*     */ import fun.rockstarity.api.helpers.game.Server;
/*     */ import fun.rockstarity.api.helpers.math.MathUtility;
/*     */ import fun.rockstarity.api.helpers.player.Player;
/*     */ import fun.rockstarity.api.render.ui.alerts.AlertType;
/*     */ import fun.rockstarity.api.sounds.Sound;
/*     */ import fun.rockstarity.client.modules.combat.Aura;
/*     */ import fun.rockstarity.client.modules.combat.BackTrack;
/*     */ import fun.rockstarity.client.modules.combat.ElytraTarget;
/*     */ import fun.rockstarity.client.modules.other.Sounds;
/*     */ import it.unimi.dsi.fastutil.objects.ObjectIterator;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.enchantment.Enchantments;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.LivingEntity;
/*     */ import net.minecraft.entity.ai.attributes.Attributes;
/*     */ import net.minecraft.entity.ai.attributes.ModifiableAttributeInstance;
/*     */ import net.minecraft.entity.player.PlayerEntity;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.SwordItem;
/*     */ import net.minecraft.network.IPacket;
/*     */ import net.minecraft.network.play.client.CAnimateHandPacket;
/*     */ import net.minecraft.network.play.client.CHeldItemChangePacket;
/*     */ import net.minecraft.util.Hand;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.vector.Vector2f;
/*     */ import net.minecraft.util.math.vector.Vector3d;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AuraUtility
/*     */   implements IAccess
/*     */ {
/*     */   private AuraUtility() {
/*  51 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*     */   }
/*     */   public static LivingEntity calculateTarget(Vector3d from, double range, boolean players, boolean mobs, boolean invisibles, boolean naked, boolean bots, boolean friends, boolean users, boolean fovsort, boolean distantsort, boolean healthSort, boolean damageTakenSort, boolean damageDealtSort) {
/*  54 */     return calculateTarget(from, range, players, mobs, invisibles, naked, bots, friends, users, fovsort, distantsort, healthSort, damageTakenSort, damageDealtSort, 180.0F, mc.player.rotationYaw, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public static LivingEntity calculateTarget(Vector3d from, double range, boolean players, boolean mobs, boolean invisibles, boolean naked, boolean bots, boolean friends, boolean users, boolean fovsort, boolean distantsort, boolean healthSort, boolean damageTakenSort, boolean damageDealtSort, float fov, float rotation, boolean walls) {
/*  59 */     ArrayList<LivingEntity> targets = new ArrayList<>();
/*  60 */     List<String> targetHandlerTargets = rock.getTargetHandler().getTarget();
/*     */     
/*  62 */     for (ObjectIterator<Entity> objectIterator = mc.world.getAllEntities().iterator(); objectIterator.hasNext(); ) { Entity ent = objectIterator.next();
/*  63 */       if (isValidTarget(ent, players, mobs, invisibles, naked, bots, friends, users, fov, rotation)) {
/*     */         
/*  65 */         double dist = from.add(new Vector3d(0.0D, mc.player.getEyeHeight(), 0.0D)).distanceTo(getPoint((LivingEntity)ent, true));
/*  66 */         if (dist >= range || (
/*  67 */           !walls && !MathUtility.canSeen(getPoint((LivingEntity)ent))))
/*  68 */           continue;  targets.add((LivingEntity)ent);
/*     */       }  }
/*     */ 
/*     */ 
/*     */     
/*  73 */     targets.sort((e1, e2) -> Boolean.compare(targetHandlerTargets.contains(e2.getName().getString()), targetHandlerTargets.contains(e1.getName().getString())));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  78 */     if (fovsort) {
/*  79 */       targets.sort(Comparator.comparingDouble(Player::getAngle));
/*  80 */     } else if (distantsort) {
/*  81 */       Objects.requireNonNull(mc.player); targets.sort(Comparator.comparingDouble(mc.player::getDistance));
/*  82 */     } else if (healthSort) {
/*  83 */       targets.sort(Comparator.comparingDouble(LivingEntity::getHealth));
/*  84 */     } else if (damageTakenSort) {
/*  85 */       targets.sort(Comparator.comparingDouble(AuraUtility::estimateTargetDPS));
/*  86 */     } else if (damageDealtSort) {
/*  87 */       targets.sort(Comparator.comparingDouble(AuraUtility::estimateMyDPSOnTarget));
/*     */     } 
/*     */     
/*  90 */     return targets.isEmpty() ? null : targets.get(0);
/*     */   }
/*     */   
/*     */   public static LivingEntity calculateCreeper(double range) {
/*  94 */     ArrayList<LivingEntity> targets = new ArrayList<>();
/*  95 */     List<String> targetHandlerTargets = rock.getTargetHandler().getTarget();
/*     */     
/*  97 */     for (ObjectIterator<Entity> objectIterator = mc.world.getAllEntities().iterator(); objectIterator.hasNext(); ) { Entity ent = objectIterator.next();
/*  98 */       if (isValidTarget(ent) && Math.abs(mc.player.getPosY() - ent.getPosY()) < 4.0D) {
/*     */         
/* 100 */         double dist = mc.player.getPositionVec().add(new Vector3d(0.0D, mc.player.getEyeHeight(), 0.0D)).distanceTo(getPoint((LivingEntity)ent, true));
/* 101 */         if (dist < range) {
/* 102 */           targets.add((LivingEntity)ent);
/*     */         }
/*     */       }  }
/*     */ 
/*     */     
/* 107 */     targets.sort((e1, e2) -> Boolean.compare(targetHandlerTargets.contains(e2.getName().getString()), targetHandlerTargets.contains(e1.getName().getString())));
/* 108 */     Objects.requireNonNull(mc.player); targets.sort(Comparator.comparingDouble(mc.player::getDistance));
/*     */     
/* 110 */     return targets.isEmpty() ? null : targets.get(0);
/*     */   }
/*     */   
/*     */   public static boolean isValidTarget(Entity ent, boolean players, boolean mobs, boolean invisibles, boolean naked, boolean bots, boolean friends, boolean users) {
/* 114 */     return isValidTarget(ent, players, mobs, invisibles, naked, bots, friends, users, 180.0F, mc.player.rotationYaw);
/*     */   }
/*     */   
/*     */   public static boolean isValidTarget(Entity ent, boolean players, boolean mobs, boolean invisibles, boolean naked, boolean bots, boolean friends, boolean users, float fov, float rotation) {
/* 118 */     if ((!(ent instanceof PlayerEntity) || !players) && ((!(ent instanceof net.minecraft.entity.MobEntity) && !(ent instanceof net.minecraft.entity.passive.AnimalEntity) && !(ent instanceof net.minecraft.entity.merchant.villager.VillagerEntity)) || !mobs)) {
/* 119 */       return false;
/*     */     }
/* 121 */     if (Player.getAngle(ent, rotation) > fov) return false; 
/* 122 */     if (ent instanceof PlayerEntity && !naked && ((LivingEntity)ent).getTotalArmorValue() == 0) return false; 
/* 123 */     if (((LivingEntity)ent).getHealth() == 0.0F) return false; 
/* 124 */     if (((LivingEntity)ent).getTotalArmorValue() == 0 && ent.isInvisible() && !invisibles) return false; 
/* 125 */     if (ent == mc.player) return false; 
/* 126 */     if (rock.getFriendsHandler().isFriend(ent.getName().getString()) && !friends) return false; 
/* 127 */     if (Server.isRW() && !bots && BotUtility.isRWBot((LivingEntity)ent)) return false; 
/* 128 */     if (ClientAPI.isRockstar(ent.getName().getString()) && !users && !rock.getTargetHandler().isTarget(ent)) return false; 
/* 129 */     if (ent instanceof PlayerEntity && (((LivingEntity)ent).getHealth() == 0.0F || (!ent.getUniqueID().equals(PlayerEntity.getOfflineUUID(ent.getName().getString())) && ent.getEntityId() != -1337)) && !bots) {
/* 130 */       return false;
/*     */     }
/* 132 */     return true;
/*     */   }
/*     */   
/*     */   public static boolean isValidTarget(Entity ent) {
/* 136 */     return ent instanceof net.minecraft.entity.monster.CreeperEntity;
/*     */   }
/*     */   
/*     */   private static double estimateTargetDPS(LivingEntity entity) {
/* 140 */     if (!(entity instanceof PlayerEntity)) return 0.0D;
/*     */     
/* 142 */     PlayerEntity player = (PlayerEntity)entity;
/* 143 */     ItemStack weapon = player.getHeldItemMainhand();
/* 144 */     double baseDamage = 1.0D;
/*     */     
/* 146 */     if (weapon.getItem() instanceof SwordItem) {
/* 147 */       baseDamage = ((SwordItem)weapon.getItem()).getAttackDamage();
/*     */       
/* 149 */       int sharpnessLevel = EnchantmentHelper.getEnchantmentLevel(Enchantments.SHARPNESS, weapon);
/* 150 */       if (sharpnessLevel > 0) {
/* 151 */         baseDamage += 1.0D + (sharpnessLevel - 1) * 0.5D;
/*     */       }
/*     */     } 
/*     */     
/* 155 */     return baseDamage;
/*     */   }
/*     */   
/*     */   private static double estimateMyDPSOnTarget(LivingEntity entity) {
/* 159 */     double armor = entity.getTotalArmorValue();
/* 160 */     double armorToughness = 0.0D;
/*     */     
/* 162 */     ModifiableAttributeInstance toughnessAttr = entity.getAttribute(Attributes.ARMOR_TOUGHNESS);
/* 163 */     if (toughnessAttr != null) {
/* 164 */       armorToughness = toughnessAttr.getValue();
/*     */     }
/*     */     
/* 167 */     ItemStack myWeapon = mc.player.getHeldItemMainhand();
/* 168 */     double baseDamage = 1.0D;
/*     */     
/* 170 */     if (myWeapon.getItem() instanceof SwordItem) {
/* 171 */       baseDamage = ((SwordItem)myWeapon.getItem()).getAttackDamage();
/*     */       
/* 173 */       int sharpnessLevel = EnchantmentHelper.getEnchantmentLevel(Enchantments.SHARPNESS, myWeapon);
/* 174 */       if (sharpnessLevel > 0) {
/* 175 */         baseDamage += 1.0D + (sharpnessLevel - 1) * 0.5D;
/*     */       }
/*     */     } 
/*     */     
/* 179 */     double reduction = Math.min(20.0D, armor * 0.04D);
/* 180 */     double reducedDamage = baseDamage * (1.0D - reduction / 25.0D);
/*     */     
/* 182 */     return reducedDamage;
/*     */   }
/*     */   
/*     */   public static Vector3d getPoint(LivingEntity target) {
/* 186 */     return getPoint(target, false);
/*     */   }
/*     */   
/*     */   public static Vector3d getPoint(LivingEntity target, boolean silent) {
/* 190 */     if (target == null) return Vector3d.ZERO; 
/* 191 */     double hitboxSize = (target.getBoundingBox()).maxY - (target.getBoundingBox()).minY;
/* 192 */     double additional = hitboxSize / 2.0D;
/* 193 */     Vector3d pos = getBestPoint(mc.player.getEyePosition(mc.timer.renderPartialTicks), target, silent);
/*     */     
/* 195 */     if (Server.is("infinity")) {
/* 196 */       pos.y = (target.getPositionVec().add(0.0D, additional + (((int)mc.player.getPosY() > (int)pos.y) ? (hitboxSize / 4.0D) : 0.0D), 0.0D)).y;
/*     */     }
/* 198 */     if (((BackTrack)rock.getModules().get(BackTrack.class)).get() && !target.getBacktrack().isEmpty() && mc.player.getDistance((Entity)target) < 10.0F) {
/* 199 */       for (BackTrack.Position track : target.getBacktrack()) {
/* 200 */         Vector3d trackPos = getBestPoint(mc.player.getEyePosition(mc.timer.renderPartialTicks), target).subtract(target.getPositionVec()).add(track.getPos());
/* 201 */         trackPos.y = (target.getPositionVec().add(0.0D, additional, 0.0D)).y;
/*     */         
/* 203 */         if (distanceTo(trackPos) < distanceTo(pos)) {
/* 204 */           pos = trackPos;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 209 */     return pos;
/*     */   }
/*     */   
/*     */   public static Vector3d getBestPoint(Vector3d pos, LivingEntity entity) {
/* 213 */     return getBestPoint(pos, entity, false);
/*     */   }
/*     */   
/*     */   public static Vector3d getBestPoint(Vector3d pos, LivingEntity entity, boolean silent) {
/* 217 */     if (entity == null) return Vector3d.ZERO;
/*     */     
/* 219 */     Aura aura = (Aura)rock.getModules().get(Aura.class);
/*     */     
/* 221 */     ElytraTarget elytraTarget = (ElytraTarget)rock.getModules().get(ElytraTarget.class);
/*     */     
/* 223 */     if (elytraTarget.get() && elytraTarget.getResolver().get()) {
/* 224 */       Vector3d pos1 = elytraTarget.getPos(entity);
/* 225 */       return ((pos1 == null) ? entity.getPositionVec() : pos1).add(0.0D, entity.getEyeHeight(), 0.0D);
/*     */     } 
/*     */     
/* 228 */     double safePoint = 0.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 238 */     Vector3d fastPoint = new Vector3d(MathHelper.clamp(pos.x, (entity.getBoundingBox()).minX + safePoint, (entity.getBoundingBox()).maxX - safePoint), MathHelper.clamp(pos.y, (entity.getBoundingBox()).minY + safePoint, (entity.getBoundingBox()).maxY - safePoint), MathHelper.clamp(pos.z, 
/* 239 */           (entity.getBoundingBox()).minZ + safePoint, 
/* 240 */           (entity.getBoundingBox()).maxZ - safePoint));
/*     */ 
/*     */     
/* 243 */     if (!aura.getWalls().get() && !silent && !MathUtility.canSeen(fastPoint)) {
/* 244 */       MultiPoints.update(entity);
/* 245 */       Vector3d bestPoint = MultiPoints.getBestPoint(entity);
/*     */       
/* 247 */       if (bestPoint != null) {
/* 248 */         return bestPoint;
/*     */       }
/*     */     } 
/* 251 */     return fastPoint;
/*     */   }
/*     */   
/*     */   public static double distanceTo(Vector3d point) {
/* 255 */     return mc.player.getPositionVec().add(0.0D, mc.player.getEyeHeight(), 0.0D).distanceTo(point);
/*     */   }
/*     */   
/*     */   public static void tryBreakShield() {
/* 259 */     int axe = -1;
/* 260 */     for (int i = 0; i < 9; i++) {
/* 261 */       if (mc.player.inventory.getStackInSlot(i).getItem() instanceof net.minecraft.item.AxeItem) {
/* 262 */         axe = i;
/*     */       }
/*     */     } 
/*     */     
/* 266 */     if (axe >= 0) {
/* 267 */       LivingEntity target = ((Aura)rock.getModules().get(Aura.class)).getTarget();
/* 268 */       if (target instanceof PlayerEntity && target.isHandActive() && target.getActiveItemStack().getItem() instanceof net.minecraft.item.ShieldItem) {
/* 269 */         mc.player.connection.sendPacket((IPacket)new CHeldItemChangePacket(axe));
/* 270 */         mc.playerController.attackEntity((PlayerEntity)mc.player, (Entity)target);
/* 271 */         mc.player.connection.sendPacket((IPacket)new CAnimateHandPacket(Hand.MAIN_HAND));
/* 272 */         mc.player.connection.sendPacket((IPacket)new CHeldItemChangePacket(mc.player.inventory.currentItem));
/* 273 */         rock.getAlertHandler().alert("Сломали щит " + target.getName().getString(), AlertType.SUCCESS);
/* 274 */         target.breakShield = true;
/* 275 */         Sounds sounds = (Sounds)rock.getModules().get(Sounds.class);
/*     */         
/* 277 */         if (sounds.get() && sounds.getShieldbreak().get()) (new Sound("nastya/shield_breaked")).play(); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static float GENIUSCLAMPERR$$$(float delta, boolean yawValue) {
/* 283 */     float recDelta = Math.min(Math.abs(delta), 0.0013888889F * MathUtility.random(6.0D, 7.0D) * 150.0F * 120.0F / (yawValue ? true : 5));
/* 284 */     delta = (delta > 0.0F) ? recDelta : -recDelta;
/* 285 */     return delta;
/*     */   }
/*     */   
/*     */   public static Vector2f fixDeltaNonVanillaMouse(float delta, float secondDelta) {
/* 289 */     float value = (float)(MathUtility.random(0.1D, 0.8D) + Math.pow(MathUtility.random(-0.3D, 0.3D), 3.0D));
/* 290 */     if (Math.abs(delta) > 0.0F && Math.abs(secondDelta) == 0.0F) secondDelta += value; 
/* 291 */     if (Math.abs(secondDelta) > 0.0F && Math.abs(delta) == 0.0F) delta += value;
/*     */     
/* 293 */     return new Vector2f(delta, secondDelta);
/*     */   }
/*     */   
/*     */   public static float calculateCorrectYawOffset(float yaw, float rotateVector) {
/* 297 */     float direction = 50.0F * (1.0F - mc.player.getSwingProgress(1.0F));
/* 298 */     return MathHelper.clamp(rotateVector, yaw - direction, yaw + direction);
/*     */   }
/*     */   
/*     */   public static float calculateCorrectYawOffset(float yaw) {
/* 302 */     float direction = 50.0F * (1.0F - mc.player.getSwingProgress(1.0F));
/* 303 */     return MathHelper.clamp(yaw, yaw - direction, yaw + direction);
/*     */   }
/*     */   
/*     */   public static float getAngle(Entity entity) {
/* 307 */     double diffX = entity.getPosX() - mc.player.getPosX();
/* 308 */     double diffZ = entity.getPosZ() - mc.player.getPosZ();
/* 309 */     return (float)Math.abs(MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0D - mc.player.rotationYawHead));
/*     */   }
/*     */   
/*     */   public static float correctRotation(float rot) {
/* 313 */     rot = getSens(rot);
/* 314 */     rot -= rot % getGCDValue();
/*     */     
/* 316 */     return rot;
/*     */   }
/*     */   
/*     */   public static float getSens(float rotation) {
/* 320 */     return getDeltaMouse(rotation) * getGCDValue();
/*     */   }
/*     */   
/*     */   public static float getDeltaMouse(float delta) {
/* 324 */     return Math.round(delta / getGCDValue());
/*     */   }
/*     */   
/*     */   public static float getGCDValue() {
/* 328 */     double realGcd = mc.gameSettings.mouseSensitivity;
/* 329 */     double d4 = realGcd * 0.6000000238418579D + 0.20000000298023224D;
/* 330 */     return (float)(d4 * d4 * d4 * 8.0D * 0.15D);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\aura\AuraUtility.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */