/*     */ package fun.rockstarity.api.helpers.math.aura;
/*     */ 
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.helpers.game.Server;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.vector.Vector2f;
/*     */ import net.minecraft.util.math.vector.Vector3d;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Rotation
/*     */   implements IAccess
/*     */ {
/*     */   private Rotation() {
/*  23 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*     */   }
/*  25 */   public static float getYaw() { return yaw; } public static float getPitch() { return pitch; } public static float getBody() { return body; }
/*  26 */    private static float yaw = -1337.0F, pitch = -1337.0F, body = 0.0F;
/*     */   
/*     */   public static Vector3d getBestPoint(Vector3d pos, Entity entity) {
/*  29 */     if (Server.is("infinity")) {
/*  30 */       return entity.getPositionVec().add(0.0D, 1.0D, 0.0D);
/*     */     }
/*  32 */     return new Vector3d(
/*  33 */         MathHelper.clamp(pos.x, (entity.getBoundingBox()).minX, (entity.getBoundingBox()).maxX), 
/*  34 */         MathHelper.clamp(pos.y + mc.player.getEyeHeight(), (entity.getBoundingBox()).minY, (entity.getBoundingBox()).maxY), 
/*  35 */         MathHelper.clamp(pos.z, (entity.getBoundingBox()).minZ, (entity.getBoundingBox()).maxZ));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Vector2f correctRotation(float yaw, float pitch) {
/*  42 */     float gcd = getGCDValue();
/*  43 */     yaw -= yaw % gcd;
/*  44 */     pitch -= pitch % gcd;
/*     */     
/*  46 */     return new Vector2f(yaw, pitch);
/*     */   }
/*     */   
/*     */   public static float getGCDValue() {
/*  50 */     double realGcd = mc.gameSettings.mouseSensitivity;
/*  51 */     double d4 = realGcd * 0.6000000238418579D + 0.20000000298023224D;
/*  52 */     return (float)(d4 * d4 * d4 * 8.0D * 0.15D);
/*     */   }
/*     */   
/*     */   public static Vector2f get(Vector3d from, Vector3d target) {
/*  56 */     Vector3d vec = target;
/*  57 */     double posX = vec.getX() - from.getX();
/*  58 */     double posY = vec.getY() - from.getY();
/*  59 */     double posZ = vec.getZ() - from.getZ();
/*  60 */     double sqrt = MathHelper.sqrt(posX * posX + posZ * posZ);
/*  61 */     float yaw = (float)(Math.atan2(posZ, posX) * 180.0D / Math.PI) - 90.0F;
/*  62 */     float pitch = (float)-(Math.atan2(posY, sqrt) * 180.0D / Math.PI);
/*  63 */     float sens = (float)(Math.pow((mc.getGameSettings()).mouseSensitivity, 1.5D) * 0.05000000074505806D + 0.10000000149011612D);
/*  64 */     float pow = sens * sens * sens * 1.2F;
/*  65 */     yaw -= yaw % pow;
/*  66 */     pitch -= pitch % pow * sens;
/*  67 */     return new Vector2f(yaw, pitch);
/*     */   }
/*     */   
/*     */   public static Vector2f get(Vector3d target) {
/*  71 */     Vector3d vec = target;
/*  72 */     double posX = vec.getX() - mc.player.getPosX();
/*  73 */     double posY = vec.getY() - mc.player.getPosY() + mc.player.getEyeHeight();
/*  74 */     double posZ = vec.getZ() - mc.player.getPosZ();
/*  75 */     double sqrt = MathHelper.sqrt(posX * posX + posZ * posZ);
/*  76 */     float yaw = (float)(Math.atan2(posZ, posX) * 180.0D / Math.PI) - 90.0F;
/*  77 */     float pitch = (float)-(Math.atan2(posY, sqrt) * 180.0D / Math.PI);
/*  78 */     float sens = (float)(Math.pow((mc.getGameSettings()).mouseSensitivity, 1.5D) * 0.05000000074505806D + 0.10000000149011612D);
/*  79 */     float pow = sens * sens * sens * 1.2F;
/*  80 */     yaw -= yaw % pow;
/*  81 */     pitch -= pitch % pow * sens;
/*  82 */     return new Vector2f(yaw, pitch);
/*     */   }
/*     */   
/*     */   public static float getDirection() {
/*  86 */     float rotationYaw = mc.player.rotationYaw;
/*  87 */     float factor = 0.0F;
/*     */     
/*  89 */     boolean forwardKeyDown = (mc.getGameSettings()).keyBindForward.isKeyDown();
/*  90 */     boolean backKeyDown = (mc.getGameSettings()).keyBindBack.isKeyDown();
/*  91 */     boolean leftKeyDown = (mc.getGameSettings()).keyBindLeft.isKeyDown();
/*  92 */     boolean rightKeyDown = (mc.getGameSettings()).keyBindRight.isKeyDown();
/*  93 */     float forward = (forwardKeyDown == backKeyDown) ? 0.0F : (forwardKeyDown ? 1.0F : -1.0F);
/*  94 */     float strafe = (leftKeyDown == rightKeyDown) ? 0.0F : (leftKeyDown ? 1.0F : -1.0F);
/*     */     
/*  96 */     if (forward > 0.0F)
/*  97 */       factor = 1.0F; 
/*  98 */     if (forward < 0.0F) {
/*  99 */       factor = -1.0F;
/*     */     }
/* 101 */     if (factor == 0.0F) {
/* 102 */       if (strafe > 0.0F) {
/* 103 */         rotationYaw -= 90.0F;
/*     */       }
/* 105 */       if (strafe < 0.0F)
/* 106 */         rotationYaw += 90.0F; 
/*     */     } else {
/* 108 */       if (strafe > 0.0F) {
/* 109 */         rotationYaw -= 45.0F * factor;
/*     */       }
/* 111 */       if (strafe < 0.0F) {
/* 112 */         rotationYaw += 45.0F * factor;
/*     */       }
/*     */     } 
/* 115 */     if (factor < 0.0F) {
/* 116 */       rotationYaw -= 180.0F;
/*     */     }
/* 118 */     if (body < rotationYaw - 50.0F) body = rotationYaw - 50.0F; 
/* 119 */     if (body > rotationYaw + 50.0F) body = rotationYaw + 50.0F;
/*     */     
/* 121 */     return rotationYaw;
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\aura\Rotation.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */