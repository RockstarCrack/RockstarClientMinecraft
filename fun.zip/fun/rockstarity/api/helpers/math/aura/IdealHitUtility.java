/*     */ package fun.rockstarity.api.helpers.math.aura;
/*     */ 
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.helpers.game.Server;
/*     */ import fun.rockstarity.api.helpers.math.MathUtility;
/*     */ import fun.rockstarity.api.helpers.player.Player;
/*     */ import fun.rockstarity.client.modules.combat.Aura;
/*     */ import fun.rockstarity.client.modules.combat.Criticals;
/*     */ import fun.rockstarity.client.modules.combat.ElytraTarget;
/*     */ import net.minecraft.block.Blocks;
/*     */ import net.minecraft.entity.LivingEntity;
/*     */ import net.minecraft.item.Items;
/*     */ import net.minecraft.potion.Effects;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.vector.Vector3d;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class IdealHitUtility
/*     */   implements IAccess
/*     */ {
/*     */   private static boolean jumped;
/*     */   
/*     */   private IdealHitUtility() {
/*  33 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*     */   }
/*  35 */   public static void setJumped(boolean jumped) { IdealHitUtility.jumped = jumped; } public static boolean isJumped() { return jumped; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float getAICooldown() {
/*  42 */     if (mc.player.getHeldItemMainhand().getItem() == Items.AIR) {
/*  43 */       return 1.0F;
/*     */     }
/*     */     
/*  46 */     if (mc.player.isPotionActive(Effects.BLINDNESS) || mc.player
/*  47 */       .isPotionActive(Effects.LEVITATION) || mc.player
/*  48 */       .isPotionActive(Effects.SLOW_FALLING) || mc.player
/*  49 */       .isInLava() || mc.player
/*  50 */       .isInWater() || mc.player
/*  51 */       .isOnLadder() || mc.player
/*  52 */       .isPassenger() || 
/*  53 */       Player.isInWeb() || mc.player
/*  54 */       .isElytraFlying() || mc.player.abilities.isFlying || 
/*     */       
/*  56 */       !((Aura)rock.getModules().get(Aura.class)).getOnlyCrits().get())
/*     */     {
/*  58 */       return 0.944F;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  63 */     if (mc.player.getHeldItemMainhand().getItem() instanceof net.minecraft.item.AxeItem || mc.player.getHeldItemMainhand().getItem() instanceof net.minecraft.item.ShovelItem) return 0.99F;
/*     */     
/*  65 */     ElytraTarget elytraTarget = (ElytraTarget)rock.getModules().get(ElytraTarget.class);
/*     */     
/*  67 */     if (elytraTarget.get()) {
/*  68 */       return 1.0F;
/*     */     }
/*  70 */     return 0.944F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float getAIFallDistance() {
/*  81 */     if (Server.is("spooky")) {
/*  82 */       return (((Aura)rock.getModules().get(Aura.class)).getAttacks() % Math.round(MathUtility.random(4.0D, 10.0D)) == 0) ? MathUtility.random(0.15D, 0.23D) : 0.0F;
/*     */     }
/*     */     
/*  85 */     return 0.0F;
/*     */   }
/*     */   
/*     */   public static float getNewFallDistance(LivingEntity target) {
/*  89 */     if (((Aura)rock.getModules().get(Aura.class)).getCritsBypass().get()) {
/*  90 */       return MathUtility.random(0.0D, 0.30000001192092896D);
/*     */     }
/*  92 */     Aura aura = (Aura)rock.getModules().get(Aura.class);
/*     */     
/*  94 */     if (Server.is("spooky")) {
/*  95 */       int attacks = ((Aura)rock.getModules().get(Aura.class)).getAttacks();
/*     */       
/*  97 */       if (Player.collideWith(target) && (Player.getBlock(0.0D, 2.0D, 0.0D) == Blocks.AIR || Player.getBlock(0.0D, -1.0D, 0.0D) == Blocks.AIR || !(mc.getGameSettings()).keyBindJump.isKeyDown())) {
/*  98 */         return (aura.getFdCount() >= 10) ? 0.3F : 0.15F;
/*     */       }
/*     */       
/* 101 */       return (aura.getFdCount() >= 10) ? 0.15F : 0.0F;
/*     */     } 
/*     */     
/* 104 */     if (((Criticals)rock.getModules().get(Criticals.class)).get() && Server.isRW()) {
/* 105 */       return 1.0F;
/*     */     }
/*     */     
/* 108 */     return 0.0F;
/*     */   }
/*     */   
/*     */   public static boolean canAIFall() {
/* 112 */     Aura aura = (Aura)rock.getModules().get(Aura.class);
/*     */     
/* 114 */     if (Player.getBlock(0.0D, 2.0D, 0.0D) != Blocks.AIR && Player.getBlock(0.0D, -1.0D, 0.0D) != Blocks.AIR && Server.is("spooky") && aura.getFdCount() > 8) {
/* 115 */       return false;
/*     */     }
/*     */     
/* 118 */     return ((Player.getBlock(0.0D, 3.0D, 0.0D) == Blocks.AIR && Player.getBlock(0.0D, 2.0D, 0.0D) == Blocks.AIR && Player.getBlock(0.0D, 1.0D, 0.0D) == Blocks.AIR) || mc.player.fallDistance < (
/* 119 */       (Player.getBlock(0.0D, 2.0D, 0.0D) != Blocks.AIR) ? 0.08F : 0.6F) || mc.player.fallDistance > 1.2F);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isBlockBelow() {
/* 124 */     Vector3d pos = mc.player.getPositionVec().add(0.0D, -1.0D, 0.0D);
/* 125 */     AxisAlignedBB hitbox = mc.player.getBoundingBox();
/*     */     
/* 127 */     float off = 0.15F;
/*     */     
/* 129 */     return (!isAir(hitbox.minX - off, pos.y, hitbox.minZ - off) || 
/* 130 */       !isAir(hitbox.maxX + off, pos.y, hitbox.minZ - off) || 
/* 131 */       !isAir(hitbox.minX - off, pos.y, hitbox.maxZ + off) || 
/* 132 */       !isAir(hitbox.maxX + off, pos.y, hitbox.maxZ + off));
/*     */   }
/*     */   
/*     */   private static boolean isAir(double x, double y, double z) {
/* 136 */     return (mc.world.getBlockState(new BlockPos(x, y, z)).getBlock() == Blocks.AIR);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\aura\IdealHitUtility.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */