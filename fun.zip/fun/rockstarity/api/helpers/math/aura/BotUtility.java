/*    */ package fun.rockstarity.api.helpers.math.aura;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ import net.minecraft.item.ArmorMaterial;
/*    */ import net.minecraft.item.DyeableArmorItem;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BotUtility
/*    */ {
/*    */   private BotUtility() {
/* 20 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated"); } public static Set<String> getVerifed() {
/* 21 */     return verifed;
/* 22 */   } private static final Set<String> verifed = new HashSet<>();
/*    */   
/*    */   public static boolean isRWBot(LivingEntity ent) {
/* 25 */     String name = ent.getScoreboardName();
/*    */     
/* 27 */     if (verifed.contains(name)) {
/* 28 */       return false;
/*    */     }
/* 30 */     if (ent.getAbsorptionAmount() != 0.0F || ent
/* 31 */       .isHandActive() || 
/* 32 */       (ent.getMotion()).y != 0.0D)
/*    */     {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 40 */       verifed.add(name);
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 52 */     return true;
/*    */   }
/*    */   
/*    */   public static boolean isFullArmor(LivingEntity entity, ArmorMaterial material) {
/* 56 */     for (ItemStack item : entity.getArmorInventoryList()) {
/* 57 */       Item item1 = item.getItem(); if (item1 instanceof DyeableArmorItem) { DyeableArmorItem armor = (DyeableArmorItem)item1; if (armor.getArmorMaterial() != material)
/* 58 */           return false;  }
/*    */     
/*    */     } 
/* 61 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\aura\BotUtility.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */