/*    */ package fun.rockstarity.api.helpers.math.aura;
/*    */ 
/*    */ import fun.rockstarity.api.modules.settings.list.Mode;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ import net.minecraft.util.math.vector.Vector2f;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class RotationMode
/*    */   extends Mode.Element
/*    */ {
/* 14 */   protected Vector2f rotation = Vector2f.ZERO;
/*    */   
/*    */   public RotationMode(Mode parent, String name) {
/* 17 */     super(parent, name);
/*    */   }
/*    */   
/*    */   public abstract void update(LivingEntity paramLivingEntity);
/*    */   
/*    */   public void reset(int reason) {
/* 23 */     this.rotation = new Vector2f(mc.player.rotationYaw, mc.player.rotationPitch);
/*    */   }
/*    */   
/*    */   public float getYaw() {
/* 27 */     return this.rotation.x;
/*    */   }
/*    */   
/*    */   public float getPitch() {
/* 31 */     return this.rotation.y;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\aura\RotationMode.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */