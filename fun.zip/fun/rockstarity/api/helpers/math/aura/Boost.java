/*     */ package fun.rockstarity.api.helpers.math.aura;
/*     */ 
/*     */ import fun.rockstarity.api.binds.Bindable;
/*     */ import fun.rockstarity.api.events.Event;
/*     */ import fun.rockstarity.api.helpers.game.Server;
/*     */ import fun.rockstarity.api.helpers.math.TimerUtility;
/*     */ import fun.rockstarity.api.helpers.player.FallingPlayer;
/*     */ import fun.rockstarity.api.helpers.player.Move;
/*     */ import fun.rockstarity.api.helpers.player.Player;
/*     */ import fun.rockstarity.api.modules.settings.list.Mode;
/*     */ import fun.rockstarity.api.modules.settings.list.Slider;
/*     */ import fun.rockstarity.client.modules.combat.Aura;
/*     */ import net.minecraft.block.Blocks;
/*     */ import net.minecraft.entity.LivingEntity;
/*     */ import net.minecraft.util.math.vector.Vector3d;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Boost
/*     */   extends Mode
/*     */ {
/*  31 */   private final Mode.Element notBoost = new Mode.Element(this, "Нет");
/*  32 */   private final Mode.Element direct = new Mode.Element(this, "Прямо");
/*  33 */   private final Mode.Element toTarget = new Mode.Element(this, "На цель");
/*     */   
/*  35 */   private final Mode boostMode = new Mode((Bindable)this.toTarget, "Режим");
/*  36 */   private final Mode.Element spookyBoost = new Mode.Element(this.boostMode, "Spooky"); public Mode.Element getSpookyBoost() { return this.spookyBoost; }
/*  37 */    private final Mode.Element custom = new Mode.Element(this.boostMode, "Свой");
/*     */   
/*  39 */   private final Slider fallingSpeed = (new Slider((Bindable)this.toTarget, "Скорость падения")).min(0.0F).max(0.4F).inc(0.05F).set(0.3F).desc("Скорость, c которой игрок будет ускоряться падая").hide(() -> Boolean.valueOf(this.spookyBoost.get()));
/*  40 */   private final Slider jumpSpeed = (new Slider((Bindable)this.toTarget, "Скорость прыжка")).min(0.0F).max(0.4F).inc(0.05F).set(0.3F).desc("Скорость, c которой игрок будет ускоряться прыгая").hide(() -> Boolean.valueOf(this.spookyBoost.get()));
/*  41 */   private final Slider groundSpeed = (new Slider((Bindable)this.toTarget, "Скорость на земле")).min(0.0F).max(0.4F).inc(0.05F).set(0.0F).desc("Скорость, c которой игрок будет ускоряться на земле").hide(() -> Boolean.valueOf(this.spookyBoost.get()));
/*  42 */   private final Slider centrifugalForce = (new Slider((Bindable)this.toTarget, "Центробежная сила")).min(0.0F).max(0.3F).inc(0.05F).set(0.0F).desc("Отклонение от центра для вращения").hide(() -> Boolean.valueOf(this.spookyBoost.get()));
/*  43 */   private final Slider multiplier = (new Slider((Bindable)this.toTarget, "Множитель")).min(-0.2F).max(3.0F).inc(0.05F).set(-0.1F).desc("Множитель ускорения. Для FunTime желательно ставить значения до 0, для SpookyTime можно ставить значения вполть до 3. Если не знаете, что ставить под конкретно ваш сервер, оствьте 0 или -0.1").hide(() -> Boolean.valueOf(false));
/*     */   
/*  45 */   private final TimerUtility collisionTimer = new TimerUtility();
/*  46 */   private final TimerUtility waitTimer = new TimerUtility();
/*     */   private boolean disabled;
/*     */   
/*     */   public Boost(Bindable parent) {
/*  50 */     super(parent, "Ускорение");
/*     */   }
/*     */   
/*     */   public void onEvent(Event event, LivingEntity target) {
/*  54 */     if (event instanceof fun.rockstarity.api.events.list.player.EventUpdate && target != null) {
/*  55 */       Aura aura = (Aura)rock.getModules().get(Aura.class);
/*     */       
/*  57 */       if (this.direct.get()) {
/*  58 */         double speed = Math.hypot(Math.abs(target.prevPosX - target.getPosX()), Math.abs(target.prevPosZ - target.getPosZ()));
/*     */ 
/*     */ 
/*     */         
/*  62 */         if (Player.collideWith(target)) {
/*  63 */           float p = mc.world.getBlockState(mc.player.getPosition().add((mc.player.getMotion()).x, (mc.player.getMotion()).y, (mc.player.getMotion()).z)).getBlock().getSlipperiness();
/*  64 */           float f = mc.player.isOnGround() ? (p * 1.0F) : (Server.is("infinity") ? 0.91F : 0.81F);
/*  65 */           float f2 = mc.player.isOnGround() ? p : 0.99F;
/*     */ 
/*     */ 
/*     */           
/*  69 */           mc.player.setVelocity(mc.player.getMotion().getX() / f * f2, mc.player.getMotion().getY(), mc.player.getMotion().getZ() / f * f2);
/*     */         }
/*  71 */         else if (mc.player.fallDistance <= 0.5F || Move.getSpeed() == 0.0D) {
/*     */ 
/*     */         
/*     */         }
/*     */       
/*     */       }
/*  77 */       else if (this.toTarget.get()) {
/*  78 */         float mult = this.multiplier.get();
/*     */         
/*  80 */         if (Player.getBlock(0.0D, 2.0D, 0.0D) != Blocks.AIR || Player.getBlock(0.0D, 3.0D, 0.0D) != Blocks.AIR || mc.world.getBlock(target.getPosition().add(0, 2, 0)) != Blocks.AIR || mc.world.getBlock(target.getPosition().add(0, 3, 0)) != Blocks.AIR || target.collidedHorizontally);
/*     */ 
/*     */ 
/*     */         
/*  84 */         if (Player.collideWith(target, mult) && !this.disabled) {
/*  85 */           Vector3d playerPos = mc.player.getPositionVec();
/*  86 */           Vector3d targetPos = target.getPositionVec();
/*     */           
/*  88 */           Vector3d direction = targetPos.subtract(playerPos).normalize();
/*     */ 
/*     */           
/*  91 */           float p = mc.world.getBlockState(mc.player.getPosition().add((mc.player.getMotion()).x, (mc.player.getMotion()).y, (mc.player.getMotion()).z)).getBlock().getSlipperiness();
/*  92 */           float f = mc.player.isOnGround() ? (p * 1.0F) : (Server.is("infinity") ? 0.91F : 0.81F);
/*  93 */           float f2 = mc.player.isOnGround() ? p : 0.99F;
/*     */           
/*  95 */           double motionY = (mc.player.getMotion()).y;
/*     */           
/*  97 */           float ground = this.spookyBoost.get() ? (Player.collideWith(target) ? 0.1F : 0.05F) : this.groundSpeed.get();
/*  98 */           float falling = this.spookyBoost.get() ? 0.05F : this.fallingSpeed.get();
/*  99 */           float jump = this.spookyBoost.get() ? 0.05F : this.jumpSpeed.get();
/*     */ 
/*     */           
/* 102 */           float gradus = (float)(System.currentTimeMillis() / 100L);
/* 103 */           float centrifugal = this.spookyBoost.get() ? 0.0F : this.centrifugalForce.get();
/* 104 */           float deviationX = (float)Math.cos(Math.toDegrees(gradus)) * centrifugal;
/* 105 */           float deviationZ = (float)Math.sin(Math.toDegrees(gradus)) * centrifugal;
/* 106 */           direction = direction.add(deviationX, 0.0D, deviationZ);
/*     */           
/* 108 */           double speed = mc.player.isOnGround() ? ground : ((mc.player.fallDistance > 0.0F) ? falling : jump);
/*     */ 
/*     */           
/* 111 */           boolean predictHit = (!mc.player.isOnGround() && IdealHitUtility.canAIFall() && (FallingPlayer.fromPlayer(mc.player).findFall(IdealHitUtility.getNewFallDistance(target)) || aura.canCritical()));
/*     */ 
/*     */           
/* 114 */           if (predictHit);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 120 */           double newX = direction.x * speed * f2 / f;
/* 121 */           double newZ = direction.z * speed * f2 / f;
/*     */           
/* 123 */           mc.player.setVelocity(
/* 124 */               (mc.player.getMotion()).x + newX, motionY, 
/*     */ 
/*     */               
/* 127 */               (mc.player.getMotion()).z + newZ);
/*     */ 
/*     */           
/* 130 */           if (this.collisionTimer.passed(2000L));
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 135 */           this.collisionTimer.reset();
/*     */           
/* 137 */           if (this.disabled && this.waitTimer.passed(1000L))
/* 138 */             this.disabled = false; 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\aura\Boost.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */