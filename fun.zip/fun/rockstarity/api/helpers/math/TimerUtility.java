/*    */ package fun.rockstarity.api.helpers.math;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimerUtility
/*    */ {
/*    */   public void setStartTime(long startTime) {
/* 13 */     this.startTime = startTime;
/* 14 */   } private long startTime = System.currentTimeMillis();
/*    */   
/*    */   public void reset() {
/* 17 */     this.startTime = System.currentTimeMillis();
/*    */   }
/*    */   
/*    */   public boolean passed(float time) {
/* 21 */     return passed((long)time);
/*    */   }
/*    */   
/*    */   public boolean passed(long time) {
/* 25 */     return (System.currentTimeMillis() - this.startTime > time);
/*    */   }
/*    */   
/*    */   public long getElapsed() {
/* 29 */     return System.currentTimeMillis() - this.startTime;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\TimerUtility.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */