/*    */ package fun.rockstarity.api.helpers.math;
/*    */ 
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ import net.minecraft.util.math.vector.Vector3d;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VectorUtility
/*    */   implements IAccess
/*    */ {
/*    */   public static Vector3d getBestVector(LivingEntity target, float jitterOnBoxValue) {
/* 15 */     double yExpand = MathHelper.clamp(mc.player.getPosYEye() - target.getPosYEye(), (target.getHeight() / 2.0F), target.getHeight()) / (mc.player.isElytraFlying() ? 10.0F : ((!mc.gameSettings.keyBindJump.isKeyDown() && mc.player.isOnGround()) ? (target.isSneaking() ? 0.8F : 0.6F) : 1.0F));
/*    */     
/* 17 */     Vector3d finalVector = target.getPositionVec().add(0.0D, yExpand, 0.0D);
/* 18 */     return finalVector.add(jitterOnBoxValue, (jitterOnBoxValue / 2.0F), jitterOnBoxValue).subtract(mc.player.getEyePosition(1.0F)).normalize();
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\VectorUtility.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */