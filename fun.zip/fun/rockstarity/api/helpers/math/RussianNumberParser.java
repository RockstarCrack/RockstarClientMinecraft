/*     */ package fun.rockstarity.api.helpers.math;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.function.BiFunction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RussianNumberParser
/*     */ {
/*     */   private RussianNumberParser() {
/*  63 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   private static final Map<String, Integer> numberMap = new HashMap<>(); static {
/*  72 */     numberMap.put("ноль", Integer.valueOf(0));
/*  73 */     numberMap.put("один", Integer.valueOf(1));
/*  74 */     numberMap.put("одна", Integer.valueOf(1));
/*  75 */     numberMap.put("одни", Integer.valueOf(1));
/*  76 */     numberMap.put("два", Integer.valueOf(2));
/*  77 */     numberMap.put("две", Integer.valueOf(2));
/*  78 */     numberMap.put("три", Integer.valueOf(3));
/*  79 */     numberMap.put("четыре", Integer.valueOf(4));
/*  80 */     numberMap.put("пять", Integer.valueOf(5));
/*  81 */     numberMap.put("шесть", Integer.valueOf(6));
/*  82 */     numberMap.put("семь", Integer.valueOf(7));
/*  83 */     numberMap.put("восемь", Integer.valueOf(8));
/*  84 */     numberMap.put("девять", Integer.valueOf(9));
/*  85 */     numberMap.put("десять", Integer.valueOf(10));
/*  86 */     numberMap.put("одиннадцать", Integer.valueOf(11));
/*  87 */     numberMap.put("двенадцать", Integer.valueOf(12));
/*  88 */     numberMap.put("тринадцать", Integer.valueOf(13));
/*  89 */     numberMap.put("четырнадцать", Integer.valueOf(14));
/*  90 */     numberMap.put("пятнадцать", Integer.valueOf(15));
/*  91 */     numberMap.put("шестнадцать", Integer.valueOf(16));
/*  92 */     numberMap.put("семнадцать", Integer.valueOf(17));
/*  93 */     numberMap.put("восемнадцать", Integer.valueOf(18));
/*  94 */     numberMap.put("девятнадцать", Integer.valueOf(19));
/*     */   }
/*  96 */   private static final Map<String, Integer> tensMap = new HashMap<>(); static {
/*  97 */     tensMap.put("двадцать", Integer.valueOf(20));
/*  98 */     tensMap.put("тридцать", Integer.valueOf(30));
/*  99 */     tensMap.put("сорок", Integer.valueOf(40));
/* 100 */     tensMap.put("писят", Integer.valueOf(50));
/* 101 */     tensMap.put("пятьдесят", Integer.valueOf(50));
/* 102 */     tensMap.put("шестьдесят", Integer.valueOf(60));
/* 103 */     tensMap.put("семьдесят", Integer.valueOf(70));
/* 104 */     tensMap.put("восемьдесят", Integer.valueOf(80));
/* 105 */     tensMap.put("девяносто", Integer.valueOf(90));
/*     */   }
/* 107 */   private static final Map<String, Integer> hundredsMap = new HashMap<>(); static {
/* 108 */     hundredsMap.put("сто", Integer.valueOf(100));
/* 109 */     hundredsMap.put("двести", Integer.valueOf(200));
/* 110 */     hundredsMap.put("триста", Integer.valueOf(300));
/* 111 */     hundredsMap.put("четыреста", Integer.valueOf(400));
/* 112 */     hundredsMap.put("пятьсот", Integer.valueOf(500));
/* 113 */     hundredsMap.put("шестьсот", Integer.valueOf(600));
/* 114 */     hundredsMap.put("семьсот", Integer.valueOf(700));
/* 115 */     hundredsMap.put("восемьсот", Integer.valueOf(800));
/* 116 */     hundredsMap.put("девятьсот", Integer.valueOf(900));
/*     */   }
/* 118 */   private static final Map<String, Integer> thousandsMap = new HashMap<>(); static {
/* 119 */     thousandsMap.put("тысяча", Integer.valueOf(1000));
/* 120 */     thousandsMap.put("две тысячи", Integer.valueOf(2000));
/* 121 */     thousandsMap.put("три тысячи", Integer.valueOf(3000));
/* 122 */     thousandsMap.put("четыре тысячи", Integer.valueOf(4000));
/* 123 */     thousandsMap.put("пять тысяч", Integer.valueOf(5000));
/* 124 */     thousandsMap.put("шесть тысяч", Integer.valueOf(6000));
/* 125 */     thousandsMap.put("семь тысяч", Integer.valueOf(7000));
/* 126 */     thousandsMap.put("восемь тысяч", Integer.valueOf(8000));
/* 127 */     thousandsMap.put("девять тысяч", Integer.valueOf(9000));
/*     */   }
/* 129 */   private static final Map<String, BiFunction<Integer, Integer, Integer>> operations = new HashMap<>(); static {
/* 130 */     operations.put("плюс", (a, b) -> Integer.valueOf(a.intValue() + b.intValue()));
/* 131 */     operations.put("минус", (a, b) -> Integer.valueOf(a.intValue() - b.intValue()));
/* 132 */     operations.put("умножить", (a, b) -> Integer.valueOf(a.intValue() * b.intValue()));
/* 133 */     operations.put("на", (a, b) -> Integer.valueOf(a.intValue() * b.intValue()));
/* 134 */     operations.put("разделить", (a, b) -> Integer.valueOf(a.intValue() / b.intValue()));
/* 135 */     operations.put("делить", (a, b) -> Integer.valueOf(a.intValue() / b.intValue()));
/* 136 */     operations.put("по", (a, b) -> Integer.valueOf(a.intValue() / b.intValue()));
/*     */   }
/*     */   
/*     */   public static int parseRussianNumber(String input) {
/* 140 */     int result = 0;
/* 141 */     int current = 0;
/*     */     
/* 143 */     String[] parts = input.toLowerCase().split("\\s+");
/*     */     
/* 145 */     boolean isNegative = false;
/* 146 */     int index = 0;
/* 147 */     if (parts.length > 0 && (parts[0].equals("минус") || parts[0].equals("-"))) {
/* 148 */       isNegative = true;
/* 149 */       index = 1;
/*     */     } 
/*     */     
/* 152 */     BiFunction<Integer, Integer, Integer> operation = null;
/* 153 */     int operand = 0;
/*     */     
/* 155 */     for (int i = index; i < parts.length; i++) {
/* 156 */       String part = parts[i];
/*     */       
/* 158 */       if (operations.containsKey(part)) {
/* 159 */         operation = operations.get(part);
/* 160 */       } else if (thousandsMap.containsKey(part)) {
/* 161 */         current += ((Integer)thousandsMap.get(part)).intValue();
/* 162 */       } else if (hundredsMap.containsKey(part)) {
/* 163 */         current += ((Integer)hundredsMap.get(part)).intValue();
/* 164 */       } else if (tensMap.containsKey(part)) {
/* 165 */         current += ((Integer)tensMap.get(part)).intValue();
/* 166 */       } else if (numberMap.containsKey(part)) {
/* 167 */         current += ((Integer)numberMap.get(part)).intValue();
/*     */       } else {
/*     */         continue;
/*     */       } 
/*     */       
/* 172 */       if (operation != null && current != 0) {
/* 173 */         operand = current;
/* 174 */         current = 0;
/*     */       } 
/*     */       continue;
/*     */     } 
/* 178 */     if (operation != null) {
/* 179 */       result = ((Integer)operation.apply(Integer.valueOf(result), Integer.valueOf(operand))).intValue();
/*     */     } else {
/* 181 */       result = current;
/*     */     } 
/*     */     
/* 184 */     if (isNegative) result = -result;
/*     */     
/* 186 */     return result;
/*     */   }
/*     */   
/*     */   public static String convert(String expression) {
/* 190 */     StringBuilder mathExpression = new StringBuilder();
/* 191 */     String[] parts = expression.toLowerCase().split("\\s+");
/*     */     
/* 193 */     boolean hasPendingMultiply = false;
/*     */     
/* 195 */     for (String part : parts) {
/* 196 */       if (numberMap.containsKey(part)) {
/* 197 */         mathExpression.append(numberMap.get(part));
/* 198 */       } else if (tensMap.containsKey(part)) {
/* 199 */         mathExpression.append(tensMap.get(part));
/* 200 */       } else if (hundredsMap.containsKey(part)) {
/* 201 */         mathExpression.append(hundredsMap.get(part));
/* 202 */       } else if (thousandsMap.containsKey(part)) {
/* 203 */         mathExpression.append(thousandsMap.get(part));
/* 204 */       } else if (operations.containsKey(part)) {
/* 205 */         switch (part) {
/*     */           case "плюс":
/* 207 */             mathExpression.append("+");
/*     */             break;
/*     */           case "минус":
/* 210 */             mathExpression.append("-");
/*     */             break;
/*     */           case "умножить":
/* 213 */             hasPendingMultiply = true;
/*     */             break;
/*     */           case "на":
/* 216 */             if (hasPendingMultiply) {
/* 217 */               mathExpression.append("*");
/* 218 */               hasPendingMultiply = false; break;
/*     */             } 
/* 220 */             mathExpression.append("/");
/*     */             break;
/*     */           
/*     */           case "разделить":
/* 224 */             hasPendingMultiply = false;
/*     */             break;
/*     */           case "делить":
/* 227 */             hasPendingMultiply = false;
/*     */             break;
/*     */           case "по":
/* 230 */             mathExpression.append("/");
/*     */             break;
/*     */         } 
/*     */ 
/*     */ 
/*     */       
/*     */       } 
/*     */     } 
/* 238 */     return mathExpression.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\RussianNumberParser.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */