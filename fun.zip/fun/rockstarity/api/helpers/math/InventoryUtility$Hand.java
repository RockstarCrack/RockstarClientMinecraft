/*     */ package fun.rockstarity.api.helpers.math;
/*     */ 
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.events.Event;
/*     */ import fun.rockstarity.api.events.list.game.packet.EventSendPacket;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Hand
/*     */ {
/*     */   public static boolean isEnabled;
/*     */   private boolean isChangingItem;
/* 175 */   private int originalSlot = -1;
/*     */   
/*     */   public void onEvent(Event e) {
/* 178 */     if (e instanceof EventSendPacket) { EventSendPacket event = (EventSendPacket)e;
/* 179 */       if (event.getPacket() instanceof net.minecraft.network.play.server.SHeldItemChangePacket) {
/* 180 */         this.isChangingItem = true;
/*     */       } }
/*     */   
/*     */   }
/*     */   
/*     */   public void handleItemChange(boolean resetItem) {
/* 186 */     if (this.isChangingItem && this.originalSlot != -1) {
/* 187 */       isEnabled = true;
/* 188 */       IAccess.mc.player.inventory.currentItem = this.originalSlot;
/* 189 */       if (resetItem) {
/* 190 */         this.isChangingItem = false;
/* 191 */         this.originalSlot = -1;
/* 192 */         isEnabled = false;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setOriginalSlot(int slot) {
/* 198 */     this.originalSlot = slot;
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\InventoryUtility$Hand.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */