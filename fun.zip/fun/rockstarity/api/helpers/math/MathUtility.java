/*     */ package fun.rockstarity.api.helpers.math;
/*     */ 
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.helpers.math.aura.Rotation;
/*     */ import fun.rockstarity.api.render.shaders.fog.Vector2d;
/*     */ import fun.rockstarity.client.modules.combat.BackTrack;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Predicate;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.EntityRayTraceResult;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.RayTraceContext;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.util.math.vector.Vector2f;
/*     */ import net.minecraft.util.math.vector.Vector3d;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MathUtility
/*     */   implements IAccess
/*     */ {
/*     */   private MathUtility() {
/*  29 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*  30 */   } static FastRandom fastRandomize = new FastRandom();
/*     */   
/*     */   public static double сквирт(double value) {
/*  33 */     return Math.sqrt(value);
/*     */   }
/*     */   
/*     */   public static double step(double value, double steps) {
/*  37 */     double roundedValue = Math.round(value / steps) * steps;
/*  38 */     return Math.round(roundedValue * 100.0D) / 100.0D;
/*     */   }
/*     */   
/*     */   public static boolean isBlockUnder(float under) {
/*  42 */     if (mc.player.getPosY() < 0.0D) {
/*  43 */       return false;
/*     */     }
/*  45 */     AxisAlignedBB aab = mc.player.getBoundingBox().offset(0.0D, -under, 0.0D);
/*  46 */     return mc.world.getCollisionShapes((Entity)mc.player, aab).toList().isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public static float random(double min, double max) {
/*  51 */     return (float)(min + (max - min) * Math.random());
/*     */   }
/*     */   
/*     */   public static int randomInt(int min, int max) {
/*  55 */     return (int)(min + (max - min) * Math.random());
/*     */   }
/*     */ 
/*     */   
/*     */   public static float randomNew(double min, double max) {
/*  60 */     if (min > max) return (float)(fastRandomize.nextFloat() * (min - max) + max); 
/*  61 */     return (float)(fastRandomize.nextFloat() * (max - min) + min);
/*     */   }
/*     */   
/*     */   public static int randomIntNew(int min, int max) {
/*  65 */     if (min > max) return fastRandomize.nextInt() * (min - max) + max; 
/*  66 */     return fastRandomize.nextInt() * (max - min) + min;
/*     */   }
/*     */   
/*     */   public static double round(double target, int decimal) {
/*  70 */     return Math.round(target * Math.pow(10.0D, decimal)) / Math.pow(10.0D, decimal);
/*     */   }
/*     */   
/*     */   public static float calculateGaussianValue(float x, float sigma) {
/*  74 */     double output = 1.0D / сквирт(6.283185307179586D * (sigma * sigma));
/*  75 */     return (float)(output * Math.exp(-(x * x) / 2.0D * (sigma * sigma)));
/*     */   }
/*     */   
/*     */   public static float interpolate(double oldValue, double newValue, double interpolationValue) {
/*  79 */     return (float)(oldValue + (newValue - oldValue) * interpolationValue);
/*     */   }
/*     */   
/*     */   public static float step(float current, float target, float step) {
/*  83 */     float difference = target - current;
/*     */     
/*  85 */     if (Math.abs(difference) <= step) {
/*  86 */       return target;
/*     */     }
/*     */     
/*  89 */     return current + Math.signum(difference) * step;
/*     */   }
/*     */   
/*     */   public static Vector2f calculate(Vector3d to) {
/*  93 */     Vector3d pos = mc.player.getPositionVec().add(0.0D, mc.player.getEyeHeight(), 0.0D);
/*  94 */     Vector3d from = new Vector3d(pos.x, pos.y, pos.z);
/*  95 */     return calculate(from, to);
/*     */   }
/*     */   
/*     */   public static Vector2f calculate(Vector3d from, Vector3d to) {
/*  99 */     Vector3d diff = to.sub(from);
/* 100 */     double distance = Math.hypot(diff.x, diff.z);
/* 101 */     float yaw = (float)(MathHelper.atan2(diff.z, diff.x) * 180.0D / Math.PI) - 90.0F;
/* 102 */     float pitch = (float)-(MathHelper.atan2(diff.y, distance) * 180.0D / Math.PI);
/* 103 */     return new Vector2f(yaw, pitch);
/*     */   }
/*     */   
/*     */   public static float calcTrajectory(BlockPos bp) {
/* 107 */     double a = Math.hypot((bp.getX() + 0.5F) - mc.player.getPosX(), (bp.getZ() + 0.5F) - mc.player.getPosZ());
/* 108 */     double y = 6.125D * ((bp.getY() + 1.0F) - mc.player.getPosY() + mc.player.getEyeHeight(mc.player.getPose()));
/* 109 */     y = 0.05000000074505806D * (0.05000000074505806D * a * a + y);
/* 110 */     y = сквирт(Math.max(0.0D, 9.37890625D - y));
/* 111 */     double d = 3.0625D - y;
/* 112 */     y = Math.atan2(d * d + y, 0.05000000074505806D * a);
/* 113 */     d = Math.atan2(d, 0.05000000074505806D * a);
/* 114 */     return (float)Math.min(y, d);
/*     */   }
/*     */   
/*     */   public static Vector2f rotationToVec(Vector3d vec) {
/* 118 */     Vector3d eyesPos = mc.player.getEyePosition(1.0F);
/* 119 */     double diffX = (vec != null) ? (vec.x - eyesPos.x) : 0.0D;
/* 120 */     double diffY = (vec != null) ? (vec.y - mc.player.getPosY() + mc.player.getEyeHeight() + 0.5D) : 0.0D;
/* 121 */     double diffZ = (vec != null) ? (vec.z - eyesPos.z) : 0.0D;
/*     */     
/* 123 */     double diffXZ = сквирт(diffX * diffX + diffZ * diffZ);
/* 124 */     float yaw = (float)(Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0D);
/* 125 */     float pitch = (float)-Math.toDegrees(Math.atan2(diffY, diffXZ));
/* 126 */     yaw = mc.player.rotationYaw + MathHelper.wrapDegrees(yaw - mc.player.rotationYaw);
/* 127 */     pitch = mc.player.rotationPitch + MathHelper.wrapDegrees(pitch - mc.player.rotationPitch);
/* 128 */     pitch = MathHelper.clamp(pitch, -90.0F, 90.0F);
/*     */     
/* 130 */     return new Vector2f(yaw, pitch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Vector2d circleCords(float point, float radius) {
/* 140 */     return new Vector2d(
/* 141 */         Math.sin(Math.toRadians(point)) * radius, 
/* 142 */         Math.cos(Math.toRadians(point)) * radius);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double getDistanceFromEye(Vector3d vec) {
/* 152 */     float f = (float)(mc.player.getPosX() - vec.x);
/* 153 */     float f1 = (float)(mc.player.getPosYEye() - vec.y);
/* 154 */     float f2 = (float)(mc.player.getPosZ() - vec.z);
/* 155 */     return MathHelper.sqrt(f * f + f1 * f1 + f2 * f2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean canSeen(Vector3d vec) {
/* 165 */     Vector3d vector3d = mc.player.getPositionVec().add(0.0D, mc.player.getEyeHeight(), 0.0D); return 
/* 166 */       (mc.world.rayTraceBlocks(new RayTraceContext(vector3d, vec, RayTraceContext.BlockMode.COLLIDER, RayTraceContext.FluidMode.NONE, (Entity)mc.player)).getType() == RayTraceResult.Type.MISS);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean canRender(Vector3d vec) {
/* 171 */     Vector3d vector3d = mc.gameRenderer.getActiveRenderInfo().getProjectedView(); return 
/* 172 */       (mc.world.rayTraceBlocks(new RayTraceContext(vector3d, vec, RayTraceContext.BlockMode.VISUAL, RayTraceContext.FluidMode.NONE, (Entity)mc.player)).getType() == RayTraceResult.Type.MISS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RayTraceResult rayTrace(double rayTraceDistance, float yaw, float pitch, Entity entity) {
/* 189 */     Vector3d startVec = mc.player.getEyePosition(1.0F);
/* 190 */     Vector3d directionVec = getVectorForRotation(pitch, yaw);
/* 191 */     Vector3d endVec = startVec.add(directionVec.x * rayTraceDistance, directionVec.y * rayTraceDistance, directionVec.z * rayTraceDistance);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 197 */     return (RayTraceResult)mc.world.rayTraceBlocks(new RayTraceContext(startVec, endVec, RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, entity));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RayTraceResult rayTrace(double rayTraceDistance, float yaw, float pitch, Entity entity, Vector3d start) {
/* 211 */     Vector3d directionVec = getVectorForRotation(pitch, yaw);
/* 212 */     Vector3d endVec = start.add(directionVec.x * rayTraceDistance, directionVec.y * rayTraceDistance, directionVec.z * rayTraceDistance);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 218 */     return (RayTraceResult)mc.world.rayTraceBlocks(new RayTraceContext(start, endVec, RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, entity));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EntityRayTraceResult rayTraceEntities(Entity shooter, Vector3d startVec, Vector3d endVec, AxisAlignedBB boundingBox, Predicate<Entity> filter, double distance) {
/* 229 */     World world = shooter.world;
/* 230 */     double d0 = distance;
/* 231 */     Entity entity = null;
/* 232 */     Vector3d vector3d = null;
/*     */     
/* 234 */     for (Entity entity1 : world.getEntitiesInAABBexcluding(shooter, boundingBox, filter)) {
/*     */       
/* 236 */       if (((BackTrack)rock.getModules().get(BackTrack.class)).get()) {
/* 237 */         for (BackTrack.Position pos : entity1.getBacktrack()) {
/* 238 */           AxisAlignedBB axisalignedbb1 = entity1.getBoundingBox().grow(entity1.getCollisionBorderSize());
/* 239 */           Vector3d entPos = entity1.getPositionVec();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 246 */           AxisAlignedBB axisAlignedBB1 = new AxisAlignedBB(axisalignedbb1.minX - entPos.x + (pos.getPos()).x, axisalignedbb1.minY - entPos.y + (pos.getPos()).y, axisalignedbb1.minZ - entPos.z + (pos.getPos()).z, axisalignedbb1.maxX - entPos.x + (pos.getPos()).x, axisalignedbb1.maxY - entPos.y + (pos.getPos()).y, axisalignedbb1.maxZ - entPos.z + (pos.getPos()).z);
/*     */           
/* 248 */           Optional<Vector3d> optional1 = axisAlignedBB1.rayTrace(startVec, endVec);
/*     */           
/* 250 */           if (axisAlignedBB1.contains(startVec)) {
/*     */             
/* 252 */             if (d0 >= 0.0D) {
/*     */               
/* 254 */               entity = entity1;
/* 255 */               vector3d = optional1.orElse(startVec);
/* 256 */               d0 = 0.0D;
/*     */             }  continue;
/*     */           } 
/* 259 */           if (optional1.isPresent()) {
/*     */             
/* 261 */             Vector3d vector3d1 = optional1.get();
/* 262 */             double d1 = startVec.squareDistanceTo(vector3d1);
/*     */             
/* 264 */             if (d1 < d0 || d0 == 0.0D) {
/*     */               
/* 266 */               if (entity1.getLowestRidingEntity() == shooter.getLowestRidingEntity()) {
/*     */                 
/* 268 */                 if (d0 == 0.0D) {
/*     */                   
/* 270 */                   entity = entity1;
/* 271 */                   vector3d = vector3d1;
/*     */                 } 
/*     */                 
/*     */                 continue;
/*     */               } 
/* 276 */               entity = entity1;
/* 277 */               vector3d = vector3d1;
/* 278 */               d0 = d1;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/* 284 */       AxisAlignedBB axisalignedbb = entity1.getBoundingBox().grow(entity1.getCollisionBorderSize());
/* 285 */       Optional<Vector3d> optional = axisalignedbb.rayTrace(startVec, endVec);
/*     */       
/* 287 */       if (axisalignedbb.contains(startVec)) {
/*     */ 
/*     */         
/* 290 */         if (d0 >= 0.0D) {
/*     */           
/* 292 */           entity = entity1;
/* 293 */           vector3d = optional.orElse(startVec);
/* 294 */           d0 = 0.0D;
/*     */         }  continue;
/*     */       } 
/* 297 */       if (optional.isPresent()) {
/*     */ 
/*     */         
/* 300 */         Vector3d vector3d1 = optional.get();
/* 301 */         double d1 = startVec.squareDistanceTo(vector3d1);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 306 */         if (entity1.getLowestRidingEntity() == shooter.getLowestRidingEntity()) {
/*     */           
/* 308 */           if (d0 == 0.0D) {
/*     */             
/* 310 */             entity = entity1;
/* 311 */             vector3d = vector3d1;
/*     */           } 
/*     */           
/*     */           continue;
/*     */         } 
/* 316 */         entity = entity1;
/* 317 */         vector3d = vector3d1;
/* 318 */         d0 = d1;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 324 */     return (entity == null) ? null : new EntityRayTraceResult(entity, vector3d);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean tracedTo(Entity shooter, Vector3d startVec, Vector3d endVec, AxisAlignedBB boundingBox, Predicate<Entity> filter, double distance, Entity target) {
/* 329 */     World world = shooter.world;
/* 330 */     double d0 = distance;
/*     */     
/* 332 */     for (Entity entity1 : world.getEntitiesInAABBexcluding(shooter, boundingBox, filter)) {
/*     */       
/* 334 */       if (((BackTrack)rock.getModules().get(BackTrack.class)).get()) {
/* 335 */         for (BackTrack.Position pos : entity1.getBacktrack()) {
/* 336 */           AxisAlignedBB axisalignedbb1 = entity1.getBoundingBox().grow(entity1.getCollisionBorderSize());
/* 337 */           Vector3d entPos = entity1.getPositionVec();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 344 */           AxisAlignedBB axisAlignedBB1 = new AxisAlignedBB(axisalignedbb1.minX - entPos.x + (pos.getPos()).x, axisalignedbb1.minY - entPos.y + (pos.getPos()).y, axisalignedbb1.minZ - entPos.z + (pos.getPos()).z, axisalignedbb1.maxX - entPos.x + (pos.getPos()).x, axisalignedbb1.maxY - entPos.y + (pos.getPos()).y, axisalignedbb1.maxZ - entPos.z + (pos.getPos()).z);
/*     */           
/* 346 */           Optional<Vector3d> optional1 = axisAlignedBB1.rayTrace(startVec, endVec);
/*     */           
/* 348 */           if (axisAlignedBB1.contains(startVec)) {
/*     */             
/* 350 */             if (d0 >= 0.0D) {
/*     */               
/* 352 */               if (entity1 == target) return true; 
/* 353 */               d0 = 0.0D;
/*     */             }  continue;
/*     */           } 
/* 356 */           if (optional1.isPresent()) {
/*     */             
/* 358 */             Vector3d vector3d1 = optional1.get();
/* 359 */             double d1 = startVec.squareDistanceTo(vector3d1);
/*     */             
/* 361 */             if (d1 < d0 || d0 == 0.0D) {
/*     */               
/* 363 */               if (entity1.getLowestRidingEntity() == shooter.getLowestRidingEntity()) {
/*     */                 
/* 365 */                 if (d0 == 0.0D)
/*     */                 {
/* 367 */                   if (entity1 == target) return true;
/*     */                 
/*     */                 }
/*     */                 continue;
/*     */               } 
/* 372 */               if (entity1 == target) return true; 
/* 373 */               d0 = d1;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/* 379 */       AxisAlignedBB axisalignedbb = entity1.getBoundingBox().grow(entity1.getCollisionBorderSize());
/* 380 */       Optional<Vector3d> optional = axisalignedbb.rayTrace(startVec, endVec);
/*     */       
/* 382 */       if (axisalignedbb.contains(startVec)) {
/*     */ 
/*     */         
/* 385 */         if (d0 >= 0.0D) {
/*     */           
/* 387 */           if (entity1 == target) return true; 
/* 388 */           d0 = 0.0D;
/*     */         }  continue;
/*     */       } 
/* 391 */       if (optional.isPresent()) {
/*     */ 
/*     */         
/* 394 */         Vector3d vector3d1 = optional.get();
/* 395 */         double d1 = startVec.squareDistanceTo(vector3d1);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 400 */         if (entity1.getLowestRidingEntity() == shooter.getLowestRidingEntity()) {
/*     */           
/* 402 */           if (d0 == 0.0D)
/*     */           {
/* 404 */             if (entity1 == target) return true;
/*     */           
/*     */           }
/*     */           continue;
/*     */         } 
/* 409 */         if (entity1 == target) return true; 
/* 410 */         d0 = d1;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 416 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean rayTraceWithBlock(double rayTraceDistance, float yaw, float pitch, Entity entity, Entity target, boolean blocks) {
/* 421 */     RayTraceResult object = null;
/* 422 */     if (target == null) return false; 
/* 423 */     if (entity != null && mc.world != null) {
/* 424 */       float partialTicks = mc.getRenderPartialTicks();
/* 425 */       double distance = rayTraceDistance;
/* 426 */       object = rayTrace(rayTraceDistance, yaw, pitch, entity);
/* 427 */       Vector3d vector3d = entity.getEyePosition(partialTicks);
/* 428 */       boolean flag = false;
/* 429 */       double d1 = distance;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 438 */       d1 *= d1;
/*     */       
/* 440 */       if (object != null) {
/* 441 */         d1 = object.getHitVec().squareDistanceTo(vector3d);
/*     */       }
/*     */       
/* 444 */       Vector3d vector3d1 = getVectorForRotation(pitch, yaw);
/* 445 */       Vector3d vector3d2 = vector3d.add(vector3d1.x * distance, vector3d1.y * distance, vector3d1.z * distance);
/* 446 */       float f = 1.0F;
/* 447 */       AxisAlignedBB axisalignedbb = entity.getBoundingBox().expand(vector3d1.scale(distance)).grow(1.0D, 1.0D, 1.0D);
/* 448 */       boolean traced = tracedTo(entity, vector3d, vector3d2, axisalignedbb, p_lambda$getMouseOver$0_0_ -> 
/*     */           
/* 450 */           (!p_lambda$getMouseOver$0_0_.isSpectator() && p_lambda$getMouseOver$0_0_.canBeCollidedWith()), d1, target);
/*     */ 
/*     */       
/* 453 */       return traced;
/*     */     } 
/*     */     
/* 456 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Vector3d getVectorForRotation(float pitch, float yaw) {
/* 467 */     float yawRadians = -yaw * 0.017453292F - 3.1415927F;
/* 468 */     float pitchRadians = -pitch * 0.017453292F;
/*     */     
/* 470 */     float cosYaw = MathHelper.cos(yawRadians);
/* 471 */     float sinYaw = MathHelper.sin(yawRadians);
/* 472 */     float cosPitch = -MathHelper.cos(pitchRadians);
/* 473 */     float sinPitch = MathHelper.sin(pitchRadians);
/*     */     
/* 475 */     return new Vector3d((sinYaw * cosPitch), sinPitch, (cosYaw * cosPitch));
/*     */   }
/*     */   
/*     */   public static float[] getRotVec(Vector3d pos, Vector3d vec) {
/* 479 */     if (vec == null)
/* 480 */       return new float[] { mc.player.rotationYaw, mc.player.rotationPitch }; 
/* 481 */     double posX = vec.getX() - pos.x;
/* 482 */     double posY = vec.getY() - pos.y + mc.player.getEyeHeight();
/* 483 */     double posZ = vec.getZ() - pos.z;
/* 484 */     double sqrt = MathHelper.sqrt(posX * posX + posZ * posZ);
/* 485 */     float yaw = (float)(Math.atan2(posZ, posX) * 180.0D / Math.PI) - 90.0F;
/* 486 */     float pitch = (float)-(Math.atan2(posY, sqrt) * 180.0D / Math.PI);
/* 487 */     float sens = (float)((mc.getGameSettings()).mouseSensitivity * 0.6000000238418579D + 0.20000000298023224D);
/* 488 */     float pow = sens * sens * sens * 1.2F;
/* 489 */     yaw -= yaw % pow;
/* 490 */     pitch -= pitch % pow * sens;
/* 491 */     return new float[] { yaw, pitch };
/*     */   }
/*     */   
/*     */   public static float[] getRotFromPos(Vector3d pos, Entity e) {
/* 495 */     Vector3d ideal = Rotation.getBestPoint(mc.player.getEyePosition(mc.timer.renderPartialTicks), e);
/* 496 */     double x = ideal.getX(), z = ideal.getZ(), y = ideal.getY();
/* 497 */     return getRotVec(pos, new Vector3d(x, y, z));
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\MathUtility.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */