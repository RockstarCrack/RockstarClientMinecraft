/*    */ package fun.rockstarity.api.helpers.math;
/*    */ 
/*    */ import fun.rockstarity.api.render.ui.rect.Rect;
/*    */ 
/*    */ public class Hover {
/*    */   public static boolean isHovered(double x, double y, double width, double height, double mouseX, double mouseY) {
/*  7 */     return (mouseX >= x && mouseY >= y && mouseX < x + width && mouseY < y + height);
/*    */   }
/*    */   
/*    */   public static boolean isHovered(Rect rect, double mouseX, double mouseY) {
/* 11 */     if (rect == null) return false; 
/* 12 */     return (mouseX >= rect.getX() && mouseY >= rect.getY() && mouseX < (rect.getX() + rect.getWidth()) && mouseY < (rect.getY() + rect.getHeight()));
/*    */   }
/*    */   
/*    */   public static float getSliderValue(float min, float max, float start, float size, double mouseX) {
/* 16 */     return (float)(Math.min(1.0D, Math.max(0.0D, (mouseX - start) / size)) * (max - min)) + min;
/*    */   }
/*    */   
/*    */   public static float getPercent(float value, float min, float max) {
/* 20 */     return (value - min) / (max - min);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\math\Hover.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */