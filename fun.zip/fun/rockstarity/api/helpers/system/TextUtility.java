/*     */ package fun.rockstarity.api.helpers.system;
/*     */ 
/*     */ import fun.rockstarity.api.render.ui.fonts.FontSize;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.datatransfer.Clipboard;
/*     */ import java.awt.datatransfer.StringSelection;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Base64;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ import net.minecraft.util.IReorderingProcessor;
/*     */ import net.minecraft.util.text.Style;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TextUtility
/*     */ {
/*     */   private TextUtility() {
/*  30 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*     */   }
/*  32 */   private static final List<String> prefixes = Arrays.asList(new String[] { "The", "Super", "Mega", "Ultra", "Power", "Master", "Great", "Hyper", "Quantum", "Atomic", "Cosmic", "Turbo", "Mighty", "Fantastic", "Legendary", "Epic", "Glorious", "Incredible", "Marvelous", "Supreme", "Stellar", "Dynamic", "Heroic", "Valiant", "Brave", "Noble", "Radiant", "Brilliant", "Bold", "Fearless", "Fierce", "Savage", "Infinit", "Storm", "Thunder", "Lightning", "Solar", "Lunar", "Galactic", "Nebula", "Phoenix", "Titan", "Colossal", "Majestic", "Regal", "Royal", "Sovereign", "Auroral", "Divine", "Ethereal", "Fiery", "Flaming", "Gigahertz", "Hypersonic", "Infernal", "Jovial", "Kaleidoscopic", "Luminous", "Magnetic", "Nebulous", "Olympian", "Pulsar", "Quasar", "Radiant", "Spectral", "Stellar", "Tachyon", "Umbra", "Vortex", "Warp", "Xenon", "Yellowstone", "Zephyr", "Masha" });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   private static final List<String> adjectives = Arrays.asList(new String[] { "Swift", "Fierce", "Sneaky", "Brave", "Savage", "Fearless", "Stealthy", "Valiant", "Bold", "Cunning", "Mighty", "Noble", "Resolute", "Vigilant", "Relentless", "Intrepid", "Daring", "Gallant", "Tenacious", "Ferocious", "Unyielding", "Audacious", "Courageous", "Indomitable", "Dauntless", "Unstoppable", "Determined", "Invincible", "Unbreakable", "Epic", "Legendary", "Mythic", "Heroic", "Glorious", "Triumphant", "Fearsome", "Imposing", "Stalwart", "Stout", "Steadfast", "Grim", "Resolute", "Fateful", "Loyal", "Trusty", "Staunch", "Hardy", "Doughty", "Unflinching", "Unfaltering", "Brisk", "Keen", "Alert", "Quick", "Agile", "Nimble", "Lithe", "Spry", "Energetic", "Vibrant", "Dynamic", "Lively", "Sprightly", "Active", "Forceful", "Vigorous", "Spirited", "Animated", "Robust", "Brawny", "Muscular", "Husky", "Strong", "Tough", "Solid", "Sturdy", "Hefty", "Powerful", "Mighty", "Colossal", "Gigantic", "Mammoth", "Titanic", "Towering", "Massive", "Monumental", "Heroic", "Bravehearted", "Gutsy", "Doughty", "Unyielding", "Unwavering", "Iron-willed", "Strong-willed", "Unshakeable", "Xuesosina" });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   private static final List<String> animals = Arrays.asList(new String[] { "Wolf", "Tiger", "Lion", "Eagle", "Panther", "Dragon", "Phoenix", "Bear", "Leopard", "Hawk", "Falcon", "Cheetah", "Jaguar", "Griffin", "Raven", "Fox", "Shark", "Viper", "Cobra", "Falcon", "Crocodile", "Raptor", "Condor", "Lynx", "Ocelot", "Cougar", "Puma", "Hound", "Bison", "Mammoth", "Rhino", "Buffalo", "Stallion", "Mustang", "Pegasus", "Wyvern", "Cerberus", "Minotaur", "Chimera", "Hydra", "Kraken", "Basilisk", "Manticore", "Unicorn", "Sphinx", "Grizzly", "Kodiak", "Polar Bear", "Sabertooth", "Direwolf", "Orca", "Narwhal", "Walrus", "Beluga", "Elephant", "Hippo", "Gorilla", "Orangutan", "Chimpanzee", "Baboon", "Mongoose", "Ferret", "Weasel", "Otter", "Badger", "Wolverine", "Honey Badger", "Lizard", "Iguana", "Gecko", "Komodo Dragon", "Monitor Lizard", "Tortoise", "Turtle", "Alligator", "Caiman", "Anaconda", "Python", "Boa", "Eel", "Swordfish", "Marlin", "Barracuda", "Piranha", "Penguin", "Albatross", "Seagull", "Pelican", "Stork", "Heron", "Flamingo", "MasTyp6ek" });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   private static final List<String> suffixes = Arrays.asList(new String[] { "Gamer", "Player", "Ninja", "Warrior", "Champion", "Legend", "Hero", "Master", "Conqueror", "Slayer", "Guardian", "Knight", "Paladin", "Crusader", "Ranger", "Assassin", "Mage", "Sorcerer", "Wizard", "Enchanter", "Necromancer", "Berserker", "Gladiator", "Samurai", "Viking", "Pirate", "Outlaw", "Mercenary", "Hunter", "Scout", "Rogue", "Thief", "Sentinel", "Protector", "Savior", "Defender", "Avenger", "Warlord", "Commander", "Captain", "General", "Marshal", "Overlord", "Monarch", "Emperor", "King", "Queen", "Prince", "Princess", "Duke", "Duchess", "Baron", "Baroness", "Lord", "Lady", "Warden", "Sentinel", "Crusader", "Champion", "Virtuoso", "Adept", "Prodigy", "Savant", "Genius", "Maven", "Whiz", "Ace", "Virtuoso", "Expert", "Specialist", "Technician", "Strategist", "Tactician", "Operative", "Agent", "Spy", "Infiltrator", "Saboteur", "Shadow", "Phantom", "Specter", "Shade", "Mystic", "Seer", "Oracle", "Prophet", "Visionary", "Dreamer", "Illusionist", "Conjurer", "Invoker", "Diviner", "Alchemist", "Shaman", "Druid", "Elementalist", "Geomancer", "Pyromancer", "Hydromancer", "Aeromancer", "Archon", "Brawler", "Catalyst", "Dynamo", "Energizer", "Flux", "Fusion", "Gizmo", "Hacker", "Innovator", "Juggernaut", "Kinetix", "Luminary", "Marauder", "Nomad", "Operator", "Pioneer", "Quickshot", "Rascal", "Slasher", "Titan", "Umbra", "Vanguard", "Warden", "Pro", "Xenon", "Yokai", "Zealot", "Zorro", "Zoltar" });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   private static final Random random = new Random(); private static final String secret = "PassWorld";
/*     */   
/*     */   public static String getRandomNick() {
/* 113 */     String prefix = getRandomElement(prefixes);
/* 114 */     String adjective = getRandomElement(adjectives);
/* 115 */     String animal = getRandomElement(animals);
/* 116 */     String suffix = getRandomElement(suffixes);
/* 117 */     String year = (random.nextInt(100) < 30) ? String.valueOf(2000 + random.nextInt(26)) : "";
/*     */     
/* 119 */     List<String> parts = new ArrayList<>();
/* 120 */     if (random.nextBoolean()) parts.add(prefix); 
/* 121 */     if (random.nextBoolean()) parts.add(adjective); 
/* 122 */     if (random.nextBoolean()) parts.add(animal); 
/* 123 */     if (random.nextBoolean()) parts.add(suffix);
/*     */     
/* 125 */     if (parts.isEmpty()) parts.add(prefix); 
/* 126 */     if (parts.size() < 2) parts.add(random.nextBoolean() ? adjective : animal);
/*     */     
/* 128 */     String nickname = String.join("", (Iterable)parts) + String.join("", (Iterable)parts);
/*     */     
/* 130 */     if (random.nextInt(100) < 20) {
/* 131 */       nickname = nickname + nickname;
/*     */     } else {
/* 133 */       nickname = nickname + nickname;
/*     */     } 
/*     */ 
/*     */     
/* 137 */     if (nickname.length() > 16) {
/* 138 */       nickname = nickname.substring(nickname.length() - 16);
/*     */     }
/*     */     
/* 141 */     return nickname;
/*     */   }
/*     */   private static byte[] key; private static SecretKeySpec secretKey;
/*     */   private static String getRandomElement(List<String> list) {
/* 145 */     return list.get(random.nextInt(list.size()));
/*     */   }
/*     */   
/*     */   private static String generateNumbers(int length) {
/* 149 */     StringBuilder sb = new StringBuilder();
/* 150 */     for (int i = 0; i < length; i++) {
/* 151 */       sb.append(random.nextInt(10));
/*     */     }
/* 153 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String makeGender(String parent) {
/* 158 */     if (parent.endsWith("а")) return "а"; 
/* 159 */     if (parent.endsWith("a")) return "а"; 
/* 160 */     if (parent.endsWith("y")) return "о"; 
/* 161 */     if (parent.endsWith("я")) return "а"; 
/* 162 */     if (parent.endsWith("ы")) return "ы"; 
/* 163 */     if (parent.endsWith("и")) return "ы";
/*     */     
/* 165 */     return "";
/*     */   }
/*     */   
/*     */   public static String formatNumber(double number) {
/* 169 */     if (number == (int)number)
/*     */     {
/* 171 */       return String.valueOf((int)number);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 176 */     String formatted = String.format("%.2f", new Object[] { Double.valueOf(number) }).replace(",", ".").replaceAll("\\.?0+$", "");
/*     */ 
/*     */     
/* 179 */     return formatted.endsWith(".") ? 
/* 180 */       formatted.replace(".", "") : 
/* 181 */       formatted;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String formatNumberOld(double number) {
/* 186 */     String formatted = String.format("%.1f", new Object[] { Double.valueOf(number) });
/* 187 */     return formatted;
/*     */   }
/*     */   
/*     */   public static void copyText(String text) {
/* 191 */     Clipboard clip = Toolkit.getDefaultToolkit().getSystemClipboard();
/* 192 */     StringSelection strse1 = new StringSelection(text);
/* 193 */     clip.setContents(strse1, strse1);
/*     */   }
/*     */   
/*     */   public static int levenshteinDistance(String input, String output) {
/* 197 */     int lenS1 = input.length();
/* 198 */     int lenS2 = output.length();
/* 199 */     int[][] dp = new int[lenS1 + 1][lenS2 + 1];
/*     */     
/* 201 */     for (int k = 0; k <= lenS1; k++) {
/* 202 */       dp[k][0] = k;
/*     */     }
/* 204 */     for (int j = 0; j <= lenS2; j++) {
/* 205 */       dp[0][j] = j;
/*     */     }
/*     */     
/* 208 */     for (int i = 1; i <= lenS1; i++) {
/* 209 */       for (int m = 1; m <= lenS2; m++) {
/* 210 */         int cost = (input.charAt(i - 1) == output.charAt(m - 1)) ? 0 : 1;
/* 211 */         dp[i][m] = Math.min(Math.min(dp[i - 1][m] + 1, dp[i][m - 1] + 1), dp[i - 1][m - 1] + cost);
/*     */       } 
/*     */     } 
/*     */     
/* 215 */     return dp[lenS1][lenS2];
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getStringFromReorderingProcessor(IReorderingProcessor reorderingProcessor) {
/* 220 */     StringBuilder stringBuilder = new StringBuilder();
/* 221 */     reorderingProcessor.accept((index, style, codePoint) -> {
/*     */           stringBuilder.append(Character.toChars(codePoint));
/*     */           return true;
/*     */         });
/* 225 */     return stringBuilder.toString();
/*     */   }
/*     */   
/*     */   public static boolean isNumeric(String str) {
/* 229 */     return str.matches("-?\\d+(\\.\\d+)?");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encrypt(String strToEncrypt) {
/*     */     try {
/* 240 */       setKey("PassWorld");
/* 241 */       Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
/* 242 */       cipher.init(1, secretKey);
/* 243 */       return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes("UTF-8")));
/*     */     }
/* 245 */     catch (Exception e) {
/*     */       
/* 247 */       System.out.println("Error while encrypting: " + e.toString());
/*     */       
/* 249 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static String decrypt(String strToDecrypt) {
/*     */     try {
/* 256 */       setKey("PassWorld");
/* 257 */       Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
/* 258 */       cipher.init(2, secretKey);
/* 259 */       return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
/*     */     }
/* 261 */     catch (Exception exception) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 266 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void setKey(String myKey) {
/* 271 */     MessageDigest sha = null;
/*     */     try {
/* 273 */       key = myKey.getBytes("UTF-8");
/* 274 */       sha = MessageDigest.getInstance("SHA-1");
/* 275 */       key = sha.digest(key);
/* 276 */       key = Arrays.copyOf(key, 16);
/* 277 */       secretKey = new SecretKeySpec(key, "AES");
/*     */     }
/* 279 */     catch (NoSuchAlgorithmException e) {
/* 280 */       e.printStackTrace();
/*     */     }
/* 282 */     catch (UnsupportedEncodingException e) {
/* 283 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String fixWidth(String text, FontSize font, float maxWidth) {
/* 288 */     if (font.getWidth(text) <= maxWidth) {
/* 289 */       return text;
/*     */     }
/* 291 */     String ellipsis = "..";
/* 292 */     float ellipsisWidth = font.getWidth(ellipsis);
/* 293 */     if (ellipsisWidth > maxWidth) {
/* 294 */       return "";
/*     */     }
/* 296 */     int lo = 0;
/* 297 */     int hi = text.length();
/* 298 */     int best = 0;
/* 299 */     while (lo <= hi) {
/* 300 */       int mid = (lo + hi) / 2;
/* 301 */       int i = mid / 2;
/* 302 */       int j = mid - i;
/* 303 */       String candidate = text.substring(0, i) + text.substring(0, i) + ellipsis;
/* 304 */       if (font.getWidth(candidate) <= maxWidth) {
/* 305 */         best = mid;
/* 306 */         lo = mid + 1; continue;
/*     */       } 
/* 308 */       hi = mid - 1;
/*     */     } 
/*     */     
/* 311 */     int prefixCount = best / 2;
/* 312 */     int suffixCount = best - prefixCount;
/* 313 */     return text.substring(0, prefixCount) + text.substring(0, prefixCount) + ellipsis;
/*     */   }
/*     */   
/*     */   public static String formatTime(long milliseconds) {
/* 317 */     long totalSeconds = milliseconds / 1000L;
/* 318 */     long days = totalSeconds / 86400L;
/* 319 */     totalSeconds %= 86400L;
/* 320 */     long hours = totalSeconds / 3600L;
/* 321 */     totalSeconds %= 3600L;
/* 322 */     long minutes = totalSeconds / 60L;
/* 323 */     long seconds = totalSeconds % 60L;
/* 324 */     StringBuilder sb = new StringBuilder();
/* 325 */     if (days > 0L) {
/* 326 */       sb.append(days).append(" ").append(getWord(days, "день", "дня", "дней")).append(" ");
/*     */     }
/* 328 */     if (hours > 0L) {
/* 329 */       sb.append(hours).append(" ").append(getWord(hours, "час", "часа", "часов")).append(" ");
/*     */     }
/* 331 */     if (minutes > 0L) {
/* 332 */       sb.append(minutes).append(" ").append(getWord(minutes, "минуту", "минуты", "минут")).append(" ");
/*     */     }
/* 334 */     if (seconds > 0L || sb.length() == 0) {
/* 335 */       sb.append(seconds).append(" ").append(getWord(seconds, "секунду", "секунды", "секунд")).append(" ");
/*     */     }
/* 337 */     return sb.toString().trim();
/*     */   }
/*     */   
/*     */   private static String getWord(long number, String form1, String form2, String form5) {
/* 341 */     long n = number % 100L;
/* 342 */     if (n >= 11L && n <= 19L) {
/* 343 */       return form5;
/*     */     }
/* 345 */     n = number % 10L;
/* 346 */     if (n == 1L) {
/* 347 */       return form1;
/*     */     }
/* 349 */     if (n >= 2L && n <= 4L) {
/* 350 */       return form2;
/*     */     }
/* 352 */     return form5;
/*     */   }
/*     */   
/*     */   public static List<String> wrapText(String text, FontSize font, float maxWidth) {
/* 356 */     List<String> lines = new ArrayList<>();
/* 357 */     while (font.getWidth(text) > maxWidth) {
/* 358 */       int lastSpace = -1;
/* 359 */       for (int i = 0; i < text.length() && 
/* 360 */         font.getWidth(text.substring(0, i)) <= maxWidth; i++) {
/*     */ 
/*     */         
/* 363 */         if (text.charAt(i) == ' ') {
/* 364 */           lastSpace = i;
/*     */         }
/*     */       } 
/* 367 */       if (lastSpace == -1) lastSpace = text.length(); 
/* 368 */       lines.add(text.substring(0, lastSpace));
/* 369 */       text = text.substring(lastSpace).trim();
/*     */     } 
/* 371 */     lines.add(text);
/* 372 */     return lines;
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\system\TextUtility.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */