/*    */ package fun.rockstarity.api.helpers.system;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileWriter;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import java.util.Collections;
/*    */ import ru.kotopushka.antiautistleak.obfuscator.includes.annotations.compile.ReleaseCompileToNativeCalls;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ReleaseCompileToNativeCalls
/*    */ public final class FileUtility
/*    */ {
/*    */   private FileUtility() {
/* 21 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*    */   }
/*    */   public static String readInputStream(InputStream inputStream) {
/* 24 */     StringBuilder stringBuilder = new StringBuilder();
/*    */     
/*    */     try {
/* 27 */       BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
/*    */       String line;
/* 29 */       while ((line = bufferedReader.readLine()) != null) {
/* 30 */         stringBuilder.append(line).append('\n');
/*    */       }
/* 32 */     } catch (Exception e) {
/* 33 */       e.printStackTrace();
/*    */     } 
/* 35 */     return stringBuilder.toString();
/*    */   }
/*    */   
/*    */   public static String readFile(File file) {
/* 39 */     StringBuilder stringBuilder = new StringBuilder();
/*    */     
/*    */     try {
/* 42 */       FileInputStream fileInputStream = new FileInputStream(file);
/*    */       
/* 44 */       BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(fileInputStream)); 
/*    */       try { String line;
/* 46 */         while ((line = bufferedReader.readLine()) != null)
/* 47 */           stringBuilder.append(line).append('\n');  } finally { if (Collections.<BufferedReader>singletonList(bufferedReader).get(0) != null)
/*    */           bufferedReader.close();  } 
/* 49 */     } catch (Exception e) {
/* 50 */       e.printStackTrace();
/*    */     } 
/* 52 */     return stringBuilder.toString();
/*    */   }
/*    */   
/*    */   public static void writeFile(File file, String content) {
/*    */     try {
/* 57 */       FileWriter fw = new FileWriter(file);
/* 58 */       fw.write(content);
/* 59 */       fw.flush();
/* 60 */       fw.close();
/* 61 */     } catch (IOException e) {
/* 62 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\system\FileUtility.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */