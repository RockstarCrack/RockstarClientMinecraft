/*    */ package fun.rockstarity.api.helpers.system;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ThreadManager
/*    */ {
/*    */   private ThreadManager() {
/* 11 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*    */   }
/*    */   public static Thread run(Runnable runnable) {
/* 14 */     Thread thread = new Thread(() -> runnable.run());
/* 15 */     thread.start();
/* 16 */     return thread;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\system\ThreadManager.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */