/*      */ package fun.rockstarity.api.helpers.render;
/*      */ 
/*      */ import com.mojang.blaze3d.matrix.MatrixStack;
/*      */ import com.mojang.blaze3d.platform.GlStateManager;
/*      */ import com.mojang.blaze3d.systems.RenderSystem;
/*      */ import fun.rockstarity.api.IAccess;
/*      */ import fun.rockstarity.api.Reacher;
/*      */ import fun.rockstarity.api.render.color.FixColor;
/*      */ import fun.rockstarity.api.render.color.themes.Style;
/*      */ import fun.rockstarity.api.render.shaders.fog.Vector2d;
/*      */ import fun.rockstarity.api.render.shaders.list.Glow;
/*      */ import fun.rockstarity.api.render.shaders.list.Outline;
/*      */ import fun.rockstarity.api.render.shaders.list.Round;
/*      */ import fun.rockstarity.api.render.ui.rect.Rect;
/*      */ import fun.rockstarity.api.secure.nativeapi.FastNative;
/*      */ import fun.rockstarity.client.modules.render.Beautifully;
/*      */ import fun.rockstarity.client.modules.render.GlowESP;
/*      */ import fun.rockstarity.client.modules.render.Interface;
/*      */ import java.awt.Color;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.nio.BufferOverflowException;
/*      */ import java.nio.ByteBuffer;
/*      */ import net.minecraft.client.MainWindow;
/*      */ import net.minecraft.client.Minecraft;
/*      */ import net.minecraft.client.gui.screen.inventory.ContainerScreen;
/*      */ import net.minecraft.client.renderer.ActiveRenderInfo;
/*      */ import net.minecraft.client.renderer.BufferBuilder;
/*      */ import net.minecraft.client.renderer.IRenderTypeBuffer;
/*      */ import net.minecraft.client.renderer.RenderHelper;
/*      */ import net.minecraft.client.renderer.Tessellator;
/*      */ import net.minecraft.client.renderer.WorldVertexBufferUploader;
/*      */ import net.minecraft.client.renderer.entity.EntityRendererManager;
/*      */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*      */ import net.minecraft.entity.Entity;
/*      */ import net.minecraft.entity.LivingEntity;
/*      */ import net.minecraft.entity.player.PlayerEntity;
/*      */ import net.minecraft.item.Item;
/*      */ import net.minecraft.item.ItemStack;
/*      */ import net.minecraft.util.IItemProvider;
/*      */ import net.minecraft.util.ResourceLocation;
/*      */ import net.minecraft.util.math.AxisAlignedBB;
/*      */ import net.minecraft.util.math.BlockPos;
/*      */ import net.minecraft.util.math.MathHelper;
/*      */ import net.minecraft.util.math.vector.Matrix4f;
/*      */ import net.minecraft.util.math.vector.Quaternion;
/*      */ import net.minecraft.util.math.vector.Vector2f;
/*      */ import net.minecraft.util.math.vector.Vector3d;
/*      */ import net.minecraft.util.math.vector.Vector3f;
/*      */ import net.optifine.Config;
/*      */ import net.optifine.shaders.Shaders;
/*      */ import org.lwjgl.BufferUtils;
/*      */ import org.lwjgl.opengl.GL11;
/*      */ import org.lwjgl.opengl.GL30;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Render
/*      */   implements IAccess
/*      */ {
/*      */   private Render() {
/*   63 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*      */   }
/*      */   public static void glow(MatrixStack ms, Rect rect, float alpha) {
/*   66 */     glow(ms, rect, alpha, true);
/*      */   }
/*      */   
/*      */   public static void glow(MatrixStack ms, Rect rect, float alpha, boolean stencil) {
/*   70 */     if (!Interface.glow())
/*      */       return; 
/*   72 */     Interface ui = (Interface)rock.getModules().get(Interface.class);
/*      */     
/*   74 */     float offset = ui.getOffset().get();
/*      */     
/*   76 */     FixColor[] circle = Interface.getCircle(alpha);
/*      */     
/*   78 */     if (stencil) {
/*   79 */       Stencil.init();
/*   80 */       Round.draw(ms, rect, 4.0F, FixColor.WHITE);
/*   81 */       Stencil.read(0);
/*      */     } 
/*      */     
/*   84 */     Glow.draw(ms, rect.size(-1.0F), offset, ui.getAlpha().get(), offset, circle[0], circle[1], circle[2], circle[3]);
/*      */     
/*   86 */     if (stencil) {
/*   87 */       Stencil.finish();
/*      */     }
/*      */   }
/*      */   
/*      */   public static void outline(MatrixStack ms, Rect rect, float alpha) {
/*   92 */     if (!Interface.outline())
/*   93 */       return;  Interface ui = (Interface)rock.getModules().get(Interface.class);
/*      */     
/*   95 */     FixColor[] circle = Interface.getCircle(alpha);
/*   96 */     Outline.draw(ms, rect.y(rect.getY()).size(-0.25F), 4.0F, ui.getOutlineWidth().get() / 4.0F, circle[0], circle[1], circle[2], circle[3]);
/*      */   }
/*      */   
/*      */   public static void grid(MatrixStack matrixStack, FixColor color, float step) {
/*  100 */     step = Math.max(1.0F, step);
/*      */     
/*  102 */     for (int x = 0; x < sr.getScaledWidth(); x = (int)(x + step)) {
/*  103 */       Round.draw(matrixStack, new Rect(x, 0.0F, 1.0F, sr.getScaledHeight()), 0.0F, color);
/*      */     }
/*  105 */     for (int y = 0; y < sr.getScaledWidth(); y = (int)(y + step)) {
/*  106 */       Round.draw(matrixStack, new Rect(0.0F, y, sr.getScaledWidth(), 1.0F), 0.0F, color);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void gridMask(MatrixStack matrixStack, FixColor color, Rect rect, float offset) {
/*  111 */     FixColor c = color;
/*      */     
/*  113 */     Stencil.init();
/*  114 */     grid(matrixStack, FixColor.WHITE, (sr.getScaledWidth() / 15));
/*  115 */     Stencil.read(1);
/*  116 */     Glow.draw(matrixStack, rect.size(-1.0F), offset, 0.2F, 10.0F + offset, c, c, c, c);
/*  117 */     Stencil.finish();
/*      */   }
/*      */   
/*      */   public static void gridMask(MatrixStack matrixStack, FixColor color, Rect rect) {
/*  121 */     gridMask(matrixStack, color, rect, 75.0F);
/*      */   }
/*      */   
/*      */   public static Vector3d cameraPos() {
/*  125 */     return mc.gameRenderer.getActiveRenderInfo().getProjectedView();
/*      */   }
/*      */   
/*      */   public static void drawItem(ItemStack itemStack, float x, float y, float alpha) {
/*  129 */     Reacher.ITEMS_ALPHA = alpha;
/*  130 */     mc.getItemRenderer().renderItemAndEffectIntoGUI(itemStack, (int)x, (int)y);
/*  131 */     mc.getItemRenderer().renderItemOverlayIntoGUI(mc.fontRenderer, itemStack, (int)x, (int)y, null);
/*  132 */     Reacher.ITEMS_ALPHA = 1.0F;
/*      */   }
/*      */   
/*      */   public static void setupOrientationMatrix(MatrixStack matrix, double x, double y, double z) {
/*  136 */     matrix.translate(x - (cameraPos()).x, y - (cameraPos()).y, z - (cameraPos()).z);
/*      */   }
/*      */   
/*      */   public static void rotateToCamera(MatrixStack matrix) {
/*  140 */     matrix.rotate(mc.getRenderManager().getCameraOrientation());
/*      */   }
/*      */ 
/*      */   
/*      */   public static void initRotate(float x, float y, float value) {
/*  145 */     GL11.glPushMatrix();
/*  146 */     GL11.glTranslatef(x, y, 0.0F);
/*  147 */     GL11.glRotatef(value, 0.0F, 0.0F, 1.0F);
/*  148 */     GL11.glTranslatef(-x, -y, 0.0F);
/*      */   }
/*      */   
/*      */   public static void endRotate() {
/*  152 */     GL11.glPopMatrix();
/*      */   }
/*      */   
/*      */   public static void setColor(int color) {
/*  156 */     GL11.glColor4ub((byte)(color >> 16 & 0xFF), (byte)(color >> 8 & 0xFF), (byte)(color & 0xFF), (byte)(color >> 24 & 0xFF));
/*      */   }
/*      */   
/*      */   public static void color(FixColor color) {
/*  160 */     float r = color.getRed() / 255.0F;
/*  161 */     float g = color.getGreen() / 255.0F;
/*  162 */     float b = color.getBlue() / 255.0F;
/*  163 */     float a = color.getAlpha() / 255.0F;
/*  164 */     GlStateManager.color4f(r, g, b, a);
/*      */   }
/*      */   
/*      */   public static void color(int color, float alpha) {
/*  168 */     float r = (color >> 16 & 0xFF) / 255.0F;
/*  169 */     float g = (color >> 8 & 0xFF) / 255.0F;
/*  170 */     float b = (color & 0xFF) / 255.0F;
/*  171 */     GlStateManager.color4f(r, g, b, alpha);
/*      */   }
/*      */   
/*      */   public static void drawStack(ItemStack itemStack, float x, float y, float size) {
/*  175 */     (mc.getItemRenderer()).zLevel = -900.0F;
/*  176 */     GlStateManager.pushMatrix();
/*  177 */     GlStateManager.disableBlend();
/*  178 */     mc.getTextureManager().bindTexture(ContainerScreen.INVENTORY_BACKGROUND);
/*  179 */     GlStateManager.translated(x, y, 0.0D);
/*  180 */     GlStateManager.scalef(size, size, size);
/*  181 */     mc.getItemRenderer().renderItemAndEffectIntoGUI(itemStack, 0, 0);
/*  182 */     mc.getItemRenderer().renderItemOverlayIntoGUI(mc.fontRenderer, itemStack, 0, 0, (itemStack.getCount() > 1) ? ("" + itemStack.getCount()) : "");
/*  183 */     GlStateManager.popMatrix();
/*      */   }
/*      */   
/*      */   public static void drawStackOld(ItemStack itemStack, float x, float y, float size) {
/*  187 */     GlStateManager.pushMatrix();
/*  188 */     GlStateManager.disableBlend();
/*  189 */     mc.getTextureManager().bindTexture(ContainerScreen.INVENTORY_BACKGROUND);
/*  190 */     GlStateManager.translated(x, y, 0.0D);
/*  191 */     GlStateManager.scalef(size, size, size);
/*  192 */     mc.getItemRenderer().renderItemAndEffectIntoGUIOld(itemStack, 0, 0);
/*  193 */     mc.getItemRenderer().renderItemOverlayIntoGUI(mc.fontRenderer, itemStack, 0, 0, (itemStack.getCount() > 1) ? ("" + itemStack.getCount()) : "");
/*  194 */     GlStateManager.popMatrix();
/*      */   }
/*      */   
/*      */   public static void drawItem(Item item, float x, float y) {
/*  198 */     drawStack(new ItemStack((IItemProvider)item), x, y);
/*      */   }
/*      */   
/*      */   public static void drawItem(Item item, float x, float y, float size) {
/*  202 */     ItemStack itemStack = new ItemStack((IItemProvider)item);
/*      */     
/*  204 */     GlStateManager.pushMatrix();
/*  205 */     GlStateManager.disableBlend();
/*  206 */     mc.getTextureManager().bindTexture(ContainerScreen.INVENTORY_BACKGROUND);
/*  207 */     GlStateManager.translated(x, y, 0.0D);
/*  208 */     GlStateManager.scalef(size, size, size);
/*  209 */     mc.getItemRenderer().renderItemAndEffectIntoGUI(itemStack, 0, 0);
/*  210 */     GlStateManager.popMatrix();
/*      */   }
/*      */   
/*      */   public static void drawStack(ItemStack stack, float x, float y) {
/*  214 */     GL11.glPushMatrix();
/*  215 */     GlStateManager.disableLighting();
/*  216 */     GlStateManager.translated(x, y, 0.0D);
/*  217 */     GlStateManager.scaled(0.6D, 0.6D, 0.6D);
/*  218 */     GL11.glEnable(2929);
/*  219 */     mc.getItemRenderer().renderItemIntoGUI(stack, 0, 0);
/*  220 */     mc.getItemRenderer().renderItemOverlayIntoGUI(mc.fontRenderer, stack, 0, 0, 
/*  221 */         (stack.getCount() > 1) ? ("" + stack.getCount()) : "");
/*  222 */     RenderHelper.disableStandardItemLighting();
/*  223 */     GlStateManager.disableLighting();
/*  224 */     GL11.glPopMatrix();
/*  225 */     GL11.glDisable(2929);
/*      */   }
/*      */   
/*      */   private static Vector2d calculateScreenPositiond(Vector3f result3f, double fov) {
/*  229 */     float halfHeight = mc.getMainWindow().getScaledHeight() / 2.0F;
/*  230 */     float scaleFactor = halfHeight / result3f.getZ() * (float)Math.tan(Math.toRadians(fov / 2.0D));
/*  231 */     Beautifully aspect = (Beautifully)rock.getModules().get(Beautifully.class);
/*  232 */     if (result3f.getZ() < 0.0F) {
/*  233 */       return new Vector2d((-result3f.getX() * scaleFactor / (aspect.get() ? aspect.getAspectRatio().get() : 1.0F) + mc.getMainWindow().getScaledWidth() / 2.0F), (mc.getMainWindow().getScaledHeight() / 2.0F - result3f.getY() * scaleFactor));
/*      */     }
/*  235 */     return new Vector2d(3.4028234663852886E38D, 3.4028234663852886E38D);
/*      */   }
/*      */   
/*      */   private static Vector2f calculateScreenPosition(Vector3f result3f, double fov) {
/*  239 */     float halfHeight = mc.getMainWindow().getScaledHeight() / 2.0F;
/*  240 */     float scaleFactor = halfHeight / result3f.getZ() * (float)Math.tan(Math.toRadians(fov / 2.0D));
/*  241 */     Beautifully aspect = (Beautifully)rock.getModules().get(Beautifully.class);
/*  242 */     if (result3f.getZ() < 0.0F) {
/*  243 */       return new Vector2f(-result3f.getX() * scaleFactor / (aspect.get() ? aspect.getAspectRatio().get() : 1.0F) + mc.getMainWindow().getScaledWidth() / 2.0F, mc.getMainWindow().getScaledHeight() / 2.0F - result3f.getY() * scaleFactor);
/*      */     }
/*  245 */     return new Vector2f(Float.MAX_VALUE, Float.MAX_VALUE);
/*      */   }
/*      */   
/*      */   public static double[] worldToScreen(double x, double y, double z) {
/*  249 */     Vector3d camera_pos = (mc.getRenderManager()).info.getProjectedView();
/*  250 */     Beautifully aspect = (Beautifully)rock.getModules().get(Beautifully.class);
/*  251 */     Quaternion camera_rotation_conj = Minecraft.getInstance().getRenderManager().getCameraOrientation().copy();
/*  252 */     camera_rotation_conj.conjugate();
/*  253 */     Vector3f result3f = new Vector3f((float)(camera_pos.x - x), (float)(camera_pos.y - y), (float)(camera_pos.z - z));
/*  254 */     result3f.transform(camera_rotation_conj);
/*      */     
/*  256 */     if ((mc.getGameSettings()).viewBobbing) {
/*  257 */       Entity renderViewEntity = mc.getRenderViewEntity();
/*  258 */       if (renderViewEntity instanceof PlayerEntity) {
/*  259 */         PlayerEntity playerentity = (PlayerEntity)renderViewEntity;
/*  260 */         float distwalked_modified = playerentity.distanceWalkedModified;
/*      */         
/*  262 */         float f = distwalked_modified - playerentity.prevDistanceWalkedModified;
/*  263 */         float f1 = -(distwalked_modified + f * mc.getRenderPartialTicks());
/*  264 */         float f2 = MathHelper.lerp(mc.getRenderPartialTicks(), playerentity.prevCameraYaw, playerentity.cameraYaw);
/*  265 */         Quaternion q2 = new Quaternion(Vector3f.XP, Math.abs(MathHelper.cos(f1 * 3.1415927F - 0.2F) * f2) * 5.0F, true);
/*  266 */         q2.conjugate();
/*  267 */         result3f.transform(q2);
/*      */         
/*  269 */         Quaternion q1 = new Quaternion(Vector3f.ZP, MathHelper.sin(f1 * 3.1415927F) * f2 * 3.0F, true);
/*  270 */         q1.conjugate();
/*  271 */         result3f.transform(q1);
/*      */         
/*  273 */         Vector3f bob_translation = new Vector3f(MathHelper.sin(f1 * 3.1415927F) * f2 * 0.5F, -Math.abs(MathHelper.cos(f1 * 3.1415927F) * f2), 0.0F);
/*  274 */         bob_translation.y = -bob_translation.getY();
/*  275 */         result3f.add(bob_translation);
/*      */       } 
/*      */     } 
/*      */     
/*  279 */     double fov = (float)mc.gameRenderer.getFOVModifier((mc.getRenderManager()).info, mc.getRenderPartialTicks(), true);
/*      */     
/*  281 */     float half_height = Minecraft.getInstance().getMainWindow().getScaledHeight() / 2.0F;
/*  282 */     float scale_factor = half_height / result3f.getZ() * (float)Math.tan(Math.toRadians(fov / 2.0D));
/*      */ 
/*      */     
/*  285 */     return new double[] { (-result3f.getX() * scale_factor / (aspect.get() ? aspect.getAspectRatio().get() : 1.0F) + (Minecraft.getInstance().getMainWindow().getScaledWidth() / 2)), ((Minecraft.getInstance().getMainWindow().getScaledHeight() / 2) - result3f.getY() * scale_factor) };
/*      */   }
/*      */   
/*      */   public static Vector2d project(double x, double y, double z) {
/*  289 */     Vector3d camera_pos = (mc.getRenderManager()).info.getProjectedView();
/*  290 */     Quaternion cameraRotation = mc.getRenderManager().getCameraOrientation().copy();
/*  291 */     cameraRotation.conjugate();
/*      */     
/*  293 */     Vector3f result3f = new Vector3f((float)(camera_pos.x - x), (float)(camera_pos.y - y), (float)(camera_pos.z - z));
/*  294 */     result3f.transform(cameraRotation);
/*      */     
/*  296 */     if ((mc.getGameSettings()).viewBobbing) {
/*  297 */       Entity renderViewEntity = mc.getRenderViewEntity();
/*  298 */       if (renderViewEntity instanceof PlayerEntity) { PlayerEntity playerentity = (PlayerEntity)renderViewEntity;
/*  299 */         calculateViewBobbing(playerentity, result3f); }
/*      */     
/*      */     } 
/*      */     
/*  303 */     double fov = mc.gameRenderer.getFOVModifier((mc.getRenderManager()).info, mc.getRenderPartialTicks(), true);
/*      */     
/*  305 */     return calculateScreenPositiond(result3f, fov);
/*      */   }
/*      */   
/*      */   public static Vector2f projectf(double x, double y, double z) {
/*  309 */     Vector3d camera_pos = (mc.getRenderManager()).info.getProjectedView();
/*  310 */     Quaternion cameraRotation = mc.getRenderManager().getCameraOrientation().copy();
/*  311 */     cameraRotation.conjugate();
/*      */     
/*  313 */     Vector3f result3f = new Vector3f((float)(camera_pos.x - x), (float)(camera_pos.y - y), (float)(camera_pos.z - z));
/*  314 */     result3f.transform(cameraRotation);
/*      */     
/*  316 */     if ((mc.getGameSettings()).viewBobbing) {
/*  317 */       Entity renderViewEntity = mc.getRenderViewEntity();
/*  318 */       if (renderViewEntity instanceof PlayerEntity) { PlayerEntity playerentity = (PlayerEntity)renderViewEntity;
/*  319 */         calculateViewBobbing(playerentity, result3f); }
/*      */     
/*      */     } 
/*      */     
/*  323 */     double fov = mc.gameRenderer.getFOVModifier((mc.getRenderManager()).info, mc.getRenderPartialTicks(), true);
/*      */     
/*  325 */     return calculateScreenPosition(result3f, fov);
/*      */   }
/*      */   
/*      */   private static void calculateViewBobbing(PlayerEntity playerentity, Vector3f result3f) {
/*  329 */     float walked = playerentity.distanceWalkedModified;
/*  330 */     float f = walked - playerentity.prevDistanceWalkedModified;
/*  331 */     float f1 = -(walked + f * mc.getRenderPartialTicks());
/*  332 */     float f2 = MathHelper.lerp(mc.getRenderPartialTicks(), playerentity.prevCameraYaw, playerentity.cameraYaw);
/*      */     
/*  334 */     Quaternion quaternion = new Quaternion(Vector3f.XP, Math.abs(MathHelper.cos(f1 * 3.1415927F - 0.2F) * f2) * 5.0F, true);
/*  335 */     quaternion.conjugate();
/*  336 */     result3f.transform(quaternion);
/*      */     
/*  338 */     Quaternion quaternion1 = new Quaternion(Vector3f.ZP, MathHelper.sin(f1 * 3.1415927F) * f2 * 3.0F, true);
/*  339 */     quaternion1.conjugate();
/*  340 */     result3f.transform(quaternion1);
/*      */     
/*  342 */     Vector3f bobTranslation = new Vector3f(MathHelper.sin(f1 * 3.1415927F) * f2 * 0.5F, -Math.abs(MathHelper.cos(f1 * 3.1415927F) * f2), 0.0F);
/*  343 */     bobTranslation.setY(-bobTranslation.getY());
/*  344 */     result3f.add(bobTranslation);
/*      */   }
/*      */   
/*      */   public static void drawCircle(float x, float y, float start, float end, float radius, float width, boolean filled, int color) {
/*  348 */     GL11.glColor4f(0.0F, 0.0F, 0.0F, 0.0F);
/*      */     
/*  350 */     if (start > end) {
/*  351 */       float endOffset = end;
/*  352 */       end = start;
/*  353 */       start = endOffset;
/*      */     } 
/*  355 */     GlStateManager.enableBlend();
/*  356 */     GlStateManager.disableTexture();
/*  357 */     GlStateManager.glBlendFuncSeparate(770, 771, 1, 0);
/*  358 */     color(color);
/*  359 */     GL11.glEnable(2848);
/*  360 */     GL11.glLineWidth(width);
/*  361 */     GL11.glBegin(3); float i;
/*  362 */     for (i = end; i >= start; i -= 4.0F) {
/*  363 */       float cos = (float)(Math.cos(i * Math.PI / 180.0D) * radius * 1.0D);
/*  364 */       float sin = (float)(Math.sin(i * Math.PI / 180.0D) * radius * 1.0D);
/*  365 */       GL11.glVertex2f(x + cos, y + sin);
/*      */     } 
/*  367 */     GL11.glEnd();
/*  368 */     GL11.glDisable(2848);
/*  369 */     GlStateManager.enableTexture();
/*  370 */     GlStateManager.disableBlend();
/*      */   }
/*      */   
/*      */   public static void drawCircle(int color, float x, float y, float radius, int start, int end) {
/*  374 */     GlStateManager.enableBlend();
/*  375 */     GlStateManager.disableTexture();
/*  376 */     GlStateManager.blendFuncSeparate(770, 771, 1, 0);
/*  377 */     color(color);
/*  378 */     GL11.glEnable(2848);
/*  379 */     GL11.glLineWidth(2.0F);
/*  380 */     GL11.glBegin(3); float i;
/*  381 */     for (i = end; i >= start; i -= 4.0F) {
/*  382 */       GL11.glVertex2f((float)(x + Math.cos(i * Math.PI / 180.0D) * (radius * 1.001F)), (float)(y + Math.sin(i * Math.PI / 180.0D) * (radius * 1.001F)));
/*      */     }
/*  384 */     GL11.glEnd();
/*  385 */     GL11.glDisable(2848);
/*  386 */     GlStateManager.enableTexture();
/*  387 */     GlStateManager.disableBlend();
/*      */   }
/*      */   
/*      */   public static void drawCircle(int color, float x, float y, float radius, float width, int start, int end) {
/*  391 */     GlStateManager.enableBlend();
/*  392 */     GlStateManager.disableTexture();
/*  393 */     GlStateManager.blendFuncSeparate(770, 771, 1, 0);
/*  394 */     color(color);
/*  395 */     GL11.glEnable(2848);
/*  396 */     GL11.glLineWidth(width);
/*  397 */     GL11.glBegin(3); float i;
/*  398 */     for (i = end; i >= start; i -= 4.0F) {
/*  399 */       GL11.glVertex2f((float)(x + Math.cos(i * Math.PI / 180.0D) * (radius * 1.001F)), (float)(y + Math.sin(i * Math.PI / 180.0D) * (radius * 1.001F)));
/*      */     }
/*  401 */     GL11.glEnd();
/*  402 */     GL11.glDisable(2848);
/*  403 */     GlStateManager.enableTexture();
/*  404 */     GlStateManager.disableBlend();
/*      */   }
/*      */   
/*      */   public static void drawTriangle(float x, float y, float size, float vector, int color) {
/*  408 */     GlStateManager.pushMatrix();
/*  409 */     GlStateManager.disableTexture();
/*  410 */     GlStateManager.enableBlend();
/*  411 */     GlStateManager.disableAlphaTest();
/*  412 */     GlStateManager.glBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA.param, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA.param, GlStateManager.SourceFactor.ONE.param, GlStateManager.DestFactor.ZERO.param);
/*  413 */     GlStateManager.shadeModel(7425);
/*  414 */     GL11.glTranslated(x, y, 0.0D);
/*  415 */     GL11.glRotatef(vector, 0.0F, 0.0F, 1.0F);
/*  416 */     float alpha = (color >> 24 & 0xFF) / 255.0F;
/*  417 */     float red = (color >> 16 & 0xFF) / 255.0F;
/*  418 */     float green = (color >> 8 & 0xFF) / 255.0F;
/*  419 */     float blue = (color & 0xFF) / 255.0F;
/*  420 */     GlStateManager.color4f(red, green, blue, alpha);
/*  421 */     GL11.glEnable(3042);
/*  422 */     GL11.glDisable(3553);
/*  423 */     GL11.glEnable(2848);
/*  424 */     GL11.glBlendFunc(770, 771);
/*  425 */     GL11.glLineWidth(1.0F);
/*  426 */     GL11.glBegin(4);
/*  427 */     GL11.glVertex2d(0.0D, size);
/*  428 */     GL11.glVertex2d((1.0F * size), -size);
/*  429 */     GL11.glVertex2d(-(1.0F * size), -size);
/*  430 */     GL11.glEnd();
/*  431 */     GL11.glDisable(2848);
/*  432 */     GL11.glEnable(3553);
/*  433 */     GL11.glDisable(3042);
/*  434 */     GL11.glRotatef(-vector, 0.0F, 0.0F, 1.0F);
/*  435 */     GL11.glTranslated(-x, -y, 0.0D);
/*  436 */     GlStateManager.shadeModel(7424);
/*  437 */     GlStateManager.disableBlend();
/*  438 */     GlStateManager.enableAlphaTest();
/*  439 */     GlStateManager.enableTexture();
/*  440 */     GlStateManager.popMatrix();
/*      */   }
/*      */   
/*      */   public static void drawLine(float startX, float startY, float endX, float endY, int segments) {
/*  444 */     GL11.glEnable(2848);
/*  445 */     GL11.glHint(3154, 4354);
/*      */     
/*  447 */     GL11.glColor3f(1.0F, 1.0F, 1.0F);
/*      */     
/*  449 */     GL11.glLineWidth(4.0F);
/*      */     
/*  451 */     float dx = (endX - startX) / segments;
/*  452 */     float dy = (endY - startY) / segments;
/*      */     
/*  454 */     GL11.glBegin(3);
/*      */     
/*  456 */     for (int i = 0; i <= segments; i++) {
/*  457 */       float x = startX + i * dx;
/*  458 */       float y = startY + i * dy;
/*      */       
/*  460 */       GL11.glVertex2f(x, y);
/*      */     } 
/*      */     
/*  463 */     GL11.glEnd();
/*      */   }
/*      */   
/*      */   public static int loadTexture(BufferedImage image) {
/*  467 */     int[] pixels = image.getRGB(0, 0, image.getWidth(), image.getHeight(), null, 0, image.getWidth());
/*  468 */     ByteBuffer buffer = BufferUtils.createByteBuffer(pixels.length * 4);
/*      */ 
/*      */     
/*  471 */     try { for (int pixel : pixels) {
/*  472 */         buffer.put((byte)(pixel >> 16 & 0xFF));
/*  473 */         buffer.put((byte)(pixel >> 8 & 0xFF));
/*  474 */         buffer.put((byte)(pixel & 0xFF));
/*  475 */         buffer.put((byte)(pixel >> 24 & 0xFF));
/*      */       } 
/*  477 */       buffer.flip(); }
/*  478 */     catch (BufferOverflowException|java.nio.ReadOnlyBufferException ex) { return -1; }
/*      */     
/*  480 */     int textureID = GlStateManager.genTexture();
/*  481 */     GlStateManager.bindTexture(textureID);
/*  482 */     GlStateManager.texParameter(3553, 10241, 9729);
/*  483 */     GlStateManager.texParameter(3553, 10240, 9729);
/*  484 */     GL30.glTexImage2D(3553, 0, 32856, image.getWidth(), image.getHeight(), 0, 6408, 5121, buffer);
/*  485 */     GlStateManager.bindTexture(0);
/*      */     
/*  487 */     return textureID;
/*      */   }
/*      */   
/*      */   public static void color(int color) {
/*  491 */     color(color, (color >> 24 & 0xFF) / 255.0F);
/*      */   }
/*      */   
/*      */   public static void resetColor() {
/*  495 */     GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
/*      */   }
/*      */   
/*      */   public static void setAlphaLimit(float limit) {
/*  499 */     GlStateManager.enableAlphaTest();
/*  500 */     GlStateManager.alphaFunc(516, (float)(limit * 0.01D));
/*      */   }
/*      */   
/*      */   public static void drawModalRectWithCustomSizedTexture(float x, float y, float u, float v, float width, float height, float textureWidth, float textureHeight) {
/*  504 */     float f = 1.0F / textureWidth;
/*  505 */     float f1 = 1.0F / textureHeight;
/*  506 */     Tessellator tessellator = Tessellator.getInstance();
/*  507 */     BufferBuilder worldrenderer = tessellator.getBuffer();
/*  508 */     worldrenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
/*  509 */     worldrenderer.pos(x, (y + height), 0.0D).tex(u * f, (v + height - 0.5F) * f1).tex(0.0F, 0.99F).endVertex();
/*  510 */     worldrenderer.pos((x + width), (y + height), 0.0D).tex((u + width) * f, (v + height - 0.5F) * f1).tex(1.0F, 0.99F).endVertex();
/*  511 */     worldrenderer.pos((x + width), y, 0.0D).tex((u + width) * f, v * f1).tex(1.0F, 0.0F).endVertex();
/*  512 */     worldrenderer.pos(x, y, 0.0D).tex(u * f, v * f1).tex(0.0F, 0.0F).endVertex();
/*      */     
/*  514 */     tessellator.draw();
/*      */   }
/*      */   public static void drawScaledCustomSizeModalRect(float x, float y, float u, float v, float uWidth, float vHeight, float width, float height, float tileWidth, float tileHeight) {
/*  517 */     float f = 1.0F / tileWidth;
/*  518 */     float f1 = 1.0F / tileHeight;
/*  519 */     Tessellator tessellator = Tessellator.getInstance();
/*  520 */     BufferBuilder worldrenderer = tessellator.getBuffer();
/*  521 */     worldrenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
/*  522 */     worldrenderer.pos(x, (y + height), 0.0D).tex(u * f, (v + vHeight) * f1).endVertex();
/*  523 */     worldrenderer.pos((x + width), (y + height), 0.0D).tex((u + uWidth) * f, (v + vHeight) * f1).endVertex();
/*  524 */     worldrenderer.pos((x + width), y, 0.0D).tex((u + uWidth) * f, v * f1).endVertex();
/*  525 */     worldrenderer.pos(x, y, 0.0D).tex(u * f, v * f1).endVertex();
/*  526 */     tessellator.draw();
/*      */   }
/*      */   
/*      */   public static void bindTexture(int texture) {
/*  530 */     GL11.glBindTexture(3553, texture);
/*      */   }
/*      */   
/*      */   public static void scissor(double x, double y, double width, double height) {
/*  534 */     MainWindow sr = Minecraft.getInstance().getMainWindow();
/*  535 */     double scale = sr.getGuiScaleFactor();
/*  536 */     double finalHeight = height * scale;
/*  537 */     double finalY = (sr.getScaledHeight() - y) * scale;
/*  538 */     double finalX = x * scale;
/*  539 */     double finalWidth = width * scale;
/*  540 */     GL11.glScissor((int)finalX, (int)(finalY - finalHeight), (int)finalWidth, (int)finalHeight);
/*      */   }
/*      */   
/*      */   public static void drawCircle(float x, float y, float radius, int start, int end, FixColor color) {
/*  544 */     drawCircle(x, y, radius, start, end, 1.5F, color);
/*      */   }
/*      */   
/*      */   public static void drawCircle(float x, float y, float radius, int start, int end, float width, FixColor color) {
/*  548 */     GlStateManager.enableBlend();
/*  549 */     GlStateManager.disableTexture();
/*  550 */     GlStateManager.blendFuncSeparate(770, 771, 1, 0);
/*  551 */     GL11.glEnable(2848);
/*  552 */     GL11.glLineWidth(width);
/*  553 */     GL11.glBegin(3); float i;
/*  554 */     for (i = end; i >= start; i -= 4.0F) {
/*  555 */       color(color.getRGB());
/*  556 */       GL11.glVertex2f((float)(x + Math.cos(i * Math.PI / 180.0D) * (radius * 1.001F)), (float)(y + Math.sin(i * Math.PI / 180.0D) * (radius * 1.001F)));
/*      */     } 
/*  558 */     GL11.glEnd();
/*  559 */     GL11.glDisable(2848);
/*  560 */     GlStateManager.enableTexture();
/*  561 */     GlStateManager.disableBlend();
/*      */   }
/*      */   
/*      */   public static void drawUICircle(float x, float y, float radius, int start, int end, float alpha) {
/*  565 */     drawClientCircle(x, y, radius, start, end, 1.5F, alpha);
/*      */   }
/*      */   
/*      */   public static void drawUICircle(float x, float y, float radius, int start, int end, float width, float alpha) {
/*  569 */     GlStateManager.enableBlend();
/*  570 */     GlStateManager.disableTexture();
/*  571 */     GlStateManager.blendFuncSeparate(770, 771, 1, 0);
/*  572 */     GL11.glEnable(2848);
/*  573 */     GL11.glLineWidth(width);
/*  574 */     GL11.glBegin(3); float i;
/*  575 */     for (i = end; i >= start; i -= 4.0F) {
/*  576 */       color(Interface.getPoint((int)i, alpha).getRGB());
/*  577 */       GL11.glVertex2f((float)(x + Math.cos(i * Math.PI / 180.0D) * (radius * 1.001F)), 
/*  578 */           (float)(y + Math.sin(i * Math.PI / 180.0D) * (radius * 1.001F)));
/*      */     } 
/*  580 */     GL11.glEnd();
/*  581 */     GL11.glDisable(2848);
/*  582 */     GlStateManager.enableTexture();
/*  583 */     GlStateManager.disableBlend();
/*      */   }
/*      */   
/*      */   public static void drawClientCircle(float x, float y, float radius, int start, int end, float alpha) {
/*  587 */     drawClientCircle(x, y, radius, start, end, 3.5F, alpha);
/*      */   }
/*      */   
/*      */   public static void drawClientCircle(float x, float y, float radius, int start, int end, float width, float alpha) {
/*  591 */     GlStateManager.enableBlend();
/*  592 */     GlStateManager.disableTexture();
/*  593 */     GlStateManager.blendFuncSeparate(770, 771, 1, 0);
/*  594 */     GL11.glEnable(2848);
/*  595 */     GL11.glLineWidth(width);
/*  596 */     GL11.glBegin(3); float i;
/*  597 */     for (i = end; i >= start; i -= 4.0F) {
/*  598 */       color(Style.getPoint((int)i).getRGB(), alpha);
/*  599 */       GL11.glVertex2f((float)(x + Math.cos(i * Math.PI / 180.0D) * (radius * 1.001F)), 
/*  600 */           (float)(y + Math.sin(i * Math.PI / 180.0D) * (radius * 1.001F)));
/*      */     } 
/*  602 */     GL11.glEnd();
/*  603 */     GL11.glDisable(2848);
/*  604 */     GlStateManager.enableTexture();
/*  605 */     GlStateManager.disableBlend();
/*      */   }
/*      */   
/*      */   public static void drawClientCircle(float x, float y, float radius, int start, int end) {
/*  609 */     GlStateManager.enableBlend();
/*  610 */     GlStateManager.disableTexture();
/*  611 */     GlStateManager.blendFuncSeparate(770, 771, 1, 0);
/*  612 */     GL11.glEnable(2848);
/*  613 */     GL11.glLineWidth(2.0F);
/*  614 */     GL11.glBegin(3); float i;
/*  615 */     for (i = end; i >= start; i -= 4.0F) {
/*  616 */       color(Style.getMain());
/*  617 */       GL11.glVertex2f((float)(x + Math.cos(i * Math.PI / 180.0D) * (radius * 1.001F)), (float)(y + Math.sin(i * Math.PI / 180.0D) * (radius * 1.001F)));
/*      */     } 
/*  619 */     GL11.glEnd();
/*  620 */     GL11.glDisable(2848);
/*  621 */     GlStateManager.enableTexture();
/*  622 */     GlStateManager.disableBlend();
/*      */   }
/*      */   
/*      */   public static Rect image(String name, float x, float y, float width, float height, Color color) {
/*  626 */     GL11.glPushMatrix();
/*  627 */     GL11.glEnable(3042);
/*  628 */     GL11.glBlendFunc(770, 771);
/*  629 */     GlStateManager.color4f(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
/*      */     try {
/*  631 */       mc.getTextureManager().bindTexture(FastNative.getImageResource(name));
/*  632 */     } catch (Exception exception) {}
/*      */ 
/*      */     
/*  635 */     GL11.glTexParameteri(3553, 10240, 9729);
/*  636 */     GL11.glTexParameteri(3553, 10241, 9729);
/*  637 */     drawModalRectWithCustomSizedTexture(x, y, 0.0F, 0.0F, width, height, width, height);
/*  638 */     GL11.glPopMatrix();
/*      */     
/*  640 */     return new Rect(x, y, width, height);
/*      */   }
/*      */   
/*      */   public static void image(MatrixStack stack, String name, double x, double y, double z, double width, double height, FixColor color1, FixColor color2, FixColor color3, FixColor color4) {
/*  644 */     GlStateManager.enableBlend();
/*  645 */     GL11.glBlendFunc(770, 771);
/*  646 */     mc.getTextureManager().bindTexture(FastNative.getImageResource(name));
/*  647 */     RenderSystem.color4f(1.0F, 1.0F, 1.0F, 1.0F);
/*      */     
/*  649 */     Matrix4f matrix = stack.getLast().getMatrix();
/*  650 */     int color1RGB = color1.getRGB();
/*  651 */     int color2RGB = color2.getRGB();
/*  652 */     int color3RGB = color3.getRGB();
/*  653 */     int color4RGB = color4.getRGB();
/*  654 */     GL11.glTexParameteri(3553, 10240, 9729);
/*  655 */     GL11.glTexParameteri(3553, 10241, 9729);
/*  656 */     BUILDER.begin(7, DefaultVertexFormats.POSITION_COLOR_TEX_LIGHTMAP);
/*  657 */     BUILDER.pos(matrix, (float)x, (float)(y + height), (float)z).color(color1RGB >> 16 & 0xFF, color1RGB >> 8 & 0xFF, color1RGB & 0xFF, color1.getAlpha()).tex(0.0F, 0.99F).lightmap(0, 240).endVertex();
/*  658 */     BUILDER.pos(matrix, (float)(x + width), (float)(y + height), (float)z).color(color2RGB >> 16 & 0xFF, color2RGB >> 8 & 0xFF, color2RGB & 0xFF, color2.getAlpha()).tex(1.0F, 0.99F).lightmap(0, 240).endVertex();
/*  659 */     BUILDER.pos(matrix, (float)(x + width), (float)y, (float)z).color(color3RGB >> 16 & 0xFF, color3RGB >> 8 & 0xFF, color3RGB & 0xFF, color3.getAlpha()).tex(1.0F, 0.0F).lightmap(0, 240).endVertex();
/*  660 */     BUILDER.pos(matrix, (float)x, (float)y, (float)z).color(color4RGB >> 16 & 0xFF, color4RGB >> 8 & 0xFF, color4RGB & 0xFF, color4.getAlpha()).tex(0.0F, 0.0F).lightmap(0, 240).endVertex();
/*      */     
/*  662 */     TESSELLATOR.draw();
/*  663 */     GlStateManager.disableBlend();
/*      */   }
/*      */   
/*      */   public static void image(ResourceLocation image, float x, float y, float width, float height, Color color) {
/*  667 */     GL11.glPushMatrix();
/*  668 */     GL11.glDisable(2929);
/*  669 */     GL11.glEnable(3042);
/*  670 */     GL11.glDepthMask(false);
/*  671 */     GL11.glBlendFunc(770, 771);
/*  672 */     GlStateManager.color4f(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
/*  673 */     Minecraft.getInstance().getTextureManager().bindTexture(image);
/*  674 */     GL11.glTexParameteri(3553, 10240, 9729);
/*  675 */     GL11.glTexParameteri(3553, 10241, 9729);
/*  676 */     drawModalRectWithCustomSizedTexture(x, y, 0.0F, 0.0F, width, height, width, height);
/*  677 */     GL11.glPopMatrix();
/*      */   }
/*      */   
/*      */   public static void drawImage(MatrixStack stack, String name, double x, double y, double z, double width, double height, FixColor color) {
/*  681 */     drawImage(stack, name, x, y, z, width, height, color, color, color, color);
/*      */   }
/*      */   
/*      */   public static void drawImage(MatrixStack stack, String name, double x, double y, double z, double width, double height, FixColor color1, FixColor color2, FixColor color3, FixColor color4) {
/*  685 */     GlStateManager.enableBlend();
/*  686 */     GlStateManager.blendFunc(770, 1);
/*  687 */     mc.getTextureManager().bindTexture(FastNative.getImageResource(name));
/*  688 */     RenderSystem.color4f(1.0F, 1.0F, 1.0F, 1.0F);
/*      */     
/*  690 */     Matrix4f matrix = stack.getLast().getMatrix();
/*  691 */     int color1RGB = color1.getRGB();
/*  692 */     int color2RGB = color2.getRGB();
/*  693 */     int color3RGB = color3.getRGB();
/*  694 */     int color4RGB = color4.getRGB();
/*      */     
/*  696 */     BUILDER.begin(7, DefaultVertexFormats.POSITION_COLOR_TEX_LIGHTMAP);
/*  697 */     BUILDER.pos(matrix, (float)x, (float)(y + height), (float)z).color(color1RGB >> 16 & 0xFF, color1RGB >> 8 & 0xFF, color1RGB & 0xFF, color1.getAlpha()).tex(0.0F, 0.99F).lightmap(0, 240).endVertex();
/*  698 */     BUILDER.pos(matrix, (float)(x + width), (float)(y + height), (float)z).color(color2RGB >> 16 & 0xFF, color2RGB >> 8 & 0xFF, color2RGB & 0xFF, color2.getAlpha()).tex(1.0F, 0.99F).lightmap(0, 240).endVertex();
/*  699 */     BUILDER.pos(matrix, (float)(x + width), (float)y, (float)z).color(color3RGB >> 16 & 0xFF, color3RGB >> 8 & 0xFF, color3RGB & 0xFF, color3.getAlpha()).tex(1.0F, 0.0F).lightmap(0, 240).endVertex();
/*  700 */     BUILDER.pos(matrix, (float)x, (float)y, (float)z).color(color4RGB >> 16 & 0xFF, color4RGB >> 8 & 0xFF, color4RGB & 0xFF, color4.getAlpha()).tex(0.0F, 0.0F).lightmap(0, 240).endVertex();
/*      */     
/*  702 */     TESSELLATOR.draw();
/*  703 */     GlStateManager.disableBlend();
/*      */   }
/*      */   
/*      */   public static void startFlatRender() {
/*  707 */     GlStateManager.depthMask(false);
/*  708 */     GlStateManager.enableBlend();
/*  709 */     GlStateManager.enableTexture();
/*  710 */     GlStateManager.blendFunc(770, 1);
/*  711 */     GL11.glShadeModel(7425);
/*  712 */     GL11.glAlphaFunc(516, 0.0F);
/*      */     
/*  714 */     RenderSystem.color4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  715 */     BUILDER.begin(7, DefaultVertexFormats.POSITION_COLOR_TEX_LIGHTMAP);
/*      */   }
/*      */   
/*      */   public static void flatImage(MatrixStack stack, String name, double x, double y, double z, double width, double height, FixColor color) {
/*  719 */     flatImage(stack, name, x, y, z, width, height, color, color, color, color);
/*      */   }
/*      */   
/*      */   public static void flatImage(MatrixStack stack, String name, double x, double y, double z, double width, double height, FixColor color1, FixColor color2, FixColor color3, FixColor color4) {
/*  723 */     Matrix4f matrix = stack.getLast().getMatrix();
/*  724 */     int color1RGB = color1.getRGB();
/*  725 */     int color2RGB = color2.getRGB();
/*  726 */     int color3RGB = color3.getRGB();
/*  727 */     int color4RGB = color4.getRGB();
/*      */     
/*  729 */     mc.getTextureManager().bindTextureFlat(FastNative.getImageResource(name));
/*      */     
/*  731 */     BUILDER.pos(matrix, (float)x, (float)(y + height), (float)z).color(color1RGB >> 16 & 0xFF, color1RGB >> 8 & 0xFF, color1RGB & 0xFF, color1.getAlpha()).tex(0.0F, 0.99F).lightmap(0, 240).endVertex();
/*  732 */     BUILDER.pos(matrix, (float)(x + width), (float)(y + height), (float)z).color(color2RGB >> 16 & 0xFF, color2RGB >> 8 & 0xFF, color2RGB & 0xFF, color2.getAlpha()).tex(1.0F, 0.99F).lightmap(0, 240).endVertex();
/*  733 */     BUILDER.pos(matrix, (float)(x + width), (float)y, (float)z).color(color3RGB >> 16 & 0xFF, color3RGB >> 8 & 0xFF, color3RGB & 0xFF, color3.getAlpha()).tex(1.0F, 0.0F).lightmap(0, 240).endVertex();
/*  734 */     BUILDER.pos(matrix, (float)x, (float)y, (float)z).color(color4RGB >> 16 & 0xFF, color4RGB >> 8 & 0xFF, color4RGB & 0xFF, color4.getAlpha()).tex(0.0F, 0.0F).lightmap(0, 240).endVertex();
/*      */   }
/*      */   
/*      */   public static void endFlatRender() {
/*  738 */     TESSELLATOR.draw();
/*  739 */     GlStateManager.disableBlend();
/*  740 */     GlStateManager.depthMask(true);
/*      */   }
/*      */   
/*      */   public static void startImageRendering(String name) {
/*  744 */     GlStateManager.depthMask(false);
/*  745 */     GlStateManager.enableBlend();
/*  746 */     GlStateManager.blendFunc(770, 1);
/*  747 */     GL11.glShadeModel(7425);
/*  748 */     GL11.glAlphaFunc(516, 0.0F);
/*      */     
/*  750 */     mc.getTextureManager().bindTexture(FastNative.getImageResource(name));
/*  751 */     RenderSystem.color4f(1.0F, 1.0F, 1.0F, 1.0F);
/*      */   }
/*      */   
/*      */   public static void drawCleanImage(MatrixStack stack, double x, double y, double z, double width, double height, FixColor color) {
/*  755 */     drawCleanImage(stack, x, y, z, width, height, color, color, color, color);
/*      */   }
/*      */   
/*      */   public static void drawCleanImage(MatrixStack stack, double x, double y, double z, double width, double height, FixColor color1, FixColor color2, FixColor color3, FixColor color4) {
/*  759 */     Matrix4f matrix = stack.getLast().getMatrix();
/*  760 */     int color1RGB = color1.getRGB();
/*  761 */     int color2RGB = color2.getRGB();
/*  762 */     int color3RGB = color3.getRGB();
/*  763 */     int color4RGB = color4.getRGB();
/*      */     
/*  765 */     BUILDER.begin(7, DefaultVertexFormats.POSITION_COLOR_TEX_LIGHTMAP);
/*  766 */     BUILDER.pos(matrix, (float)x, (float)(y + height), (float)z).color(color1RGB >> 16 & 0xFF, color1RGB >> 8 & 0xFF, color1RGB & 0xFF, color1.getAlpha()).tex(0.0F, 0.99F).lightmap(0, 240).endVertex();
/*  767 */     BUILDER.pos(matrix, (float)(x + width), (float)(y + height), (float)z).color(color2RGB >> 16 & 0xFF, color2RGB >> 8 & 0xFF, color2RGB & 0xFF, color2.getAlpha()).tex(1.0F, 0.99F).lightmap(0, 240).endVertex();
/*  768 */     BUILDER.pos(matrix, (float)(x + width), (float)y, (float)z).color(color3RGB >> 16 & 0xFF, color3RGB >> 8 & 0xFF, color3RGB & 0xFF, color3.getAlpha()).tex(1.0F, 0.0F).lightmap(0, 240).endVertex();
/*  769 */     BUILDER.pos(matrix, (float)x, (float)y, (float)z).color(color4RGB >> 16 & 0xFF, color4RGB >> 8 & 0xFF, color4RGB & 0xFF, color4.getAlpha()).tex(0.0F, 0.0F).lightmap(0, 240).endVertex();
/*      */     
/*  771 */     TESSELLATOR.draw();
/*      */   }
/*      */   
/*      */   public static void finishImageRendering() {
/*  775 */     GlStateManager.disableBlend();
/*  776 */     GlStateManager.depthMask(true);
/*      */   }
/*      */   
/*      */   public static void enableSmoothLine(float width) {
/*  780 */     GL11.glDisable(3008);
/*  781 */     GL11.glEnable(3042);
/*  782 */     GL11.glBlendFunc(770, 771);
/*  783 */     GL11.glDisable(3553);
/*  784 */     GL11.glDisable(2929);
/*  785 */     GL11.glDepthMask(false);
/*  786 */     GL11.glEnable(2884);
/*  787 */     GL11.glEnable(2848);
/*  788 */     GL11.glHint(3154, 4354);
/*  789 */     GL11.glHint(3155, 4354);
/*  790 */     GL11.glLineWidth(width);
/*      */   }
/*      */   
/*      */   public static void disableSmoothLine() {
/*  794 */     GL11.glEnable(3553);
/*  795 */     GL11.glEnable(2929);
/*  796 */     GL11.glDisable(3042);
/*  797 */     GL11.glEnable(3008);
/*  798 */     GL11.glDepthMask(true);
/*  799 */     GL11.glCullFace(1029);
/*  800 */     GL11.glDisable(2848);
/*  801 */     GL11.glHint(3154, 4352);
/*  802 */     GL11.glHint(3155, 4352);
/*      */   }
/*      */   
/*      */   public static void scale(float x, float y, float scale) {
/*  806 */     GL11.glPushMatrix();
/*  807 */     GL11.glTranslatef(x, y, 0.0F);
/*  808 */     GL11.glScalef(scale, scale, 1.0F);
/*  809 */     GL11.glTranslatef(-x, -y, 0.0F);
/*      */   }
/*      */   
/*      */   public static void scale(float x, float y, float z, float scale) {
/*  813 */     GL11.glPushMatrix();
/*  814 */     GL11.glTranslatef(x, y, z);
/*  815 */     GL11.glScalef(scale, scale, 1.0F);
/*  816 */     GL11.glTranslatef(-x, -y, 0.0F);
/*      */   }
/*      */   
/*      */   public static void end() {
/*  820 */     GL11.glPopMatrix();
/*      */   }
/*      */   
/*      */   public static void drawBoxing(AxisAlignedBB boundingBox) {
/*  824 */     BUILDER.begin(3, DefaultVertexFormats.POSITION);
/*  825 */     BUILDER.pos(boundingBox.minX, boundingBox.minY, boundingBox.minZ).endVertex();
/*  826 */     BUILDER.pos(boundingBox.maxX, boundingBox.minY, boundingBox.minZ).endVertex();
/*  827 */     BUILDER.pos(boundingBox.maxX, boundingBox.minY, boundingBox.maxZ).endVertex();
/*  828 */     BUILDER.pos(boundingBox.minX, boundingBox.minY, boundingBox.maxZ).endVertex();
/*  829 */     BUILDER.pos(boundingBox.minX, boundingBox.minY, boundingBox.minZ).endVertex();
/*  830 */     TESSELLATOR.draw();
/*  831 */     BUILDER.begin(3, DefaultVertexFormats.POSITION);
/*  832 */     BUILDER.pos(boundingBox.minX, boundingBox.maxY, boundingBox.minZ).endVertex();
/*  833 */     BUILDER.pos(boundingBox.maxX, boundingBox.maxY, boundingBox.minZ).endVertex();
/*  834 */     BUILDER.pos(boundingBox.maxX, boundingBox.maxY, boundingBox.maxZ).endVertex();
/*  835 */     BUILDER.pos(boundingBox.minX, boundingBox.maxY, boundingBox.maxZ).endVertex();
/*  836 */     BUILDER.pos(boundingBox.minX, boundingBox.maxY, boundingBox.minZ).endVertex();
/*  837 */     TESSELLATOR.draw();
/*  838 */     BUILDER.begin(1, DefaultVertexFormats.POSITION);
/*  839 */     BUILDER.pos(boundingBox.minX, boundingBox.minY, boundingBox.minZ).endVertex();
/*  840 */     BUILDER.pos(boundingBox.minX, boundingBox.maxY, boundingBox.minZ).endVertex();
/*  841 */     BUILDER.pos(boundingBox.maxX, boundingBox.minY, boundingBox.minZ).endVertex();
/*  842 */     BUILDER.pos(boundingBox.maxX, boundingBox.maxY, boundingBox.minZ).endVertex();
/*  843 */     BUILDER.pos(boundingBox.maxX, boundingBox.minY, boundingBox.maxZ).endVertex();
/*  844 */     BUILDER.pos(boundingBox.maxX, boundingBox.maxY, boundingBox.maxZ).endVertex();
/*  845 */     BUILDER.pos(boundingBox.minX, boundingBox.minY, boundingBox.maxZ).endVertex();
/*  846 */     BUILDER.pos(boundingBox.minX, boundingBox.maxY, boundingBox.maxZ).endVertex();
/*  847 */     TESSELLATOR.draw();
/*      */   }
/*      */   
/*      */   public static void drawBoxing(AxisAlignedBB axisalignedbb, float red, float green, float blue, float alpha) {
/*  851 */     BUILDER.begin(7, DefaultVertexFormats.POSITION_TEX);
/*  852 */     BUILDER.pos(axisalignedbb.minX, axisalignedbb.minY, axisalignedbb.minZ).color(red, green, blue, alpha).endVertex();
/*  853 */     BUILDER.pos(axisalignedbb.minX, axisalignedbb.maxY, axisalignedbb.minZ).color(red, green, blue, alpha).endVertex();
/*  854 */     BUILDER.pos(axisalignedbb.maxX, axisalignedbb.minY, axisalignedbb.minZ).color(red, green, blue, alpha).endVertex();
/*  855 */     BUILDER.pos(axisalignedbb.maxX, axisalignedbb.maxY, axisalignedbb.minZ).color(red, green, blue, alpha).endVertex();
/*  856 */     BUILDER.pos(axisalignedbb.maxX, axisalignedbb.minY, axisalignedbb.maxZ).color(red, green, blue, alpha).endVertex();
/*  857 */     BUILDER.pos(axisalignedbb.maxX, axisalignedbb.maxY, axisalignedbb.maxZ).color(red, green, blue, alpha).endVertex();
/*  858 */     BUILDER.pos(axisalignedbb.minX, axisalignedbb.minY, axisalignedbb.maxZ).color(red, green, blue, alpha).endVertex();
/*  859 */     BUILDER.pos(axisalignedbb.minX, axisalignedbb.maxY, axisalignedbb.maxZ).color(red, green, blue, alpha).endVertex();
/*  860 */     TESSELLATOR.draw();
/*  861 */     BUILDER.begin(7, DefaultVertexFormats.POSITION_TEX);
/*  862 */     BUILDER.pos(axisalignedbb.maxX, axisalignedbb.maxY, axisalignedbb.minZ).color(red, green, blue, alpha).endVertex();
/*  863 */     BUILDER.pos(axisalignedbb.maxX, axisalignedbb.minY, axisalignedbb.minZ).color(red, green, blue, alpha).endVertex();
/*  864 */     BUILDER.pos(axisalignedbb.minX, axisalignedbb.maxY, axisalignedbb.minZ).color(red, green, blue, alpha).endVertex();
/*  865 */     BUILDER.pos(axisalignedbb.minX, axisalignedbb.minY, axisalignedbb.minZ).color(red, green, blue, alpha).endVertex();
/*  866 */     BUILDER.pos(axisalignedbb.minX, axisalignedbb.maxY, axisalignedbb.maxZ).color(red, green, blue, alpha).endVertex();
/*  867 */     BUILDER.pos(axisalignedbb.minX, axisalignedbb.minY, axisalignedbb.maxZ).color(red, green, blue, alpha).endVertex();
/*  868 */     BUILDER.pos(axisalignedbb.maxX, axisalignedbb.maxY, axisalignedbb.maxZ).color(red, green, blue, alpha).endVertex();
/*  869 */     BUILDER.pos(axisalignedbb.maxX, axisalignedbb.minY, axisalignedbb.maxZ).color(red, green, blue, alpha).endVertex();
/*  870 */     TESSELLATOR.draw();
/*  871 */     BUILDER.begin(7, DefaultVertexFormats.POSITION_TEX);
/*  872 */     BUILDER.pos(axisalignedbb.minX, axisalignedbb.maxY, axisalignedbb.minZ).color(red, green, blue, alpha).endVertex();
/*  873 */     BUILDER.pos(axisalignedbb.maxX, axisalignedbb.maxY, axisalignedbb.minZ).color(red, green, blue, alpha).endVertex();
/*  874 */     BUILDER.pos(axisalignedbb.maxX, axisalignedbb.maxY, axisalignedbb.maxZ).color(red, green, blue, alpha).endVertex();
/*  875 */     BUILDER.pos(axisalignedbb.minX, axisalignedbb.maxY, axisalignedbb.maxZ).color(red, green, blue, alpha).endVertex();
/*  876 */     BUILDER.pos(axisalignedbb.minX, axisalignedbb.maxY, axisalignedbb.minZ).color(red, green, blue, alpha).endVertex();
/*  877 */     BUILDER.pos(axisalignedbb.minX, axisalignedbb.maxY, axisalignedbb.maxZ).color(red, green, blue, alpha).endVertex();
/*  878 */     BUILDER.pos(axisalignedbb.maxX, axisalignedbb.maxY, axisalignedbb.maxZ).color(red, green, blue, alpha).endVertex();
/*  879 */     BUILDER.pos(axisalignedbb.maxX, axisalignedbb.maxY, axisalignedbb.minZ).color(red, green, blue, alpha).endVertex();
/*  880 */     TESSELLATOR.draw();
/*  881 */     BUILDER.begin(7, DefaultVertexFormats.POSITION_TEX);
/*  882 */     BUILDER.pos(axisalignedbb.minX, axisalignedbb.minY, axisalignedbb.minZ).color(red, green, blue, alpha).endVertex();
/*  883 */     BUILDER.pos(axisalignedbb.maxX, axisalignedbb.minY, axisalignedbb.minZ).color(red, green, blue, alpha).endVertex();
/*  884 */     BUILDER.pos(axisalignedbb.maxX, axisalignedbb.minY, axisalignedbb.maxZ).color(red, green, blue, alpha).endVertex();
/*  885 */     BUILDER.pos(axisalignedbb.minX, axisalignedbb.minY, axisalignedbb.maxZ).color(red, green, blue, alpha).endVertex();
/*  886 */     BUILDER.pos(axisalignedbb.minX, axisalignedbb.minY, axisalignedbb.minZ).color(red, green, blue, alpha).endVertex();
/*  887 */     BUILDER.pos(axisalignedbb.minX, axisalignedbb.minY, axisalignedbb.maxZ).color(red, green, blue, alpha).endVertex();
/*  888 */     BUILDER.pos(axisalignedbb.maxX, axisalignedbb.minY, axisalignedbb.maxZ).color(red, green, blue, alpha).endVertex();
/*  889 */     BUILDER.pos(axisalignedbb.maxX, axisalignedbb.minY, axisalignedbb.minZ).color(red, green, blue, alpha).endVertex();
/*  890 */     TESSELLATOR.draw();
/*  891 */     BUILDER.begin(7, DefaultVertexFormats.POSITION_TEX);
/*  892 */     BUILDER.pos(axisalignedbb.minX, axisalignedbb.minY, axisalignedbb.minZ).color(red, green, blue, alpha).endVertex();
/*  893 */     BUILDER.pos(axisalignedbb.minX, axisalignedbb.maxY, axisalignedbb.minZ).color(red, green, blue, alpha).endVertex();
/*  894 */     BUILDER.pos(axisalignedbb.minX, axisalignedbb.minY, axisalignedbb.maxZ).color(red, green, blue, alpha).endVertex();
/*  895 */     BUILDER.pos(axisalignedbb.minX, axisalignedbb.maxY, axisalignedbb.maxZ).color(red, green, blue, alpha).endVertex();
/*  896 */     BUILDER.pos(axisalignedbb.maxX, axisalignedbb.minY, axisalignedbb.maxZ).color(red, green, blue, alpha).endVertex();
/*  897 */     BUILDER.pos(axisalignedbb.maxX, axisalignedbb.maxY, axisalignedbb.maxZ).color(red, green, blue, alpha).endVertex();
/*  898 */     BUILDER.pos(axisalignedbb.maxX, axisalignedbb.minY, axisalignedbb.minZ).color(red, green, blue, alpha).endVertex();
/*  899 */     BUILDER.pos(axisalignedbb.maxX, axisalignedbb.maxY, axisalignedbb.minZ).color(red, green, blue, alpha).endVertex();
/*  900 */     TESSELLATOR.draw();
/*  901 */     BUILDER.begin(7, DefaultVertexFormats.POSITION_TEX);
/*  902 */     BUILDER.pos(axisalignedbb.minX, axisalignedbb.maxY, axisalignedbb.maxZ).color(red, green, blue, alpha).endVertex();
/*  903 */     BUILDER.pos(axisalignedbb.minX, axisalignedbb.minY, axisalignedbb.maxZ).color(red, green, blue, alpha).endVertex();
/*  904 */     BUILDER.pos(axisalignedbb.minX, axisalignedbb.maxY, axisalignedbb.minZ).color(red, green, blue, alpha).endVertex();
/*  905 */     BUILDER.pos(axisalignedbb.minX, axisalignedbb.minY, axisalignedbb.minZ).color(red, green, blue, alpha).endVertex();
/*  906 */     BUILDER.pos(axisalignedbb.maxX, axisalignedbb.maxY, axisalignedbb.minZ).color(red, green, blue, alpha).endVertex();
/*  907 */     BUILDER.pos(axisalignedbb.maxX, axisalignedbb.minY, axisalignedbb.minZ).color(red, green, blue, alpha).endVertex();
/*  908 */     BUILDER.pos(axisalignedbb.maxX, axisalignedbb.maxY, axisalignedbb.maxZ).color(red, green, blue, alpha).endVertex();
/*  909 */     BUILDER.pos(axisalignedbb.maxX, axisalignedbb.minY, axisalignedbb.maxZ).color(red, green, blue, alpha).endVertex();
/*  910 */     TESSELLATOR.draw();
/*      */   }
/*      */   
/*      */   public static void drawEntity3D(MatrixStack ms, LivingEntity player, Vector3d pos, float alpha) {
/*  914 */     ActiveRenderInfo activeRenderInfo = mc.gameRenderer.getActiveRenderInfo();
/*      */     
/*  916 */     GlowESP.SILENT_RENDERING = true;
/*      */     
/*  918 */     ms.push();
/*      */     
/*  920 */     GlStateManager.enableBlend();
/*  921 */     GlStateManager.depthMask(false);
/*  922 */     GlStateManager.disableTexture();
/*  923 */     GL11.glShadeModel(7425);
/*  924 */     GlStateManager.disableCull();
/*  925 */     GlStateManager.enableDepthTest();
/*  926 */     GlStateManager.blendFunc(770, 772);
/*  927 */     GlStateManager.glBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA.param, GlStateManager.DestFactor.ONE.param, GlStateManager.SourceFactor.ZERO.param, GlStateManager.DestFactor.ONE.param);
/*  928 */     GL11.glEnable(2929);
/*      */ 
/*      */     
/*  931 */     Vector3d cameraPos = (mc.getRenderManager()).info.getProjectedView();
/*      */     try {
/*  933 */       double x = pos.x - (mc.getRenderManager()).info.getProjectedView().getX();
/*  934 */       double y = pos.y - (mc.getRenderManager()).info.getProjectedView().getY();
/*  935 */       double z = pos.z - (mc.getRenderManager()).info.getProjectedView().getZ();
/*      */       
/*  937 */       EntityRendererManager renderManager = mc.getRenderManager();
/*      */       
/*  939 */       if (renderManager == null) {
/*      */         return;
/*      */       }
/*  942 */       float partialTicks = mc.getRenderPartialTicks();
/*      */       
/*  944 */       Vector3d camera = activeRenderInfo.getProjectedView();
/*      */       
/*  946 */       Reacher.ENTITY_ALPHA = alpha;
/*  947 */       Reacher.SILENT = true;
/*      */ 
/*      */       
/*  950 */       if (Config.isShaders()) {
/*  951 */         Shaders.nextEntity((Entity)player);
/*      */       }
/*      */       
/*  954 */       renderManager.renderEntityStaticSilent((Entity)player, x, y, z, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  959 */           MathHelper.lerp(partialTicks, player.prevRotationYaw, player.rotationYaw), partialTicks, ms, (IRenderTypeBuffer)mc
/*      */           
/*  961 */           .getRenderTypeBuffers().getBufferSource(), renderManager
/*  962 */           .getPackedLight((Entity)player, partialTicks));
/*      */ 
/*      */       
/*  965 */       Reacher.ENTITY_ALPHA = 1.0F;
/*  966 */       Reacher.SILENT = false;
/*  967 */     } catch (Exception e1) {
/*  968 */       e1.printStackTrace();
/*      */     } 
/*      */ 
/*      */     
/*  972 */     GlStateManager.blendFunc(770, 771);
/*  973 */     GlStateManager.shadeModel(7424);
/*  974 */     GlStateManager.disableBlend();
/*  975 */     GlStateManager.enableTexture();
/*  976 */     GlStateManager.depthMask(true);
/*  977 */     GlStateManager.enableCull();
/*  978 */     ms.pop();
/*  979 */     GlowESP.SILENT_RENDERING = false;
/*      */   }
/*      */   
/*      */   public static void blockEsp(BlockPos blockPos, int color) {
/*  983 */     double x = blockPos.getX();
/*  984 */     double y = blockPos.getY();
/*  985 */     double z = blockPos.getZ();
/*  986 */     GL11.glPushMatrix();
/*  987 */     GL11.glBlendFunc(770, 771);
/*  988 */     GL11.glEnable(3042);
/*  989 */     GL11.glLineWidth(1.0F);
/*  990 */     GL11.glDisable(3553);
/*  991 */     GL11.glDisable(2929);
/*      */     
/*  993 */     color(color);
/*  994 */     drawBoxing(new AxisAlignedBB(x, y, z, x + 1.0D, y + 1.0D, z + 1.0D));
/*  995 */     drawBoxing(new AxisAlignedBB(x, y, z, x + 1.0D, y + 1.0D, z + 1.0D));
/*  996 */     GL11.glLineWidth(2.0F);
/*  997 */     GL11.glEnable(3553);
/*  998 */     GL11.glEnable(2929);
/*  999 */     GL11.glDisable(3042);
/* 1000 */     resetColor();
/* 1001 */     GL11.glPopMatrix();
/*      */   }
/*      */   
/*      */   public static void drawRect(MatrixStack matrix, float x, float y, float width, float height, FixColor color) {
/* 1005 */     float minX = x;
/* 1006 */     float minY = y;
/* 1007 */     float maxX = x + width;
/* 1008 */     float maxY = y + height;
/*      */     
/* 1010 */     float f3 = color.getAlpha() / 255.0F;
/* 1011 */     float f = color.getRed() / 255.0F;
/* 1012 */     float f1 = color.getGreen() / 255.0F;
/* 1013 */     float f2 = color.getBlue() / 255.0F;
/* 1014 */     BufferBuilder bufferbuilder = Tessellator.getInstance().getBuffer();
/* 1015 */     RenderSystem.enableBlend();
/* 1016 */     RenderSystem.disableTexture();
/* 1017 */     RenderSystem.defaultBlendFunc();
/* 1018 */     bufferbuilder.begin(7, DefaultVertexFormats.POSITION_COLOR);
/* 1019 */     bufferbuilder.pos(matrix.getLast().getMatrix(), minX, maxY, 0.0F).color(f, f1, f2, f3).endVertex();
/* 1020 */     bufferbuilder.pos(matrix.getLast().getMatrix(), maxX, maxY, 0.0F).color(f, f1, f2, f3).endVertex();
/* 1021 */     bufferbuilder.pos(matrix.getLast().getMatrix(), maxX, minY, 0.0F).color(f, f1, f2, f3).endVertex();
/* 1022 */     bufferbuilder.pos(matrix.getLast().getMatrix(), minX, minY, 0.0F).color(f, f1, f2, f3).endVertex();
/* 1023 */     bufferbuilder.finishDrawing();
/* 1024 */     WorldVertexBufferUploader.draw(bufferbuilder);
/* 1025 */     RenderSystem.enableTexture();
/* 1026 */     RenderSystem.disableBlend();
/*      */   }
/*      */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\render\Render.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */