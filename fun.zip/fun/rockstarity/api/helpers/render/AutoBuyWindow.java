/*     */ package fun.rockstarity.api.helpers.render;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import fun.rockstarity.api.helpers.math.Hover;
/*     */ import fun.rockstarity.api.modules.Module;
/*     */ import fun.rockstarity.api.modules.settings.Setting;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.shaders.list.Round;
/*     */ import fun.rockstarity.api.render.ui.clickgui.SettingRect;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import fun.rockstarity.api.render.ui.widgets.Window;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ public class AutoBuyWindow
/*     */   extends Window
/*     */ {
/*     */   private final Module element;
/*  21 */   private final List<SettingRect> settings = new ArrayList<>();
/*     */   
/*     */   public AutoBuyWindow(Module element) {
/*  24 */     super(165.0F, (sr.getScaledHeight() / 2 - 100), 145.0F, 10.0F);
/*     */     
/*  26 */     this.element = element;
/*     */     
/*  28 */     for (Setting setting : element.getSettings()) {
/*  29 */       this.settings.add(new SettingRect(setting));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/*  35 */     if (this.opening.finished(false))
/*     */       return; 
/*  37 */     GL11.glPushMatrix();
/*  38 */     GL11.glTranslated(0.0D, 0.0D, 999.0D);
/*     */     
/*  40 */     this.x = 165.0F;
/*  41 */     this.y = (sr.getScaledHeight() / 2) - this.height / 2.0F;
/*     */     
/*  43 */     Render.glow(matrixStack, (Rect)this, this.opening.get());
/*     */     
/*  45 */     Round.draw(matrixStack, (Rect)this, 4.0F, rock.getThemes().getFirstColor().alpha(this.opening.get()));
/*     */     
/*  47 */     bold.get(16).draw(matrixStack, "AutoBuy", this.x, this.y - 13.0F, FixColor.WHITE.alpha(this.opening.get()));
/*     */     
/*  49 */     Stencil.init();
/*  50 */     Round.draw(matrixStack, (Rect)this, 4.0F, rock.getThemes().getFirstColor().alpha(this.opening.get()));
/*  51 */     Stencil.read(1);
/*     */     
/*  53 */     float yOff = 0.0F;
/*  54 */     for (SettingRect setting : this.settings) {
/*  55 */       setting.getHide().setForward(setting.getParent().isHide());
/*     */       
/*  57 */       setting.set(this.x, this.y + yOff - 2.0F - 10.0F + 10.0F * this.opening.get() * (1.0F - setting.getHide().get()), 145.0F, setting.getHeight());
/*  58 */       setting.render(matrixStack, mouseX, mouseY, partialTicks, this.opening.get() * (1.0F - setting.getHide().get()), false, false);
/*     */       
/*  60 */       yOff += (setting.getHeight() - 13.0F) * (1.0F - setting.getHide().get());
/*     */     } 
/*  62 */     Stencil.finish();
/*     */     
/*  64 */     Render.outline(matrixStack, (Rect)this, this.opening.get());
/*     */     
/*  66 */     GL11.glPopMatrix();
/*     */     
/*  68 */     this.height = yOff + 10.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean clicked(double mouseX, double mouseY, int button) {
/*  73 */     if (!Hover.isHovered(this.x, this.y, this.width, this.height, mouseX, mouseY) || button != 0) {
/*  74 */       return super.released(mouseX, mouseY, button);
/*     */     }
/*     */     
/*  77 */     float yOff = 0.0F;
/*  78 */     for (SettingRect setting : this.settings) {
/*  79 */       if (Hover.isHovered(setting.y(this.y + yOff - 2.0F - 10.0F + 10.0F * this.opening.get() + 3.0F).height(setting.getHeight() - 14.0F), mouseX, mouseY)) {
/*  80 */         setting.clicked(mouseX, mouseY, button, false);
/*     */       }
/*  82 */       yOff += (setting.getHeight() - 13.0F) * (1.0F - setting.getHide().get());
/*     */     } 
/*     */     
/*  85 */     return super.clicked(mouseX, mouseY, button);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean released(double mouseX, double mouseY, int button) {
/*  90 */     if (button != 0) return super.clicked(mouseX, mouseY, button);
/*     */     
/*  92 */     for (SettingRect setting : this.settings) {
/*  93 */       if (setting.getParent().isHide()) {
/*     */         continue;
/*     */       }
/*  96 */       setting.clicked(mouseX, mouseY, button, true);
/*     */     } 
/*     */     
/*  99 */     return super.released(mouseX, mouseY, button);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean pressed(int keyCode, int scanCode, int modifiers) {
/* 104 */     for (SettingRect setting : this.settings) {
/* 105 */       if (setting.getParent().isHide()) {
/*     */         continue;
/*     */       }
/* 108 */       setting.pressed(keyCode, scanCode, modifiers);
/*     */     } 
/* 110 */     return false;
/*     */   }
/*     */   
/*     */   public void tick() {
/* 114 */     for (SettingRect setting : this.settings) {
/* 115 */       if (setting.getParent().isHide()) {
/*     */         continue;
/*     */       }
/* 118 */       setting.tick();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void charTyped(char codePoint, int modifiers) {
/* 123 */     for (SettingRect setting : this.settings) {
/* 124 */       if (setting.getParent().isHide()) {
/*     */         continue;
/*     */       }
/* 127 */       setting.charTyped(codePoint, modifiers);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\render\AutoBuyWindow.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */