/*     */ package fun.rockstarity.api.helpers.render;
/*     */ 
/*     */ import fun.rockstarity.api.secure.Debugger;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontFormatException;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.imageio.ImageIO;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.texture.DynamicTexture;
/*     */ import net.minecraft.client.renderer.texture.NativeImage;
/*     */ import net.minecraft.client.renderer.texture.TextureManager;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Converter
/*     */ {
/*  27 */   private static final HashMap<String, ResourceLocation> images = new HashMap<>();
/*  28 */   private static final Map<String, byte[]> streamCache = (Map)new HashMap<>();
/*     */   private static final String BASE_PATH = "/assets/minecraft/rockstar/files/";
/*     */   
/*     */   public static InputStream getInputStream(String path) {
/*  32 */     if (streamCache.containsKey(path)) {
/*  33 */       return new ByteArrayInputStream(streamCache.get(path));
/*     */     }
/*     */     
/*  36 */     try { InputStream inputStream = Converter.class.getResourceAsStream("/assets/minecraft/rockstar/files/" + path); 
/*  37 */       try { ByteArrayOutputStream outputStream = new ByteArrayOutputStream(); 
/*  38 */         try { if (inputStream == null)
/*  39 */           { Debugger.print(new IOException("Resource not found: " + path));
/*  40 */             System.out.println("Ошибка при загрузке ресурса: " + path);
/*  41 */             InputStream inputStream1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*  53 */             outputStream.close(); if (inputStream != null) inputStream.close();  return inputStream1; }  byte[] buffer = new byte[1024]; int bytesRead; while ((bytesRead = inputStream.read(buffer)) != -1) outputStream.write(buffer, 0, bytesRead);  byte[] data = outputStream.toByteArray(); streamCache.put(path, data); ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(data); outputStream.close(); if (inputStream != null) inputStream.close();  return byteArrayInputStream; } catch (Throwable throwable) { try { outputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (Throwable throwable) { if (inputStream != null) try { inputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException e)
/*  54 */     { Debugger.print(e);
/*  55 */       System.out.println("Ошибка при загрузке ресурса: " + path);
/*  56 */       return null; }
/*     */   
/*     */   }
/*     */   
/*     */   public static ResourceLocation getResourceLocation(String link) {
/*  61 */     if (images.containsKey(link)) {
/*  62 */       return images.get(link);
/*     */     }
/*     */     
/*  65 */     NativeImage nativeImage = null;
/*     */     
/*  67 */     try { InputStream inputStream = Converter.class.getResourceAsStream("/assets/minecraft/rockstar/files/" + link); 
/*  68 */       try { ByteArrayOutputStream outputStream = new ByteArrayOutputStream(); 
/*  69 */         try { if (inputStream == null)
/*  70 */           { Debugger.print(new IOException("Resource not found: /assets/minecraft/rockstar/files/" + link));
/*  71 */             System.out.println("Ошибка при загрузке картинки: " + link);
/*  72 */             ResourceLocation resourceLocation = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*  83 */             outputStream.close(); if (inputStream != null) inputStream.close();  return resourceLocation; }  byte[] buffer = new byte[1024]; int bytesRead; while ((bytesRead = inputStream.read(buffer)) != -1) outputStream.write(buffer, 0, bytesRead);  byte[] imageData = outputStream.toByteArray(); nativeImage = NativeImage.read(new ByteArrayInputStream(imageData)); outputStream.close(); } catch (Throwable throwable) { try { outputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  if (inputStream != null) inputStream.close();  } catch (Throwable throwable) { if (inputStream != null) try { inputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException e)
/*  84 */     { Debugger.print(e);
/*  85 */       System.out.println("Ошибка при загрузке картинки: " + link); }
/*     */ 
/*     */     
/*  88 */     if (nativeImage == null) {
/*  89 */       return null;
/*     */     }
/*     */     
/*  92 */     TextureManager textureManager = Minecraft.getInstance().getTextureManager();
/*  93 */     DynamicTexture dynamicTexture = new DynamicTexture(nativeImage);
/*  94 */     ResourceLocation res = textureManager.getDynamicTextureLocation("custom", dynamicTexture);
/*  95 */     images.put(link, res);
/*  96 */     return res;
/*     */   }
/*     */   
/*     */   public static ResourceLocation getFixed(String path) {
/* 100 */     if (images.containsKey(path)) {
/* 101 */       return images.get(path);
/*     */     }
/*     */     
/* 104 */     ResourceLocation rs = new ResourceLocation("rockstar", path);
/* 105 */     images.put(path, rs);
/* 106 */     return rs;
/*     */   }
/*     */   public static BufferedImage loadImage(ResourceLocation resourceLocation) {
/*     */     
/* 110 */     try { InputStream inputStream = Minecraft.getInstance().getResourceManager().getResource(resourceLocation).getInputStream(); 
/* 111 */       try { BufferedImage bufferedImage = ImageIO.read(inputStream);
/* 112 */         if (inputStream != null) inputStream.close();  return bufferedImage; } catch (Throwable throwable) { if (inputStream != null) try { inputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException e)
/* 113 */     { Debugger.print(e);
/* 114 */       System.out.println("Ошибка при загрузке картинки: " + resourceLocation.getPath());
/* 115 */       return null; }
/*     */   
/*     */   }
/*     */   public static NativeImage loadNativeImage(String path) {
/*     */     
/* 120 */     try { InputStream inputStream = Converter.class.getResourceAsStream("/assets/minecraft/rockstar/files/" + path); 
/* 121 */       try { if (inputStream == null)
/* 122 */         { Debugger.print(new IOException("Resource not found: " + path));
/* 123 */           System.out.println("Ошибка при загрузке картинки: " + path);
/* 124 */           NativeImage nativeImage1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 136 */           if (inputStream != null) inputStream.close();  return nativeImage1; }  ByteArrayOutputStream outputStream = new ByteArrayOutputStream(); byte[] buffer = new byte[1024]; int bytesRead; while ((bytesRead = inputStream.read(buffer)) != -1) outputStream.write(buffer, 0, bytesRead);  byte[] imageData = outputStream.toByteArray(); NativeImage nativeImage = NativeImage.read(new ByteArrayInputStream(imageData)); if (inputStream != null) inputStream.close();  return nativeImage; } catch (Throwable throwable) { if (inputStream != null) try { inputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException e)
/* 137 */     { Debugger.print(e);
/* 138 */       System.out.println("Ошибка при загрузке картинки: " + path);
/* 139 */       return null; }
/*     */   
/*     */   }
/*     */   
/*     */   public static Font getFont(String name, int style, int size) {
/* 144 */     Font font = null;
/*     */     
/* 146 */     try { InputStream fontStream = Converter.class.getResourceAsStream("/assets/minecraft/rockstar/files/fonts/" + name + ".ttf"); 
/* 147 */       try { if (fontStream == null)
/* 148 */         { Debugger.print(new IOException("Font not found: " + name));
/* 149 */           Font font1 = new Font("Arial", style, size);
/*     */ 
/*     */ 
/*     */           
/* 153 */           if (fontStream != null) fontStream.close();  return font1; }  font = Font.createFont(0, fontStream).deriveFont(style, size); if (fontStream != null) fontStream.close();  } catch (Throwable throwable) { if (fontStream != null) try { fontStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (FontFormatException|IOException e)
/* 154 */     { Debugger.print(e);
/* 155 */       return new Font("Arial", style, size); }
/*     */ 
/*     */     
/* 158 */     return font;
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\render\Converter.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */