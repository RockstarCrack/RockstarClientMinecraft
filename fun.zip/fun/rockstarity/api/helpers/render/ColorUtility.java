/*     */ package fun.rockstarity.api.helpers.render;
/*     */ 
/*     */ import fun.rockstarity.api.helpers.math.MathUtility;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ColorUtility
/*     */ {
/*     */   private ColorUtility() {
/*  15 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*     */   }
/*     */   public static int red(int c) {
/*  18 */     return c >> 16 & 0xFF;
/*     */   }
/*     */   
/*     */   public static int green(int c) {
/*  22 */     return c >> 8 & 0xFF;
/*     */   }
/*     */   
/*     */   public static int blue(int c) {
/*  26 */     return c & 0xFF;
/*     */   }
/*     */   
/*     */   public static int alpha(int c) {
/*  30 */     return c >> 24 & 0xFF;
/*     */   }
/*     */   
/*     */   public static float redf(int c) {
/*  34 */     return red(c) / 255.0F;
/*     */   }
/*     */   
/*     */   public static float greenf(int c) {
/*  38 */     return green(c) / 255.0F;
/*     */   }
/*     */   
/*     */   public static float bluef(int c) {
/*  42 */     return blue(c) / 255.0F;
/*     */   }
/*     */   
/*     */   public static float alphaf(int c) {
/*  46 */     return alpha(c) / 255.0F;
/*     */   }
/*     */   
/*     */   public static int[] getRGBA(int c) {
/*  50 */     return new int[] { red(c), green(c), blue(c), alpha(c) };
/*     */   }
/*     */   
/*     */   public static int[] getRGB(int c) {
/*  54 */     return new int[] { red(c), green(c), blue(c) };
/*     */   }
/*     */   
/*     */   public static float[] getRGBAf(int c) {
/*  58 */     return new float[] { redf(c), greenf(c), bluef(c), alphaf(c) };
/*     */   }
/*     */   
/*     */   public static float[] getRGBf(int c) {
/*  62 */     return new float[] { redf(c), greenf(c), bluef(c) };
/*     */   }
/*     */   
/*     */   public static int getColor(float red, float green, float blue, float alpha) {
/*  66 */     return getColor(Math.round(red * 255.0F), Math.round(green * 255.0F), Math.round(blue * 255.0F), Math.round(alpha * 255.0F));
/*     */   }
/*     */   
/*     */   public static int getColor(int red, int green, int blue, float alpha) {
/*  70 */     return getColor(red, green, blue, Math.round(alpha * 255.0F));
/*     */   }
/*     */   
/*     */   public static int getColor(float red, float green, float blue) {
/*  74 */     return getColor(red, green, blue, 1.0F);
/*     */   }
/*     */   
/*     */   public static int getColor(int brightness, int alpha) {
/*  78 */     return getColor(brightness, brightness, brightness, alpha);
/*     */   }
/*     */   
/*     */   public static int getColor(int brightness, float alpha) {
/*  82 */     return getColor(brightness, Math.round(alpha * 255.0F));
/*     */   }
/*     */   
/*     */   public static int getColor(int brightness) {
/*  86 */     return getColor(brightness, brightness, brightness);
/*     */   }
/*     */   
/*     */   public static int replAlpha(int color, int alpha) {
/*  90 */     return getColor(red(color), green(color), blue(color), alpha);
/*     */   }
/*     */   
/*     */   public static float[] getRGBAFloat(FixColor color) {
/*  94 */     return new float[] { color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F };
/*     */   }
/*     */   
/*     */   public static FixColor gradient(int speed, int index, FixColor... colors) {
/*  98 */     int angle = (int)((System.currentTimeMillis() / speed + index) % 360L);
/*  99 */     angle = (angle >= 180) ? (360 - angle) : angle;
/*     */     
/* 101 */     float position = angle / 180.0F;
/* 102 */     int segment = Math.min((int)(position * (colors.length - 1)), colors.length - 2);
/*     */     
/* 104 */     float fraction = position * (colors.length - 1) - segment;
/*     */     
/* 106 */     return interpolateColor(colors[segment], colors[segment + 1], fraction);
/*     */   }
/*     */   
/*     */   public static FixColor gradient(int speed, int index, ArrayList<FixColor> colors) {
/* 110 */     int angle = (int)((System.currentTimeMillis() / speed + index) % 360L);
/* 111 */     angle = (angle >= 180) ? (360 - angle) : angle;
/*     */     
/* 113 */     float position = angle / 180.0F;
/* 114 */     int segment = Math.min((int)(position * (colors.size() - 1)), colors.size() - 2);
/*     */     
/* 116 */     float fraction = position * (colors.size() - 1) - segment;
/*     */     
/* 118 */     return interpolateColor(colors.get(segment), colors.get(segment + 1), fraction);
/*     */   }
/*     */   
/*     */   public static FixColor interpolateColor(FixColor color1, FixColor color2, float amount) {
/* 122 */     amount = Math.min(1.0F, Math.max(0.0F, amount));
/* 123 */     return new FixColor(MathUtility.interpolate(color1.getRed(), color2.getRed(), amount), 
/* 124 */         MathUtility.interpolate(color1.getGreen(), color2.getGreen(), amount), 
/* 125 */         MathUtility.interpolate(color1.getBlue(), color2.getBlue(), amount), 
/* 126 */         MathUtility.interpolate(color1.getAlpha(), color2.getAlpha(), amount));
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\render\ColorUtility.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */