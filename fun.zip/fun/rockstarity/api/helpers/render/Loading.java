/*    */ package fun.rockstarity.api.helpers.render;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.render.animation.Animation;
/*    */ import fun.rockstarity.api.render.animation.Easing;
/*    */ import fun.rockstarity.api.render.color.FixColor;
/*    */ import fun.rockstarity.api.render.shaders.list.Round;
/*    */ import fun.rockstarity.api.render.ui.rect.Rect;
/*    */ import net.minecraft.util.math.vector.Vector2f;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Loading
/*    */ {
/*    */   private Loading() {
/* 19 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*    */   }
/* 21 */   private static final Vector2f left = Vector2f.ZERO; private static final Vector2f center = Vector2f.ZERO; private static final Vector2f right = Vector2f.ZERO;
/* 22 */   private static final Animation first = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); private static final Animation second = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300);
/*    */   private static boolean swap;
/*    */   
/*    */   public static void render(MatrixStack matrixStack, float x, float y, float size) {
/* 26 */     first.setSpeed(400);
/* 27 */     second.setSpeed(400);
/*    */     
/* 29 */     if (!swap) {
/* 30 */       if (first.finished(false)) {
/* 31 */         first.setForward(true);
/*    */       }
/* 33 */       if (first.finished()) {
/* 34 */         second.setForward(true);
/*    */       }
/* 36 */       if (first.finished() && second.finished())
/* 37 */         swap = true; 
/*    */     } else {
/* 39 */       if (second.finished()) {
/* 40 */         second.setForward(false);
/*    */       }
/* 42 */       if (second.finished(false)) {
/* 43 */         first.setForward(false);
/*    */       }
/* 45 */       if (first.finished(false) && second.finished(false)) {
/* 46 */         swap = false;
/*    */       }
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 56 */     float secondMiddle = (second.get() <= 0.5D) ? (1.0F - second.get() * 2.0F) : ((second.get() - 0.5F) * 2.0F);
/* 57 */     float firstMiddle = (first.get() <= 0.5D) ? (1.0F - first.get() * 2.0F) : ((first.get() - 0.5F) * 2.0F);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 70 */     Round.draw(matrixStack, new Rect(x + size * 2.0F * second.get(), y + size / 4.0F - size / 4.0F * secondMiddle, size, size / 2.0F + size / 2.0F * secondMiddle), size / 4.0F + size / 4.0F * secondMiddle, FixColor.WHITE);
/*    */ 
/*    */ 
/*    */     
/* 74 */     Round.draw(matrixStack, new Rect(x + size * 2.0F + size * 2.0F * first.get(), y + size / 4.0F - size / 4.0F * firstMiddle, size, size / 2.0F + size / 2.0F * firstMiddle), size / 4.0F + size / 4.0F * firstMiddle, FixColor.WHITE);
/*    */ 
/*    */ 
/*    */     
/* 78 */     float pointX = (float)Math.cos(Math.toRadians((-first.get() * 180.0F))) * size - size;
/* 79 */     float pointY = (float)Math.sin(Math.toRadians((-first.get() * 180.0F))) * size;
/*    */     
/* 81 */     if (first.finished() || (!second.isForward() && !second.finished(false))) {
/* 82 */       pointX = (float)Math.cos(Math.toRadians((-second.get() * 180.0F))) * size - size * 3.0F;
/* 83 */       pointY = (float)Math.sin(Math.toRadians((-second.get() * 180.0F))) * size;
/*    */     } 
/*    */     
/* 86 */     Round.draw(matrixStack, new Rect(x + size * 4.0F + pointX, y + pointY, size, size), size / 2.0F, FixColor.WHITE);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\render\Loading.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */