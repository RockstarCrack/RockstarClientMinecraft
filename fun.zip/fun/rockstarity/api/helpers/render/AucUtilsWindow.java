/*    */ package fun.rockstarity.api.helpers.render;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.helpers.math.Hover;
/*    */ import fun.rockstarity.api.modules.Module;
/*    */ import fun.rockstarity.api.modules.settings.Setting;
/*    */ import fun.rockstarity.api.render.color.FixColor;
/*    */ import fun.rockstarity.api.render.shaders.list.Round;
/*    */ import fun.rockstarity.api.render.ui.clickgui.SettingRect;
/*    */ import fun.rockstarity.api.render.ui.rect.Rect;
/*    */ import fun.rockstarity.api.render.ui.widgets.Window;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ public class AucUtilsWindow
/*    */   extends Window
/*    */ {
/*    */   private final Module element;
/* 21 */   private final List<SettingRect> settings = new ArrayList<>();
/*    */   
/*    */   public AucUtilsWindow(Module element) {
/* 24 */     super(10.0F, (sr.getScaledHeight() / 2 - 100), 145.0F, 10.0F);
/*    */     
/* 26 */     this.element = element;
/*    */     
/* 28 */     for (Setting setting : element.getSettings()) {
/* 29 */       this.settings.add(new SettingRect(setting));
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/* 35 */     this.x = 10.0F;
/* 36 */     this.y = (sr.getScaledHeight() / 2) - this.height / 2.0F;
/*    */     
/* 38 */     GL11.glPushMatrix();
/* 39 */     GL11.glTranslated(0.0D, 0.0D, 999.0D);
/*    */     
/* 41 */     Render.glow(matrixStack, (Rect)this, this.opening.get());
/*    */     
/* 43 */     Round.draw(matrixStack, (Rect)this, 4.0F, rock.getThemes().getFirstColor().alpha(this.opening.get()));
/*    */     
/* 45 */     bold.get(16).draw(matrixStack, "AuctionUtils", this.x, this.y - 13.0F, FixColor.WHITE.alpha(this.opening.get()));
/*    */     
/* 47 */     Stencil.init();
/* 48 */     Round.draw(matrixStack, (Rect)this, 4.0F, rock.getThemes().getFirstColor().alpha(this.opening.get()));
/* 49 */     Stencil.read(1);
/*    */     
/* 51 */     float yOff = 0.0F;
/* 52 */     for (SettingRect setting : this.settings) {
/* 53 */       setting.getHide().setForward(setting.getParent().isHide());
/*    */       
/* 55 */       setting.set(this.x, this.y + yOff - 2.0F - 10.0F + 10.0F * this.opening.get() * (1.0F - setting.getHide().get()), 145.0F, setting.getHeight());
/* 56 */       setting.render(matrixStack, mouseX, mouseY, partialTicks, this.opening.get() * (1.0F - setting.getHide().get()), false, false);
/*    */       
/* 58 */       yOff += (setting.getHeight() - 13.0F) * (1.0F - setting.getHide().get());
/*    */     } 
/* 60 */     Stencil.finish();
/*    */     
/* 62 */     Render.outline(matrixStack, (Rect)this, this.opening.get());
/* 63 */     GL11.glPopMatrix();
/*    */     
/* 65 */     this.height = yOff + 10.0F;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean clicked(double mouseX, double mouseY, int button) {
/* 70 */     if (!Hover.isHovered(this.x, this.y, this.width, this.height, mouseX, mouseY) || button != 0) {
/* 71 */       return super.released(mouseX, mouseY, button);
/*    */     }
/*    */     
/* 74 */     float yOff = 0.0F;
/* 75 */     for (SettingRect setting : this.settings) {
/* 76 */       if (Hover.isHovered(setting.y(this.y + yOff - 2.0F - 10.0F + 10.0F * this.opening.get() + 3.0F).height(setting.getHeight() - 14.0F), mouseX, mouseY)) {
/* 77 */         setting.clicked(mouseX, mouseY, button, false);
/*    */       }
/* 79 */       yOff += (setting.getHeight() - 13.0F) * (1.0F - setting.getHide().get());
/*    */     } 
/*    */     
/* 82 */     return super.clicked(mouseX, mouseY, button);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean released(double mouseX, double mouseY, int button) {
/* 87 */     if (button != 0) return super.clicked(mouseX, mouseY, button);
/*    */     
/* 89 */     for (SettingRect setting : this.settings) {
/* 90 */       if (setting.getParent().isHide()) {
/*    */         continue;
/*    */       }
/* 93 */       setting.clicked(mouseX, mouseY, button, true);
/*    */     } 
/*    */     
/* 96 */     return super.released(mouseX, mouseY, button);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\render\AucUtilsWindow.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */