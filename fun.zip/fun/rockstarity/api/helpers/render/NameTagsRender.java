/*    */ package fun.rockstarity.api.helpers.render;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.helpers.math.Hover;
/*    */ import fun.rockstarity.api.modules.Module;
/*    */ import fun.rockstarity.api.modules.settings.Setting;
/*    */ import fun.rockstarity.api.render.shaders.list.Round;
/*    */ import fun.rockstarity.api.render.ui.clickgui.SettingRect;
/*    */ import fun.rockstarity.api.render.ui.rect.Rect;
/*    */ import fun.rockstarity.api.render.ui.widgets.Window;
/*    */ import fun.rockstarity.client.modules.render.NameTags;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ public class NameTagsRender
/*    */   extends Window
/*    */ {
/*    */   private final Module element;
/* 20 */   private final List<SettingRect> settings = new ArrayList<>();
/*    */   
/*    */   public NameTagsRender(Module element) {
/* 23 */     super(10.0F, (sr.getScaledHeight() / 2 - 100), 145.0F, 10.0F);
/*    */     
/* 25 */     this.element = element;
/*    */     
/* 27 */     for (Setting setting : element.getSettings()) {
/* 28 */       this.settings.add(new SettingRect(setting));
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/* 34 */     this.x = 10.0F;
/* 35 */     this.y = (sr.getScaledHeight() / 2) - this.height / 2.0F;
/*    */     
/* 37 */     Render.glow(matrixStack, (Rect)this, this.opening.get());
/*    */     
/* 39 */     Round.draw(matrixStack, (Rect)this, 8.0F, rock.getThemes().getFirstColor().alpha(this.opening.get()));
/*    */     
/* 41 */     Stencil.init();
/* 42 */     Round.draw(matrixStack, (Rect)this, 8.0F, rock.getThemes().getFirstColor().alpha(this.opening.get()));
/* 43 */     Stencil.read(1);
/*    */     
/* 45 */     float yOff = 0.0F;
/* 46 */     for (SettingRect setting : this.settings) {
/* 47 */       setting.getHide().setForward(setting.getParent().isHide());
/*    */       
/* 49 */       setting.set(this.x, this.y + yOff - 2.0F - 10.0F + 10.0F * this.opening.get() * (1.0F - setting.getHide().get()), 145.0F, setting.getHeight());
/* 50 */       setting.render(matrixStack, mouseX, mouseY, partialTicks, this.opening.get() * (1.0F - setting.getHide().get()), false, false);
/*    */       
/* 52 */       yOff += (setting.getHeight() - 13.0F) * (1.0F - setting.getHide().get());
/*    */     } 
/*    */     
/* 55 */     Stencil.finish();
/*    */     
/* 57 */     Render.outline(matrixStack, (Rect)this, this.opening.get());
/*    */     
/* 59 */     this.height = yOff + 10.0F;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean clicked(double mouseX, double mouseY, int button) {
/* 64 */     float yOff = 0.0F;
/* 65 */     for (SettingRect setting : this.settings) {
/* 66 */       if (Hover.isHovered(this.x, (this.y + yOff - 2.0F - 10.0F + 10.0F * this.opening.get() * (1.0F - setting.getHide().get())), 145.0D, setting.getHeight(), mouseX, mouseY)) {
/* 67 */         ((NameTags)rock.getModules().get(NameTags.class)).setVisible(true);
/*    */       } else {
/* 69 */         ((NameTags)rock.getModules().get(NameTags.class)).setVisible(false);
/*    */       } 
/*    */       
/* 72 */       if (Hover.isHovered(setting.y(this.y + yOff - 2.0F - 10.0F + 10.0F * this.opening.get() + 3.0F).height(setting.getHeight() - 14.0F), mouseX, mouseY)) {
/* 73 */         setting.clicked(mouseX, mouseY, button, false);
/*    */       }
/* 75 */       yOff += (setting.getHeight() - 13.0F) * (1.0F - setting.getHide().get());
/*    */     } 
/*    */     
/* 78 */     return super.clicked(mouseX, mouseY, button);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean released(double mouseX, double mouseY, int button) {
/* 83 */     if (button != 0) return super.clicked(mouseX, mouseY, button);
/*    */     
/* 85 */     for (SettingRect setting : this.settings) {
/* 86 */       if (setting.getParent().isHide()) {
/*    */         continue;
/*    */       }
/* 89 */       setting.clicked(mouseX, mouseY, button, true);
/*    */     } 
/*    */     
/* 92 */     return super.released(mouseX, mouseY, button);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\render\NameTagsRender.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */