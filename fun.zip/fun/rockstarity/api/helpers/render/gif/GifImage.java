/*     */ package fun.rockstarity.api.helpers.render.gif;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.imageio.ImageIO;
/*     */ 
/*     */ public class GifImage
/*     */ {
/*     */   public GifDecoder getDecoder() {
/*  18 */     return this.decoder;
/*     */   }
/*     */   
/*     */   public void setOutputFile(File outputFile) {
/*  22 */     this.outputFile = outputFile; } public File getOutputFile() {
/*  23 */     return this.outputFile;
/*     */   }
/*     */   public List<BufferedImage> getFrames() {
/*  26 */     return this.frames;
/*     */   }
/*     */ 
/*     */   
/*  30 */   private final GifDecoder decoder = new GifDecoder();
/*  31 */   private GifEncoder encoder = new GifEncoder(); private File outputFile;
/*  32 */   private final List<BufferedImage> frames = new ArrayList<>();
/*     */ 
/*     */ 
/*     */   
/*     */   public GifImage(File file) throws FileNotFoundException {
/*  37 */     this();
/*  38 */     loadFrom(file);
/*     */   }
/*     */ 
/*     */   
/*     */   public int loadFrom(File file) throws FileNotFoundException {
/*  43 */     if (!file.exists()) throw new FileNotFoundException("File does not exist"); 
/*  44 */     return loadFrom(new FileInputStream(file));
/*     */   }
/*     */ 
/*     */   
/*     */   public int loadFrom(InputStream stream) {
/*  49 */     this.frames.clear();
/*  50 */     this.encoder.setRepeat(0);
/*  51 */     int status = this.decoder.read(stream);
/*  52 */     for (int n = 0; n < this.decoder.getFrameCount(); ) { this.frames.add(this.decoder.getFrame(n)); n++; }
/*  53 */      return status;
/*     */   }
/*     */ 
/*     */   
/*     */   public void reverseFrames() {
/*  58 */     Collections.reverse(this.frames);
/*     */   }
/*     */ 
/*     */   
/*     */   public void saveAllFrames(File outputDirectory) {
/*  63 */     saveAllFrames(outputDirectory, "png");
/*     */   }
/*     */ 
/*     */   
/*     */   public void saveAllFrames(File outputDirectory, String format) {
/*  68 */     for (BufferedImage frame : getFrames()) {
/*     */       try {
/*  70 */         ImageIO.write(frame, format, new File(outputDirectory, "frame" + getFrames().indexOf(frame) + "." + format));
/*  71 */       } catch (IOException e) {
/*  72 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean save() {
/*  79 */     return finish();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean finish() {
/*  84 */     if (this.outputFile == null) throw new NullPointerException("Output file is null"); 
/*  85 */     this.encoder = GifEncoder.cloneFrom(this.encoder);
/*  86 */     this.encoder.start(this.outputFile.getAbsolutePath());
/*  87 */     for (BufferedImage frame : this.frames) {
/*  88 */       this.encoder.addFrame(frame);
/*     */     }
/*  90 */     return this.encoder.finish();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFrame(int index, BufferedImage frame) {
/*  95 */     this.frames.set(index, frame);
/*     */   }
/*     */ 
/*     */   
/*     */   public void repeatInfinitely(boolean repeat) {
/* 100 */     if (this.encoder.isStarted()) throw new UnsupportedOperationException("Encoder has already started"); 
/* 101 */     this.encoder.setRepeat(repeat ? 0 : 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addFrame(BufferedImage frame) {
/* 106 */     this.frames.add(frame);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeFrame(BufferedImage frame) {
/* 111 */     this.frames.remove(frame);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeFrame(int frameIndex) {
/* 116 */     this.frames.remove(frameIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public BufferedImage getFirstFrame() {
/* 121 */     return getFrame(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public BufferedImage getFrame(int index) {
/* 126 */     return getFrames().get(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public AnimatedGifEncoder getEncoder() {
/* 131 */     return this.encoder;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRepeat(int iteration) {
/* 136 */     this.encoder.setRepeat(iteration);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTransparent(Color color) {
/* 141 */     this.encoder.setTransparent(color);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTransparent(Color color, boolean exactMatch) {
/* 146 */     setTransparent(color, exactMatch);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setQuality(int quality) {
/* 151 */     this.encoder.setQuality(quality);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDelay(int ms) {
/* 156 */     this.encoder.setDelay(ms);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBackground(Color background) {
/* 161 */     this.encoder.setBackground(background);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFramerate(int fps) {
/* 166 */     this.encoder.setFrameRate(fps);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSize(int width, int height) {
/* 171 */     this.encoder.setSize(width, height);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDispose(int dispose) {
/* 176 */     this.encoder.setDispose(dispose);
/*     */   }
/*     */   
/*     */   public GifImage() {}
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\render\gif\GifImage.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */