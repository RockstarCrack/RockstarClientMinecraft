/*     */ package fun.rockstarity.api.helpers.render.gif;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.DataBufferByte;
/*     */ import java.awt.image.ImageObserver;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnimatedGifEncoder
/*     */ {
/*     */   protected int width;
/*     */   protected int height;
/*  19 */   protected Color transparent = null;
/*     */   
/*     */   protected boolean transparentExactMatch = false;
/*  22 */   protected Color background = null; public void setBackground(Color background) { this.background = background; }
/*     */   
/*     */   protected int transIndex;
/*  25 */   protected int repeat = -1;
/*  26 */   protected int delay = 0; protected boolean started = false; public boolean isStarted() {
/*  27 */     return this.started;
/*     */   }
/*     */   protected OutputStream out;
/*     */   protected BufferedImage image;
/*     */   protected byte[] pixels;
/*     */   protected byte[] indexedPixels;
/*     */   protected int colorDepth;
/*     */   protected byte[] colorTab;
/*  35 */   protected boolean[] usedEntry = new boolean[256];
/*  36 */   protected int palSize = 7;
/*  37 */   protected int dispose = -1;
/*     */   protected boolean closeStream = false;
/*     */   protected boolean firstFrame = true;
/*     */   protected boolean sizeSet = false;
/*  41 */   protected int sample = 10;
/*     */ 
/*     */   
/*     */   public void setDelay(int ms) {
/*  45 */     this.delay = Math.round(ms / 10.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDispose(int code) {
/*  50 */     if (code >= 0) {
/*  51 */       this.dispose = code;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRepeat(int iter) {
/*  57 */     if (iter >= 0) {
/*  58 */       this.repeat = iter;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTransparent(Color c) {
/*  64 */     setTransparent(c, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTransparent(Color c, boolean exactMatch) {
/*  69 */     this.transparent = c;
/*  70 */     this.transparentExactMatch = exactMatch;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addFrame(BufferedImage im) {
/*  75 */     if (im == null || !this.started) {
/*  76 */       return false;
/*     */     }
/*  78 */     boolean ok = true;
/*     */     try {
/*  80 */       if (!this.sizeSet)
/*     */       {
/*  82 */         setSize(im.getWidth(), im.getHeight());
/*     */       }
/*  84 */       this.image = im;
/*  85 */       getImagePixels();
/*  86 */       analyzePixels();
/*  87 */       if (this.firstFrame) {
/*  88 */         writeLSD();
/*  89 */         writePalette();
/*  90 */         if (this.repeat >= 0)
/*     */         {
/*  92 */           writeNetscapeExt();
/*     */         }
/*     */       } 
/*  95 */       writeGraphicCtrlExt();
/*  96 */       writeImageDesc();
/*  97 */       if (!this.firstFrame) {
/*  98 */         writePalette();
/*     */       }
/* 100 */       writePixels();
/* 101 */       this.firstFrame = false;
/* 102 */     } catch (IOException e) {
/* 103 */       ok = false;
/*     */     } 
/*     */     
/* 106 */     return ok;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean finish() {
/* 111 */     if (!this.started) return false; 
/* 112 */     boolean ok = true;
/* 113 */     this.started = false;
/*     */     try {
/* 115 */       this.out.write(59);
/* 116 */       this.out.flush();
/* 117 */       if (this.closeStream) {
/* 118 */         this.out.close();
/*     */       }
/* 120 */     } catch (IOException e) {
/* 121 */       ok = false;
/*     */     } 
/*     */ 
/*     */     
/* 125 */     this.transIndex = 0;
/* 126 */     this.out = null;
/* 127 */     this.image = null;
/* 128 */     this.pixels = null;
/* 129 */     this.indexedPixels = null;
/* 130 */     this.colorTab = null;
/* 131 */     this.closeStream = false;
/* 132 */     this.firstFrame = true;
/*     */     
/* 134 */     return ok;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFrameRate(float fps) {
/* 139 */     if (fps != 0.0F) {
/* 140 */       this.delay = Math.round(100.0F / fps);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setQuality(int quality) {
/* 146 */     if (quality < 1) quality = 1; 
/* 147 */     this.sample = quality;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSize(int w, int h) {
/* 152 */     if (this.started && !this.firstFrame)
/* 153 */       return;  this.width = w;
/* 154 */     this.height = h;
/* 155 */     if (this.width < 1) this.width = 320; 
/* 156 */     if (this.height < 1) this.height = 240; 
/* 157 */     this.sizeSet = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean start(OutputStream os) {
/* 162 */     if (os == null) return false; 
/* 163 */     boolean ok = true;
/* 164 */     this.closeStream = false;
/* 165 */     this.out = os;
/*     */     try {
/* 167 */       writeString("GIF89a");
/* 168 */     } catch (IOException e) {
/* 169 */       ok = false;
/*     */     } 
/* 171 */     return this.started = ok;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean start(String file) {
/* 176 */     boolean ok = true;
/*     */     try {
/* 178 */       this.out = new BufferedOutputStream(new FileOutputStream(file));
/* 179 */       ok = start(this.out);
/* 180 */       this.closeStream = true;
/* 181 */     } catch (IOException e) {
/* 182 */       ok = false;
/*     */     } 
/* 184 */     return this.started = ok;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void analyzePixels() {
/* 189 */     int len = this.pixels.length;
/* 190 */     int nPix = len / 3;
/* 191 */     this.indexedPixels = new byte[nPix];
/* 192 */     NeuQuant nq = new NeuQuant(this.pixels, len, this.sample);
/* 193 */     this.colorTab = nq.process();
/* 194 */     for (int i = 0; i < this.colorTab.length; i += 3) {
/* 195 */       byte temp = this.colorTab[i];
/* 196 */       this.colorTab[i] = this.colorTab[i + 2];
/* 197 */       this.colorTab[i + 2] = temp;
/* 198 */       this.usedEntry[i / 3] = false;
/*     */     } 
/* 200 */     int k = 0;
/* 201 */     for (int j = 0; j < nPix; j++) {
/*     */       
/* 203 */       int index = nq.map(this.pixels[k++] & 0xFF, this.pixels[k++] & 0xFF, this.pixels[k++] & 0xFF);
/*     */ 
/*     */       
/* 206 */       this.usedEntry[index] = true;
/* 207 */       this.indexedPixels[j] = (byte)index;
/*     */     } 
/* 209 */     this.pixels = null;
/* 210 */     this.colorDepth = 8;
/* 211 */     this.palSize = 7;
/* 212 */     if (this.transparent != null) {
/* 213 */       this.transIndex = this.transparentExactMatch ? findExact(this.transparent) : findClosest(this.transparent);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected int findClosest(Color c) {
/* 219 */     if (this.colorTab == null) return -1; 
/* 220 */     int r = c.getRed();
/* 221 */     int g = c.getGreen();
/* 222 */     int b = c.getBlue();
/* 223 */     int minpos = 0;
/* 224 */     int dmin = 16777216;
/* 225 */     int len = this.colorTab.length;
/* 226 */     for (int i = 0; i < len; ) {
/* 227 */       int dr = r - (this.colorTab[i++] & 0xFF);
/* 228 */       int dg = g - (this.colorTab[i++] & 0xFF);
/* 229 */       int db = b - (this.colorTab[i] & 0xFF);
/* 230 */       int d = dr * dr + dg * dg + db * db;
/* 231 */       int index = i / 3;
/* 232 */       if (this.usedEntry[index] && d < dmin) {
/* 233 */         dmin = d;
/* 234 */         minpos = index;
/*     */       } 
/* 236 */       i++;
/*     */     } 
/* 238 */     return minpos;
/*     */   }
/*     */   
/*     */   boolean isColorUsed(Color c) {
/* 242 */     return (findExact(c) != -1);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int findExact(Color c) {
/* 247 */     if (this.colorTab == null) {
/* 248 */       return -1;
/*     */     }
/*     */     
/* 251 */     int r = c.getRed();
/* 252 */     int g = c.getGreen();
/* 253 */     int b = c.getBlue();
/* 254 */     int len = this.colorTab.length / 3;
/* 255 */     for (int index = 0; index < len; index++) {
/* 256 */       int i = index * 3;
/*     */       
/* 258 */       if (this.usedEntry[index] && r == (this.colorTab[i] & 0xFF) && g == (this.colorTab[i + 1] & 0xFF) && b == (this.colorTab[i + 2] & 0xFF)) {
/* 259 */         return index;
/*     */       }
/*     */     } 
/* 262 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void getImagePixels() {
/* 267 */     int w = this.image.getWidth();
/* 268 */     int h = this.image.getHeight();
/* 269 */     int type = this.image.getType();
/* 270 */     if (w != this.width || h != this.height || type != 5) {
/*     */ 
/*     */ 
/*     */       
/* 274 */       BufferedImage temp = new BufferedImage(this.width, this.height, 5);
/*     */       
/* 276 */       Graphics2D g = temp.createGraphics();
/* 277 */       g.setColor(this.background);
/* 278 */       g.fillRect(0, 0, this.width, this.height);
/* 279 */       g.drawImage(this.image, 0, 0, (ImageObserver)null);
/* 280 */       this.image = temp;
/*     */     } 
/* 282 */     this.pixels = ((DataBufferByte)this.image.getRaster().getDataBuffer()).getData();
/*     */   }
/*     */   
/*     */   protected void writeGraphicCtrlExt() throws IOException {
/*     */     int transp, i;
/* 287 */     this.out.write(33);
/* 288 */     this.out.write(249);
/* 289 */     this.out.write(4);
/*     */     
/* 291 */     if (this.transparent == null) {
/* 292 */       transp = 0;
/* 293 */       i = 0;
/*     */     } else {
/* 295 */       transp = 1;
/* 296 */       i = 2;
/*     */     } 
/* 298 */     if (this.dispose >= 0) {
/* 299 */       i = this.dispose & 0x7;
/*     */     }
/* 301 */     i <<= 2;
/*     */ 
/*     */     
/* 304 */     this.out.write(i | transp);
/*     */     
/* 306 */     writeShort(this.delay);
/* 307 */     this.out.write(this.transIndex);
/* 308 */     this.out.write(0);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void writeImageDesc() throws IOException {
/* 313 */     this.out.write(44);
/* 314 */     writeShort(0);
/* 315 */     writeShort(0);
/* 316 */     writeShort(this.width);
/* 317 */     writeShort(this.height);
/*     */     
/* 319 */     if (this.firstFrame) {
/*     */       
/* 321 */       this.out.write(0);
/*     */     } else {
/*     */       
/* 324 */       this.out.write(0x80 | this.palSize);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeLSD() throws IOException {
/* 331 */     writeShort(this.width);
/* 332 */     writeShort(this.height);
/*     */     
/* 334 */     this.out.write(0xF0 | this.palSize);
/*     */     
/* 336 */     this.out.write(0);
/* 337 */     this.out.write(0);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void writeNetscapeExt() throws IOException {
/* 342 */     this.out.write(33);
/* 343 */     this.out.write(255);
/* 344 */     this.out.write(11);
/* 345 */     writeString("NETSCAPE2.0");
/* 346 */     this.out.write(3);
/* 347 */     this.out.write(1);
/* 348 */     writeShort(this.repeat);
/* 349 */     this.out.write(0);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void writePalette() throws IOException {
/* 354 */     this.out.write(this.colorTab, 0, this.colorTab.length);
/* 355 */     int n = 768 - this.colorTab.length;
/* 356 */     for (int i = 0; i < n; i++) {
/* 357 */       this.out.write(0);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void writePixels() throws IOException {
/* 363 */     LZWEncoder encoder = new LZWEncoder(this.width, this.height, this.indexedPixels, this.colorDepth);
/*     */     
/* 365 */     encoder.encode(this.out);
/*     */   }
/*     */   
/*     */   protected void writeShort(int value) throws IOException {
/* 369 */     this.out.write(value & 0xFF);
/* 370 */     this.out.write(value >> 8 & 0xFF);
/*     */   }
/*     */   
/*     */   protected void writeString(String s) throws IOException {
/* 374 */     for (int i = 0; i < s.length(); i++)
/* 375 */       this.out.write((byte)s.charAt(i)); 
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\render\gif\AnimatedGifEncoder.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */