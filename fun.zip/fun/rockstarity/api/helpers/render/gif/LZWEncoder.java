/*     */ package fun.rockstarity.api.helpers.render.gif;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LZWEncoder
/*     */ {
/*     */   private static final int EOF = -1;
/*     */   private final int imgW;
/*     */   private final int imgH;
/*     */   private final byte[] pixAry;
/*     */   private final int initCodeSize;
/*     */   private int remaining;
/*     */   private int curPixel;
/*     */   static final int BITS = 12;
/*     */   static final int HSIZE = 5003;
/*     */   int n_bits;
/*  21 */   int maxbits = 12;
/*     */   int maxcode;
/*  23 */   int maxmaxcode = 4096;
/*     */   
/*  25 */   int[] htab = new int[5003];
/*  26 */   int[] codetab = new int[5003];
/*     */   
/*  28 */   int hsize = 5003;
/*     */   
/*  30 */   int free_ent = 0;
/*     */ 
/*     */   
/*     */   boolean clear_flg = false;
/*     */   
/*     */   int g_init_bits;
/*     */   
/*     */   int ClearCode;
/*     */   
/*     */   int EOFCode;
/*     */   
/*  41 */   int cur_accum = 0;
/*  42 */   int cur_bits = 0;
/*     */   
/*  44 */   int[] masks = new int[] { 0, 1, 3, 7, 15, 31, 63, 127, 255, 511, 1023, 2047, 4095, 8191, 16383, 32767, 65535 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int a_count;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   byte[] accum = new byte[256];
/*     */ 
/*     */   
/*     */   LZWEncoder(int width, int height, byte[] pixels, int color_depth) {
/*  72 */     this.imgW = width;
/*  73 */     this.imgH = height;
/*  74 */     this.pixAry = pixels;
/*  75 */     this.initCodeSize = Math.max(2, color_depth);
/*     */   }
/*     */ 
/*     */   
/*     */   void char_out(byte c, OutputStream outs) throws IOException {
/*  80 */     this.accum[this.a_count++] = c;
/*  81 */     if (this.a_count >= 254) {
/*  82 */       flush_char(outs);
/*     */     }
/*     */   }
/*     */   
/*     */   void cl_block(OutputStream outs) throws IOException {
/*  87 */     cl_hash(this.hsize);
/*  88 */     this.free_ent = this.ClearCode + 2;
/*  89 */     this.clear_flg = true;
/*     */     
/*  91 */     output(this.ClearCode, outs);
/*     */   }
/*     */ 
/*     */   
/*     */   void cl_hash(int hsize) {
/*  96 */     for (int i = 0; i < hsize; i++) {
/*  97 */       this.htab[i] = -1;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void compress(int init_bits, OutputStream outs) throws IOException {
/* 110 */     this.g_init_bits = init_bits;
/*     */ 
/*     */     
/* 113 */     this.clear_flg = false;
/* 114 */     this.n_bits = this.g_init_bits;
/* 115 */     this.maxcode = MAXCODE(this.n_bits);
/*     */     
/* 117 */     this.ClearCode = 1 << init_bits - 1;
/* 118 */     this.EOFCode = this.ClearCode + 1;
/* 119 */     this.free_ent = this.ClearCode + 2;
/*     */     
/* 121 */     this.a_count = 0;
/*     */     
/* 123 */     int ent = nextPixel();
/*     */     
/* 125 */     int hshift = 0; int fcode;
/* 126 */     for (fcode = this.hsize; fcode < 65536; fcode *= 2)
/* 127 */       hshift++; 
/* 128 */     hshift = 8 - hshift;
/*     */     
/* 130 */     int hsize_reg = this.hsize;
/* 131 */     cl_hash(hsize_reg);
/*     */     
/* 133 */     output(this.ClearCode, outs);
/*     */     
/*     */     int c;
/* 136 */     label35: while ((c = nextPixel()) != -1) {
/* 137 */       fcode = (c << this.maxbits) + ent;
/* 138 */       int i = c << hshift ^ ent;
/*     */       
/* 140 */       if (this.htab[i] == fcode) {
/* 141 */         ent = this.codetab[i]; continue;
/*     */       } 
/* 143 */       if (this.htab[i] >= 0) {
/* 144 */         int disp = hsize_reg - i;
/* 145 */         if (i == 0)
/* 146 */           disp = 1; 
/*     */         do {
/* 148 */           if ((i -= disp) < 0) {
/* 149 */             i += hsize_reg;
/*     */           }
/* 151 */           if (this.htab[i] == fcode) {
/* 152 */             ent = this.codetab[i];
/*     */             continue label35;
/*     */           } 
/* 155 */         } while (this.htab[i] >= 0);
/*     */       } 
/* 157 */       output(ent, outs);
/* 158 */       ent = c;
/* 159 */       if (this.free_ent < this.maxmaxcode) {
/* 160 */         this.codetab[i] = this.free_ent++;
/* 161 */         this.htab[i] = fcode; continue;
/*     */       } 
/* 163 */       cl_block(outs);
/*     */     } 
/*     */     
/* 166 */     output(ent, outs);
/* 167 */     output(this.EOFCode, outs);
/*     */   }
/*     */ 
/*     */   
/*     */   void encode(OutputStream os) throws IOException {
/* 172 */     os.write(this.initCodeSize);
/*     */     
/* 174 */     this.remaining = this.imgW * this.imgH;
/* 175 */     this.curPixel = 0;
/*     */     
/* 177 */     compress(this.initCodeSize + 1, os);
/*     */     
/* 179 */     os.write(0);
/*     */   }
/*     */ 
/*     */   
/*     */   void flush_char(OutputStream outs) throws IOException {
/* 184 */     if (this.a_count > 0) {
/* 185 */       outs.write(this.a_count);
/* 186 */       outs.write(this.accum, 0, this.a_count);
/* 187 */       this.a_count = 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   final int MAXCODE(int n_bits) {
/* 192 */     return (1 << n_bits) - 1;
/*     */   }
/*     */ 
/*     */   
/*     */   private int nextPixel() {
/* 197 */     if (this.remaining == 0) {
/* 198 */       return -1;
/*     */     }
/* 200 */     this.remaining--;
/*     */     
/* 202 */     byte pix = this.pixAry[this.curPixel++];
/*     */     
/* 204 */     return pix & 0xFF;
/*     */   }
/*     */   
/*     */   void output(int code, OutputStream outs) throws IOException {
/* 208 */     this.cur_accum &= this.masks[this.cur_bits];
/*     */     
/* 210 */     if (this.cur_bits > 0) {
/* 211 */       this.cur_accum |= code << this.cur_bits;
/*     */     } else {
/* 213 */       this.cur_accum = code;
/*     */     } 
/* 215 */     this.cur_bits += this.n_bits;
/*     */     
/* 217 */     while (this.cur_bits >= 8) {
/* 218 */       char_out((byte)(this.cur_accum & 0xFF), outs);
/* 219 */       this.cur_accum >>= 8;
/* 220 */       this.cur_bits -= 8;
/*     */     } 
/* 222 */     if (this.free_ent > this.maxcode || this.clear_flg) {
/* 223 */       if (this.clear_flg) {
/* 224 */         this.maxcode = MAXCODE(this.n_bits = this.g_init_bits);
/* 225 */         this.clear_flg = false;
/*     */       } else {
/* 227 */         this.n_bits++;
/* 228 */         if (this.n_bits == this.maxbits) {
/* 229 */           this.maxcode = this.maxmaxcode;
/*     */         } else {
/* 231 */           this.maxcode = MAXCODE(this.n_bits);
/*     */         } 
/*     */       } 
/*     */     }
/* 235 */     if (code == this.EOFCode) {
/*     */       
/* 237 */       while (this.cur_bits > 0) {
/* 238 */         char_out((byte)(this.cur_accum & 0xFF), outs);
/* 239 */         this.cur_accum >>= 8;
/* 240 */         this.cur_bits -= 8;
/*     */       } 
/*     */       
/* 243 */       flush_char(outs);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\render\gif\LZWEncoder.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */