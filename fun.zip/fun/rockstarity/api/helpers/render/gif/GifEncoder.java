/*     */ package fun.rockstarity.api.helpers.render.gif;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ public class GifEncoder
/*     */   extends AnimatedGifEncoder
/*     */ {
/*     */   public static GifEncoder cloneFrom(GifEncoder encoder) {
/*  11 */     GifEncoder gifEncoder = new GifEncoder();
/*  12 */     gifEncoder.setDelay(encoder.getDelay());
/*  13 */     gifEncoder.setRepeat(encoder.getRepeat());
/*  14 */     gifEncoder.setBackground(encoder.getBackground());
/*  15 */     gifEncoder.setDispose(encoder.getDispose());
/*  16 */     gifEncoder.setQuality(encoder.getSample());
/*  17 */     if (encoder.getWidth() >= 1 && encoder.getHeight() >= 1)
/*  18 */       gifEncoder.setSize(encoder.getWidth(), encoder.getHeight()); 
/*  19 */     gifEncoder.setTransparent(encoder.getTransparent(), encoder.isTransparentExactMatch());
/*  20 */     return gifEncoder;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getWidth() {
/*  25 */     return this.width;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHeight() {
/*  30 */     return this.height;
/*     */   }
/*     */ 
/*     */   
/*     */   public Color getTransparent() {
/*  35 */     return this.transparent;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTransparentExactMatch() {
/*  40 */     return this.transparentExactMatch;
/*     */   }
/*     */ 
/*     */   
/*     */   public Color getBackground() {
/*  45 */     return this.background;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTransIndex() {
/*  50 */     return this.transIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRepeat() {
/*  55 */     return this.repeat;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDelay() {
/*  60 */     return this.delay;
/*     */   }
/*     */ 
/*     */   
/*     */   public OutputStream getOut() {
/*  65 */     return this.out;
/*     */   }
/*     */ 
/*     */   
/*     */   public BufferedImage getImage() {
/*  70 */     return this.image;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getPixels() {
/*  75 */     return this.pixels;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getIndexedPixels() {
/*  80 */     return this.indexedPixels;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getColorDepth() {
/*  85 */     return this.colorDepth;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getColorTab() {
/*  90 */     return this.colorTab;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean[] getUsedEntry() {
/*  95 */     return this.usedEntry;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPalSize() {
/* 100 */     return this.palSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDispose() {
/* 105 */     return this.dispose;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCloseStream() {
/* 110 */     return this.closeStream;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFirstFrame() {
/* 115 */     return this.firstFrame;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isSizeSet() {
/* 120 */     return this.sizeSet;
/*     */   }
/*     */ 
/*     */   
/*     */   private int getSample() {
/* 125 */     return this.sample;
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\render\gif\GifEncoder.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */