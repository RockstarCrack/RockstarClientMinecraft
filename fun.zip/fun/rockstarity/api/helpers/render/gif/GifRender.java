/*     */ package fun.rockstarity.api.helpers.render.gif;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.shaders.list.Round;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.renderer.BufferBuilder;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GifRender
/*     */   implements IAccess
/*     */ {
/*  31 */   private final List<Integer> frames = new ArrayList<>();
/*     */   public GifRender(ResourceLocation resourceLocation) {
/*     */     
/*  34 */     try { InputStream inputStream = mc.getResourceManager().getResource(resourceLocation).getInputStream(); 
/*  35 */       try { GifImage gifImage = new GifImage();
/*  36 */         gifImage.loadFrom(inputStream);
/*     */         
/*  38 */         for (BufferedImage frame : gifImage.getFrames()) {
/*  39 */           this.frames.add(Integer.valueOf(loadTexture(frame)));
/*     */         }
/*  41 */         if (inputStream != null) inputStream.close();  } catch (Throwable throwable) { if (inputStream != null) try { inputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException e)
/*  42 */     { e.printStackTrace();
/*  43 */       throw new RuntimeException("Failed to load GIF from resource: " + String.valueOf(resourceLocation), e); }
/*     */   
/*     */   }
/*     */   
/*     */   public GifRender(File file) {
/*  48 */     GifImage gifImage = new GifImage();
/*     */     try {
/*  50 */       gifImage.loadFrom(file);
/*  51 */     } catch (FileNotFoundException e) {
/*  52 */       e.printStackTrace();
/*     */     } 
/*     */     
/*  55 */     for (BufferedImage frame : gifImage.getFrames()) {
/*  56 */       this.frames.add(Integer.valueOf(loadTexture(frame)));
/*     */     }
/*     */   }
/*     */   
/*     */   public GifRender(InputStream inputStream) {
/*  61 */     GifImage gifImage = new GifImage();
/*  62 */     gifImage.loadFrom(inputStream);
/*     */     
/*  64 */     for (BufferedImage frame : gifImage.getFrames()) {
/*  65 */       this.frames.add(Integer.valueOf(loadTexture(frame)));
/*     */     }
/*     */   }
/*     */   
/*     */   public void draw(MatrixStack stack, float x, float y, float width, float height, float alpha, double speed) {
/*  70 */     draw(stack, x, y, width, height, alpha, speed, false);
/*     */   }
/*     */   
/*     */   public void draw(MatrixStack stack, float x, float y, float width, float height, float alpha, double speed, boolean bloom) {
/*  74 */     bindTexture(speed);
/*     */     
/*  76 */     GlStateManager.pushMatrix();
/*  77 */     GlStateManager.enableBlend();
/*  78 */     if (bloom) { GlStateManager.blendFunc(770, 1); }
/*  79 */     else { RenderSystem.defaultBlendFunc(); }
/*  80 */      GlStateManager.disableAlphaTest();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  85 */     FixColor color = FixColor.WHITE.alpha(alpha);
/*  86 */     BufferBuilder buffer = Tessellator.getInstance().getBuffer();
/*  87 */     buffer.begin(7, DefaultVertexFormats.POSITION_COLOR_TEX);
/*  88 */     buffer.pos(stack.getLast().getMatrix(), x, y, 0.0F)
/*  89 */       .color(color)
/*  90 */       .tex(0.0F, 0.0F)
/*  91 */       .endVertex();
/*  92 */     buffer.pos(stack.getLast().getMatrix(), x, y + height, 0.0F)
/*  93 */       .color(color)
/*  94 */       .tex(0.0F, 1.0F)
/*  95 */       .endVertex();
/*  96 */     buffer.pos(stack.getLast().getMatrix(), x + width, y + height, 0.0F)
/*  97 */       .color(color)
/*  98 */       .tex(1.0F, 1.0F)
/*  99 */       .endVertex();
/* 100 */     buffer.pos(stack.getLast().getMatrix(), x + width, y, 0.0F)
/* 101 */       .color(color)
/* 102 */       .tex(1.0F, 0.0F)
/* 103 */       .endVertex();
/* 104 */     Tessellator.getInstance().draw();
/*     */     
/* 106 */     GlStateManager.enableAlphaTest();
/* 107 */     GlStateManager.popMatrix();
/*     */   }
/*     */   
/*     */   public void drawRound(MatrixStack stack, float x, float y, float width, float height, float round, float alpha, double speed) {
/* 111 */     bindTexture(speed);
/*     */     
/* 113 */     GlStateManager.pushMatrix();
/* 114 */     GlStateManager.enableBlend();
/* 115 */     RenderSystem.defaultBlendFunc();
/* 116 */     GlStateManager.disableAlphaTest();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 121 */     Round.drawTextured(stack, new Rect(x, y, width, height), round, alpha);
/*     */     
/* 123 */     GlStateManager.enableAlphaTest();
/* 124 */     GlStateManager.popMatrix();
/*     */   }
/*     */   
/*     */   public int loadTexture(BufferedImage image) {
/*     */     try {
/* 129 */       int[] pixels = image.getRGB(0, 0, image.getWidth(), image.getHeight(), null, 0, image.getWidth());
/* 130 */       ByteBuffer buffer = ByteBuffer.allocateDirect(pixels.length * 4);
/*     */       
/* 132 */       for (int pixel : pixels) {
/* 133 */         buffer.put((byte)(pixel >> 16 & 0xFF));
/* 134 */         buffer.put((byte)(pixel >> 8 & 0xFF));
/* 135 */         buffer.put((byte)(pixel & 0xFF));
/* 136 */         buffer.put((byte)(pixel >> 24 & 0xFF));
/*     */       } 
/* 138 */       buffer.flip();
/*     */       
/* 140 */       int textureID = GlStateManager.genTexture();
/* 141 */       GlStateManager.bindTexture(textureID);
/*     */ 
/*     */       
/* 144 */       GL11.glTexParameteri(3553, 10242, 33071);
/* 145 */       GL11.glTexParameteri(3553, 10243, 33071);
/* 146 */       GL11.glTexParameteri(3553, 10241, 9729);
/* 147 */       GL11.glTexParameteri(3553, 10240, 9729);
/*     */       
/* 149 */       GL11.glTexImage2D(3553, 0, 6408, image.getWidth(), image.getHeight(), 0, 6408, 5121, buffer);
/*     */ 
/*     */       
/* 152 */       GlStateManager.bindTexture(0);
/*     */       
/* 154 */       return textureID;
/* 155 */     } catch (Exception e) {
/* 156 */       return 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void bindTexture(double speed) {
/* 161 */     int frameIndex = (int)(System.currentTimeMillis() / speed % this.frames.size());
/* 162 */     int textureID = ((Integer)this.frames.get(frameIndex)).intValue();
/* 163 */     GlStateManager.bindTexture(textureID);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\render\gif\GifRender.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */