/*     */ package fun.rockstarity.api.helpers.render.gif;
/*     */ 
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.DataBufferInt;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GifDecoder
/*     */ {
/*     */   public static final int STATUS_OK = 0;
/*     */   public static final int STATUS_FORMAT_ERROR = 1;
/*     */   public static final int STATUS_OPEN_ERROR = 2;
/*     */   protected BufferedInputStream in;
/*     */   protected int status;
/*     */   protected int width;
/*     */   protected int height;
/*     */   protected boolean gctFlag;
/*     */   protected int gctSize;
/*  32 */   protected int loopCount = 1;
/*     */   
/*     */   protected int[] gct;
/*     */   
/*     */   protected int[] lct;
/*     */   protected int[] act;
/*     */   protected int bgIndex;
/*     */   protected int bgColor;
/*     */   protected int lastBgColor;
/*     */   protected int pixelAspect;
/*     */   protected boolean lctFlag;
/*     */   protected boolean interlace;
/*     */   protected int lctSize;
/*     */   protected int ix;
/*     */   protected int iy;
/*     */   protected int iw;
/*     */   protected int ih;
/*     */   protected Rectangle lastRect;
/*     */   protected BufferedImage image;
/*     */   protected BufferedImage lastImage;
/*  52 */   protected byte[] block = new byte[256];
/*  53 */   protected int blockSize = 0;
/*     */ 
/*     */   
/*  56 */   protected int dispose = 0;
/*     */   
/*  58 */   protected int lastDispose = 0;
/*     */   protected boolean transparency = false;
/*  60 */   protected int delay = 0;
/*     */   protected int transIndex;
/*     */   protected static final int MaxStackSize = 4096;
/*     */   protected short[] prefix;
/*     */   protected byte[] suffix;
/*     */   protected byte[] pixelStack;
/*     */   protected byte[] pixels;
/*     */   protected ArrayList frames;
/*     */   protected int frameCount;
/*     */   
/*     */   static class GifFrame
/*     */   {
/*     */     public BufferedImage image;
/*     */     public int delay;
/*     */     
/*     */     public GifFrame(BufferedImage im, int del) {
/*  76 */       this.image = im;
/*  77 */       this.delay = del;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDelay(int n) {
/*  87 */     this.delay = -1;
/*  88 */     if (n >= 0 && n < this.frameCount) {
/*  89 */       this.delay = ((GifFrame)this.frames.get(n)).delay;
/*     */     }
/*  91 */     return this.delay;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFrameCount() {
/*  96 */     return this.frameCount;
/*     */   }
/*     */ 
/*     */   
/*     */   public BufferedImage getImage() {
/* 101 */     return getFrame(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLoopCount() {
/* 106 */     return this.loopCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setPixels() {
/* 113 */     int[] dest = ((DataBufferInt)this.image.getRaster().getDataBuffer()).getData();
/*     */ 
/*     */     
/* 116 */     if (this.lastDispose > 0) {
/* 117 */       if (this.lastDispose == 3) {
/*     */         
/* 119 */         int n = this.frameCount - 2;
/* 120 */         if (n > 0) {
/* 121 */           this.lastImage = getFrame(n - 1);
/*     */         } else {
/* 123 */           this.lastImage = null;
/*     */         } 
/*     */       } 
/*     */       
/* 127 */       if (this.lastImage != null) {
/*     */         
/* 129 */         int[] prev = ((DataBufferInt)this.lastImage.getRaster().getDataBuffer()).getData();
/* 130 */         System.arraycopy(prev, 0, dest, 0, this.width * this.height);
/*     */ 
/*     */         
/* 133 */         if (this.lastDispose == 2) {
/*     */           
/* 135 */           Graphics2D g = this.image.createGraphics();
/* 136 */           Color c = null;
/* 137 */           if (this.transparency) {
/* 138 */             c = new Color(0, 0, 0, 0);
/*     */           } else {
/* 140 */             c = new Color(this.lastBgColor);
/*     */           } 
/* 142 */           g.setColor(c);
/* 143 */           g.setComposite(AlphaComposite.Src);
/* 144 */           g.fill(this.lastRect);
/* 145 */           g.dispose();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 151 */     int pass = 1;
/* 152 */     int inc = 8;
/* 153 */     int iline = 0;
/* 154 */     for (int i = 0; i < this.ih; i++) {
/* 155 */       int line = i;
/* 156 */       if (this.interlace) {
/* 157 */         if (iline >= this.ih) {
/* 158 */           pass++;
/* 159 */           switch (pass) {
/*     */             case 2:
/* 161 */               iline = 4;
/*     */               break;
/*     */             case 3:
/* 164 */               iline = 2;
/* 165 */               inc = 4;
/*     */               break;
/*     */             case 4:
/* 168 */               iline = 1;
/* 169 */               inc = 2; break;
/*     */           } 
/*     */         } 
/* 172 */         line = iline;
/* 173 */         iline += inc;
/*     */       } 
/* 175 */       line += this.iy;
/* 176 */       if (line < this.height) {
/* 177 */         int k = line * this.width;
/* 178 */         int dx = k + this.ix;
/* 179 */         int dlim = dx + this.iw;
/* 180 */         if (k + this.width < dlim) {
/* 181 */           dlim = k + this.width;
/*     */         }
/* 183 */         int sx = i * this.iw;
/* 184 */         while (dx < dlim) {
/*     */           
/* 186 */           int index = this.pixels[sx++] & 0xFF;
/* 187 */           int c = this.act[index];
/* 188 */           if (c != 0) {
/* 189 */             dest[dx] = c;
/*     */           }
/* 191 */           dx++;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public BufferedImage getFrame(int n) {
/* 199 */     BufferedImage im = null;
/* 200 */     if (n >= 0 && n < this.frameCount) {
/* 201 */       im = ((GifFrame)this.frames.get(n)).image;
/*     */     }
/* 203 */     return im;
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getFrameSize() {
/* 208 */     return new Dimension(this.width, this.height);
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(BufferedInputStream is) {
/* 213 */     init();
/* 214 */     if (is != null) {
/* 215 */       this.in = is;
/* 216 */       readHeader();
/* 217 */       if (!err()) {
/* 218 */         readContents();
/* 219 */         if (this.frameCount < 0) {
/* 220 */           this.status = 1;
/*     */         }
/*     */       } 
/*     */     } else {
/* 224 */       this.status = 2;
/*     */     } 
/*     */     try {
/* 227 */       is.close();
/* 228 */     } catch (IOException iOException) {}
/*     */     
/* 230 */     return this.status;
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(InputStream is) {
/* 235 */     init();
/* 236 */     if (is != null) {
/* 237 */       if (!(is instanceof BufferedInputStream))
/* 238 */         is = new BufferedInputStream(is); 
/* 239 */       this.in = (BufferedInputStream)is;
/* 240 */       readHeader();
/* 241 */       if (!err()) {
/* 242 */         readContents();
/* 243 */         if (this.frameCount < 0) {
/* 244 */           this.status = 1;
/*     */         }
/*     */       } 
/*     */     } else {
/* 248 */       this.status = 2;
/*     */     } 
/*     */     try {
/* 251 */       is.close();
/* 252 */     } catch (IOException iOException) {}
/*     */     
/* 254 */     return this.status;
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(String name) {
/* 259 */     this.status = 0;
/*     */     try {
/* 261 */       name = name.trim().toLowerCase();
/* 262 */       if (name.indexOf("file:") >= 0 || name
/* 263 */         .indexOf(":/") > 0) {
/* 264 */         URL url = new URL(name);
/* 265 */         this.in = new BufferedInputStream(url.openStream());
/*     */       } else {
/* 267 */         this.in = new BufferedInputStream(new FileInputStream(name));
/*     */       } 
/* 269 */       this.status = read(this.in);
/* 270 */     } catch (IOException e) {
/* 271 */       this.status = 2;
/*     */     } 
/*     */     
/* 274 */     return this.status;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void decodeImageData() {
/* 279 */     int NullCode = -1;
/* 280 */     int npix = this.iw * this.ih;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 299 */     if (this.pixels == null || this.pixels.length < npix) {
/* 300 */       this.pixels = new byte[npix];
/*     */     }
/* 302 */     if (this.prefix == null) this.prefix = new short[4096]; 
/* 303 */     if (this.suffix == null) this.suffix = new byte[4096]; 
/* 304 */     if (this.pixelStack == null) this.pixelStack = new byte[4097];
/*     */ 
/*     */     
/* 307 */     int data_size = read();
/* 308 */     int clear = 1 << data_size;
/* 309 */     int end_of_information = clear + 1;
/* 310 */     int available = clear + 2;
/* 311 */     int old_code = NullCode;
/* 312 */     int code_size = data_size + 1;
/* 313 */     int code_mask = (1 << code_size) - 1; int code;
/* 314 */     for (code = 0; code < clear; code++) {
/* 315 */       this.prefix[code] = 0;
/* 316 */       this.suffix[code] = (byte)code;
/*     */     } 
/*     */ 
/*     */     
/* 320 */     int bi = 0, pi = bi, top = pi, first = top, count = first, bits = count, datum = bits;
/*     */     int i;
/* 322 */     for (i = 0; i < npix; ) {
/* 323 */       if (top == 0) {
/* 324 */         if (bits < code_size) {
/*     */           
/* 326 */           if (count == 0) {
/*     */             
/* 328 */             count = readBlock();
/* 329 */             if (count <= 0)
/*     */               break; 
/* 331 */             bi = 0;
/*     */           } 
/* 333 */           datum += (this.block[bi] & 0xFF) << bits;
/* 334 */           bits += 8;
/* 335 */           bi++;
/* 336 */           count--;
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 341 */         code = datum & code_mask;
/* 342 */         datum >>= code_size;
/* 343 */         bits -= code_size;
/*     */ 
/*     */         
/* 346 */         if (code > available || code == end_of_information)
/*     */           break; 
/* 348 */         if (code == clear) {
/*     */           
/* 350 */           code_size = data_size + 1;
/* 351 */           code_mask = (1 << code_size) - 1;
/* 352 */           available = clear + 2;
/* 353 */           old_code = NullCode;
/*     */           continue;
/*     */         } 
/* 356 */         if (old_code == NullCode) {
/* 357 */           this.pixelStack[top++] = this.suffix[code];
/* 358 */           old_code = code;
/* 359 */           first = code;
/*     */           continue;
/*     */         } 
/* 362 */         int in_code = code;
/* 363 */         if (code == available) {
/* 364 */           this.pixelStack[top++] = (byte)first;
/* 365 */           code = old_code;
/*     */         } 
/* 367 */         while (code > clear) {
/* 368 */           this.pixelStack[top++] = this.suffix[code];
/* 369 */           code = this.prefix[code];
/*     */         } 
/* 371 */         first = this.suffix[code] & 0xFF;
/*     */ 
/*     */         
/* 374 */         if (available >= 4096) {
/* 375 */           this.pixelStack[top++] = (byte)first;
/*     */           continue;
/*     */         } 
/* 378 */         this.pixelStack[top++] = (byte)first;
/* 379 */         this.prefix[available] = (short)old_code;
/* 380 */         this.suffix[available] = (byte)first;
/* 381 */         available++;
/* 382 */         if ((available & code_mask) == 0 && available < 4096) {
/*     */           
/* 384 */           code_size++;
/* 385 */           code_mask += available;
/*     */         } 
/* 387 */         old_code = in_code;
/*     */       } 
/*     */ 
/*     */       
/* 391 */       top--;
/* 392 */       this.pixels[pi++] = this.pixelStack[top];
/* 393 */       i++;
/*     */     } 
/*     */     
/* 396 */     for (i = pi; i < npix; i++) {
/* 397 */       this.pixels[i] = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean err() {
/* 404 */     return (this.status != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void init() {
/* 409 */     this.status = 0;
/* 410 */     this.frameCount = 0;
/* 411 */     this.frames = new ArrayList();
/* 412 */     this.gct = null;
/* 413 */     this.lct = null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int read() {
/* 418 */     int curByte = 0;
/*     */     try {
/* 420 */       curByte = this.in.read();
/* 421 */     } catch (IOException e) {
/* 422 */       this.status = 1;
/*     */     } 
/* 424 */     return curByte;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int readBlock() {
/* 429 */     this.blockSize = read();
/* 430 */     int n = 0;
/* 431 */     if (this.blockSize > 0) {
/*     */       try {
/* 433 */         int count = 0;
/* 434 */         while (n < this.blockSize) {
/* 435 */           count = this.in.read(this.block, n, this.blockSize - n);
/* 436 */           if (count == -1)
/*     */             break; 
/* 438 */           n += count;
/*     */         } 
/* 440 */       } catch (IOException iOException) {}
/*     */ 
/*     */       
/* 443 */       if (n < this.blockSize) {
/* 444 */         this.status = 1;
/*     */       }
/*     */     } 
/* 447 */     return n;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int[] readColorTable(int ncolors) {
/* 452 */     int nbytes = 3 * ncolors;
/* 453 */     int[] tab = null;
/* 454 */     byte[] c = new byte[nbytes];
/* 455 */     int n = 0;
/*     */     try {
/* 457 */       n = this.in.read(c);
/* 458 */     } catch (IOException iOException) {}
/*     */     
/* 460 */     if (n < nbytes) {
/* 461 */       this.status = 1;
/*     */     } else {
/* 463 */       tab = new int[256];
/* 464 */       int i = 0;
/* 465 */       int j = 0;
/* 466 */       while (i < ncolors) {
/* 467 */         int r = c[j++] & 0xFF;
/* 468 */         int g = c[j++] & 0xFF;
/* 469 */         int b = c[j++] & 0xFF;
/* 470 */         tab[i++] = 0xFF000000 | r << 16 | g << 8 | b;
/*     */       } 
/*     */     } 
/* 473 */     return tab;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void readContents() {
/* 479 */     boolean done = false;
/* 480 */     while (!done && !err()) {
/* 481 */       String app; int i, code = read();
/* 482 */       switch (code) {
/*     */         
/*     */         case 44:
/* 485 */           readImage();
/*     */           continue;
/*     */         
/*     */         case 33:
/* 489 */           code = read();
/* 490 */           switch (code) {
/*     */             case 249:
/* 492 */               readGraphicControlExt();
/*     */               continue;
/*     */             
/*     */             case 255:
/* 496 */               readBlock();
/* 497 */               app = "";
/* 498 */               for (i = 0; i < 11; i++) {
/* 499 */                 app = app + app;
/*     */               }
/* 501 */               if (app.equals("NETSCAPE2.0")) {
/* 502 */                 readNetscapeExt(); continue;
/*     */               } 
/* 504 */               skip();
/*     */               continue;
/*     */           } 
/*     */           
/* 508 */           skip();
/*     */           continue;
/*     */ 
/*     */         
/*     */         case 59:
/* 513 */           done = true;
/*     */           continue;
/*     */         
/*     */         case 0:
/*     */           continue;
/*     */       } 
/*     */       
/* 520 */       this.status = 1;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void readGraphicControlExt() {
/* 527 */     read();
/* 528 */     int packed = read();
/* 529 */     this.dispose = (packed & 0x1C) >> 2;
/* 530 */     if (this.dispose == 0) {
/* 531 */       this.dispose = 1;
/*     */     }
/* 533 */     this.transparency = ((packed & 0x1) != 0);
/* 534 */     this.delay = readShort() * 10;
/* 535 */     this.transIndex = read();
/* 536 */     read();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void readHeader() {
/* 541 */     StringBuilder id = new StringBuilder();
/* 542 */     for (int i = 0; i < 6; i++) {
/* 543 */       id.append((char)read());
/*     */     }
/* 545 */     if (!id.toString().startsWith("GIF")) {
/* 546 */       this.status = 1;
/*     */       
/*     */       return;
/*     */     } 
/* 550 */     readLSD();
/* 551 */     if (this.gctFlag && !err()) {
/* 552 */       this.gct = readColorTable(this.gctSize);
/* 553 */       this.bgColor = this.gct[this.bgIndex];
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void readImage() {
/* 559 */     this.ix = readShort();
/* 560 */     this.iy = readShort();
/* 561 */     this.iw = readShort();
/* 562 */     this.ih = readShort();
/*     */     
/* 564 */     int packed = read();
/* 565 */     this.lctFlag = ((packed & 0x80) != 0);
/* 566 */     this.interlace = ((packed & 0x40) != 0);
/*     */ 
/*     */     
/* 569 */     this.lctSize = 2 << (packed & 0x7);
/*     */     
/* 571 */     if (this.lctFlag) {
/* 572 */       this.lct = readColorTable(this.lctSize);
/* 573 */       this.act = this.lct;
/*     */     } else {
/* 575 */       this.act = this.gct;
/* 576 */       if (this.bgIndex == this.transIndex)
/* 577 */         this.bgColor = 0; 
/*     */     } 
/* 579 */     int save = 0;
/* 580 */     if (this.transparency) {
/* 581 */       save = this.act[this.transIndex];
/* 582 */       this.act[this.transIndex] = 0;
/*     */     } 
/*     */     
/* 585 */     if (this.act == null) {
/* 586 */       this.status = 1;
/*     */     }
/*     */     
/* 589 */     if (err())
/*     */       return; 
/* 591 */     decodeImageData();
/* 592 */     skip();
/*     */     
/* 594 */     if (err())
/*     */       return; 
/* 596 */     this.frameCount++;
/*     */ 
/*     */     
/* 599 */     this.image = new BufferedImage(this.width, this.height, 3);
/*     */ 
/*     */     
/* 602 */     setPixels();
/*     */     
/* 604 */     this.frames.add(new GifFrame(this.image, this.delay));
/*     */     
/* 606 */     if (this.transparency) {
/* 607 */       this.act[this.transIndex] = save;
/*     */     }
/* 609 */     resetFrame();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void readLSD() {
/* 617 */     this.width = readShort();
/* 618 */     this.height = readShort();
/*     */ 
/*     */     
/* 621 */     int packed = read();
/* 622 */     this.gctFlag = ((packed & 0x80) != 0);
/*     */ 
/*     */     
/* 625 */     this.gctSize = 2 << (packed & 0x7);
/*     */     
/* 627 */     this.bgIndex = read();
/* 628 */     this.pixelAspect = read();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void readNetscapeExt() {
/*     */     do {
/* 634 */       readBlock();
/* 635 */       if (this.block[0] != 1)
/*     */         continue; 
/* 637 */       int b1 = this.block[1] & 0xFF;
/* 638 */       int b2 = this.block[2] & 0xFF;
/* 639 */       this.loopCount = b2 << 8 | b1;
/*     */     }
/* 641 */     while (this.blockSize > 0 && !err());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int readShort() {
/* 647 */     return read() | read() << 8;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void resetFrame() {
/* 652 */     this.lastDispose = this.dispose;
/* 653 */     this.lastRect = new Rectangle(this.ix, this.iy, this.iw, this.ih);
/* 654 */     this.lastImage = this.image;
/* 655 */     this.lastBgColor = this.bgColor;
/* 656 */     int dispose = 0;
/* 657 */     boolean transparency = false;
/* 658 */     int delay = 0;
/* 659 */     this.lct = null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void skip() {
/*     */     do {
/* 665 */       readBlock();
/* 666 */     } while (this.blockSize > 0 && !err());
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\render\gif\GifDecoder.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */