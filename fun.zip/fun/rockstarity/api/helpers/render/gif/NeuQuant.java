/*     */ package fun.rockstarity.api.helpers.render.gif;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NeuQuant
/*     */ {
/*     */   protected static final int netsize = 256;
/*     */   protected static final int prime1 = 499;
/*     */   protected static final int prime2 = 491;
/*     */   protected static final int prime3 = 487;
/*     */   protected static final int prime4 = 503;
/*     */   protected static final int minpicturebytes = 1509;
/*     */   protected static final int maxnetpos = 255;
/*     */   protected static final int netbiasshift = 4;
/*     */   protected static final int ncycles = 100;
/*     */   protected static final int intbiasshift = 16;
/*     */   protected static final int intbias = 65536;
/*     */   protected static final int gammashift = 10;
/*     */   protected static final int gamma = 1024;
/*     */   protected static final int betashift = 10;
/*     */   protected static final int beta = 64;
/*     */   protected static final int betagamma = 65536;
/*     */   protected static final int initrad = 32;
/*     */   protected static final int radiusbiasshift = 6;
/*     */   protected static final int radiusbias = 64;
/*     */   protected static final int initradius = 2048;
/*     */   protected static final int radiusdec = 30;
/*     */   protected static final int alphabiasshift = 10;
/*     */   protected static final int initalpha = 1024;
/*     */   protected int alphadec;
/*     */   protected static final int radbiasshift = 8;
/*     */   protected static final int radbias = 256;
/*     */   protected static final int alpharadbshift = 18;
/*     */   protected static final int alpharadbias = 262144;
/*     */   protected byte[] thepicture;
/*     */   protected int lengthcount;
/*     */   protected int samplefac;
/*     */   protected int[][] network;
/*  51 */   protected int[] netindex = new int[256];
/*     */ 
/*     */   
/*  54 */   protected int[] bias = new int[256];
/*     */   
/*  56 */   protected int[] freq = new int[256];
/*  57 */   protected int[] radpower = new int[32];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NeuQuant(byte[] thepic, int len, int sample) {
/*  64 */     this.thepicture = thepic;
/*  65 */     this.lengthcount = len;
/*  66 */     this.samplefac = sample;
/*     */     
/*  68 */     this.network = new int[256][];
/*  69 */     for (int i = 0; i < 256; i++) {
/*  70 */       this.network[i] = new int[4];
/*  71 */       int[] p = this.network[i];
/*  72 */       p[2] = (i << 12) / 256; p[1] = (i << 12) / 256; p[0] = (i << 12) / 256;
/*  73 */       this.freq[i] = 256;
/*  74 */       this.bias[i] = 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   public byte[] colorMap() {
/*  79 */     byte[] map = new byte[768];
/*  80 */     int[] index = new int[256];
/*  81 */     for (int i = 0; i < 256; i++)
/*  82 */       index[this.network[i][3]] = i; 
/*  83 */     int k = 0;
/*  84 */     for (int j = 0; j < 256; j++) {
/*  85 */       int m = index[j];
/*  86 */       map[k++] = (byte)this.network[m][0];
/*  87 */       map[k++] = (byte)this.network[m][1];
/*  88 */       map[k++] = (byte)this.network[m][2];
/*     */     } 
/*  90 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void inxbuild() {
/* 100 */     int previouscol = 0;
/* 101 */     int startpos = 0;
/* 102 */     for (int i = 0; i < 256; i++) {
/* 103 */       int[] p = this.network[i];
/* 104 */       int smallpos = i;
/* 105 */       int smallval = p[1];
/*     */       int k;
/* 107 */       for (k = i + 1; k < 256; k++) {
/* 108 */         int[] arrayOfInt = this.network[k];
/* 109 */         if (arrayOfInt[1] < smallval) {
/* 110 */           smallpos = k;
/* 111 */           smallval = arrayOfInt[1];
/*     */         } 
/*     */       } 
/* 114 */       int[] q = this.network[smallpos];
/*     */       
/* 116 */       if (i != smallpos) {
/* 117 */         k = q[0];
/* 118 */         q[0] = p[0];
/* 119 */         p[0] = k;
/* 120 */         k = q[1];
/* 121 */         q[1] = p[1];
/* 122 */         p[1] = k;
/* 123 */         k = q[2];
/* 124 */         q[2] = p[2];
/* 125 */         p[2] = k;
/* 126 */         k = q[3];
/* 127 */         q[3] = p[3];
/* 128 */         p[3] = k;
/*     */       } 
/*     */       
/* 131 */       if (smallval != previouscol) {
/* 132 */         this.netindex[previouscol] = startpos + i >> 1;
/* 133 */         for (k = previouscol + 1; k < smallval; k++)
/* 134 */           this.netindex[k] = i; 
/* 135 */         previouscol = smallval;
/* 136 */         startpos = i;
/*     */       } 
/*     */     } 
/* 139 */     this.netindex[previouscol] = startpos + 255 >> 1;
/* 140 */     for (int j = previouscol + 1; j < 256; j++) {
/* 141 */       this.netindex[j] = 255;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void learn() {
/*     */     int step;
/* 151 */     if (this.lengthcount < 1509)
/* 152 */       this.samplefac = 1; 
/* 153 */     this.alphadec = 30 + (this.samplefac - 1) / 3;
/* 154 */     byte[] p = this.thepicture;
/* 155 */     int pix = 0;
/* 156 */     int lim = this.lengthcount;
/* 157 */     int samplepixels = this.lengthcount / 3 * this.samplefac;
/* 158 */     int delta = samplepixels / 100;
/* 159 */     int alpha = 1024;
/* 160 */     int radius = 2048;
/*     */     
/* 162 */     int rad = radius >> 6; int i;
/* 163 */     for (i = 0; i < rad; i++) {
/* 164 */       this.radpower[i] = alpha * (rad * rad - i * i) * 256 / rad * rad;
/*     */     }
/*     */     
/* 167 */     if (this.lengthcount < 1509) {
/* 168 */       step = 3;
/* 169 */     } else if (this.lengthcount % 499 != 0) {
/* 170 */       step = 1497;
/*     */     }
/* 172 */     else if (this.lengthcount % 491 != 0) {
/* 173 */       step = 1473;
/*     */     }
/* 175 */     else if (this.lengthcount % 487 != 0) {
/* 176 */       step = 1461;
/*     */     } else {
/* 178 */       step = 1509;
/*     */     } 
/*     */ 
/*     */     
/* 182 */     i = 0;
/* 183 */     while (i < samplepixels) {
/* 184 */       int b = (p[pix] & 0xFF) << 4;
/* 185 */       int g = (p[pix + 1] & 0xFF) << 4;
/* 186 */       int r = (p[pix + 2] & 0xFF) << 4;
/* 187 */       int j = contest(b, g, r);
/*     */       
/* 189 */       altersingle(alpha, j, b, g, r);
/* 190 */       if (rad != 0) {
/* 191 */         alterneigh(rad, j, b, g, r);
/*     */       }
/* 193 */       pix += step;
/* 194 */       if (pix >= lim) {
/* 195 */         pix -= this.lengthcount;
/*     */       }
/* 197 */       i++;
/* 198 */       if (delta == 0)
/* 199 */         delta = 1; 
/* 200 */       if (i % delta == 0) {
/* 201 */         alpha -= alpha / this.alphadec;
/* 202 */         radius -= radius / 30;
/* 203 */         rad = radius >> 6;
/* 204 */         if (rad <= 1)
/* 205 */           rad = 0; 
/* 206 */         for (j = 0; j < rad; j++) {
/* 207 */           this.radpower[j] = alpha * (rad * rad - j * j) * 256 / rad * rad;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int map(int b, int g, int r) {
/* 219 */     int bestd = 1000;
/* 220 */     int best = -1;
/* 221 */     int i = this.netindex[g];
/* 222 */     int j = i - 1;
/*     */     
/* 224 */     while (i < 256 || j >= 0) {
/* 225 */       if (i < 256) {
/* 226 */         int[] p = this.network[i];
/* 227 */         int dist = p[1] - g;
/* 228 */         if (dist >= bestd) {
/* 229 */           i = 256;
/*     */         } else {
/* 231 */           i++;
/* 232 */           if (dist < 0)
/* 233 */             dist = -dist; 
/* 234 */           int a = p[0] - b;
/* 235 */           if (a < 0)
/* 236 */             a = -a; 
/* 237 */           dist += a;
/* 238 */           if (dist < bestd) {
/* 239 */             a = p[2] - r;
/* 240 */             if (a < 0)
/* 241 */               a = -a; 
/* 242 */             dist += a;
/* 243 */             if (dist < bestd) {
/* 244 */               bestd = dist;
/* 245 */               best = p[3];
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 250 */       if (j >= 0) {
/* 251 */         int[] p = this.network[j];
/* 252 */         int dist = g - p[1];
/* 253 */         if (dist >= bestd) {
/* 254 */           j = -1; continue;
/*     */         } 
/* 256 */         j--;
/* 257 */         if (dist < 0)
/* 258 */           dist = -dist; 
/* 259 */         int a = p[0] - b;
/* 260 */         if (a < 0)
/* 261 */           a = -a; 
/* 262 */         dist += a;
/* 263 */         if (dist < bestd) {
/* 264 */           a = p[2] - r;
/* 265 */           if (a < 0)
/* 266 */             a = -a; 
/* 267 */           dist += a;
/* 268 */           if (dist < bestd) {
/* 269 */             bestd = dist;
/* 270 */             best = p[3];
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 276 */     return best;
/*     */   }
/*     */   
/*     */   public byte[] process() {
/* 280 */     learn();
/* 281 */     unbiasnet();
/* 282 */     inxbuild();
/* 283 */     return colorMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unbiasnet() {
/* 290 */     for (int i = 0; i < 256; i++) {
/* 291 */       this.network[i][0] = this.network[i][0] >> 4;
/* 292 */       this.network[i][1] = this.network[i][1] >> 4;
/* 293 */       this.network[i][2] = this.network[i][2] >> 4;
/* 294 */       this.network[i][3] = i;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void alterneigh(int rad, int i, int b, int g, int r) {
/* 303 */     int lo = i - rad;
/* 304 */     if (lo < -1)
/* 305 */       lo = -1; 
/* 306 */     int hi = i + rad;
/* 307 */     if (hi > 256) {
/* 308 */       hi = 256;
/*     */     }
/* 310 */     int j = i + 1;
/* 311 */     int k = i - 1;
/* 312 */     int m = 1;
/* 313 */     while (j < hi || k > lo) {
/* 314 */       int a = this.radpower[m++];
/* 315 */       if (j < hi) {
/* 316 */         int[] p = this.network[j++];
/*     */         try {
/* 318 */           p[0] = p[0] - a * (p[0] - b) / 262144;
/* 319 */           p[1] = p[1] - a * (p[1] - g) / 262144;
/* 320 */           p[2] = p[2] - a * (p[2] - r) / 262144;
/* 321 */         } catch (Exception exception) {}
/*     */       } 
/*     */       
/* 324 */       if (k > lo) {
/* 325 */         int[] p = this.network[k--];
/*     */         try {
/* 327 */           p[0] = p[0] - a * (p[0] - b) / 262144;
/* 328 */           p[1] = p[1] - a * (p[1] - g) / 262144;
/* 329 */           p[2] = p[2] - a * (p[2] - r) / 262144;
/* 330 */         } catch (Exception exception) {}
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void altersingle(int alpha, int i, int b, int g, int r) {
/* 340 */     int[] n = this.network[i];
/* 341 */     n[0] = n[0] - alpha * (n[0] - b) / 1024;
/* 342 */     n[1] = n[1] - alpha * (n[1] - g) / 1024;
/* 343 */     n[2] = n[2] - alpha * (n[2] - r) / 1024;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int contest(int b, int g, int r) {
/* 352 */     int bestd = Integer.MAX_VALUE;
/* 353 */     int bestbiasd = bestd;
/* 354 */     int bestpos = -1;
/* 355 */     int bestbiaspos = bestpos;
/*     */     
/* 357 */     for (int i = 0; i < 256; i++) {
/* 358 */       int[] n = this.network[i];
/* 359 */       int dist = n[0] - b;
/* 360 */       if (dist < 0)
/* 361 */         dist = -dist; 
/* 362 */       int a = n[1] - g;
/* 363 */       if (a < 0)
/* 364 */         a = -a; 
/* 365 */       dist += a;
/* 366 */       a = n[2] - r;
/* 367 */       if (a < 0)
/* 368 */         a = -a; 
/* 369 */       dist += a;
/* 370 */       if (dist < bestd) {
/* 371 */         bestd = dist;
/* 372 */         bestpos = i;
/*     */       } 
/* 374 */       int biasdist = dist - (this.bias[i] >> 12);
/* 375 */       if (biasdist < bestbiasd) {
/* 376 */         bestbiasd = biasdist;
/* 377 */         bestbiaspos = i;
/*     */       } 
/* 379 */       int betafreq = this.freq[i] >> 10;
/* 380 */       this.freq[i] = this.freq[i] - betafreq;
/* 381 */       this.bias[i] = this.bias[i] + (betafreq << 10);
/*     */     } 
/* 383 */     this.freq[bestpos] = this.freq[bestpos] + 64;
/* 384 */     this.bias[bestpos] = this.bias[bestpos] - 65536;
/* 385 */     return bestbiaspos;
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\render\gif\NeuQuant.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */