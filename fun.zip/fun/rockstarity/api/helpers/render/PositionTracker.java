/*    */ package fun.rockstarity.api.helpers.render;
/*    */ 
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import java.nio.FloatBuffer;
/*    */ import java.nio.IntBuffer;
/*    */ import net.minecraft.client.renderer.GLAllocation;
/*    */ import net.minecraft.client.renderer.WorldRenderer;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraft.util.math.vector.Vector3d;
/*    */ 
/*    */ 
/*    */ public final class PositionTracker
/*    */   implements IAccess
/*    */ {
/*    */   private PositionTracker() {
/* 17 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 24 */   private static final IntBuffer viewport = GLAllocation.createDirectIntBuffer(16);
/* 25 */   private static final FloatBuffer modelview = GLAllocation.createDirectFloatBuffer(16);
/* 26 */   private static final FloatBuffer projection = GLAllocation.createDirectFloatBuffer(16);
/* 27 */   private static final FloatBuffer vector = GLAllocation.createDirectFloatBuffer(4);
/*    */ 
/*    */   
/*    */   public static boolean isInView(Entity ent) {
/* 31 */     if (mc.getRenderViewEntity() == null || (mc.getRenderManager()).info == null) return false; 
/* 32 */     WorldRenderer.frustum.setCameraPosition(((mc.getRenderManager()).info.getProjectedView()).x, ((mc.getRenderManager()).info.getProjectedView()).y, ((mc.getRenderManager()).info.getProjectedView()).z);
/* 33 */     return (WorldRenderer.frustum.isBoundingBoxInFrustum(ent.getBoundingBox()) || ent.ignoreFrustumCheck);
/*    */   }
/*    */   
/*    */   public static boolean isInView(Vector3d vec) {
/* 37 */     assert mc.getRenderViewEntity() != null;
/* 38 */     WorldRenderer.frustum.setCameraPosition(((mc.getRenderManager()).info.getProjectedView()).x, ((mc.getRenderManager()).info.getProjectedView()).y, ((mc.getRenderManager()).info.getProjectedView()).z);
/* 39 */     return WorldRenderer.frustum.isBoundingBoxInFrustum(new AxisAlignedBB(vec.add(-0.5D, -0.5D, -0.5D), vec.add(0.5D, 0.5D, 0.5D)));
/*    */   }
/*    */   
/*    */   public static boolean isInView(double x, double y, double z) {
/* 43 */     return isInView(new Vector3d(x, y, z));
/*    */   }
/*    */   
/*    */   public static boolean isInView(AxisAlignedBB box) {
/* 47 */     if (mc.getRenderViewEntity() == null) {
/* 48 */       return false;
/*    */     }
/* 50 */     return WorldRenderer.frustum.isBoundingBoxInFrustum(box);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\render\PositionTracker.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */