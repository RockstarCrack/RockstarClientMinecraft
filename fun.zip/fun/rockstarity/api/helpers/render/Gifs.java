/*    */ package fun.rockstarity.api.helpers.render;
/*    */ 
/*    */ import fun.rockstarity.api.helpers.render.gif.GifRender;
/*    */ 
/*    */ 
/*    */ public final class Gifs
/*    */ {
/*    */   public static GifRender idontknow;
/*    */   public static GifRender sleep;
/*    */   
/*    */   private Gifs() {
/* 12 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*    */   }
/*    */   
/*    */   public static GifRender loading;
/*    */   public static GifRender clean;
/*    */   public static GifRender avatar;
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\render\Gifs.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */