/*    */ package fun.rockstarity.api.helpers.render;
/*    */ 
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import net.minecraft.client.MainWindow;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.shader.Framebuffer;
/*    */ import org.lwjgl.opengl.EXTFramebufferObject;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Stencil
/*    */   implements IAccess
/*    */ {
/*    */   public static void checkSetupFBO(Framebuffer framebuffer) {
/* 28 */     if (framebuffer != null && 
/* 29 */       framebuffer.depthBuffer > -1) {
/* 30 */       setupFBO(framebuffer);
/* 31 */       framebuffer.depthBuffer = -1;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static void setupFBO(Framebuffer framebuffer) {
/* 37 */     MainWindow sr = Minecraft.getInstance().getMainWindow();
/* 38 */     EXTFramebufferObject.glDeleteRenderbuffersEXT(framebuffer.depthBuffer);
/* 39 */     int stencilDepthBufferID = EXTFramebufferObject.glGenRenderbuffersEXT();
/* 40 */     EXTFramebufferObject.glBindRenderbufferEXT(36161, stencilDepthBufferID);
/* 41 */     EXTFramebufferObject.glRenderbufferStorageEXT(36161, 34041, sr.getWidth(), sr.getHeight());
/* 42 */     EXTFramebufferObject.glFramebufferRenderbufferEXT(36160, 36128, 36161, stencilDepthBufferID);
/* 43 */     EXTFramebufferObject.glFramebufferRenderbufferEXT(36160, 36096, 36161, stencilDepthBufferID);
/*    */   }
/*    */   
/*    */   public static void init() {
/* 47 */     mc.getFramebuffer().bindFramebuffer(false);
/* 48 */     checkSetupFBO(mc.getFramebuffer());
/* 49 */     GL11.glClear(1024);
/* 50 */     GL11.glEnable(2960);
/*    */     
/* 52 */     GL11.glStencilFunc(519, 1, 1);
/* 53 */     GL11.glStencilOp(7681, 7681, 7681);
/* 54 */     GL11.glColorMask(false, false, false, false);
/*    */   }
/*    */   
/*    */   public static void read(int ref) {
/* 58 */     GL11.glColorMask(true, true, true, true);
/* 59 */     GL11.glStencilFunc(514, ref, 1);
/* 60 */     GL11.glStencilOp(7680, 7680, 7680);
/*    */   }
/*    */   
/*    */   public static void finish() {
/* 64 */     GL11.glDisable(2960);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\render\Stencil.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */