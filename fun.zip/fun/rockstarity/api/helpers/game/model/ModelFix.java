/*     */ package fun.rockstarity.api.helpers.game.model;
/*     */ 
/*     */ import com.google.gson.annotations.Expose;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import net.minecraft.client.renderer.model.BlockPart;
/*     */ import net.minecraft.client.renderer.model.ItemModelGenerator;
/*     */ import net.minecraft.client.renderer.texture.AtlasTexture;
/*     */ import net.minecraft.util.Direction;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.math.vector.Vector3f;
/*     */ 
/*     */ public final class ModelFix {
/*     */   private ModelFix() {
/*  15 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*     */   }
/*  17 */   private static final ResourceLocation BLOCK_ATLAS = new ResourceLocation("textures/atlas/blocks.png");
/*     */   
/*     */   @Expose
/*     */   public static final double quad_indent = 1.0E-4D;
/*     */   
/*     */   @Expose
/*     */   public static final double quad_expansion = 0.002D;
/*     */   
/*     */   public static double getRecess() {
/*  26 */     return 1.0E-4D;
/*     */   }
/*     */   
/*     */   public static double getExpansion() {
/*  30 */     return 0.002D;
/*     */   }
/*     */   
/*     */   public static float getShrinkRatio(AtlasTexture atlas, float defaultValue, float returnValue) {
/*  34 */     if (atlas.getTextureLocation().equals(BLOCK_ATLAS) && defaultValue == returnValue) {
/*  35 */       return 0.0F;
/*     */     }
/*     */     
/*  38 */     return -1.0F;
/*     */   }
/*     */   
/*     */   public static void enlargeFaces(List<BlockPart> cir) {
/*  42 */     float inc = (float)getRecess();
/*  43 */     float inc2 = (float)getExpansion();
/*     */     
/*  45 */     for (BlockPart e : cir) {
/*  46 */       Vector3f from = e.positionFrom;
/*  47 */       Vector3f to = e.positionTo;
/*  48 */       Set<Direction> set = e.mapFaces.keySet();
/*     */       
/*  50 */       if (set.size() == 1) {
/*  51 */         Direction dir = set.stream().findAny().get();
/*     */         
/*  53 */         switch (dir) {
/*     */           case UP:
/*  55 */             from.set(from.x - inc2, from.y - inc, from.z - inc2);
/*  56 */             to.set(to.x + inc2, to.y - inc, to.z + inc2);
/*     */ 
/*     */           
/*     */           case DOWN:
/*  60 */             from.set(from.x - inc2, from.y + inc, from.z - inc2);
/*  61 */             to.set(to.x + inc2, to.y + inc, to.z + inc2);
/*     */ 
/*     */           
/*     */           case WEST:
/*  65 */             from.set(from.x - inc, from.y + inc2, from.z - inc2);
/*  66 */             to.set(to.x - inc, to.y - inc2, to.z + inc2);
/*     */ 
/*     */           
/*     */           case EAST:
/*  70 */             from.set(from.x + inc, from.y + inc2, from.z - inc2);
/*  71 */             to.set(to.x + inc, to.y - inc2, to.z + inc2);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void createOrExpandSpan(List<ItemModelGenerator.Span> listSpans, ItemModelGenerator.SpanFacing spanFacing, int pixelX, int pixelY) {
/*  84 */     ItemModelGenerator.Span existingSpan = null;
/*     */     
/*  86 */     for (ItemModelGenerator.Span span2 : listSpans) {
/*  87 */       if (span2.getFacing() == spanFacing) {
/*  88 */         int i = spanFacing.isHorizontal() ? pixelY : pixelX;
/*  89 */         if (span2.getAnchor() != i || (
/*  90 */           getExpansion() != 0.0D && span2.getMax() != (!spanFacing.isHorizontal() ? pixelY : pixelX) - 1)) {
/*     */           continue;
/*     */         }
/*  93 */         existingSpan = span2;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*  98 */     int length = spanFacing.isHorizontal() ? pixelX : pixelY;
/*     */     
/* 100 */     if (existingSpan == null) {
/* 101 */       int newStart = spanFacing.isHorizontal() ? pixelY : pixelX;
/* 102 */       listSpans.add(new ItemModelGenerator.Span(spanFacing, length, newStart));
/*     */     } else {
/* 104 */       existingSpan.expand(length);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\game\model\ModelFix.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */