/*    */ package fun.rockstarity.api.helpers.game;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import net.minecraft.client.util.InputMappings;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Binds
/*    */ {
/* 14 */   public static HashMap<String, Integer> KEYS = new HashMap<>();
/*    */   
/*    */   public static void add(String nameIn, int keyCode) {
/* 17 */     KEYS.put(nameIn.replace("key.keyboard.", "").replace("key.", "").replace(".", "").replace("left", (keyCode == 263 || keyCode == 262) ? "left" : "l").replace("right", (keyCode == 263 || keyCode == 262) ? "right" : "r").replace("printscreen", "prtsc").replace("graveaccent", "grave"), Integer.valueOf(keyCode));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String getName(int key, int scan) {
/* 30 */     String str = InputMappings.getInputByCode(key, scan).toString().replace("SCANCODE", "").replace("key.keyboard.", "").replace("key.", "").replace(".", "").replace("left", "l").replace("right", "r").replace("printscreen", "prtsc").replace("graveaccent", "grave").replace("control", "ctrl").toUpperCase();
/*    */     
/* 32 */     if (key == -1) {
/* 33 */       switch (scan) { case 0:
/* 34 */           str = "ЛКМ"; break;
/* 35 */         case 1: str = "ПКМ"; break;
/* 36 */         case 2: str = "Колесико"; break;
/* 37 */         case 3: str = "MOUSE4"; break;
/* 38 */         case 4: str = "MOUSE5"; break;
/* 39 */         case 5: str = "MOUSE6"; break;
/* 40 */         default: str = "MOUSE" + scan;
/*    */           break; }
/*    */     
/*    */     }
/* 44 */     if (key < 0 && scan < 0) {
/* 45 */       str = "NONE";
/*    */     }
/*    */     
/* 48 */     return str;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\game\Binds.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */