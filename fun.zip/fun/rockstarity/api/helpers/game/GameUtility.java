/*    */ package fun.rockstarity.api.helpers.game;
/*    */ 
/*    */ import com.mojang.authlib.Agent;
/*    */ import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
/*    */ import com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication;
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.connection.globals.ServerAPI;
/*    */ import fun.rockstarity.api.via.ViaFixer;
/*    */ import java.net.Proxy;
/*    */ import net.minecraft.util.Session;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GameUtility
/*    */   implements IAccess
/*    */ {
/*    */   private GameUtility() {
/* 22 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*    */   }
/*    */   public static void changeName(String name) {
/* 25 */     name = name.replace("\\", "");
/*    */     
/* 27 */     YggdrasilAuthenticationService service = new YggdrasilAuthenticationService(Proxy.NO_PROXY, "");
/* 28 */     YggdrasilUserAuthentication auth = (YggdrasilUserAuthentication)service.createUserAuthentication(Agent.MINECRAFT);
/* 29 */     auth.logOut();
/*    */     
/* 31 */     mc.setSession(new Session(name, name, "0", "legacy"));
/* 32 */     ServerAPI.updateName();
/*    */     
/* 34 */     ViaFixer.reconnected = false;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\game\GameUtility.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */