/*     */ package fun.rockstarity.api.helpers.game;
/*     */ 
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.events.Event;
/*     */ import fun.rockstarity.api.events.list.game.packet.EventReceivePacket;
/*     */ import fun.rockstarity.api.events.list.player.EventMotion;
/*     */ import fun.rockstarity.api.helpers.math.TimerUtility;
/*     */ import fun.rockstarity.api.render.animation.infinity.InfinityAnimation;
/*     */ import fun.rockstarity.client.modules.combat.Aura;
/*     */ import fun.rockstarity.client.modules.combat.ElytraTarget;
/*     */ import net.minecraft.entity.LivingEntity;
/*     */ import net.minecraft.network.IPacket;
/*     */ import net.minecraft.network.play.server.SPlayerPositionLookPacket;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BoostUtility
/*     */   implements IAccess
/*     */ {
/*     */   private BoostUtility() {
/*  26 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*     */   }
/*  28 */   public static final TimerUtility clean = new TimerUtility();
/*     */   public static double lastSpeed;
/*  30 */   public static final InfinityAnimation speed = new InfinityAnimation();
/*     */   public static boolean up;
/*     */   public static int flagFactor;
/*     */   private static float prevYaw;
/*     */   private static int direction;
/*     */   
/*     */   public static double getBoost(int ticks) {
/*  37 */     boolean passive = true;
/*  38 */     float realBoostable = passive ? 1.5F : 1.67F;
/*  39 */     float countableSpeed = realBoostable;
/*  40 */     ElytraTarget elytratarget = (ElytraTarget)rock.getModules().get(ElytraTarget.class);
/*  41 */     Aura aura = (Aura)rock.getModules().get(Aura.class);
/*  42 */     LivingEntity target = aura.getTarget();
/*     */     
/*  44 */     if (elytratarget.getDefensive().get() && target != null && target.getResolvedPos() != null && !elytratarget.isLeaving(target)) {
/*  45 */       if (EventMotion.LAST_PITCH > 0.0F) {
/*  46 */         countableSpeed = 1.5F;
/*     */       } else {
/*  48 */         countableSpeed = 1.5F;
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/*  53 */       int[] vectors = { -45, 45, 135, -135 };
/*  54 */       int[] addVectors = { -90, 90, 180, -180, 0 };
/*  55 */       int[] pitchVectors = { -45, 45 };
/*     */       
/*  57 */       float lastYaw = EventMotion.LAST_YAW;
/*  58 */       float lastPitch = EventMotion.LAST_PITCH;
/*     */       
/*  60 */       int minDist = findClosestVector(lastYaw, vectors);
/*  61 */       float maxDist = Math.abs(MathHelper.wrapDegrees(lastYaw) - vectors[minDist]);
/*     */       
/*  63 */       int addMinDist = findClosestVector(lastYaw, addVectors);
/*  64 */       float addMaxDist = Math.abs(MathHelper.wrapDegrees(lastYaw) - addVectors[addMinDist]);
/*     */       
/*  66 */       countableSpeed = (minDist == -1) ? 1.5F : (2.06F - maxDist * 0.56F / 45.0F);
/*     */       
/*  68 */       if (addMaxDist < 10.0F) {
/*  69 */         countableSpeed += 0.1F - 0.1F * addMaxDist / 10.0F;
/*     */       }
/*     */       
/*  72 */       int pitchMinDist = findClosestVector(lastPitch, pitchVectors);
/*  73 */       float pitchMaxDist = Math.abs(Math.abs(lastPitch) - Math.abs(pitchVectors[pitchMinDist]));
/*     */       
/*  75 */       if (pitchMaxDist < 26.0F) {
/*  76 */         countableSpeed = Math.max(1.94F, countableSpeed);
/*     */         
/*  78 */         countableSpeed += 0.05F - pitchMaxDist * 0.05F / 26.0F;
/*     */       } 
/*     */       
/*  81 */       countableSpeed = Math.min(2.045F, countableSpeed);
/*     */       
/*  83 */       prevYaw = EventMotion.LAST_YAW;
/*     */ 
/*     */       
/*  86 */       if (EventMotion.LAST_PITCH > -55.0F && EventMotion.LAST_PITCH < -19.0F) {
/*  87 */         countableSpeed = 1.91F;
/*  88 */       } else if (EventMotion.LAST_PITCH < -55.0F) {
/*  89 */         countableSpeed = 1.54F;
/*     */       } 
/*     */       
/*  92 */       if (EventMotion.LAST_PITCH > 19.0F && EventMotion.LAST_PITCH < 55.0F) {
/*  93 */         countableSpeed = 1.8F;
/*  94 */       } else if (EventMotion.LAST_PITCH > 55.0F) {
/*  95 */         countableSpeed = 1.54F;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 101 */     return countableSpeed;
/*     */   }
/*     */   
/*     */   private static int findClosestVector(float lastYaw, int[] vectors) {
/* 105 */     int index = 0;
/* 106 */     int minDistIndex = -1;
/* 107 */     float minDist = Float.MAX_VALUE;
/*     */     
/* 109 */     for (int vector : vectors) {
/* 110 */       float dist = Math.abs(MathHelper.wrapDegrees(lastYaw) - vector);
/* 111 */       if (dist < minDist) {
/* 112 */         minDist = dist;
/* 113 */         minDistIndex = index;
/*     */       } 
/* 115 */       index++;
/*     */     } 
/*     */     
/* 118 */     return minDistIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float adjustValue(float value) {
/* 187 */     return value;
/*     */   }
/*     */   
/*     */   public static void onEvent(Event event) {
/* 191 */     if (event instanceof EventReceivePacket) { EventReceivePacket e = (EventReceivePacket)event;
/* 192 */       IPacket iPacket = e.getPacket(); if (iPacket instanceof SPlayerPositionLookPacket) { SPlayerPositionLookPacket packet = (SPlayerPositionLookPacket)iPacket;
/* 193 */         flagFactor++;
/* 194 */         speed.animate(1.5F, 1); }
/*     */        }
/*     */ 
/*     */     
/* 198 */     if (event instanceof fun.rockstarity.api.events.list.player.EventUpdate);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\game\BoostUtility.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */