/*    */ package fun.rockstarity.api.helpers.game;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.events.list.game.packet.EventReceivePacket;
/*    */ import java.util.Arrays;
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TPSHandler
/*    */ {
/* 17 */   private static float[] tickRates = new float[20];
/* 18 */   private int nextIndex = 0;
/*    */   private long timeLastTimeUpdate;
/*    */   
/*    */   public TPSHandler() {
/* 22 */     this.nextIndex = 0;
/* 23 */     this.timeLastTimeUpdate = -1L;
/* 24 */     Arrays.fill(tickRates, 0.0F);
/*    */   }
/*    */   
/*    */   public float getTPS() {
/* 28 */     float numTicks = 0.0F, sumTickRates = 0.0F;
/* 29 */     for (float tickRate : tickRates) {
/* 30 */       if (tickRate > 0.0F) {
/* 31 */         sumTickRates += tickRate;
/* 32 */         numTicks++;
/*    */       } 
/*    */     } 
/* 35 */     return MathHelper.clamp(sumTickRates / numTicks, 0.0F, 20.0F);
/*    */   }
/*    */   
/*    */   private void onTimeUpdate() {
/* 39 */     if (this.timeLastTimeUpdate != -1L) {
/* 40 */       float timeElapsed = (float)(System.nanoTime() - this.timeLastTimeUpdate) / 1.0E9F;
/* 41 */       tickRates[this.nextIndex % tickRates.length] = MathHelper.clamp(20.0F / timeElapsed, 0.0F, 20.0F);
/* 42 */       this.nextIndex++;
/*    */     } 
/* 44 */     this.timeLastTimeUpdate = System.nanoTime();
/*    */   }
/*    */   
/*    */   public void onEvent(Event e) {
/* 48 */     if (e instanceof EventReceivePacket) {
/* 49 */       EventReceivePacket event = (EventReceivePacket)e;
/* 50 */       if (event.getPacket() instanceof net.minecraft.network.play.server.SUpdateTimePacket)
/* 51 */         onTimeUpdate(); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\game\TPSHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */