/*     */ package fun.rockstarity.api.helpers.game;
/*     */ 
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.render.ui.alerts.AlertType;
/*     */ import fun.rockstarity.client.commands.WayCommand;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import net.minecraft.util.math.vector.Vector3d;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.StringTextComponent;
/*     */ import net.minecraft.util.text.TranslationTextComponent;
/*     */ import net.minecraft.util.text.event.ClickEvent;
/*     */ import net.minecraft.util.text.event.HoverEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MessageListener
/*     */   implements IAccess
/*     */ {
/*     */   private MessageListener() {
/*  25 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*     */   }
/*  27 */   private static final Pattern COORDINATE_PATTERN = Pattern.compile("(-?\\d+)[\\s,]+(-?\\d+)(?:[\\s,]+(-?\\d+))?");
/*     */   
/*     */   public static ITextComponent handle(ITextComponent comp) {
/*  30 */     if (rock.isPanic()) return comp;
/*     */     
/*  32 */     if (comp instanceof StringTextComponent) { StringTextComponent strComp = (StringTextComponent)comp;
/*  33 */       String message = strComp.getString();
/*  34 */       Matcher matcher = COORDINATE_PATTERN.matcher(message);
/*     */       
/*  36 */       TranslationTextComponent chatComponent = new TranslationTextComponent("");
/*     */       
/*  38 */       int lastEnd = 0;
/*  39 */       if (matcher.find()) {
/*  40 */         String x = matcher.group(1);
/*  41 */         String y = (matcher.group(3) == null) ? "60" : matcher.group(2);
/*  42 */         String z = (matcher.group(3) == null) ? matcher.group(2) : matcher.group(3);
/*     */         
/*  44 */         for (ITextComponent child1 : strComp.getSiblings()) {
/*  45 */           if (child1 instanceof StringTextComponent) { StringTextComponent textComponent = (StringTextComponent)child1;
/*  46 */             if (textComponent.text.contains(matcher.group())) {
/*  47 */               textComponent.setStyle(textComponent.getStyle().setClickEvent(new ClickEvent(ClickEvent.Action.RUNNABLE, () -> handleCoords(comp.getString(), x, y, z))).setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new StringTextComponent("Нажми, чтобы поставить метку"))));
/*     */             } }
/*     */ 
/*     */           
/*  51 */           for (ITextComponent child2 : child1.getSiblings()) {
/*  52 */             if (child2 instanceof StringTextComponent) { StringTextComponent textComponent = (StringTextComponent)child2;
/*  53 */               if (textComponent.text.contains(matcher.group())) {
/*  54 */                 textComponent.setStyle(textComponent.getStyle().setClickEvent(new ClickEvent(ClickEvent.Action.RUNNABLE, () -> handleCoords(comp.getString(), x, y, z))).setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new StringTextComponent("Нажми, чтобы поставить метку"))));
/*     */               } }
/*     */ 
/*     */             
/*  58 */             for (ITextComponent child3 : child1.getSiblings()) {
/*  59 */               if (child3 instanceof StringTextComponent) { StringTextComponent textComponent = (StringTextComponent)child3;
/*  60 */                 if (textComponent.text.contains(matcher.group())) {
/*  61 */                   textComponent.setStyle(textComponent.getStyle().setClickEvent(new ClickEvent(ClickEvent.Action.RUNNABLE, () -> handleCoords(comp.getString(), x, y, z))).setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new StringTextComponent("Нажми, чтобы поставить метку"))));
/*     */                 } }
/*     */             
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/*  68 */         return comp;
/*     */       }  }
/*     */ 
/*     */     
/*  72 */     return comp;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void handleCoords(String text, String strX, String strY, String strZ) {
/*     */     try {
/*  78 */       int x = Integer.parseInt(strX);
/*  79 */       int y = Integer.parseInt(strY);
/*  80 */       int z = Integer.parseInt(strZ);
/*     */       
/*  82 */       String name = "Метка";
/*     */       
/*  84 */       if (text.toLowerCase().contains("мистический алтарь")) {
/*  85 */         name = "Мистический Алтарь";
/*  86 */       } else if (text.toLowerCase().contains("мистический сундук")) {
/*  87 */         name = "Мистический Сундук";
/*  88 */       } else if (text.toLowerCase().contains("маяк убийца")) {
/*  89 */         name = "Маяк Убийца";
/*  90 */       } else if (text.toLowerCase().contains("вулкан")) {
/*  91 */         name = "Вулкан";
/*  92 */       } else if (text.toLowerCase().contains("алтарь")) {
/*  93 */         name = "Алтарь";
/*     */       } 
/*     */       
/*  96 */       if (text.contains(" сек") && text.contains("через: ")) {
/*  97 */         Integer time = Integer.valueOf(Integer.parseInt(text.split("через: ")[1].split(" сек")[0].trim()));
/*  98 */         ((WayCommand)rock.getCommands().get(WayCommand.class)).add(name, new Vector3d(x, y, z), time.intValue());
/*  99 */       } else if (text.contains(" сек") && text.contains("открытия: ")) {
/* 100 */         Integer time = Integer.valueOf(Integer.parseInt(text.split("открытия: ")[1].split(" сек")[0].trim()));
/* 101 */         ((WayCommand)rock.getCommands().get(WayCommand.class)).add(name, new Vector3d(x, y, z), time.intValue());
/* 102 */       } else if (text.contains(" сек") && text.contains("извержения ")) {
/* 103 */         Integer time = Integer.valueOf(Integer.parseInt(text.split("извержения ")[1].split(" сек")[0].trim()));
/* 104 */         ((WayCommand)rock.getCommands().get(WayCommand.class)).add(name, new Vector3d(x, y, z), time.intValue());
/*     */       } else {
/* 106 */         ((WayCommand)rock.getCommands().get(WayCommand.class)).add(name, new Vector3d(x, y, z));
/*     */       } 
/*     */       
/* 109 */       rock.getAlertHandler().alert("Метка добавлена", AlertType.INFO);
/* 110 */     } catch (Exception e) {
/* 111 */       Chat.debug(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\game\MessageListener.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */