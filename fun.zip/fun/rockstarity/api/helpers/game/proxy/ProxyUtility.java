/*    */ package fun.rockstarity.api.helpers.game.proxy;
/*    */ public final class ProxyUtility {
/*    */   private static String proxyIp;
/*    */   private static int proxyPort;
/*    */   private static boolean enabled;
/*    */   
/*  7 */   private ProxyUtility() { throw new UnsupportedOperationException("This is a utility class and cannot be instantiated"); } public static String getProxyIp() {
/*  8 */     return proxyIp;
/*    */   } public static int getProxyPort() {
/* 10 */     return proxyPort;
/*    */   } public static boolean isEnabled() {
/* 12 */     return enabled;
/*    */   }
/*    */   
/*    */   public static void setProxy(String ip, int port) {
/* 16 */     proxyIp = ip;
/* 17 */     proxyPort = port;
/* 18 */     enabled = true;
/*    */   }
/*    */   
/*    */   public static void disableProxy() {
/* 22 */     enabled = false;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\game\proxy\ProxyUtility.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */