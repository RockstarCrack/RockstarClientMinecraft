/*    */ package fun.rockstarity.api.helpers.game.proxy;
/*    */ 
/*    */ import net.minecraft.client.gui.widget.button.Button;
/*    */ 
/*    */ public class ProxyServer {
/*    */   public static boolean proxyEnabled = false;
/*  7 */   public static Proxy proxy = new Proxy();
/*  8 */   public static Proxy lastUsedProxy = new Proxy();
/*    */   public static Button proxyMenuButton;
/*    */   
/*    */   public ProxyServer() {
/* 12 */     onInitialize();
/*    */   }
/*    */   
/*    */   public void onInitialize() {
/* 16 */     AccountsProxy.loadProxyAccounts();
/*    */   }
/*    */   
/*    */   public static String getLastUsedProxyIp() {
/* 20 */     return lastUsedProxy.ipPort.isEmpty() ? "none" : lastUsedProxy.getIp();
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\game\proxy\ProxyServer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */