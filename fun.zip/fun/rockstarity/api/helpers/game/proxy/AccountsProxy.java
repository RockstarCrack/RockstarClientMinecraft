/*    */ package fun.rockstarity.api.helpers.game.proxy;
/*    */ 
/*    */ import com.google.common.reflect.TypeToken;
/*    */ import com.google.gson.Gson;
/*    */ import com.google.gson.GsonBuilder;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Type;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.util.HashMap;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import org.apache.commons.io.FileUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AccountsProxy
/*    */ {
/* 18 */   private static final String ACCOUNTS_PATH = String.valueOf((Minecraft.getInstance()).gameDir) + "/assets/skins/0/proxy/config/ProxyAccounts.json";
/* 19 */   public static HashMap<String, Proxy> accounts = new HashMap<>();
/* 20 */   public static String lastPlayerName = "";
/*    */   
/*    */   public static void loadProxyAccounts() {
/* 23 */     File accountsFile = new File(ACCOUNTS_PATH);
/*    */     
/*    */     try {
/* 26 */       if (!accountsFile.exists()) {
/* 27 */         if (!accountsFile.createNewFile());
/*    */ 
/*    */         
/*    */         return;
/*    */       } 
/*    */       
/* 33 */       String accountsString = FileUtils.readFileToString(accountsFile, "UTF-8");
/*    */ 
/*    */       
/* 36 */       Type type = (new TypeToken<HashMap<String, Proxy>>() {  }).getType();
/* 37 */       accounts = (HashMap<String, Proxy>)(new Gson()).fromJson(accountsString, type);
/* 38 */       if (accounts == null) {
/* 39 */         accounts = new HashMap<>();
/*    */       }
/* 41 */     } catch (Exception e) {
/*    */       
/* 43 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */   
/*    */   public static void setDefaultProxy(Proxy proxy) {
/* 48 */     accounts.put("", proxy);
/*    */   }
/*    */   
/*    */   public static void saveProxyAccounts() {
/*    */     try {
/* 53 */       Gson gson = (new GsonBuilder()).setPrettyPrinting().create();
/* 54 */       FileUtils.write(new File(ACCOUNTS_PATH), gson.toJson(accounts), StandardCharsets.UTF_8);
/* 55 */     } catch (IOException e) {
/*    */       
/* 57 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\game\proxy\AccountsProxy.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */