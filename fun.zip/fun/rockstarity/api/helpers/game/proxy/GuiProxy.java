/*     */ package fun.rockstarity.api.helpers.game.proxy;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.screen.Screen;
/*     */ import net.minecraft.client.gui.widget.TextFieldWidget;
/*     */ import net.minecraft.client.gui.widget.Widget;
/*     */ import net.minecraft.client.gui.widget.button.Button;
/*     */ import net.minecraft.client.gui.widget.button.CheckboxButton;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.StringTextComponent;
/*     */ import net.minecraft.util.text.TextFormatting;
/*     */ 
/*     */ 
/*     */ public class GuiProxy
/*     */   extends Screen
/*     */ {
/*     */   private boolean isSocks4 = false;
/*     */   private TextFieldWidget ipPort;
/*     */   private TextFieldWidget username;
/*     */   private TextFieldWidget password;
/*     */   private CheckboxButton enabledCheck;
/*     */   private Screen parentScreen;
/*  24 */   private String msg = "";
/*     */   
/*     */   private int[] positionY;
/*     */   
/*     */   private int positionX;
/*     */   
/*     */   private Proxy oldProxy;
/*  31 */   private TestPing testPing = new TestPing(); public TestPing getTestPing() { return this.testPing; }
/*     */ 
/*     */   
/*     */   public GuiProxy(Screen parentScreen) {
/*  35 */     super((ITextComponent)new StringTextComponent("Proxy"));
/*  36 */     this.parentScreen = parentScreen;
/*     */   }
/*     */   
/*     */   private boolean setProxy() {
/*  40 */     if (!isValidIpPort(this.ipPort.getText())) {
/*  41 */       this.msg = String.valueOf(TextFormatting.RED) + "Invalid IP:PORT";
/*  42 */       this.ipPort.changeFocus(true);
/*  43 */       return false;
/*     */     } 
/*     */     
/*  46 */     ProxyServer.proxy = new Proxy(this.isSocks4, this.ipPort.getText().trim(), this.username.getText().trim(), this.password.getText().trim());
/*  47 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean isValidIpPort(String ipP) {
/*  51 */     return ipP.matches("(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5]):[0-9]+");
/*     */   }
/*     */   
/*     */   private void centerButtons(int amount, int buttonLength, int gap) {
/*  55 */     this.positionX = this.width / 2 - buttonLength / 2;
/*  56 */     this.positionY = new int[amount];
/*  57 */     int center = (this.height + amount * gap) / 2;
/*  58 */     int buttonStarts = center - amount * gap;
/*  59 */     for (int i = 0; i != amount; i++) {
/*  60 */       this.positionY[i] = buttonStarts + gap * i;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
/*  66 */     super.keyPressed(keyCode, scanCode, modifiers);
/*  67 */     this.msg = "";
/*  68 */     this.testPing.state = "";
/*  69 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/*  74 */     renderBackground(matrixStack);
/*     */     
/*  76 */     if (this.enabledCheck.isChecked() && !isValidIpPort(this.ipPort.getText())) {
/*  77 */       this.enabledCheck.onPress();
/*     */     }
/*     */     
/*  80 */     this.font.drawStringWithShadow(matrixStack, "Proxy Type:", this.width / 2.0F - 149.0F, (this.positionY[1] + 5), 10526880);
/*  81 */     drawCenteredString(matrixStack, this.font, "Proxy Authentication (optional)", this.width / 2, this.positionY[3] + 8, TextFormatting.WHITE.getColor().intValue());
/*  82 */     this.font.drawStringWithShadow(matrixStack, "IP:PORT: ", this.width / 2.0F - 125.0F, (this.positionY[2] + 5), 10526880);
/*     */     
/*  84 */     this.ipPort.render(matrixStack, mouseX, mouseY, partialTicks);
/*  85 */     if (this.isSocks4) {
/*  86 */       this.font.drawStringWithShadow(matrixStack, "User ID: ", this.width / 2.0F - 140.0F, (this.positionY[4] + 5), 10526880);
/*  87 */       this.username.render(matrixStack, mouseX, mouseY, partialTicks);
/*     */     } else {
/*  89 */       this.font.drawStringWithShadow(matrixStack, "Username: ", this.width / 2.0F - 140.0F, (this.positionY[4] + 5), 10526880);
/*  90 */       this.font.drawStringWithShadow(matrixStack, "Password: ", this.width / 2.0F - 140.0F, (this.positionY[5] + 5), 10526880);
/*  91 */       this.username.render(matrixStack, mouseX, mouseY, partialTicks);
/*  92 */       this.password.render(matrixStack, mouseX, mouseY, partialTicks);
/*     */     } 
/*     */     
/*  95 */     drawCenteredString(matrixStack, this.font, !this.msg.isEmpty() ? this.msg : this.testPing.state, this.width / 2, this.positionY[6] + 5, 10526880);
/*     */     
/*  97 */     super.render(matrixStack, mouseX, mouseY, partialTicks);
/*     */   }
/*     */ 
/*     */   
/*     */   public void tick() {
/* 102 */     this.testPing.pingPendingNetworks();
/*     */     
/* 104 */     this.ipPort.tick();
/* 105 */     this.username.tick();
/* 106 */     this.password.tick();
/*     */   }
/*     */ 
/*     */   
/*     */   public void init() {
/* 111 */     mc.keyboardListener.enableRepeatEvents(true);
/* 112 */     int buttonLength = 160;
/* 113 */     centerButtons(10, buttonLength, 26);
/*     */     
/* 115 */     this.isSocks4 = (ProxyServer.proxy.type == Proxy.ProxyType.SOCKS4);
/* 116 */     this.oldProxy = ProxyServer.proxy;
/*     */     
/* 118 */     Button proxyType = new Button(this.positionX, this.positionY[1], buttonLength, 20, (ITextComponent)new StringTextComponent(this.isSocks4 ? "Socks 4" : "Socks 5"), button -> {
/*     */           this.isSocks4 = !this.isSocks4;
/*     */           button.setMessage((ITextComponent)new StringTextComponent(this.isSocks4 ? "Socks 4" : "Socks 5"));
/*     */         });
/* 122 */     addButton((Widget)proxyType);
/*     */     
/* 124 */     this.ipPort = new TextFieldWidget(this.font, this.positionX, this.positionY[2], buttonLength, 20, (ITextComponent)new StringTextComponent(""));
/* 125 */     this.ipPort.setText(ProxyServer.proxy.ipPort);
/* 126 */     this.ipPort.setMaxStringLength(21);
/* 127 */     this.ipPort.changeFocus(true);
/* 128 */     this.children.add(this.ipPort);
/*     */     
/* 130 */     this.username = new TextFieldWidget(this.font, this.positionX, this.positionY[4], buttonLength, 20, (ITextComponent)new StringTextComponent(""));
/* 131 */     this.username.setMaxStringLength(255);
/* 132 */     this.username.setText(ProxyServer.proxy.username);
/* 133 */     this.children.add(this.username);
/*     */     
/* 135 */     this.password = new TextFieldWidget(this.font, this.positionX, this.positionY[5], buttonLength, 20, (ITextComponent)new StringTextComponent(""));
/* 136 */     this.password.setMaxStringLength(255);
/* 137 */     this.password.setText(ProxyServer.proxy.password);
/* 138 */     this.children.add(this.password);
/*     */ 
/*     */     
/* 141 */     int posXButtons = this.width / 2 - buttonLength / 2 * 3 / 3;
/*     */     
/* 143 */     Button apply = new Button(posXButtons, this.positionY[8], buttonLength / 2 - 3, 20, (ITextComponent)new StringTextComponent("Apply"), button -> {
/*     */           if (setProxy()) {
/*     */             AccountsProxy.setDefaultProxy(ProxyServer.proxy);
/*     */             AccountsProxy.saveProxyAccounts();
/*     */             ProxyServer.proxyEnabled = this.enabledCheck.isChecked();
/*     */             Minecraft.getInstance().displayGuiScreen(this.parentScreen);
/*     */           } 
/*     */         });
/* 151 */     addButton((Widget)apply);
/*     */     
/* 153 */     Button test = new Button(posXButtons + buttonLength / 2 + 3, this.positionY[8], buttonLength / 2 - 3, 20, (ITextComponent)new StringTextComponent("Test"), button -> {
/*     */           if (this.ipPort.getText().isEmpty() || this.ipPort.getText().equalsIgnoreCase("none")) {
/*     */             this.msg = String.valueOf(TextFormatting.RED) + "Specify proxy to test";
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/*     */           if (setProxy()) {
/*     */             this.testPing = new TestPing();
/*     */             this.testPing.run("mc.funtime.su", 25565, ProxyServer.proxy);
/*     */           } 
/*     */         });
/* 165 */     this.enabledCheck = new CheckboxButton(this.width / 2 - (15 + this.font.getStringWidth("Proxy Enabled")) / 2, this.positionY[7], buttonLength, 20, (ITextComponent)new StringTextComponent("Proxy Enabled"), ProxyServer.proxyEnabled);
/* 166 */     addButton((Widget)this.enabledCheck);
/*     */ 
/*     */     
/* 169 */     Button cancel = new Button(posXButtons + buttonLength / 2 + 3, this.positionY[8], buttonLength / 2 - 3, 20, (ITextComponent)new StringTextComponent("Cancel"), button -> {
/*     */           ProxyServer.proxy = this.oldProxy;
/*     */           Minecraft.getInstance().displayGuiScreen(this.parentScreen);
/*     */         });
/* 173 */     addButton((Widget)cancel);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\game\proxy\GuiProxy.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */