/*    */ package fun.rockstarity.api.helpers.game.toolTip;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.util.text.ITextComponent;
/*    */ import net.minecraft.util.text.StringTextComponent;
/*    */ import net.minecraft.util.text.Style;
/*    */ 
/*    */ public final class FixToolTip {
/*    */   public static int x;
/*    */   public static int width;
/*    */   
/*    */   private FixToolTip() {
/* 16 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*    */   }
/*    */   
/*    */   private static int mouseX;
/*    */   
/*    */   public static void set(int x, int width) {
/* 22 */     FixToolTip.x = Math.max(0, x);
/* 23 */     FixToolTip.width = width - 20;
/* 24 */     mouseX = FixToolTip.x - 24;
/* 25 */     flipped = false;
/*    */   }
/*    */   static boolean flipped;
/*    */   public static List<ITextComponent> doFix(List<ITextComponent> text, FontRenderer textRenderer) {
/* 29 */     List<ITextComponent> originalText = text;
/* 30 */     text = new ArrayList<>(text);
/*    */     
/* 32 */     if (text.size() == 0 || (text.size() == 1 && ((ITextComponent)text.get(0)).getString().length() <= 12)) {
/* 33 */       return text;
/*    */     }
/*    */     
/* 36 */     for (int i = 0; i < text.size(); i++) {
/* 37 */       if (isTooWide(textRenderer, ((ITextComponent)text.get(i)).getString())) {
/* 38 */         Style style = ((ITextComponent)text.get(i)).getStyle();
/* 39 */         List<String> words = new ArrayList<>(Arrays.asList(((ITextComponent)text.get(i)).getString().split(" ")));
/* 40 */         if (words.isEmpty()) return text;
/*    */         
/* 42 */         String newLine = words.remove(0);
/* 43 */         if (isTooWide(textRenderer, newLine)) {
/* 44 */           if (!flipped && x > width / 2) {
/* 45 */             flipped = true;
/* 46 */             return doFix(originalText, textRenderer);
/*    */           } 
/* 48 */           String oldLine = newLine;
/* 49 */           while (isTooWide(textRenderer, newLine + "-")) {
/* 50 */             newLine = newLine.substring(0, newLine.length() - 1);
/*    */           }
/* 52 */           words.add(0, "-" + oldLine.substring(newLine.length()));
/* 53 */           newLine = newLine + "-";
/*    */         } else {
/*    */           
/* 56 */           while (words.size() > 0 && 
/* 57 */             !isTooWide(textRenderer, newLine + " " + newLine)) {
/* 58 */             newLine = newLine + " " + newLine;
/*    */           }
/*    */         } 
/*    */ 
/*    */ 
/*    */         
/* 64 */         text.set(i, (new StringTextComponent(newLine)).setStyle(style));
/* 65 */         if (words.size() > 0) {
/* 66 */           text.add(i + 1, (new StringTextComponent(String.join(" ", (Iterable)words))).setStyle(style));
/*    */         }
/*    */       } 
/*    */     } 
/* 70 */     return text;
/*    */   }
/*    */   
/*    */   private static boolean isTooWide(FontRenderer textRenderer, String line) {
/* 74 */     if (flipped) {
/* 75 */       if (mouseX - textRenderer.getStringWidth(line) > 0) {
/* 76 */         attemptUpdateMaxWidth(line, textRenderer);
/* 77 */         return false;
/*    */       } 
/* 79 */       return true;
/*    */     } 
/* 81 */     return (x + textRenderer.getStringWidth(line) > width);
/*    */   }
/*    */   
/*    */   private static void attemptUpdateMaxWidth(String newLine, FontRenderer textRenderer) {
/* 85 */     int lineWidth = textRenderer.getStringWidth(newLine);
/* 86 */     if (lineWidth > mouseX - x)
/* 87 */       x = mouseX - lineWidth; 
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\game\toolTip\FixToolTip.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */