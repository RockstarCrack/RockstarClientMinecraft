/*     */ package fun.rockstarity.api.helpers.game;
/*     */ 
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.stream.Collectors;
/*     */ import net.minecraft.client.util.ITooltipFlag;
/*     */ import net.minecraft.inventory.ItemStackHelper;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.Items;
/*     */ import net.minecraft.nbt.CompoundNBT;
/*     */ import net.minecraft.nbt.ListNBT;
/*     */ import net.minecraft.util.NonNullList;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ItemUtility
/*     */   implements IAccess
/*     */ {
/*     */   private ItemUtility() {
/*  28 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*  29 */   } private static final Pattern funTimePricePattern = Pattern.compile("\\$(\\d+(?:\\s\\d{3})*(?:\\.\\d{2})?)");
/*     */ 
/*     */   
/*  32 */   public static ListNBT[] UNSHIP = new ListNBT[4];
/*  33 */   public static ListNBT[] SHIP = new ListNBT[4];
/*     */   
/*     */   public static int getPrice(ItemStack stack) {
/*     */     try {
/*  37 */       List<ITextComponent> itemTooltip = stack.getTooltip(null, (ITooltipFlag)ITooltipFlag.TooltipFlags.NORMAL);
/*  38 */       String sell = Server.is("spooky") ? "Цена" : (Server.isHW() ? "Цена" : "Ценa");
/*  39 */       for (ITextComponent str : itemTooltip) {
/*     */         
/*  41 */         if (str.getString().contains(sell)) {
/*  42 */           if (Server.isFT())
/*  43 */             return Integer.parseInt(str.getString().replace("$ Ценa $", "").replace(" ", "").replace(",", "")); 
/*  44 */           if (Server.isHW())
/*  45 */             return Integer.parseInt(str.getString().replace("▍", "").replace("¤", "").replace("Цена", "").replace(" ", "").replace(",", "").replace(":", "").replace("шага", "")); 
/*  46 */           if (Server.isFS()) {
/*  47 */             return Integer.parseInt(str.getString().replace("$", "").replace("Цена", "").replace(":", "").replace("$ Цена $", "").replace(" ", "").replace(",", ""));
/*     */           }
/*  49 */           return Integer.parseInt(str.getString().replace("Цена", "").replace("$", "").replace(": ", "").replace(" ", "").replace(",", "").trim());
/*     */         }
/*     */       
/*     */       } 
/*  53 */     } catch (NumberFormatException number) {
/*  54 */       Chat.debug(number);
/*  55 */       return -1;
/*     */     } 
/*  57 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean contains(ItemStack stack, String str1) {
/*     */     try {
/*  63 */       List<ITextComponent> itemTooltip = stack.getTooltip(null, (ITooltipFlag)ITooltipFlag.TooltipFlags.NORMAL);
/*  64 */       for (ITextComponent str : itemTooltip) {
/*  65 */         if (str.getString().contains(str1)) {
/*  66 */           return true;
/*     */         }
/*     */       } 
/*  69 */     } catch (NumberFormatException number) {
/*  70 */       return false;
/*     */     } 
/*  72 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getSeller(ItemStack stack) {
/*     */     try {
/*  78 */       List<ITextComponent> itemTooltip = stack.getTooltip(null, (ITooltipFlag)ITooltipFlag.TooltipFlags.NORMAL);
/*     */       
/*  80 */       for (ITextComponent str : itemTooltip) {
/*  81 */         String name = str.getString();
/*     */         
/*  83 */         if (name.contains("⚕ Прoдaвeц: ")) {
/*  84 */           String seller = name.replace("⚕ Прoдaвeц: ", "");
/*  85 */           if (!seller.equals(mc.player.getName().getString())) {
/*  86 */             return seller;
/*     */           }
/*     */         } 
/*     */       } 
/*  90 */     } catch (NumberFormatException number) {
/*  91 */       Chat.debug(number);
/*  92 */       return "";
/*     */     } 
/*  94 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<ItemStack> getItemsInShulker(ItemStack s) {
/*  99 */     CompoundNBT compoundnbt = s.getChildTag("BlockEntityTag");
/*     */     
/* 101 */     if (compoundnbt != null && 
/* 102 */       compoundnbt.contains("Items", 9)) {
/* 103 */       NonNullList<ItemStack> nonnulllist = NonNullList.withSize(27, ItemStack.EMPTY);
/* 104 */       ItemStackHelper.loadAllItems(compoundnbt, nonnulllist);
/* 105 */       return (List<ItemStack>)nonnulllist.stream()
/* 106 */         .filter(item -> (item.getItem() != Items.AIR))
/*     */         
/* 108 */         .collect(Collectors.toList());
/*     */     } 
/*     */ 
/*     */     
/* 112 */     return new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isRare(ItemStack stack) {
/* 118 */     return (stack.getDisplayName().getString().contains("★") || stack
/* 119 */       .getDisplayName().getString().toLowerCase().contains("крушителя") || stack
/* 120 */       .getItem() == Items.ENCHANTED_GOLDEN_APPLE || stack
/* 121 */       .getItem() == Items.SHULKER_BOX || stack
/* 122 */       .getItem() == Items.NETHERITE_INGOT);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\game\ItemUtility.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */