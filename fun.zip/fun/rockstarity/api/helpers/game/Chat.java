/*    */ package fun.rockstarity.api.helpers.game;
/*    */ 
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import net.minecraft.client.resources.I18n;
/*    */ import net.minecraft.util.text.ITextComponent;
/*    */ import net.minecraft.util.text.StringTextComponent;
/*    */ import net.minecraft.util.text.Style;
/*    */ import net.minecraft.util.text.TextFormatting;
/*    */ import net.minecraft.util.text.event.ClickEvent;
/*    */ import net.minecraft.util.text.event.HoverEvent;
/*    */ 
/*    */ public final class Chat implements IAccess {
/*    */   private Chat() {
/* 14 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*    */   }
/*    */   public static void msg(Object msg) {
/* 17 */     msg(msg, true);
/*    */   }
/*    */   
/*    */   public static void msg(Object msg, boolean prefix) {
/* 21 */     String str = String.valueOf(msg);
/*    */     try {
/* 23 */       if (str.contains("PHP_EOL")) {
/* 24 */         String[] msgs = str.split("PHP_EOL");
/* 25 */         int i = 0;
/* 26 */         for (String message : msgs) {
/* 27 */           mc.player.addChatMessage(((i == 0 || prefix) ? (String.valueOf(TextFormatting.AQUA) + "[Rockstar] ") : "") + ((i == 0 || prefix) ? (String.valueOf(TextFormatting.AQUA) + "[Rockstar] ") : "") + String.valueOf(TextFormatting.RESET));
/*    */         }
/*    */         return;
/*    */       } 
/* 31 */       mc.player.addChatMessage(String.valueOf(TextFormatting.AQUA) + "[Rockstar] " + String.valueOf(TextFormatting.AQUA) + String.valueOf(TextFormatting.RESET));
/* 32 */     } catch (Exception exception) {}
/*    */   }
/*    */   
/*    */   public static void msg(Object msg, String hover, Runnable action) {
/* 36 */     StringTextComponent stringtextcomponent = new StringTextComponent(I18n.format(msg.toString(), new Object[0]));
/* 37 */     stringtextcomponent.setStyle(Style.EMPTY.setClickEvent(new ClickEvent(ClickEvent.Action.RUNNABLE, action)).setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new StringTextComponent(hover))));
/* 38 */     mc.ingameGUI.getChatGUI().printChatMessage((ITextComponent)stringtextcomponent);
/*    */   }
/*    */   
/*    */   public static void msg(String prefix, Object msg) {
/* 42 */     mc.player.addChatMessage(String.format("%s[%s]%s %s", new Object[] { TextFormatting.AQUA, prefix, TextFormatting.RESET, msg }));
/*    */   }
/*    */   
/*    */   public static void debug(Object msg) {
/* 46 */     if (!rock.isDebugging())
/*    */       return; 
/* 48 */     String str = String.valueOf(msg);
/*    */     try {
/* 50 */       if (str.contains("PHP_EOL")) {
/* 51 */         String[] msgs = str.split("PHP_EOL");
/* 52 */         int i = 0;
/* 53 */         for (String message : msgs) {
/* 54 */           mc.player.addChatMessage(message);
/*    */         }
/*    */         return;
/*    */       } 
/* 58 */       mc.player.addChatMessage(String.valueOf(TextFormatting.AQUA) + "[Debug] " + String.valueOf(TextFormatting.AQUA) + String.valueOf(TextFormatting.RESET));
/* 59 */     } catch (Exception exception) {}
/*    */   }
/*    */   
/*    */   public static void bot(String bot, Object msg) {
/* 63 */     if (!rock.isDebugging())
/*    */       return; 
/* 65 */     String str = String.valueOf(msg);
/*    */     
/*    */     try {
/* 68 */       mc.player.addChatMessage(String.valueOf(TextFormatting.AQUA) + "[" + String.valueOf(TextFormatting.AQUA) + "] " + bot + String.valueOf(TextFormatting.RESET));
/*    */     }
/* 70 */     catch (Exception exception) {}
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\game\Chat.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */