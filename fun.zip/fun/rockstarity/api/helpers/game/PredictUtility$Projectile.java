/*    */ package fun.rockstarity.api.helpers.game;
/*    */ 
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ import net.minecraft.util.math.vector.Vector3d;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Projectile
/*    */ {
/*    */   private Projectile() {
/* 70 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*    */   }
/*    */   private static Vector3d simulateShoot(double x, double y, double z, float velocity, float inaccuracy) {
/* 73 */     float rand = 0.5F;
/* 74 */     Vector3d vector3d = (new Vector3d(x, y, z)).normalize().add(0.0037499999161809683D * inaccuracy, 0.0037499999161809683D * inaccuracy, 0.0037499999161809683D * inaccuracy).scale(velocity);
/* 75 */     return vector3d;
/*    */   }
/*    */ 
/*    */   
/*    */   private static Vector3d simulateThrow(Entity thrower, float pitch, float yaw, float p_234612_4_, float velocity, float inaccuracy) {
/* 80 */     float f = -MathHelper.sin(yaw * 0.017453292F) * MathHelper.cos(pitch * 0.017453292F);
/* 81 */     float f1 = -MathHelper.sin((pitch + p_234612_4_) * 0.017453292F);
/* 82 */     float f2 = MathHelper.cos(yaw * 0.017453292F) * MathHelper.cos(pitch * 0.017453292F);
/* 83 */     Vector3d shootMotion = simulateShoot(f, f1, f2, velocity, inaccuracy);
/* 84 */     Vector3d vector3d = thrower.getMotion();
/* 85 */     return shootMotion.add(vector3d.x, thrower.isOnGround() ? 0.0D : vector3d.y, vector3d.z);
/*    */   }
/*    */ 
/*    */   
/*    */   public static Vector3d predictThrowMotion(LivingEntity thrower, Item item) {
/* 90 */     if (item instanceof net.minecraft.item.TridentItem)
/* 91 */       return simulateThrow((Entity)thrower, thrower.rotationPitch, thrower.rotationYaw, 0.0F, 2.5F, 1.0F); 
/* 92 */     if (item instanceof net.minecraft.item.SplashPotionItem || item instanceof net.minecraft.item.LingeringPotionItem) {
/* 93 */       return simulateThrow((Entity)thrower, thrower.rotationPitch, thrower.rotationYaw, 0.0F, 0.5F, 1.0F);
/*    */     }
/* 95 */     return simulateThrow((Entity)thrower, thrower.rotationPitch, thrower.rotationYaw, 0.0F, 1.5F, 1.0F);
/*    */   }
/*    */   
/*    */   public static Vector3d predictThrowPos(LivingEntity thrower) {
/* 99 */     return new Vector3d(thrower.getPosX(), thrower.getPosYEye() - 0.10000000149011612D, thrower.getPosZ());
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\game\PredictUtility$Projectile.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */