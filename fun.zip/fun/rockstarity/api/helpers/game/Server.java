/*     */ package fun.rockstarity.api.helpers.game;
/*     */ 
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.helpers.player.Player;
/*     */ import fun.rockstarity.api.render.ui.alerts.AlertType;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Objects;
/*     */ import net.minecraft.client.gui.overlay.BossOverlayGui;
/*     */ import net.minecraft.client.gui.overlay.PlayerTabOverlayGui;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Server
/*     */   implements IAccess
/*     */ {
/*     */   private Server() {
/*  20 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*  21 */   } public static int FT_ANARCHY = -1; public static int RW_GRIEF = -1;
/*     */   
/*  23 */   private static String lastIP = "mc.funtime.su";
/*     */   
/*     */   public static String getIP() {
/*  26 */     if (!Player.isInGame()) return "mainmenu"; 
/*  27 */     if (mc.isSingleplayer()) return "local"; 
/*  28 */     if (mc.getCurrentServerData() != null) return lastIP = (mc.getCurrentServerData()).serverIP.toLowerCase();
/*     */     
/*  30 */     return lastIP;
/*     */   }
/*     */   
/*     */   public static boolean isSunWay() {
/*  34 */     String ip = getIP();
/*  35 */     return ip.contains("sunw");
/*     */   }
/*     */   
/*     */   public static boolean isSaturn() {
/*  39 */     String ip = getIP();
/*  40 */     return ip.contains("saturn");
/*     */   }
/*     */   
/*     */   public static boolean isSR() {
/*  44 */     String ip = getIP();
/*  45 */     return ip.contains("sunmc");
/*     */   }
/*     */   
/*     */   public static boolean isFS() {
/*  49 */     String ip = getIP();
/*  50 */     return ip.contains("funsky");
/*     */   }
/*     */   
/*     */   public static boolean isBravo() {
/*  54 */     String ip = getIP();
/*  55 */     return ip.contains("bravohvh");
/*     */   }
/*     */   
/*     */   public static boolean isRW() {
/*  59 */     String ip = getIP();
/*  60 */     return (ip.contains("reallyworld") || ip.contains("playrw"));
/*     */   }
/*     */   
/*     */   public static boolean isServerForHPFix() {
/*  64 */     String ip = getIP();
/*  65 */     return (isFT() || isFS() || isRW() || isSaturn() || ip.contains("legend") || ip.contains("wildgrief") || ip.contains("lighttime"));
/*     */   }
/*     */   
/*     */   public static String getServerName(boolean shortName) {
/*  69 */     String ip = getIP();
/*  70 */     String[] parts = ip.split("\\.");
/*     */     
/*  72 */     if (mc.isSingleplayer()) {
/*  73 */       return applyCase(ip, shortName);
/*     */     }
/*  75 */     if (parts.length == 3) {
/*  76 */       return applyCase(parts[1], shortName);
/*     */     }
/*  78 */     if (parts.length == 2) {
/*  79 */       return applyCase(parts[0], shortName);
/*     */     }
/*  81 */     if (ip.contains(":")) {
/*  82 */       return ip.split(":")[0];
/*     */     }
/*  84 */     return ip;
/*     */   }
/*     */   
/*     */   private static String applyCase(String server, boolean shortName) {
/*  88 */     server = server.replace("-", "");
/*     */     
/*  90 */     ArrayList<Data> datas = new ArrayList<>();
/*  91 */     String[] suffixes = { "legacy", "bars", "world", "best", "times", "time", "shine", "sky", "lands", "land", "trainer", "server", "blaze", "mine", "lord", "cube", "grief", "craft", "rise", "force", "project" };
/*     */     
/*  93 */     Arrays.<String>stream(suffixes).forEach(suffix -> datas.add(genData(suffix)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  99 */     Objects.requireNonNull(datas); Arrays.<Data>stream(new Data[] { new Data("mc", "MC", "-MC"), new Data("hvh", "HVH", "-HVH"), new Data("pvp", "PVP", "PVP") }).forEach(datas::add);
/*     */     
/* 101 */     if (mc.isSingleplayer() && !shortName) {
/* 102 */       server = "LocalHost";
/*     */     }
/* 104 */     if (isSR()) {
/* 105 */       server = shortName ? "SR" : "SunRise";
/*     */     }
/* 107 */     if (isSaturn()) {
/* 108 */       server = shortName ? "S-X" : "SaturnX";
/*     */     }
/* 110 */     if (isSunWay()) {
/* 111 */       server = shortName ? "SW" : "SunWay";
/*     */     }
/* 113 */     for (Data data : datas) {
/* 114 */       if (server.contains(data.orig)) {
/* 115 */         if (shortName) {
/* 116 */           String rightPart = server.replace(data.orig, "");
/* 117 */           server = server.substring(0, 1).toUpperCase() + server.substring(0, 1).toUpperCase();
/*     */         } else {
/* 119 */           server = server.replace(data.orig, data.big);
/* 120 */           server = server.substring(0, 1).toUpperCase() + server.substring(0, 1).toUpperCase();
/*     */         } 
/*     */         
/* 123 */         return server;
/*     */       } 
/*     */     } 
/*     */     
/* 127 */     server = server.substring(0, 1).toUpperCase() + server.substring(0, 1).toUpperCase();
/*     */     
/* 129 */     return server;
/*     */   }
/*     */   
/*     */   public static boolean isFT() {
/* 133 */     String ip = getIP();
/* 134 */     return (ip.contains("funtime") || ip.contains("ft") || ip.contains("FunTime"));
/*     */   }
/*     */   
/*     */   public static boolean isHW() {
/* 138 */     String ip = getIP();
/* 139 */     return (ip.contains("holyworld") || ip.contains("hollyworld"));
/*     */   }
/*     */   
/*     */   public static boolean is(String str) {
/* 143 */     return getIP().contains(str);
/*     */   }
/*     */   
/*     */   public static boolean hasCT() {
/* 147 */     return BossOverlayGui.CT;
/*     */   }
/*     */   
/*     */   public static int getTimeCT() {
/* 151 */     return BossOverlayGui.timeCT;
/*     */   }
/*     */   
/*     */   public static int ping() {
/* 155 */     return (PlayerTabOverlayGui.getPlayerPings() == null || !PlayerTabOverlayGui.getPlayerPings().containsKey(mc.player.getName().getString())) ? 0 : ((Integer)PlayerTabOverlayGui.getPlayerPings().get(mc.player.getName().getString())).intValue();
/*     */   }
/*     */   
/*     */   public static void warningFT() {
/* 159 */     if (!isFT()) {
/* 160 */       rock.getAlertHandler().alert("Этот модуль подходит под FunTime!", AlertType.INFO);
/*     */     }
/*     */   }
/*     */   
/*     */   private static Data genData(String full) {
/* 165 */     return new Data(full, full.substring(0, 1).toUpperCase() + full.substring(0, 1).toUpperCase(), full.substring(0, 1).toUpperCase());
/*     */   }
/*     */   static class Data { public Data(String orig, String big, String small) {
/* 168 */       this.orig = orig; this.big = big; this.small = small;
/*     */     }
/*     */     
/*     */     private String orig;
/*     */     private String big;
/*     */     private String small; }
/*     */ 
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\helpers\game\Server.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */