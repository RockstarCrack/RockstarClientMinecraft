/*    */ package fun.rockstarity.api.modules;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModuleInfo
/*    */ {
/*    */   private final String name;
/*    */   private final String desc;
/*    */   private final Category type;
/*    */   private final String[] module;
/*    */   
/*    */   public ModuleInfo(String name, String desc, Category type, String[] module) {
/* 17 */     this.name = name; this.desc = desc; this.type = type; this.module = module;
/*    */   }
/*    */   public String name() {
/* 20 */     return this.name;
/*    */   } public String desc() {
/* 22 */     return this.desc;
/*    */   } public Category type() {
/* 24 */     return this.type;
/*    */   } public String[] module() {
/* 26 */     return this.module;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\modules\ModuleInfo.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */