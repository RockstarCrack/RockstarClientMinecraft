package fun.rockstarity.api.modules;

import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Inherited
@Retention(RetentionPolicy.RUNTIME)
public @interface Info {
  String name();
  
  String desc();
  
  Category type();
  
  String[] module() default {""};
}


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\modules\Info.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */