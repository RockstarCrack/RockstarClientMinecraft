/*     */ package fun.rockstarity.api.modules.settings;
/*     */ 
/*     */ import fun.rockstarity.api.binds.Bindable;
/*     */ import fun.rockstarity.api.modules.Module;
/*     */ import fun.rockstarity.api.modules.settings.list.Mode;
/*     */ import fun.rockstarity.api.modules.settings.list.Select;
/*     */ import fun.rockstarity.api.render.animation.Animation;
/*     */ import fun.rockstarity.api.render.animation.Easing;
/*     */ import fun.rockstarity.api.render.ui.clickgui.esp.ESPElement;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import fun.rockstarity.client.modules.render.Interface;
/*     */ import java.util.ArrayList;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Setting
/*     */   extends Bindable
/*     */ {
/*  26 */   private final ArrayList<Setting> settings = new ArrayList<>(); public ArrayList<Setting> getSettings() { return this.settings; }
/*  27 */   protected Supplier<Boolean> hide = () -> Boolean.valueOf(false); protected final Bindable parent; public Supplier<Boolean> getHide() { return this.hide; } private final String name; protected String desc; public Bindable getParent() {
/*  28 */     return this.parent; }
/*  29 */   public String getName() { return this.name; } public String getDesc() {
/*  30 */     return this.desc;
/*     */   }
/*  32 */   private Rect settingRect = Rect.EMPTY; public void setSettingRect(Rect settingRect) { this.settingRect = settingRect; } public Rect getSettingRect() {
/*  33 */     return this.settingRect;
/*  34 */   } private Animation settingsAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public Animation getSettingsAnim() { return this.settingsAnim; }
/*     */   
/*  36 */   private float height = 28.0F, bindHeight = 28.0F; public float getHeight() { return this.height; } public float getBindHeight() { return this.bindHeight; }
/*     */   
/*     */   public Setting(Bindable parent, String name) {
/*  39 */     this.parent = parent;
/*  40 */     this.name = name;
/*     */     
/*  42 */     if (parent instanceof Module) { Module mod = (Module)parent;
/*  43 */       mod.getSettings().add(this);
/*     */       
/*     */       return; }
/*     */     
/*  47 */     if (parent instanceof Interface.UIElement) { Interface.UIElement ui = (Interface.UIElement)parent;
/*  48 */       ui.getSettings().add(this);
/*     */       
/*     */       return; }
/*     */     
/*  52 */     if (parent instanceof ESPElement) { ESPElement ui = (ESPElement)parent;
/*  53 */       ui.getSettings().add(this);
/*     */       
/*     */       return; }
/*     */     
/*  57 */     if (parent instanceof Setting) { Setting ui = (Setting)parent;
/*  58 */       ui.getSettings().add(this);
/*     */       
/*     */       return; }
/*     */     
/*  62 */     if (parent instanceof Select.Element) { Select.Element ui = (Select.Element)parent;
/*  63 */       ui.getSettings().add(this);
/*     */       
/*     */       return; }
/*     */     
/*  67 */     if (parent instanceof Mode.Element) { Mode.Element ui = (Mode.Element)parent;
/*  68 */       ui.getSettings().add(this);
/*     */       return; }
/*     */   
/*     */   }
/*     */   
/*     */   public boolean canSettings() {
/*  74 */     return !this.settingsAnim.finished(false);
/*     */   }
/*     */   
/*     */   public boolean hasSettings() {
/*  78 */     return !this.settings.isEmpty();
/*     */   }
/*     */   
/*     */   public void setHeight(float val) {
/*  82 */     setHeight(val, false);
/*     */   }
/*     */   
/*     */   public void reset() {
/*  86 */     for (Setting setting : this.settings) {
/*  87 */       setting.reset();
/*     */     }
/*  89 */     getBinds().clear();
/*     */   }
/*     */   
/*     */   public void setHeight(float val, boolean bind) {
/*  93 */     if (bind) {
/*  94 */       this.bindHeight = val;
/*     */     } else {
/*  96 */       this.height = val;
/*     */     } 
/*     */   }
/*     */   public Setting hide(Supplier<Boolean> hide) {
/* 100 */     this.hide = hide;
/* 101 */     return this;
/*     */   }
/*     */   
/*     */   public Setting desc(String desc) {
/* 105 */     this.desc = desc;
/* 106 */     return this;
/*     */   }
/*     */   
/*     */   public boolean isHide() {
/* 110 */     return ((Boolean)this.hide.get()).booleanValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\modules\settings\Setting.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */