/*     */ package fun.rockstarity.api.modules.settings.list;
/*     */ 
/*     */ import fun.rockstarity.api.binds.Bind;
/*     */ import fun.rockstarity.api.binds.BindType;
/*     */ import fun.rockstarity.api.binds.Bindable;
/*     */ import fun.rockstarity.api.helpers.system.TextUtility;
/*     */ import fun.rockstarity.api.modules.settings.Setting;
/*     */ import fun.rockstarity.api.render.animation.Animation;
/*     */ import fun.rockstarity.api.render.animation.Easing;
/*     */ import fun.rockstarity.api.render.ui.alerts.AlertType;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import fun.rockstarity.client.modules.render.Interface;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Element
/*     */   extends Bindable
/*     */ {
/* 125 */   private Animation settingsAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public Animation getSettingsAnim() { return this.settingsAnim; } private boolean ifEnabled = true; public boolean isIfEnabled() {
/* 126 */     return this.ifEnabled;
/* 127 */   } private final ArrayList<Setting> settings = new ArrayList<>(); public ArrayList<Setting> getSettings() { return this.settings; } protected Supplier<Boolean> hide = () -> Boolean.valueOf(false); private Select parent; private String name; private boolean enabled; private boolean prevEnabled;
/* 128 */   public Supplier<Boolean> getHide() { return this.hide; }
/* 129 */   public Select getParent() { return this.parent; }
/* 130 */   public String getName() { return this.name; }
/* 131 */   public boolean isEnabled() { return this.enabled; } public boolean isPrevEnabled() { return this.prevEnabled; }
/* 132 */    private final Animation anim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(200).setSize(1.0F), hover = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(200).setSize(0.5F); public Animation getAnim() { return this.anim; } public Animation getHover() { return this.hover; } private final Animation hideAnim = (new Animation())
/* 133 */     .setEasing(Easing.BOTH_SINE).setSpeed(200); private boolean dragging; private float dragX; private float dragY; public Animation getHideAnim() { return this.hideAnim; } private Rect rect; private Runnable onEnable; private Runnable onDisable; private Rect settingRect; public boolean isDragging() {
/* 134 */     return this.dragging; } public void setDragging(boolean dragging) { this.dragging = dragging; }
/* 135 */   public float getDragX() { return this.dragX; } public float getDragY() { return this.dragY; } public void setDragX(float dragX) { this.dragX = dragX; } public void setDragY(float dragY) { this.dragY = dragY; }
/* 136 */   public Rect getRect() { return this.rect; } public void setRect(Rect rect) { this.rect = rect; }
/* 137 */   public Runnable getOnEnable() { return this.onEnable; } public Runnable getOnDisable() { return this.onDisable; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Element(Select parent, String name)
/*     */   {
/* 145 */     this.settingRect = Rect.EMPTY; this.parent = parent; this.name = name; parent.add(this); } public void setSettingRect(Rect settingRect) { this.settingRect = settingRect; } public Rect getSettingRect() {
/* 146 */     return this.settingRect;
/*     */   }
/*     */   
/*     */   public boolean canSettings() {
/* 150 */     return !this.settingsAnim.finished(false);
/*     */   }
/*     */   
/*     */   public boolean hasSettings() {
/* 154 */     return (!this.settings.isEmpty() && !(this instanceof Interface.UIElement));
/*     */   }
/*     */   
/*     */   public Element ifEnabled(boolean ifEnabled) {
/* 158 */     this.ifEnabled = ifEnabled;
/* 159 */     return this;
/*     */   }
/*     */   
/*     */   public boolean ifEnabled() {
/* 163 */     return this.ifEnabled;
/*     */   }
/*     */   
/*     */   public Element set(boolean val, boolean silent) {
/* 167 */     int toggledCount = this.parent.getToggled().size();
/* 168 */     if ((val && toggledCount < this.parent.max) || (!val && toggledCount > this.parent.min) || silent) {
/* 169 */       this.enabled = val;
/*     */     }
/* 171 */     else if (!silent) {
/* 172 */       String word = "больше";
/*     */       
/* 174 */       if (toggledCount < this.parent.max) word = "меньше";
/*     */       
/* 176 */       rock.getAlertHandler().alert("Вы не можете выбрать " + word + " элементов", AlertType.ERROR);
/*     */     } 
/*     */     
/* 179 */     return this;
/*     */   }
/*     */   
/*     */   public Element set(boolean val) {
/* 183 */     if (val) {
/* 184 */       call(this.onEnable);
/*     */     } else {
/* 186 */       call(this.onDisable);
/* 187 */     }  return set(val, false);
/*     */   }
/*     */   
/*     */   public boolean get() {
/* 191 */     return (this.enabled && !isHide());
/*     */   }
/*     */   
/*     */   public Element hide(Supplier<Boolean> hide) {
/* 195 */     this.hide = hide;
/* 196 */     return this;
/*     */   }
/*     */   
/*     */   public Element onEnable(Runnable val) {
/* 200 */     this.onEnable = val;
/* 201 */     return this;
/*     */   }
/*     */   
/*     */   public Element onDisable(Runnable val) {
/* 205 */     this.onDisable = val;
/* 206 */     return this;
/*     */   }
/*     */   
/*     */   private void call(Runnable run) {
/* 210 */     if (run != null) run.run(); 
/*     */   }
/*     */   
/*     */   public boolean isHide() {
/* 214 */     return ((Boolean)this.hide.get()).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public void toggleWithBind(Optional<Bind> opt) {
/* 219 */     Bind bind = opt.get();
/*     */     
/* 221 */     if (isHide())
/*     */       return; 
/* 223 */     this.toggled = !this.toggled;
/*     */     
/* 225 */     String gender = TextUtility.makeGender(getName());
/*     */     
/* 227 */     if (bind.getType() != BindType.HOLD || bind.isHolding()) {
/* 228 */       if (this.toggled) {
/* 229 */         this.prevEnabled = get();
/* 230 */         set(!get());
/* 231 */         bind.setAlert(rock.getAlertHandler().alert(getName() + " переключен" + getName(), (bind.getType() == BindType.HOLD) ? AlertType.WAIT : (get() ? AlertType.SUCCESS : AlertType.ERROR)));
/*     */       } else {
/* 233 */         set(this.prevEnabled);
/* 234 */         bind.setAlert(rock.getAlertHandler().alert(getName() + " переключен" + getName(), (bind.getType() == BindType.HOLD) ? AlertType.WAIT : (get() ? AlertType.SUCCESS : AlertType.ERROR)));
/*     */       } 
/* 236 */       bind.getAlert().setBindable(this);
/* 237 */       bind.getAlert().setBind(bind);
/*     */     } else {
/* 239 */       set(this.prevEnabled);
/* 240 */       if (bind.getAlert() != null) {
/* 241 */         bind.getAlert().hide();
/*     */       }
/*     */     } 
/* 244 */     ((Interface)rock.getModules().get(Interface.class)).getKeyBinds().updateBind(bind, this.toggled, "");
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\modules\settings\list\Select$Element.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */