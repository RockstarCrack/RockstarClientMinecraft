/*     */ package fun.rockstarity.api.modules.settings.list;
/*     */ 
/*     */ import fun.rockstarity.api.binds.Bindable;
/*     */ import fun.rockstarity.api.modules.settings.Setting;
/*     */ import fun.rockstarity.api.render.animation.Animation;
/*     */ import fun.rockstarity.api.render.animation.Easing;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Element
/*     */   extends Bindable
/*     */ {
/*     */   private boolean ifEnabled = true;
/*     */   
/*     */   public boolean isIfEnabled() {
/* 166 */     return this.ifEnabled;
/* 167 */   } private Mode parent; private final ArrayList<Setting> settings = new ArrayList<>(); private String name; public ArrayList<Setting> getSettings() { return this.settings; }
/* 168 */   public Mode getParent() { return this.parent; } public String getName() {
/* 169 */     return this.name;
/* 170 */   } private final Animation anim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300), hover = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(200).setSize(0.5F); public Animation getAnim() { return this.anim; } public Animation getHover() { return this.hover; } private final Animation bindAnim = (new Animation())
/* 171 */     .setEasing(Easing.BOTH_SINE).setSpeed(300); private final Animation bindHover = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(200).setSize(0.5F); public Animation getBindAnim() { return this.bindAnim; } public Animation getBindHover() { return this.bindHover; }
/* 172 */    private Animation settingsAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public Animation getSettingsAnim() { return this.settingsAnim; }
/*     */   
/* 174 */   private Rect settingRect = Rect.EMPTY; public void setSettingRect(Rect settingRect) { this.settingRect = settingRect; } public Rect getSettingRect() {
/* 175 */     return this.settingRect;
/*     */   }
/*     */   
/*     */   public boolean canSettings() {
/* 179 */     return !this.settingsAnim.finished(false);
/*     */   }
/*     */   
/*     */   public boolean hasSettings() {
/* 183 */     return !this.settings.isEmpty();
/*     */   }
/*     */   
/*     */   public Element ifEnabled(boolean ifEnabled) {
/* 187 */     this.ifEnabled = ifEnabled;
/* 188 */     return this;
/*     */   }
/*     */   
/*     */   public boolean ifEnabled() {
/* 192 */     return this.ifEnabled;
/*     */   }
/*     */   
/*     */   public Animation getAnim(boolean bind) {
/* 196 */     return bind ? this.anim : this.bindAnim;
/*     */   }
/*     */   
/*     */   public Animation getHover(boolean bind) {
/* 200 */     return bind ? this.hover : this.bindHover;
/*     */   }
/*     */   
/*     */   public Element(Mode parent, String name) {
/* 204 */     this.parent = parent;
/* 205 */     this.name = name;
/* 206 */     parent.add(this);
/*     */   }
/*     */   
/*     */   public Element set() {
/* 210 */     this.parent.set(this);
/* 211 */     return this;
/*     */   }
/*     */   
/*     */   public boolean get() {
/* 215 */     return this.parent.is(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\modules\settings\list\Mode$Element.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */