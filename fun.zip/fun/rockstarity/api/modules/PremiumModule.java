package fun.rockstarity.api.modules;

public abstract class PremiumModule extends Module {}


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\modules\PremiumModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */