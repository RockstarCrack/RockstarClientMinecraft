/*     */ package fun.rockstarity.api.modules;
/*     */ 
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.binds.Bind;
/*     */ import fun.rockstarity.client.modules.combat.AimAssist;
/*     */ import fun.rockstarity.client.modules.combat.AimBot;
/*     */ import fun.rockstarity.client.modules.combat.Aura;
/*     */ import fun.rockstarity.client.modules.combat.AutoArmor;
/*     */ import fun.rockstarity.client.modules.combat.AutoExplosion;
/*     */ import fun.rockstarity.client.modules.combat.AutoGApple;
/*     */ import fun.rockstarity.client.modules.combat.AutoPotion;
/*     */ import fun.rockstarity.client.modules.combat.AutoSoup;
/*     */ import fun.rockstarity.client.modules.combat.AutoTotem;
/*     */ import fun.rockstarity.client.modules.combat.BackTrack;
/*     */ import fun.rockstarity.client.modules.combat.Criticals;
/*     */ import fun.rockstarity.client.modules.combat.ElytraTarget;
/*     */ import fun.rockstarity.client.modules.combat.FastBow;
/*     */ import fun.rockstarity.client.modules.combat.HitBoxes;
/*     */ import fun.rockstarity.client.modules.combat.SuperBow;
/*     */ import fun.rockstarity.client.modules.combat.TriggerBot;
/*     */ import fun.rockstarity.client.modules.combat.Velocity;
/*     */ import fun.rockstarity.client.modules.move.AutoLoot;
/*     */ import fun.rockstarity.client.modules.move.AutoSprint;
/*     */ import fun.rockstarity.client.modules.move.BoatControl;
/*     */ import fun.rockstarity.client.modules.move.Flight;
/*     */ import fun.rockstarity.client.modules.move.Jesus;
/*     */ import fun.rockstarity.client.modules.move.LongJump;
/*     */ import fun.rockstarity.client.modules.move.NoClip;
/*     */ import fun.rockstarity.client.modules.move.Speed;
/*     */ import fun.rockstarity.client.modules.move.Spider;
/*     */ import fun.rockstarity.client.modules.move.Strafe;
/*     */ import fun.rockstarity.client.modules.move.Timer;
/*     */ import fun.rockstarity.client.modules.move.WaterLeave;
/*     */ import fun.rockstarity.client.modules.move.WaterSpeed;
/*     */ import fun.rockstarity.client.modules.other.Assist;
/*     */ import fun.rockstarity.client.modules.other.AuctionUtils;
/*     */ import fun.rockstarity.client.modules.other.AutoAccept;
/*     */ import fun.rockstarity.client.modules.other.AutoAuth;
/*     */ import fun.rockstarity.client.modules.other.AutoBrew;
/*     */ import fun.rockstarity.client.modules.other.AutoDuels;
/*     */ import fun.rockstarity.client.modules.other.AutoDupe;
/*     */ import fun.rockstarity.client.modules.other.AutoFarmNew;
/*     */ import fun.rockstarity.client.modules.other.AutoInvisible;
/*     */ import fun.rockstarity.client.modules.other.AutoJoin;
/*     */ import fun.rockstarity.client.modules.other.AutoKit;
/*     */ import fun.rockstarity.client.modules.other.AutoLeave;
/*     */ import fun.rockstarity.client.modules.other.AutoPilot;
/*     */ import fun.rockstarity.client.modules.other.Baritone;
/*     */ import fun.rockstarity.client.modules.other.ChatUtils;
/*     */ import fun.rockstarity.client.modules.other.DeathCoordinates;
/*     */ import fun.rockstarity.client.modules.other.ElytraUtils;
/*     */ import fun.rockstarity.client.modules.other.Globals;
/*     */ import fun.rockstarity.client.modules.other.GodExploit;
/*     */ import fun.rockstarity.client.modules.other.ItemTimer;
/*     */ import fun.rockstarity.client.modules.other.KTLeave;
/*     */ import fun.rockstarity.client.modules.other.MultiActions;
/*     */ import fun.rockstarity.client.modules.other.NameProtect;
/*     */ import fun.rockstarity.client.modules.other.Panic;
/*     */ import fun.rockstarity.client.modules.other.PotionCombiner;
/*     */ import fun.rockstarity.client.modules.other.PotionRemover;
/*     */ import fun.rockstarity.client.modules.other.RussianRoulette;
/*     */ import fun.rockstarity.client.modules.other.Sounds;
/*     */ import fun.rockstarity.client.modules.player.AutoCreeperFarm;
/*     */ import fun.rockstarity.client.modules.player.AutoDodge;
/*     */ import fun.rockstarity.client.modules.player.AutoEat;
/*     */ import fun.rockstarity.client.modules.player.AutoPearl;
/*     */ import fun.rockstarity.client.modules.player.AutoSwap;
/*     */ import fun.rockstarity.client.modules.player.AutoUse;
/*     */ import fun.rockstarity.client.modules.player.Blink;
/*     */ import fun.rockstarity.client.modules.player.ClickTrough;
/*     */ import fun.rockstarity.client.modules.player.EnderChest;
/*     */ import fun.rockstarity.client.modules.player.FreeCam;
/*     */ import fun.rockstarity.client.modules.player.InvCleaner;
/*     */ import fun.rockstarity.client.modules.player.InvUtils;
/*     */ import fun.rockstarity.client.modules.player.MiddleClick;
/*     */ import fun.rockstarity.client.modules.player.MineHelper;
/*     */ import fun.rockstarity.client.modules.player.NoDelay;
/*     */ import fun.rockstarity.client.modules.player.NoFall;
/*     */ import fun.rockstarity.client.modules.player.NoInteract;
/*     */ import fun.rockstarity.client.modules.player.NoPush;
/*     */ import fun.rockstarity.client.modules.player.NoRotate;
/*     */ import fun.rockstarity.client.modules.player.NoSlow;
/*     */ import fun.rockstarity.client.modules.player.Nuker;
/*     */ import fun.rockstarity.client.modules.player.Phase;
/*     */ import fun.rockstarity.client.modules.player.PlayerUtils;
/*     */ import fun.rockstarity.client.modules.player.Reach;
/*     */ import fun.rockstarity.client.modules.player.Sneak;
/*     */ import fun.rockstarity.client.modules.player.SpeedMine;
/*     */ import fun.rockstarity.client.modules.player.Stealer;
/*     */ import fun.rockstarity.client.modules.player.WebUtils;
/*     */ import fun.rockstarity.client.modules.render.AntiInvisible;
/*     */ import fun.rockstarity.client.modules.render.Arrows;
/*     */ import fun.rockstarity.client.modules.render.Beautifully;
/*     */ import fun.rockstarity.client.modules.render.BlockESP;
/*     */ import fun.rockstarity.client.modules.render.ClickGui;
/*     */ import fun.rockstarity.client.modules.render.Constructor;
/*     */ import fun.rockstarity.client.modules.render.Cosmetics;
/*     */ import fun.rockstarity.client.modules.render.ESP;
/*     */ import fun.rockstarity.client.modules.render.FreeLook;
/*     */ import fun.rockstarity.client.modules.render.Hand;
/*     */ import fun.rockstarity.client.modules.render.Interface;
/*     */ import fun.rockstarity.client.modules.render.KillEffects;
/*     */ import fun.rockstarity.client.modules.render.NameTags;
/*     */ import fun.rockstarity.client.modules.render.NoRender;
/*     */ import fun.rockstarity.client.modules.render.ObjectsInfo;
/*     */ import fun.rockstarity.client.modules.render.Particles;
/*     */ import fun.rockstarity.client.modules.render.Prediction;
/*     */ import fun.rockstarity.client.modules.render.TNTTimer;
/*     */ import fun.rockstarity.client.modules.render.TargetESP;
/*     */ import fun.rockstarity.client.modules.render.Torus;
/*     */ import fun.rockstarity.client.modules.render.World;
/*     */ import fun.rockstarity.client.modules.render.XRay;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Modules
/*     */   extends HashMap<Class, Module>
/*     */   implements IAccess
/*     */ {
/* 143 */   private List<Module> modules = new ArrayList<>(); public List<Module> getModules() { return this.modules; }
/*     */   
/*     */   public Modules() {
/* 146 */     Arrays.<Module>stream(new Module[] { (Module)new AimAssist(), (Module)new AutoArmor(), (Module)new Aura(), (Module)new AutoGApple(), (Module)new AutoTotem(), (Module)new AutoPotion(), (Module)new Velocity(), (Module)new HitBoxes(), (Module)new TriggerBot(), (Module)new FastBow(), (Module)new SuperBow(), (Module)new BackTrack(), (Module)new AutoExplosion(), (Module)new AutoSoup(), (Module)new AimBot(), (Module)new Criticals(), (Module)new ElytraTarget(), (new AutoSprint())
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 166 */           .set(true), (Module)new Flight(), (Module)new Strafe(), (Module)new Speed(), (Module)new Jesus(), (Module)new LongJump(), (Module)new NoSlow(), (Module)new Timer(), (Module)new WaterSpeed(), (Module)new Spider(), (Module)new WaterLeave(), (Module)new NoClip(), (Module)new BoatControl(), (Module)new AutoLoot(), (Module)new ESP(), (Module)new World(), (new Interface())
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 183 */           .set(true), (Module)new NoRender(), (Module)new NameTags(), (new ClickGui())
/*     */ 
/*     */ 
/*     */           
/* 187 */           .addBind(new Bind(344)), (Module)new Hand(), (Module)new Prediction(), (Module)new AntiInvisible(), (Module)new TNTTimer(), (Module)new Arrows(), (Module)new Particles(), (Module)new XRay(), (Module)new Constructor(), (new TargetESP())
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 196 */           .set(true), (Module)new Beautifully(), (Module)new FreeLook(), (Module)new BlockESP(), (Module)new KillEffects(), (new Cosmetics())
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 201 */           .set(true), (Module)new ObjectsInfo(), (Module)new Torus(), (Module)new EnderChest(), (Module)new Phase(), (new Sounds())
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 207 */           .set(true), (Module)new FreeCam(), (Module)new EnderChest(), (Module)new AutoUse(), (Module)new AutoEat(), (new InvUtils())
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 212 */           .set(true), (Module)new Blink(), (Module)new InvCleaner(), (Module)new WebUtils(), (Module)new NoDelay(), (Module)new AutoSwap(), (Module)new NoInteract(), (Module)new Stealer(), (Module)new SpeedMine(), (Module)new PlayerUtils(), (Module)new Sneak(), (Module)new NoRotate(), (Module)new Reach(), (Module)new NoFall(), (Module)new AutoCreeperFarm(), (Module)new MiddleClick(), (Module)new AutoPearl(), (Module)new Nuker(), (Module)new ClickTrough(), (Module)new PotionRemover(), (Module)new AutoDodge(), (Module)new MineHelper(), (Module)new AutoKit(), (Module)new Baritone(), (Module)new AutoFarmNew(), (Module)new KTLeave(), (Module)new PotionCombiner(), (Module)new Globals(), (Module)new ElytraUtils(), (Module)new AutoLeave(), (Module)new Panic(), (Module)new AutoInvisible(), (new Assist())
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 245 */           .set(true), (Module)new AuctionUtils(), (Module)new ItemTimer(), (Module)new AutoDuels(), (Module)new AutoPilot(), (Module)new DeathCoordinates(), (Module)new AutoAuth(), (Module)new MultiActions(), (Module)new NoPush(), (Module)new AutoJoin(), (Module)new GodExploit(), (Module)new NameProtect(), (Module)new RussianRoulette(), (new ChatUtils())
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 258 */           .set(true), (Module)new AutoAccept(), (Module)new AutoBrew(), (Module)new AutoDupe()
/*     */ 
/*     */ 
/*     */         
/* 262 */         }).forEach(this::add);
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(Module module) {
/* 267 */     if (module.getClass().isAnnotationPresent((Class)Info.class)) {
/* 268 */       Info info = module.getClass().<Info>getAnnotation(Info.class);
/* 269 */       module.setInfo(new ModuleInfo(info.name(), info.desc(), info.type(), info.module()));
/*     */     } 
/*     */     
/* 272 */     put(module.getClass(), module);
/*     */     
/* 274 */     this.modules = new ArrayList<>(values());
/* 275 */     this.modules.sort(Comparator.comparingInt(Module::getPriority));
/*     */   }
/*     */   
/*     */   public void remove(Class moduleClass) {
/* 279 */     remove(moduleClass);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends Module> T get(Class<T> moduleClass) {
/* 284 */     return moduleClass.cast(get(moduleClass));
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\modules\Modules.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */