/*     */ package fun.rockstarity.api.modules;
/*     */ 
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.binds.Bind;
/*     */ import fun.rockstarity.api.binds.BindType;
/*     */ import fun.rockstarity.api.binds.Bindable;
/*     */ import fun.rockstarity.api.events.Event;
/*     */ import fun.rockstarity.api.events.EventType;
/*     */ import fun.rockstarity.api.events.IEventable;
/*     */ import fun.rockstarity.api.events.list.game.client.EventToggle;
/*     */ import fun.rockstarity.api.helpers.system.TextUtility;
/*     */ import fun.rockstarity.api.modules.settings.Setting;
/*     */ import fun.rockstarity.api.render.animation.Animation;
/*     */ import fun.rockstarity.api.render.animation.Easing;
/*     */ import fun.rockstarity.api.render.ui.alerts.AlertType;
/*     */ import fun.rockstarity.client.modules.render.Interface;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Module
/*     */   extends Bindable
/*     */   implements IEventable, IAccess
/*     */ {
/*     */   private ModuleInfo info;
/*     */   private boolean enabled;
/*     */   
/*     */   public ModuleInfo getInfo() {
/*  33 */     return this.info; } public void setInfo(ModuleInfo info) { this.info = info; }
/*     */ 
/*     */   
/*  36 */   private int priority = 1; public int getPriority() { return this.priority; }
/*     */   
/*  38 */   private ArrayList<Setting> settings = new ArrayList<>(); public ArrayList<Setting> getSettings() { return this.settings; } public void setSettings(ArrayList<Setting> settings) { this.settings = settings; }
/*     */   
/*  40 */   public Animation getHover() { return this.hover; } public Animation getOpened() { return this.opened; } public Animation getTogglingAnim() { return this.togglingAnim; } private final Animation hover = (new Animation())
/*  41 */     .setEasing(Easing.BOTH_SINE).setSpeed(300);
/*  42 */   private final Animation opened = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300);
/*  43 */   private final Animation togglingAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300);
/*     */   
/*     */   public Module(int priority) {
/*  46 */     this.priority = priority;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onAllEvent(Event event) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Module set(boolean enabled) {
/*  59 */     this.enabled = enabled;
/*     */     
/*  61 */     return this;
/*     */   }
/*     */   
/*     */   public boolean get() {
/*  65 */     return rock.isPanic() ? false : this.enabled;
/*     */   }
/*     */   
/*     */   public Module addBind(Bind bind) {
/*  69 */     getBinds().add(bind);
/*     */     
/*  71 */     return this;
/*     */   }
/*     */   
/*     */   public void toggle(boolean state, boolean silent) {
/*  75 */     this.enabled = state;
/*     */     
/*  77 */     String gender = TextUtility.makeGender(this.info.name());
/*     */     
/*  79 */     if (this.enabled) {
/*  80 */       onEnable();
/*  81 */       (new EventToggle(this, true)).hook();
/*  82 */       if (!(this instanceof fun.rockstarity.client.modules.render.ClickGui) && !(this instanceof fun.rockstarity.client.modules.render.Constructor))
/*  83 */         rock.getAlertHandler().alert(this.info.name() + " включен" + this.info.name(), AlertType.SUCCESS); 
/*     */     } else {
/*  85 */       onDisable();
/*  86 */       (new EventToggle(this, false)).hook();
/*  87 */       if (!(this instanceof fun.rockstarity.client.modules.render.ClickGui) && !(this instanceof fun.rockstarity.client.modules.render.Constructor)) {
/*  88 */         rock.getAlertHandler().alert(this.info.name() + " выключен" + this.info.name(), AlertType.ERROR);
/*     */       }
/*     */     } 
/*  91 */     for (Bind bind : getBinds()) {
/*  92 */       if (bind.getType() == BindType.HOLD && bind.isHolding()) {
/*  93 */         bind.getAlert().hide();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void toggleWithBind(Optional<Bind> opt) {
/* 100 */     Bind bind = opt.get();
/*     */     
/* 102 */     this.enabled = !this.enabled;
/*     */     
/* 104 */     String gender = TextUtility.makeGender(this.info.name());
/*     */     
/* 106 */     if (bind.getType() != BindType.HOLD || bind.isHolding()) {
/* 107 */       if (this.enabled) {
/* 108 */         onEnable();
/* 109 */         (new EventToggle(this, true)).hook();
/* 110 */         if (!(this instanceof fun.rockstarity.client.modules.render.ClickGui) && !(this instanceof fun.rockstarity.client.modules.render.Constructor))
/* 111 */           bind.setAlert(rock.getAlertHandler().alert(this.info.name() + " включен" + this.info.name(), (bind.getType() == BindType.HOLD) ? AlertType.WAIT : AlertType.SUCCESS)); 
/*     */       } else {
/* 113 */         onDisable();
/* 114 */         (new EventToggle(this, false)).hook();
/* 115 */         bind.setAlert(rock.getAlertHandler().alert(this.info.name() + " выключен" + this.info.name(), (bind.getType() == BindType.HOLD) ? AlertType.WAIT : AlertType.ERROR));
/*     */       } 
/* 117 */       if (bind.getAlert() != null) {
/* 118 */         bind.getAlert().setBindable(this);
/* 119 */         bind.getAlert().setBind(bind);
/*     */       } 
/*     */     } else {
/* 122 */       if (bind.getAlert() != null)
/* 123 */         bind.getAlert().hide(); 
/* 124 */       onDisable();
/* 125 */       (new EventToggle(this, false)).hook();
/*     */     } 
/*     */     
/* 128 */     if (!(this instanceof fun.rockstarity.client.modules.render.ClickGui))
/* 129 */       ((Interface)rock.getModules().<Interface>get(Interface.class)).getKeyBinds().updateBind(bind, true, ""); 
/*     */   }
/*     */   
/*     */   public void toggle() {
/* 133 */     toggle(!this.enabled, false);
/*     */   }
/*     */   
/*     */   public EventType getEventType() {
/* 137 */     return getClass().<EventType>getAnnotation(EventType.class);
/*     */   }
/*     */   
/*     */   public abstract void onEvent(Event paramEvent);
/*     */   
/*     */   public abstract void onEnable();
/*     */   
/*     */   public abstract void onDisable();
/*     */   
/*     */   public Module() {}
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\modules\Module.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */