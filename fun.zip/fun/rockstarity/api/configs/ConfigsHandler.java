/*     */ package fun.rockstarity.api.configs;
/*     */ 
/*     */ import com.google.gson.GsonBuilder;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.autobuy.logic.items.AutoBuyItem;
/*     */ import fun.rockstarity.api.autobuy.logic.items.MinecraftItem;
/*     */ import fun.rockstarity.api.binds.Bind;
/*     */ import fun.rockstarity.api.binds.BindType;
/*     */ import fun.rockstarity.api.binds.Bindable;
/*     */ import fun.rockstarity.api.events.EventHandler;
/*     */ import fun.rockstarity.api.helpers.game.Chat;
/*     */ import fun.rockstarity.api.helpers.player.Player;
/*     */ import fun.rockstarity.api.helpers.system.ThreadManager;
/*     */ import fun.rockstarity.api.modules.Category;
/*     */ import fun.rockstarity.api.modules.Module;
/*     */ import fun.rockstarity.api.modules.settings.Setting;
/*     */ import fun.rockstarity.api.modules.settings.list.CheckBox;
/*     */ import fun.rockstarity.api.modules.settings.list.ColorPicker;
/*     */ import fun.rockstarity.api.modules.settings.list.Input;
/*     */ import fun.rockstarity.api.modules.settings.list.ItemSelect;
/*     */ import fun.rockstarity.api.modules.settings.list.Mode;
/*     */ import fun.rockstarity.api.modules.settings.list.Position;
/*     */ import fun.rockstarity.api.modules.settings.list.Select;
/*     */ import fun.rockstarity.api.modules.settings.list.Slider;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.ui.alerts.Alert;
/*     */ import fun.rockstarity.api.render.ui.alerts.AlertType;
/*     */ import fun.rockstarity.api.render.ui.clickgui.esp.ESPElement;
/*     */ import fun.rockstarity.api.scripts.Script;
/*     */ import fun.rockstarity.api.secure.Debugger;
/*     */ import fun.rockstarity.client.commands.MacroCommand;
/*     */ import fun.rockstarity.client.commands.ScoreCommand;
/*     */ import fun.rockstarity.client.modules.render.Interface;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Files;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.item.Items;
/*     */ import net.minecraft.util.text.TextFormatting;
/*     */ import org.json.simple.JSONArray;
/*     */ import org.json.simple.JSONObject;
/*     */ import org.json.simple.parser.JSONParser;
/*     */ import ru.kotopushka.antiautistleak.obfuscator.includes.annotations.compile.ReleaseCompileToNativeCalls;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ReleaseCompileToNativeCalls
/*     */ public class ConfigsHandler
/*     */   implements IAccess
/*     */ {
/*  62 */   private final ConfigWindow window = new ConfigWindow(new ConfigWrapper()); public ConfigWindow getWindow() { return this.window; }
/*     */   
/*     */   private Alert alert;
/*  65 */   private String current = "default"; public String getCurrent() { return this.current; } public void setCurrent(String current) { this.current = current; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void save(String name, boolean silent) {
/*  70 */     if (name.length() > 20) {
/*  71 */       name = name.substring(0, 19);
/*     */     }
/*     */     
/*  74 */     String finalName = name;
/*     */     
/*  76 */     this.alert = silent ? null : rock.getAlertHandler().alert("Сохраняем ваш конфиг", AlertType.WAIT);
/*     */     
/*  78 */     ThreadManager.run(() -> {
/*     */           JSONObject config = new JSONObject();
/*     */           
/*     */           JSONObject mods = new JSONObject();
/*     */           
/*     */           List<Module> modules = new ArrayList<>();
/*     */           
/*     */           rock.getModules().values().forEach(());
/*     */           
/*     */           for (Script script : rock.getScriptHandler().getEnabledScripts()) {
/*     */             script.getScriptModules().forEach(());
/*     */           }
/*     */           
/*     */           for (Module mod : modules) {
/*     */             JSONObject module = new JSONObject();
/*     */             
/*     */             for (Setting set : mod.getSettings()) {
/*     */               JSONObject setting = new JSONObject();
/*     */               
/*     */               saveSetting(set, setting);
/*     */               
/*     */               if (set instanceof Select) {
/*     */                 Select select = (Select)set;
/*     */                 
/*     */                 JSONObject selects = new JSONObject();
/*     */                 
/*     */                 for (Select.Element elmt : select.getElements()) {
/*     */                   JSONObject jSONObject = new JSONObject();
/*     */                   
/*     */                   for (Bind bind : elmt.getBinds()) {
/*     */                     jSONObject.put("" + bind.getKey() + ":" + bind.getKey(), bind.getType().getName());
/*     */                   }
/*     */                   
/*     */                   selects.put(elmt.getName(), jSONObject);
/*     */                 } 
/*     */                 
/*     */                 setting.put("selects", selects);
/*     */               } 
/*     */               
/*     */               JSONObject jSONObject1 = new JSONObject();
/*     */               
/*     */               for (Bind bind : set.getBinds()) {
/*     */                 jSONObject1.put("" + bind.getKey() + ":" + bind.getKey(), bind.getType().getName());
/*     */               }
/*     */               
/*     */               setting.put("binds", jSONObject1);
/*     */               
/*     */               module.put(set.getName(), setting);
/*     */             } 
/*     */             
/*     */             JSONObject binds = new JSONObject();
/*     */             for (Bind bind : mod.getBinds()) {
/*     */               binds.put("" + bind.getKey() + ":" + bind.getKey(), bind.getType().getName());
/*     */             }
/*     */             module.put("binds", binds);
/*     */             module.put("enabled", Boolean.valueOf(mod.get()));
/*     */             mods.put(mod.getInfo().name(), module);
/*     */           } 
/*     */           config.put("mods", mods);
/*     */           JSONObject hud = new JSONObject();
/*     */           for (Select.Element element : ((Interface)rock.getModules().get(Interface.class)).getElements().getElements()) {
/*     */             Interface.UIElement ui = (Interface.UIElement)element;
/*     */             JSONObject elmt = new JSONObject();
/*     */             for (Setting set : ui.getSettings()) {
/*     */               JSONObject setting = new JSONObject();
/*     */               Bindable patt0$temp = set.getParent();
/*     */               if (patt0$temp instanceof Interface.UIElement) {
/*     */                 Interface.UIElement parent = (Interface.UIElement)patt0$temp;
/*     */               } else {
/*     */                 return;
/*     */               } 
/*     */               saveSetting(set, setting);
/*     */               JSONObject binds = new JSONObject();
/*     */               for (Bind bind : set.getBinds()) {
/*     */                 binds.put("" + bind.getKey() + ":" + bind.getKey(), bind.getType().getName());
/*     */               }
/*     */               setting.put("binds", binds);
/*     */               elmt.put(set.getName(), setting);
/*     */             } 
/*     */             hud.put(element.getName(), elmt);
/*     */           } 
/*     */           config.put("ui", hud);
/*     */           JSONObject esp = new JSONObject();
/*     */           for (ESPElement elmt : rock.getEspSettingsHandler().getEspElements()) {
/*     */             JSONObject element = new JSONObject();
/*     */             element.put("active", Boolean.valueOf(elmt.isActive()));
/*     */             element.put("direction", Integer.valueOf(elmt.getDirection()));
/*     */             esp.put(elmt.getName(), element);
/*     */           } 
/*     */           config.put("esp", esp);
/*     */           try {
/*     */             JSONArray itemsArray = new JSONArray();
/*     */             for (AutoBuyItem item : rock.getAutoBuy().getItems()) {
/*     */               itemsArray.add(item.toJson());
/*     */             }
/*     */             config.put("items", itemsArray);
/* 174 */           } catch (Exception e) {
/*     */             Debugger.print(e);
/*     */           }  String code = (new GsonBuilder()).setPrettyPrinting().create().toJson(config);
/*     */           File configDir = new File((Minecraft.getInstance()).gameDir, "rock/configs");
/*     */           if (!configDir.exists())
/*     */             configDir.mkdirs(); 
/*     */           File configFile = new File(configDir, finalName + ".json");
/*     */           try {
/*     */             FileWriter writer = new FileWriter(configFile);
/*     */             
/*     */             try { writer.write(code);
/*     */               writer.close(); }
/* 186 */             catch (Throwable throwable) { try { writer.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/*     */           
/* 188 */           } catch (IOException e) {
/*     */             Debugger.print(e);
/*     */             if (!silent) {
/*     */               rock.getAlertHandler().alert("Ошибка при сохранении конфига", AlertType.ERROR);
/*     */             }
/*     */           } 
/*     */           if (!silent) {
/*     */             rock.getAlertHandler().alert("Конфиг сохранен", AlertType.INFO);
/*     */             this.alert.hide();
/*     */           } 
/*     */           this.current = finalName;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void load(String name) {
/* 205 */     load(name, false);
/*     */   }
/*     */   
/*     */   public void resetToDefault() {
/* 209 */     for (Module mod : rock.getModules().values()) {
/* 210 */       if (mod.getInfo().name().contains("ClickGui"))
/* 211 */         continue;  mod.set(false);
/* 212 */       for (Setting set : mod.getSettings()) {
/* 213 */         set.reset();
/*     */       }
/* 215 */       mod.getBinds().clear();
/*     */     } 
/* 217 */     for (Script script : rock.getScriptHandler().getScripts()) {
/* 218 */       script.setEnabled(false);
/*     */     }
/*     */     
/* 221 */     for (ESPElement elmt : rock.getEspSettingsHandler().getEspElements()) {
/* 222 */       elmt.setActive(false);
/* 223 */       elmt.setDirection(0);
/*     */     } 
/*     */     
/* 226 */     for (Select.Element element : ((Interface)rock.getModules().get(Interface.class)).getElements().getElements()) {
/* 227 */       Interface.UIElement ui = (Interface.UIElement)element;
/* 228 */       for (Setting set : ui.getSettings()) {
/* 229 */         set.getBinds().clear();
/*     */       }
/*     */     } 
/*     */     
/* 233 */     MacroCommand.getMacroses().clear();
/* 234 */     ScoreCommand.getScores().clear();
/* 235 */     rock.getFriendsHandler().getFriends().clear();
/* 236 */     rock.getTargetHandler().getTarget().clear();
/* 237 */     rock.getAutoBuy().getItems().clear();
/* 238 */     rock.setCfgToLoad("default");
/* 239 */     EventHandler.resetConfig();
/*     */   }
/*     */   
/*     */   public void load(String name, boolean silent) {
/* 243 */     ThreadManager.run(() -> {
/*     */           Alert alert = null;
/*     */           
/*     */           if (!silent) {
/*     */             alert = rock.getAlertHandler().alert("Загружаем ваш конфиг", AlertType.WAIT);
/*     */           }
/*     */           
/* 250 */           boolean loadBinds = (this.window.getElement().getLoadBinds().get() || !Player.isInGame());
/*     */           
/*     */           try {
/*     */             File configDir = new File((Minecraft.getInstance()).gameDir, "rock/configs");
/*     */             
/*     */             File configFile = new File(configDir, name + ".json");
/*     */             
/*     */             if (!configFile.exists()) {
/*     */               if (!silent) {
/*     */                 rock.getAlertHandler().alert("Конфиг не найден", AlertType.ERROR);
/*     */                 
/*     */                 alert.hide();
/*     */               } 
/*     */               return;
/*     */             } 
/*     */             String code = new String(Files.readAllBytes(configFile.toPath()));
/*     */             JSONObject config = null;
/*     */             try {
/*     */               JSONParser parser = new JSONParser();
/*     */               config = (JSONObject)parser.parse(code);
/*     */               for (Module mod : rock.getModules().values()) {
/*     */                 if (loadBinds) {
/*     */                   mod.getBinds().clear();
/*     */                 }
/*     */               } 
/* 275 */             } catch (Exception e) {
/*     */               Debugger.print(e);
/*     */               
/*     */               if (!silent) {
/*     */                 alert.hide();
/*     */                 
/*     */                 rock.getAlertHandler().alert("Ошибка при загрузке", AlertType.ERROR);
/*     */               } 
/*     */               
/*     */               return;
/*     */             } 
/*     */             List<Module> modules = new ArrayList<>();
/*     */             rock.getModules().values().forEach(());
/*     */             for (Script script : rock.getScriptHandler().getEnabledScripts()) {
/*     */               script.getScriptModules().forEach(());
/*     */             }
/*     */             for (Module mod : modules) {
/*     */               boolean bool = false;
/*     */               if (Player.isInGame()) {
/*     */                 for (Select.Element elmt : this.window.getElement().getCategories().getElements()) {
/*     */                   if (mod.getInfo().type().getDisplayName().equals(elmt.getName()) && !elmt.get()) {
/*     */                     bool = true;
/*     */                   }
/*     */                 } 
/*     */               }
/*     */               if (bool) {
/*     */                 continue;
/*     */               }
/*     */               JSONObject mods = (JSONObject)((JSONObject)config.get("mods")).get(mod.getInfo().name());
/*     */               for (Setting set : mod.getSettings()) {
/*     */                 if (loadBinds) {
/*     */                   set.getBinds().clear();
/*     */                 }
/*     */                 try {
/*     */                   loadSetting(set, mods);
/*     */                   if (set instanceof Select) {
/*     */                     Select select = (Select)set;
/*     */                     JSONObject selects = (JSONObject)((JSONObject)mods.get(set.getName())).get("selects");
/*     */                     for (Select.Element elmt : select.getElements()) {
/*     */                       if (loadBinds) {
/*     */                         elmt.getBinds().clear();
/*     */                       }
/*     */                       JSONObject jSONObject = (JSONObject)selects.get(elmt.getName());
/*     */                       if (loadBinds) {
/*     */                         for (Object bind : jSONObject.keySet()) {
/*     */                           elmt.getBinds().add(new Bind(Integer.parseInt(String.valueOf(bind).split(":")[0]), Integer.parseInt(String.valueOf(bind).split(":")[1]), BindType.get(String.valueOf(jSONObject.get(bind)))));
/*     */                         }
/*     */                       }
/*     */                     } 
/*     */                   } 
/*     */                   JSONObject binds = (JSONObject)((JSONObject)mods.get(set.getName())).get("binds");
/*     */                   if (loadBinds) {
/*     */                     for (Object bind : binds.keySet()) {
/*     */                       set.getBinds().add(new Bind(Integer.parseInt(String.valueOf(bind).split(":")[0]), Integer.parseInt(String.valueOf(bind).split(":")[1]), BindType.get(String.valueOf(binds.get(bind)))));
/*     */                     }
/*     */                   }
/* 331 */                 } catch (Exception exception) {}
/*     */               } 
/*     */               if (mod instanceof Interface) {
/*     */                 Interface interfaceMod = (Interface)mod;
/*     */                 if (!config.containsKey("ui")) {
/*     */                   for (Select.Element element : interfaceMod.getElements().getElements()) {
/*     */                     Interface.UIElement ui = (Interface.UIElement)element;
/*     */                     for (Setting set : ui.getSettings()) {
/*     */                       if (loadBinds)
/*     */                         set.getBinds().clear(); 
/*     */                       try {
/*     */                         Bindable patt0$temp = set.getParent();
/*     */                         if (patt0$temp instanceof Interface.UIElement) {
/*     */                           Interface.UIElement parent = (Interface.UIElement)patt0$temp;
/*     */                         } else {
/*     */                           return;
/*     */                         } 
/*     */                         loadSetting(set, mods);
/*     */                         JSONObject binds = (JSONObject)((JSONObject)mods.get(set.getName())).get("binds");
/*     */                         if (loadBinds)
/*     */                           for (Object bind : binds.keySet())
/*     */                             set.getBinds().add(new Bind(Integer.parseInt(String.valueOf(bind).split(":")[0]), Integer.parseInt(String.valueOf(bind).split(":")[1]), BindType.get(String.valueOf(binds.get(bind)))));  
/* 353 */                       } catch (Exception parent) {}
/*     */                     } 
/*     */                   } 
/*     */                 }
/*     */               } 
/*     */               
/*     */               try {
/*     */                 JSONObject binds = (JSONObject)mods.get("binds");
/*     */                 
/*     */                 if (loadBinds) {
/*     */                   for (Object bind : binds.keySet()) {
/*     */                     mod.getBinds().add(new Bind(Integer.parseInt(String.valueOf(bind).split(":")[0]), Integer.parseInt(String.valueOf(bind).split(":")[1]), BindType.get(String.valueOf(binds.get(bind)))));
/*     */                   }
/*     */                 }
/*     */                 mod.set(((Boolean)mods.get("enabled")).booleanValue());
/* 368 */               } catch (Exception e) {
/*     */                 Debugger.print(e);
/*     */               } 
/*     */             } 
/*     */             boolean next = false;
/*     */             if (Player.isInGame()) {
/*     */               for (Select.Element elmt : this.window.getElement().getCategories().getElements()) {
/*     */                 if (Category.RENDER.getDisplayName().equals(elmt.getName()) && !elmt.get()) {
/*     */                   next = true;
/*     */                 }
/*     */               } 
/*     */             }
/*     */             if (!next) {
/*     */               try {
/*     */                 JSONObject hud = (JSONObject)config.get("ui");
/*     */                 for (Select.Element element : ((Interface)rock.getModules().get(Interface.class)).getElements().getElements()) {
/*     */                   Interface.UIElement ui = (Interface.UIElement)element;
/*     */                   JSONObject elmt = (JSONObject)hud.get(element.getName());
/*     */                   for (Setting set : ui.getSettings()) {
/*     */                     if (loadBinds) {
/*     */                       set.getBinds().clear();
/*     */                     }
/*     */                     try {
/*     */                       Bindable patt0$temp = set.getParent();
/*     */                       if (patt0$temp instanceof Interface.UIElement) {
/*     */                         Interface.UIElement parent = (Interface.UIElement)patt0$temp;
/*     */                       } else {
/*     */                         return;
/*     */                       } 
/*     */                       loadSetting(set, elmt);
/*     */                       JSONObject binds = (JSONObject)((JSONObject)elmt.get(set.getName())).get("binds");
/*     */                       if (loadBinds)
/*     */                         for (Object bind : binds.keySet()) {
/*     */                           set.getBinds().add(new Bind(Integer.parseInt(String.valueOf(bind).split(":")[0]), Integer.parseInt(String.valueOf(bind).split(":")[1]), BindType.get(String.valueOf(binds.get(bind)))));
/*     */                         } 
/* 403 */                     } catch (Exception parent) {}
/*     */                   }
/*     */                 
/*     */                 } 
/* 407 */               } catch (Exception e) {
/*     */                 Debugger.print(e);
/*     */               } 
/*     */             }
/*     */             
/*     */             try {
/*     */               JSONObject esp = (JSONObject)config.get("esp");
/*     */               
/*     */               for (ESPElement elmt : rock.getEspSettingsHandler().getEspElements()) {
/*     */                 JSONObject element = (JSONObject)esp.get(elmt.getName());
/*     */                 elmt.setDirection((int)((Long)element.get("direction")).longValue());
/*     */                 elmt.setActive(((Boolean)element.get("active")).booleanValue());
/*     */               } 
/* 420 */             } catch (Exception e) {
/*     */               Debugger.print(e);
/*     */             } 
/*     */             
/*     */             try {
/*     */               rock.getAutoBuy().getItems().clear();
/*     */               
/*     */               JSONArray itemsArray = (JSONArray)config.get("items");
/*     */               if (itemsArray != null) {
/*     */                 for (Object itemObj : itemsArray) {
/*     */                   JSONObject itemJson = (JSONObject)itemObj;
/*     */                   AutoBuyItem item = AutoBuyItem.fromJson(itemJson);
/*     */                   rock.getAutoBuy().getItems().add(item);
/*     */                 } 
/*     */               }
/* 435 */             } catch (Exception e) {
/*     */               Debugger.print(e);
/*     */             } 
/*     */             
/*     */             if (!silent) {
/*     */               rock.getAlertHandler().alert("Конфиг загружен", AlertType.INFO);
/*     */             }
/*     */             EventHandler.resetConfig();
/*     */             this.current = name;
/* 444 */           } catch (Exception e) {
/*     */             Debugger.print(e);
/*     */             if (!silent) {
/*     */               rock.getAlertHandler().alert("Ошибка при загрузке", AlertType.ERROR);
/*     */               alert.hide();
/*     */             } 
/*     */           } 
/*     */           if (!silent && alert != null)
/*     */             alert.hide(); 
/*     */         });
/*     */   }
/*     */   
/*     */   public void load(String name, String module) {
/* 457 */     ThreadManager.run(() -> {
/*     */           Alert alert = rock.getAlertHandler().alert("Загружаем модуль из конфига", AlertType.WAIT);
/*     */           
/*     */           try {
/*     */             File configDir = new File((Minecraft.getInstance()).gameDir, "rock/configs");
/*     */             
/*     */             File configFile = new File(configDir, name + ".json");
/*     */             
/*     */             if (!configFile.exists()) {
/*     */               rock.getAlertHandler().alert("Конфиг не найден", AlertType.ERROR);
/*     */               
/*     */               alert.hide();
/*     */               return;
/*     */             } 
/*     */             String code = new String(Files.readAllBytes(configFile.toPath()));
/*     */             JSONObject config = null;
/*     */             try {
/*     */               JSONParser parser = new JSONParser();
/*     */               config = (JSONObject)parser.parse(code);
/* 476 */             } catch (Exception e) {
/*     */               Debugger.print(e);
/*     */               
/*     */               alert.hide();
/*     */               
/*     */               rock.getAlertHandler().alert("Ошибка при загрузке", AlertType.ERROR);
/*     */               
/*     */               return;
/*     */             } 
/*     */             List<Module> modules = new ArrayList<>();
/*     */             rock.getModules().values().forEach(());
/*     */             for (Script script : rock.getScriptHandler().getEnabledScripts()) {
/*     */               script.getScriptModules().forEach(());
/*     */             }
/*     */             for (Module mod : modules) {
/*     */               if (!mod.getInfo().name().equalsIgnoreCase(module)) {
/*     */                 continue;
/*     */               }
/*     */               boolean next = false;
/*     */               if (Player.isInGame()) {
/*     */                 for (Select.Element elmt : this.window.getElement().getCategories().getElements()) {
/*     */                   if (mod.getInfo().type().getDisplayName().equals(elmt.getName()) && !elmt.get()) {
/*     */                     next = true;
/*     */                   }
/*     */                 } 
/*     */               }
/*     */               if (next) {
/*     */                 continue;
/*     */               }
/*     */               JSONObject mods = (JSONObject)((JSONObject)config.get("mods")).get(mod.getInfo().name());
/*     */               for (Setting set : mod.getSettings()) {
/*     */                 try {
/*     */                   loadSetting(set, mods);
/* 509 */                 } catch (Exception exception) {}
/*     */               }  if (mod instanceof Interface) {
/*     */                 Interface interfaceMod = (Interface)mod; if (!config.containsKey("ui")) {
/*     */                   for (Select.Element element : interfaceMod.getElements().getElements()) {
/*     */                     Interface.UIElement ui = (Interface.UIElement)element;
/*     */                     for (Setting set : ui.getSettings()) {
/*     */                       try {
/*     */                         Bindable patt0$temp = set.getParent();
/*     */                         if (patt0$temp instanceof Interface.UIElement) {
/*     */                           Interface.UIElement parent = (Interface.UIElement)patt0$temp;
/*     */                         } else {
/*     */                           return;
/*     */                         } 
/*     */                         loadSetting(set, mods);
/*     */                         JSONObject jSONObject = (JSONObject)((JSONObject)mods.get(set.getName())).get("binds");
/* 524 */                       } catch (Exception parent) {}
/*     */                     } 
/*     */                   } 
/*     */                 }
/*     */               } 
/*     */               
/*     */               try {
/*     */                 mod.set(((Boolean)mods.get("enabled")).booleanValue());
/* 532 */               } catch (Exception e) {
/*     */                 Debugger.print(e);
/*     */               } 
/*     */             } 
/*     */             if (module.equalsIgnoreCase("Interface")) {
/*     */               try {
/*     */                 JSONObject hud = (JSONObject)config.get("ui");
/*     */                 for (Select.Element element : ((Interface)rock.getModules().get(Interface.class)).getElements().getElements()) {
/*     */                   Interface.UIElement ui = (Interface.UIElement)element;
/*     */                   JSONObject elmt = (JSONObject)hud.get(element.getName());
/*     */                   for (Setting set : ui.getSettings()) {
/*     */                     try {
/*     */                       Bindable patt0$temp = set.getParent();
/*     */                       if (patt0$temp instanceof Interface.UIElement) {
/*     */                         Interface.UIElement parent = (Interface.UIElement)patt0$temp;
/*     */                       } else {
/*     */                         return;
/*     */                       } 
/*     */                       loadSetting(set, elmt);
/* 551 */                     } catch (Exception parent) {}
/*     */                   }
/*     */                 
/*     */                 } 
/* 555 */               } catch (Exception e) {
/*     */                 Debugger.print(e);
/*     */               } 
/*     */             }
/*     */             
/*     */             if (module.equalsIgnoreCase("ESP")) {
/*     */               try {
/*     */                 JSONObject esp = (JSONObject)config.get("esp");
/*     */                 
/*     */                 for (ESPElement elmt : rock.getEspSettingsHandler().getEspElements()) {
/*     */                   JSONObject element = (JSONObject)esp.get(elmt.getName());
/*     */                   
/*     */                   elmt.setDirection((int)((Long)element.get("direction")).longValue());
/*     */                   elmt.setActive(((Boolean)element.get("active")).booleanValue());
/*     */                 } 
/* 570 */               } catch (Exception e) {
/*     */                 Debugger.print(e);
/*     */               } 
/*     */             }
/*     */             
/*     */             if (module.equalsIgnoreCase("AutoBuy")) {
/*     */               try {
/*     */                 rock.getAutoBuy().getItems().clear();
/*     */                 
/*     */                 JSONArray itemsArray = (JSONArray)config.get("items");
/*     */                 if (itemsArray != null) {
/*     */                   for (Object itemObj : itemsArray) {
/*     */                     JSONObject itemJson = (JSONObject)itemObj;
/*     */                     AutoBuyItem item = AutoBuyItem.fromJson(itemJson);
/*     */                     rock.getAutoBuy().getItems().add(item);
/*     */                   } 
/*     */                 }
/* 587 */               } catch (Exception e) {
/*     */                 Debugger.print(e);
/*     */               } 
/*     */             }
/*     */             
/*     */             rock.getAlertHandler().alert("Модуль из конфига загружен", AlertType.INFO);
/*     */             
/*     */             EventHandler.resetConfig();
/* 595 */           } catch (Exception e) {
/*     */             Debugger.print(e);
/*     */             rock.getAlertHandler().alert("Ошибка при загрузке", AlertType.ERROR);
/*     */           } 
/*     */           alert.hide();
/*     */         });
/*     */   }
/*     */   
/*     */   public void delete(String name) {
/* 604 */     Alert alert = rock.getAlertHandler().alert("Удаляем ваш конфиг", AlertType.WAIT);
/*     */     
/* 606 */     ThreadManager.run(() -> {
/*     */           try {
/*     */             File configDir = new File((Minecraft.getInstance()).gameDir, "rock/configs");
/*     */             
/*     */             File configFile = new File(configDir, name + ".json");
/*     */             if (configFile.exists()) {
/*     */               configFile.delete();
/*     */               rock.getAlertHandler().alert("Конфиг удален", AlertType.INFO);
/*     */             } else {
/*     */               rock.getAlertHandler().alert("Конфиг не найден", AlertType.ERROR);
/*     */             } 
/* 617 */           } catch (Exception e) {
/*     */             Debugger.print(e);
/*     */             rock.getAlertHandler().alert("Ошибка при удалении", AlertType.ERROR);
/*     */           } 
/*     */           alert.hide();
/*     */         });
/*     */   }
/*     */   
/*     */   public void list() {
/* 626 */     Alert alert = rock.getAlertHandler().alert("Получаем список конфигов", AlertType.WAIT);
/*     */     
/* 628 */     ThreadManager.run(() -> {
/*     */           try {
/*     */             File configDir = new File((Minecraft.getInstance()).gameDir, "rock/configs");
/*     */             
/*     */             if (!configDir.exists()) {
/*     */               rock.getAlertHandler().alert("Папка конфигов не найдена", AlertType.INFO);
/*     */               
/*     */               alert.hide();
/*     */               
/*     */               return;
/*     */             } 
/*     */             File[] files = configDir.listFiles(());
/*     */             if (files == null || files.length == 0) {
/*     */               Chat.msg(String.valueOf(TextFormatting.AQUA) + "[Rockstar] " + String.valueOf(TextFormatting.AQUA) + "Нет доступных конфигов");
/*     */             } else {
/*     */               for (File file : files) {
/*     */                 String cfgName = file.getName().replace(".json", "");
/*     */                 Chat.msg(String.valueOf(TextFormatting.AQUA) + "[Rockstar] " + String.valueOf(TextFormatting.AQUA) + String.valueOf(TextFormatting.RESET), String.format("%sЗагрузить конфиг %s%s", new Object[] { TextFormatting.WHITE, TextFormatting.UNDERLINE, cfgName }), ());
/*     */               } 
/*     */             } 
/*     */             rock.getAlertHandler().alert("Список получен", AlertType.INFO);
/* 649 */           } catch (Exception e) {
/*     */             Debugger.print(e);
/*     */             rock.getAlertHandler().alert("Ошибка при получении списка", AlertType.ERROR);
/*     */           } 
/*     */           alert.hide();
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public void saveSetting(Setting set, JSONObject setting) {
/* 659 */     if (set instanceof Input) {
/* 660 */       setting.put("value", ((Input)set).get());
/*     */     }
/*     */     
/* 663 */     if (set instanceof CheckBox) {
/* 664 */       setting.put("value", Boolean.valueOf(((CheckBox)set).get()));
/* 665 */       setting.put("bind-value", Boolean.valueOf(((CheckBox)set).bind()));
/*     */     } 
/*     */     
/* 668 */     if (set instanceof Mode) { Mode mode = (Mode)set;
/* 669 */       setting.put("value", ((Mode)set).getMode().getName());
/* 670 */       setting.put("bind-value", ((Mode)set).bind().getName());
/*     */       
/* 672 */       for (Mode.Element elmt : mode.getElements()) {
/* 673 */         if (elmt.hasSettings()) {
/* 674 */           JSONObject settings = new JSONObject();
/*     */           
/* 676 */           for (Setting set1 : elmt.getSettings()) {
/* 677 */             JSONObject setting1 = new JSONObject();
/*     */             
/* 679 */             saveSetting(set1, setting1);
/*     */             
/* 681 */             if (set1 instanceof Select) { Select select = (Select)set1;
/* 682 */               JSONObject selects = new JSONObject();
/* 683 */               for (Select.Element elmt1 : select.getElements()) {
/* 684 */                 JSONObject jSONObject = new JSONObject();
/* 685 */                 for (Bind bind : elmt1.getBinds()) {
/* 686 */                   jSONObject.put("" + bind.getKey() + ":" + bind.getKey(), bind.getType().getName());
/*     */                 }
/* 688 */                 selects.put(elmt1.getName(), jSONObject);
/*     */               } 
/* 690 */               setting1.put("selects", selects); }
/*     */ 
/*     */             
/* 693 */             JSONObject binds = new JSONObject();
/* 694 */             for (Bind bind : set1.getBinds()) {
/* 695 */               binds.put("" + bind.getKey() + ":" + bind.getKey(), bind.getType().getName());
/*     */             }
/*     */             
/* 698 */             setting1.put("binds", binds);
/* 699 */             settings.put(set1.getName(), setting1);
/*     */           } 
/*     */           
/* 702 */           setting.put(elmt.getName() + "-settings", settings);
/*     */         } 
/*     */       }  }
/*     */ 
/*     */     
/* 707 */     if (set instanceof ColorPicker) { ColorPicker picker = (ColorPicker)set;
/* 708 */       JSONObject colors = new JSONObject();
/*     */       
/* 710 */       for (FixColor color : picker.getColors()) {
/* 711 */         colors.put(Integer.valueOf(picker.getColors().indexOf(color)), "" + color.getRed() + ":" + color.getRed() + ":" + color.getGreen());
/*     */       }
/*     */       
/* 714 */       setting.put("value", colors);
/* 715 */       setting.put("client", Boolean.valueOf(picker.isClient())); }
/*     */ 
/*     */     
/* 718 */     if (set instanceof Select) { Select sel = (Select)set;
/* 719 */       JSONObject select = new JSONObject();
/* 720 */       for (Select.Element elmt : ((Select)set).getElements()) {
/* 721 */         select.put(elmt.getName(), Boolean.valueOf(elmt.get()));
/*     */       }
/* 723 */       setting.put("value", select);
/*     */       
/* 725 */       for (Select.Element elmt : sel.getElements()) {
/* 726 */         if (elmt.hasSettings()) {
/* 727 */           JSONObject settings = new JSONObject();
/*     */           
/* 729 */           for (Setting set1 : elmt.getSettings()) {
/* 730 */             JSONObject setting1 = new JSONObject();
/*     */             
/* 732 */             saveSetting(set1, setting1);
/*     */             
/* 734 */             if (set1 instanceof Select) { Select select1 = (Select)set1;
/* 735 */               JSONObject selects = new JSONObject();
/* 736 */               for (Select.Element elmt1 : select1.getElements()) {
/* 737 */                 JSONObject jSONObject = new JSONObject();
/* 738 */                 for (Bind bind : elmt1.getBinds()) {
/* 739 */                   jSONObject.put("" + bind.getKey() + ":" + bind.getKey(), bind.getType().getName());
/*     */                 }
/* 741 */                 selects.put(elmt1.getName(), jSONObject);
/*     */               } 
/* 743 */               setting1.put("selects", selects); }
/*     */ 
/*     */             
/* 746 */             JSONObject binds = new JSONObject();
/* 747 */             for (Bind bind : set1.getBinds()) {
/* 748 */               binds.put("" + bind.getKey() + ":" + bind.getKey(), bind.getType().getName());
/*     */             }
/*     */             
/* 751 */             setting1.put("binds", binds);
/* 752 */             settings.put(set1.getName(), setting1);
/*     */           } 
/*     */           
/* 755 */           setting.put(elmt.getName() + "-settings", settings);
/*     */         } 
/*     */       }  }
/*     */ 
/*     */     
/* 760 */     if (set instanceof Slider) {
/* 761 */       setting.put("value", Float.valueOf(((Slider)set).get()));
/* 762 */       setting.put("bind-value", Float.valueOf(((Slider)set).bind()));
/*     */     } 
/*     */     
/* 765 */     if (set instanceof Position) {
/* 766 */       setting.put("value", "" + ((Position)set).getX() + ":" + ((Position)set).getX());
/* 767 */       setting.put("bind-value", "" + ((Position)set).getBindX() + ":" + ((Position)set).getBindX());
/*     */     } 
/*     */     
/* 770 */     if (set instanceof ItemSelect) { ItemSelect sel = (ItemSelect)set;
/* 771 */       JSONObject select = new JSONObject();
/* 772 */       for (MinecraftItem elmt : sel.getItems()) {
/* 773 */         select.put(elmt.getName(), Boolean.valueOf(true));
/*     */       }
/* 775 */       setting.put("value", select); }
/*     */ 
/*     */     
/* 778 */     if (set.hasSettings()) {
/* 779 */       for (Setting set1 : set.getSettings()) {
/* 780 */         JSONObject setting1 = new JSONObject();
/*     */         
/* 782 */         saveSetting(set1, setting1);
/*     */         
/* 784 */         if (set1 instanceof Select) { Select select = (Select)set1;
/* 785 */           JSONObject selects = new JSONObject();
/* 786 */           for (Select.Element elmt : select.getElements()) {
/* 787 */             JSONObject jSONObject = new JSONObject();
/* 788 */             for (Bind bind : elmt.getBinds()) {
/* 789 */               jSONObject.put("" + bind.getKey() + ":" + bind.getKey(), bind.getType().getName());
/*     */             }
/* 791 */             selects.put(elmt.getName(), jSONObject);
/*     */           } 
/* 793 */           setting1.put("selects", selects); }
/*     */ 
/*     */         
/* 796 */         JSONObject binds = new JSONObject();
/* 797 */         for (Bind bind : set1.getBinds()) {
/* 798 */           binds.put("" + bind.getKey() + ":" + bind.getKey(), bind.getType().getName());
/*     */         }
/*     */         
/* 801 */         setting1.put("binds", binds);
/* 802 */         setting.put(set1.getName(), setting1);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void loadSetting(Setting set, JSONObject mods) {
/* 809 */     boolean loadBinds = (this.window.getElement().getLoadBinds().get() || !Player.isInGame());
/*     */     
/* 811 */     if (set instanceof Input) {
/* 812 */       ((Input)set).getInput().setText((String)((JSONObject)mods.get(set.getName())).get("value"));
/* 813 */       ((Input)set).set((String)((JSONObject)mods.get(set.getName())).get("value"));
/*     */     } 
/*     */     
/* 816 */     if (set instanceof CheckBox) {
/* 817 */       ((CheckBox)set).set(((Boolean)((JSONObject)mods.get(set.getName())).get("value")).booleanValue());
/* 818 */       ((CheckBox)set).bind(((Boolean)((JSONObject)mods.get(set.getName())).get("bind-value")).booleanValue());
/*     */     } 
/*     */     
/* 821 */     if (set instanceof Mode) { Mode mode = (Mode)set;
/* 822 */       ((Mode)set).set((String)((JSONObject)mods.get(set.getName())).get("value"));
/* 823 */       ((Mode)set).bind((String)((JSONObject)mods.get(set.getName())).get("bind-value"));
/*     */       
/* 825 */       for (Mode.Element elmt : mode.getElements()) {
/* 826 */         if (elmt.hasSettings()) {
/* 827 */           for (Setting set1 : elmt.getSettings()) {
/* 828 */             JSONObject setting1 = new JSONObject();
/*     */             
/* 830 */             JSONObject elmt1 = (JSONObject)((JSONObject)mods.get(set.getName())).get(elmt.getName() + "-settings");
/*     */             
/* 832 */             loadSetting(set1, elmt1);
/*     */             
/* 834 */             if (loadBinds) {
/* 835 */               JSONObject binds = (JSONObject)((JSONObject)elmt1.get(set1.getName())).get("binds");
/* 836 */               set1.getBinds().clear();
/* 837 */               for (Object bind : binds.keySet()) {
/* 838 */                 set1.getBinds().add(new Bind(Integer.parseInt(String.valueOf(bind).split(":")[0]), Integer.parseInt(String.valueOf(bind).split(":")[1]), BindType.get(String.valueOf(binds.get(bind)))));
/*     */               }
/*     */             } 
/*     */           } 
/*     */         }
/*     */       }  }
/*     */ 
/*     */     
/* 846 */     if (set instanceof ColorPicker) { ColorPicker picker = (ColorPicker)set;
/* 847 */       picker.getColors().clear();
/*     */       
/* 849 */       JSONObject colors = (JSONObject)((JSONObject)mods.get(set.getName())).get("value");
/*     */       
/* 851 */       for (Object color : colors.values()) {
/* 852 */         String[] rgb = ((String)color).split(":");
/* 853 */         picker.add(new FixColor[] { new FixColor(Integer.parseInt(rgb[0]), Integer.parseInt(rgb[1]), Integer.parseInt(rgb[2])) });
/*     */       } 
/*     */       
/* 856 */       picker.set(((Boolean)((JSONObject)mods.get(set.getName())).get("client")).booleanValue()); }
/*     */ 
/*     */     
/* 859 */     if (set instanceof Select) {
/* 860 */       JSONObject select = (JSONObject)mods.get(set.getName());
/* 861 */       for (Select.Element elmt : ((Select)set).getElements()) {
/* 862 */         elmt.set(((Boolean)((JSONObject)select.get("value")).get(elmt.getName())).booleanValue(), true);
/*     */       }
/*     */       
/* 865 */       for (Select.Element elmt : ((Select)set).getElements()) {
/* 866 */         if (elmt.hasSettings()) {
/* 867 */           for (Setting set1 : elmt.getSettings()) {
/*     */             try {
/* 869 */               JSONObject setting1 = new JSONObject();
/*     */               
/* 871 */               JSONObject elmt1 = (JSONObject)select.get(elmt.getName() + "-settings");
/*     */               
/* 873 */               loadSetting(set1, elmt1);
/*     */               
/* 875 */               if (loadBinds) {
/* 876 */                 JSONObject binds = (JSONObject)((JSONObject)elmt1.get(set1.getName())).get("binds");
/*     */                 
/* 878 */                 set1.getBinds().clear();
/* 879 */                 for (Object bind : binds.keySet()) {
/* 880 */                   set1.getBinds().add(new Bind(Integer.parseInt(String.valueOf(bind).split(":")[0]), Integer.parseInt(String.valueOf(bind).split(":")[1]), BindType.get(String.valueOf(binds.get(bind)))));
/*     */                 }
/*     */               } 
/* 883 */             } catch (Exception e) {
/* 884 */               e.printStackTrace();
/*     */             } 
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 891 */     if (set instanceof Slider) {
/* 892 */       ((Slider)set).set(Float.parseFloat(String.valueOf(((JSONObject)mods.get(set.getName())).get("value"))));
/* 893 */       ((Slider)set).bind(Float.parseFloat(String.valueOf(((JSONObject)mods.get(set.getName())).get("bind-value"))));
/*     */     } 
/*     */     
/* 896 */     if (set instanceof Position) {
/* 897 */       ((Position)set).x(Float.parseFloat(String.valueOf(((JSONObject)mods.get(set.getName())).get("value")).split(":")[0]));
/* 898 */       ((Position)set).y(Float.parseFloat(String.valueOf(((JSONObject)mods.get(set.getName())).get("value")).split(":")[1]));
/*     */       
/* 900 */       ((Position)set).bindX(Float.parseFloat(String.valueOf(((JSONObject)mods.get(set.getName())).get("bind-value")).split(":")[0]));
/* 901 */       ((Position)set).bindY(Float.parseFloat(String.valueOf(((JSONObject)mods.get(set.getName())).get("bind-value")).split(":")[1]));
/*     */     } 
/*     */     
/* 904 */     if (set instanceof ItemSelect) { ItemSelect sel = (ItemSelect)set;
/* 905 */       JSONObject select = (JSONObject)((JSONObject)mods.get(set.getName())).get("value");
/* 906 */       sel.getItems().clear();
/*     */       
/* 908 */       for (MinecraftItem elmt : Items.getMinecraftItems()) {
/* 909 */         if (select.get(elmt.getName()) != null) {
/* 910 */           sel.getItems().add(elmt);
/*     */         }
/*     */       }  }
/*     */     
/* 914 */     if (set.hasSettings())
/* 915 */       for (Setting set1 : set.getSettings()) {
/* 916 */         JSONObject setting1 = new JSONObject();
/*     */         
/* 918 */         JSONObject elmt = (JSONObject)mods.get(set.getName());
/*     */         
/* 920 */         loadSetting(set1, elmt);
/*     */         
/* 922 */         if (loadBinds) {
/* 923 */           JSONObject binds = (JSONObject)((JSONObject)elmt.get(set1.getName())).get("binds");
/*     */           
/* 925 */           set1.getBinds().clear();
/* 926 */           for (Object bind : binds.keySet())
/* 927 */             set1.getBinds().add(new Bind(Integer.parseInt(String.valueOf(bind).split(":")[0]), Integer.parseInt(String.valueOf(bind).split(":")[1]), BindType.get(String.valueOf(binds.get(bind))))); 
/*     */         } 
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\configs\ConfigsHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */