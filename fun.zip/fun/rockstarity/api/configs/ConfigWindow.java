/*     */ package fun.rockstarity.api.configs;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import fun.rockstarity.api.events.Event;
/*     */ import fun.rockstarity.api.events.list.game.EventChatScreen;
/*     */ import fun.rockstarity.api.helpers.math.Hover;
/*     */ import fun.rockstarity.api.helpers.render.Stencil;
/*     */ import fun.rockstarity.api.modules.settings.Setting;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.shaders.list.Outline;
/*     */ import fun.rockstarity.api.render.shaders.list.Round;
/*     */ import fun.rockstarity.api.render.ui.clickgui.SettingRect;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import fun.rockstarity.api.render.ui.widgets.Window;
/*     */ import fun.rockstarity.client.modules.render.Interface;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ public class ConfigWindow
/*     */   extends Window
/*     */ {
/*     */   private final ConfigWrapper element;
/*     */   
/*     */   public ConfigWrapper getElement() {
/*  27 */     return this.element;
/*  28 */   } private boolean canRender; private final List<SettingRect> settings = new ArrayList<>(); public List<SettingRect> getSettings() { return this.settings; } public boolean isCanRender() {
/*  29 */     return this.canRender;
/*     */   }
/*     */   public ConfigWindow(ConfigWrapper element) {
/*  32 */     super(165.0F, (sr.getScaledHeight() / 2 - 100), 145.0F, 10.0F);
/*     */     
/*  34 */     this.element = element;
/*     */     
/*  36 */     for (Setting setting : element.getSettings()) {
/*  37 */       this.settings.add(new SettingRect(setting));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/*  43 */     if (this.opening.finished(false) || !this.canRender)
/*  44 */       return;  Interface ui = (Interface)rock.getModules().get(Interface.class);
/*     */     
/*  46 */     GL11.glPushMatrix();
/*  47 */     GL11.glTranslated(0.0D, 0.0D, 999.0D);
/*     */     
/*  49 */     this.x = sr.getScaledWidth() - this.width - 5.0F;
/*  50 */     this.y = sr.getScaledHeight() - this.height - 20.0F;
/*     */     
/*  52 */     Round.draw(matrixStack, (Rect)this, 8.0F, rock.getThemes().getFirstColor().alpha(this.opening.get()));
/*     */     
/*  54 */     String title = "Настройки загрузки конфига";
/*  55 */     bold.get(15).draw(matrixStack, title, this.x + this.width / 2.0F - bold.get(15).getWidth(title) / 2.0F, this.y - 13.0F, FixColor.WHITE.alpha(this.opening.get()));
/*     */     
/*  57 */     Stencil.init();
/*  58 */     Round.draw(matrixStack, (Rect)this, 8.0F, rock.getThemes().getFirstColor().alpha(this.opening.get()));
/*  59 */     Stencil.read(1);
/*     */     
/*  61 */     float yOff = 0.0F;
/*  62 */     for (SettingRect setting : this.settings) {
/*  63 */       setting.getHide().setForward(setting.getParent().isHide());
/*     */       
/*  65 */       setting.set(this.x, this.y + yOff - 2.0F - 10.0F + 10.0F * this.opening.get() * (1.0F - setting.getHide().get()), 145.0F, setting.getHeight());
/*  66 */       setting.render(matrixStack, mouseX, mouseY, partialTicks, this.opening.get() * (1.0F - setting.getHide().get()), false, false);
/*     */       
/*  68 */       yOff += (setting.getHeight() - 13.0F) * (1.0F - setting.getHide().get());
/*     */     } 
/*  70 */     Stencil.finish();
/*     */     
/*  72 */     Outline.draw(matrixStack, y(getY()).size(-0.25F), 8.0F, ui.getOutlineWidth().get() / 4.0F, rock.getThemes().getFoursColor().alpha(this.opening.get()));
/*     */     
/*  74 */     GL11.glPopMatrix();
/*     */     
/*  76 */     this.height = yOff + 10.0F;
/*     */   }
/*     */   
/*     */   public void onEvent(Event event) {
/*  80 */     if (event instanceof EventChatScreen) { EventChatScreen e = (EventChatScreen)event;
/*  81 */       boolean can = (e.getField().getText().contains(".cfg load") || e.getField().getText().contains(".config load"));
/*  82 */       this.opening.setForward(can);
/*  83 */       if (can) {
/*  84 */         this.canRender = true;
/*     */       } }
/*     */     
/*  87 */     if (event instanceof fun.rockstarity.api.events.list.player.EventUpdate && mc.currentScreen == null) {
/*  88 */       this.opening.setForward(false);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean clicked(double mouseX, double mouseY, int button) {
/*  94 */     if (!Hover.isHovered(this.x, this.y, this.width, this.height, mouseX, mouseY) || button != 0) {
/*  95 */       return super.released(mouseX, mouseY, button);
/*     */     }
/*     */     
/*  98 */     float yOff = 0.0F;
/*  99 */     for (SettingRect setting : this.settings) {
/* 100 */       if (Hover.isHovered(setting.y(this.y + yOff - 2.0F - 10.0F + 10.0F * this.opening.get() + 3.0F).height(setting.getHeight() - 14.0F), mouseX, mouseY)) {
/* 101 */         setting.clicked(mouseX, mouseY, button, false);
/*     */       }
/*     */       
/* 104 */       yOff += (setting.getHeight() - 13.0F) * (1.0F - setting.getHide().get());
/*     */     } 
/*     */     
/* 107 */     return super.clicked(mouseX, mouseY, button);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean released(double mouseX, double mouseY, int button) {
/* 112 */     if (button != 0) return super.clicked(mouseX, mouseY, button);
/*     */     
/* 114 */     for (SettingRect setting : this.settings) {
/* 115 */       if (setting.getParent().isHide()) {
/*     */         continue;
/*     */       }
/* 118 */       setting.clicked(mouseX, mouseY, button, true);
/*     */     } 
/*     */     
/* 121 */     return super.released(mouseX, mouseY, button);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean pressed(int keyCode, int scanCode, int modifiers) {
/* 126 */     for (SettingRect setting : this.settings) {
/* 127 */       if (setting.getParent().isHide()) {
/*     */         continue;
/*     */       }
/* 130 */       setting.pressed(keyCode, scanCode, modifiers);
/*     */     } 
/* 132 */     return false;
/*     */   }
/*     */   
/*     */   public void tick() {
/* 136 */     for (SettingRect setting : this.settings) {
/* 137 */       if (setting.getParent().isHide()) {
/*     */         continue;
/*     */       }
/* 140 */       setting.tick();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void charTyped(char codePoint, int modifiers) {
/* 145 */     for (SettingRect setting : this.settings) {
/* 146 */       if (setting.getParent().isHide()) {
/*     */         continue;
/*     */       }
/* 149 */       setting.charTyped(codePoint, modifiers);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\configs\ConfigWindow.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */