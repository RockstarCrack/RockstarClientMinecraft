/*     */ package fun.rockstarity.api.configs;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.GsonBuilder;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParser;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.binds.Bind;
/*     */ import fun.rockstarity.api.binds.BindType;
/*     */ import fun.rockstarity.api.friends.Friend;
/*     */ import fun.rockstarity.api.helpers.game.Binds;
/*     */ import fun.rockstarity.api.helpers.game.GameUtility;
/*     */ import fun.rockstarity.api.modules.settings.Setting;
/*     */ import fun.rockstarity.api.modules.settings.list.Select;
/*     */ import fun.rockstarity.api.render.ui.draggables.Draggable;
/*     */ import fun.rockstarity.api.render.ui.mainmenu.Page;
/*     */ import fun.rockstarity.api.render.ui.mainmenu.alt.Alt;
/*     */ import fun.rockstarity.api.render.ui.mainmenu.screens.AltScreen;
/*     */ import fun.rockstarity.api.scripts.Script;
/*     */ import fun.rockstarity.api.secure.Debugger;
/*     */ import fun.rockstarity.client.commands.InventoryCommand;
/*     */ import fun.rockstarity.client.commands.MacroCommand;
/*     */ import fun.rockstarity.client.commands.ScoreCommand;
/*     */ import fun.rockstarity.client.commands.WayCommand;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import org.json.simple.JSONObject;
/*     */ import org.json.simple.parser.JSONParser;
/*     */ import ru.kotopushka.antiautistleak.obfuscator.includes.annotations.compile.ReleaseCompileToNativeCalls;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ReleaseCompileToNativeCalls
/*     */ public class ClientConfigHandler
/*     */   implements IAccess
/*     */ {
/*  51 */   private static final Gson GSON = (new GsonBuilder()).setPrettyPrinting().create();
/*  52 */   private static final File CONFIG_FILE = new File((Minecraft.getInstance()).gameDir, "rockstar/config.json");
/*     */ 
/*     */   
/*     */   public void load() {
/*     */     try {
/*  57 */       File configDir = CONFIG_FILE.getParentFile();
/*  58 */       if (!configDir.exists()) {
/*  59 */         configDir.mkdirs();
/*     */       }
/*     */ 
/*     */       
/*  63 */       if (!CONFIG_FILE.exists()) {
/*  64 */         Debugger.print(new IOException("Config file not found: " + CONFIG_FILE.getPath()));
/*     */         
/*     */         return;
/*     */       } 
/*  68 */       StringBuilder encryptedContent = new StringBuilder();
/*  69 */       FileReader reader = new FileReader(CONFIG_FILE); 
/*     */       try { int c;
/*  71 */         while ((c = reader.read()) != -1) {
/*  72 */           encryptedContent.append((char)c);
/*     */         }
/*  74 */         reader.close(); } catch (Throwable throwable) { try { reader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */          throw throwable; }
/*  76 */        JsonObject info = (JsonObject)GSON.fromJson(encryptedContent.toString().trim(), JsonObject.class);
/*     */       
/*  78 */       if (info == null) {
/*  79 */         Debugger.print(new Exception("Failed to load client config: null JSON"));
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*  84 */       if (info.has("macroses")) {
/*  85 */         JsonObject macroses = info.getAsJsonObject("macroses");
/*  86 */         for (Map.Entry<String, JsonElement> entry : (Iterable<Map.Entry<String, JsonElement>>)macroses.entrySet()) {
/*  87 */           MacroCommand.getMacroses().add(new MacroCommand.Macro(entry
/*  88 */                 .getKey(), ((Integer)Binds.KEYS
/*  89 */                 .get(((String)entry.getKey()).toLowerCase())).intValue(), ((JsonElement)entry
/*  90 */                 .getValue()).getAsString()));
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*  96 */       if (info.has("scoreboard")) {
/*  97 */         JsonObject scoreboard = info.getAsJsonObject("scoreboard");
/*  98 */         for (Map.Entry<String, JsonElement> entry : (Iterable<Map.Entry<String, JsonElement>>)scoreboard.entrySet()) {
/*  99 */           ScoreCommand.getScores().add(new ScoreCommand.Line(entry.getKey(), ((JsonElement)entry.getValue()).getAsString()));
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 104 */       if (info.has("scripts")) {
/* 105 */         JsonObject scripts = info.getAsJsonObject("scripts");
/* 106 */         for (Script script : rock.getScriptHandler().getScripts()) {
/* 107 */           if (scripts.has(script.getName())) {
/* 108 */             script.setEnabled(scripts.get(script.getName()).getAsBoolean());
/* 109 */             if (script.isEnabled()) script.load();
/*     */           
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 115 */       if (info.has("draggables")) {
/* 116 */         JsonObject draggables = info.getAsJsonObject("draggables");
/* 117 */         for (Draggable draggable : rock.getDraggableHandler().getDraggables()) {
/* 118 */           if (draggables.has(draggable.getName())) {
/* 119 */             JsonObject dragData = draggables.getAsJsonObject(draggable.getName());
/*     */             try {
/* 121 */               draggable.load((JsonElement)dragData);
/* 122 */             } catch (Exception e) {
/* 123 */               Debugger.print(new Exception("Failed to load draggable: " + draggable.getName(), e));
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 130 */       if (info.has("username")) {
/* 131 */         GameUtility.changeName(info.get("username").getAsString());
/*     */       }
/*     */ 
/*     */       
/* 135 */       if (info.has("via")) {
/* 136 */         rock.getVia().getViaScreen().setText(info.get("via").getAsString());
/*     */       }
/*     */ 
/*     */       
/* 140 */       if (info.has("waypoints")) {
/* 141 */         ((WayCommand)rock.getCommands().get(WayCommand.class)).load(info.getAsJsonObject("waypoints"));
/*     */       }
/*     */ 
/*     */       
/* 145 */       if (info.has("inventory")) {
/* 146 */         ((InventoryCommand)rock.getCommands().get(InventoryCommand.class)).load((JsonElement)info.getAsJsonObject("inventory"));
/*     */       }
/*     */ 
/*     */       
/* 150 */       if (info.has("alts")) {
/* 151 */         JsonObject alts = info.getAsJsonObject("alts");
/* 152 */         AltScreen altScreen = (AltScreen)Page.ALT.getScreen();
/* 153 */         for (Map.Entry<String, JsonElement> entry : (Iterable<Map.Entry<String, JsonElement>>)alts.entrySet()) {
/*     */           try {
/* 155 */             altScreen.getAlts().add(Alt.load(((JsonElement)entry.getValue()).getAsJsonObject()));
/* 156 */           } catch (Exception e) {
/* 157 */             Debugger.print(new Exception("Failed to load alt: " + (String)entry.getKey(), e));
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 163 */       if (info.has("config")) {
/* 164 */         rock.setCfgToLoad(info.get("config").getAsString());
/*     */       }
/*     */ 
/*     */       
/* 168 */       if (info.has("hideinfo")) {
/* 169 */         rock.setHideInfo(info.get("hideinfo").getAsBoolean());
/*     */       }
/*     */ 
/*     */       
/* 173 */       if (info.has("friends")) {
/* 174 */         JsonObject friendsJson = info.getAsJsonObject("friends");
/* 175 */         for (Map.Entry<String, JsonElement> entry : (Iterable<Map.Entry<String, JsonElement>>)friendsJson.entrySet()) {
/* 176 */           rock.getFriendsHandler().getFriends().add(new Friend(entry.getKey()));
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 181 */       if (info.has("targets")) {
/* 182 */         String[] targetsArray = info.get("targets").getAsString().split(",");
/* 183 */         for (String target : targetsArray) {
/* 184 */           String trimmedTarget = target.trim();
/* 185 */           if (!trimmedTarget.isEmpty() && !rock.getTargetHandler().getTarget().contains(trimmedTarget)) {
/* 186 */             rock.getTargetHandler().getTarget().add(trimmedTarget);
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 192 */       if (info.has("configs")) {
/* 193 */         ConfigWrapper wrapper = rock.getConfigHandler().getWindow().getElement();
/* 194 */         ConfigsHandler configs = rock.getConfigHandler();
/* 195 */         JsonObject jsonConfigs = info.getAsJsonObject("configs");
/* 196 */         JSONObject config = (JSONObject)(new JSONParser()).parse(jsonConfigs.toString());
/*     */         
/* 198 */         for (Setting set : wrapper.getSettings()) {
/* 199 */           set.getBinds().clear();
/*     */           try {
/* 201 */             configs.loadSetting(set, config);
/*     */             
/* 203 */             if (set instanceof Select) { Select select = (Select)set;
/* 204 */               JSONObject selects = (JSONObject)((JSONObject)config.get(set.getName())).get("selects");
/* 205 */               for (Select.Element elmt : select.getElements()) {
/* 206 */                 elmt.getBinds().clear();
/* 207 */                 JSONObject jSONObject = (JSONObject)selects.get(elmt.getName());
/*     */                 
/* 209 */                 for (Object bind : jSONObject.keySet()) {
/* 210 */                   elmt.getBinds().add(new Bind(
/* 211 */                         Integer.parseInt(String.valueOf(bind).split(":")[0]), 
/* 212 */                         Integer.parseInt(String.valueOf(bind).split(":")[1]), 
/* 213 */                         BindType.get(String.valueOf(jSONObject.get(bind)))));
/*     */                 }
/*     */               }  }
/*     */ 
/*     */ 
/*     */             
/* 219 */             JSONObject binds = (JSONObject)((JSONObject)config.get(set.getName())).get("binds");
/*     */             
/* 221 */             for (Object bind : binds.keySet()) {
/* 222 */               set.getBinds().add(new Bind(
/* 223 */                     Integer.parseInt(String.valueOf(bind).split(":")[0]), 
/* 224 */                     Integer.parseInt(String.valueOf(bind).split(":")[1]), 
/* 225 */                     BindType.get(String.valueOf(binds.get(bind)))));
/*     */             }
/*     */           }
/* 228 */           catch (Exception e) {
/* 229 */             Debugger.print(new Exception("Failed to load setting: " + set.getName(), e));
/*     */           } 
/*     */         } 
/*     */       } 
/* 233 */     } catch (Exception e) {
/* 234 */       Debugger.print(new Exception("Failed to load client config", e));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void save() {
/* 239 */     if (rock.isPanic())
/*     */       return; 
/* 241 */     JsonObject info = new JsonObject();
/* 242 */     info.addProperty("username", mc.getSession().getUsername());
/* 243 */     info.addProperty("via", rock.getVia().getViaScreen().getText());
/* 244 */     info.addProperty("config", rock.getConfigHandler().getCurrent());
/* 245 */     info.add("waypoints", (JsonElement)((WayCommand)rock.getCommands().get(WayCommand.class)).save());
/* 246 */     info.add("inventory", (JsonElement)((InventoryCommand)rock.getCommands().get(InventoryCommand.class)).save());
/* 247 */     info.addProperty("hideinfo", Boolean.valueOf(rock.isHideInfo()));
/* 248 */     info.addProperty("targets", String.join(",", rock.getTargetHandler().getTarget()));
/*     */ 
/*     */     
/* 251 */     JsonObject macroses = new JsonObject();
/* 252 */     for (MacroCommand.Macro macro : MacroCommand.getMacroses()) {
/* 253 */       macroses.addProperty(macro.getName(), macro.getMsg().trim());
/*     */     }
/* 255 */     info.add("macroses", (JsonElement)macroses);
/*     */ 
/*     */     
/* 258 */     JsonObject scoreboard = new JsonObject();
/* 259 */     for (ScoreCommand.Line line : ScoreCommand.getScores()) {
/* 260 */       scoreboard.addProperty(line.getOriginal(), line.getNewVal());
/*     */     }
/* 262 */     info.add("scoreboard", (JsonElement)scoreboard);
/*     */ 
/*     */     
/* 265 */     JsonObject draggablesJson = new JsonObject();
/* 266 */     for (Draggable draggable : rock.getDraggableHandler().getDraggables()) {
/* 267 */       draggablesJson.add(draggable.getName(), draggable.save());
/*     */     }
/* 269 */     info.add("draggables", (JsonElement)draggablesJson);
/*     */ 
/*     */     
/* 272 */     JsonObject scripts = new JsonObject();
/* 273 */     for (Script script : rock.getScriptHandler().getEnabledScripts()) {
/* 274 */       scripts.addProperty(script.getName(), Boolean.valueOf(script.isEnabled()));
/*     */     }
/* 276 */     info.add("scripts", (JsonElement)scripts);
/*     */ 
/*     */     
/* 279 */     JsonObject alts = new JsonObject();
/* 280 */     AltScreen altScreen = (AltScreen)Page.ALT.getScreen();
/* 281 */     for (int i = 0; i < altScreen.getAlts().size(); i++) {
/* 282 */       alts.add(String.valueOf(i), (JsonElement)((Alt)altScreen.getAlts().get(i)).save());
/*     */     }
/* 284 */     info.add("alts", (JsonElement)alts);
/*     */ 
/*     */     
/* 287 */     JsonObject friendsJson = new JsonObject();
/* 288 */     for (Friend friend : rock.getFriendsHandler().getFriends()) {
/* 289 */       friendsJson.add(friend.getName(), friend.save());
/*     */     }
/* 291 */     info.add("friends", (JsonElement)friendsJson);
/*     */ 
/*     */     
/* 294 */     ConfigWrapper wrapper = rock.getConfigHandler().getWindow().getElement();
/* 295 */     ConfigsHandler configs = rock.getConfigHandler();
/* 296 */     JSONObject config = new JSONObject();
/*     */     
/* 298 */     for (Setting set : wrapper.getSettings()) {
/* 299 */       JSONObject setting = new JSONObject();
/* 300 */       configs.saveSetting(set, setting);
/*     */       
/* 302 */       if (set instanceof Select) { Select select = (Select)set;
/* 303 */         JSONObject selects = new JSONObject();
/* 304 */         for (Select.Element elmt : select.getElements()) {
/* 305 */           JSONObject jSONObject = new JSONObject();
/* 306 */           for (Bind bind : elmt.getBinds()) {
/* 307 */             jSONObject.put("" + bind.getKey() + ":" + bind.getKey(), bind.getType().getName());
/*     */           }
/* 309 */           selects.put(elmt.getName(), jSONObject);
/*     */         } 
/* 311 */         setting.put("selects", selects); }
/*     */ 
/*     */       
/* 314 */       JSONObject binds = new JSONObject();
/* 315 */       for (Bind bind : set.getBinds()) {
/* 316 */         binds.put("" + bind.getKey() + ":" + bind.getKey(), bind.getType().getName());
/*     */       }
/*     */       
/* 319 */       setting.put("binds", binds);
/* 320 */       config.put(set.getName(), setting);
/*     */     } 
/*     */     
/* 323 */     info.add("configs", (JsonElement)(new JsonParser()).parse(config.toString()).getAsJsonObject());
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 328 */       File configDir = CONFIG_FILE.getParentFile();
/* 329 */       if (!configDir.exists()) {
/* 330 */         configDir.mkdirs();
/*     */       }
/*     */ 
/*     */       
/* 334 */       String json = GSON.toJson((JsonElement)info);
/* 335 */       FileWriter writer = new FileWriter(CONFIG_FILE); 
/* 336 */       try { writer.write(json);
/* 337 */         writer.close(); } catch (Throwable throwable) { try { writer.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; } 
/* 338 */     } catch (Exception e) {
/* 339 */       Debugger.print(new Exception("Failed to save client config", e));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\configs\ClientConfigHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */