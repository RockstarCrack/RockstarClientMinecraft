/*    */ package fun.rockstarity.api.configs;
/*    */ 
/*    */ import fun.rockstarity.api.binds.Bindable;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.modules.Category;
/*    */ import fun.rockstarity.api.modules.Module;
/*    */ import fun.rockstarity.api.modules.settings.list.CheckBox;
/*    */ import fun.rockstarity.api.modules.settings.list.Select;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigWrapper
/*    */   extends Module
/*    */ {
/* 21 */   private final CheckBox loadBinds = (new CheckBox((Bindable)this, "Загружать бинды")).set(true); public CheckBox getLoadBinds() { return this.loadBinds; }
/*    */   
/* 23 */   private final Select categories = new Select((Bindable)this, "Загружать категории"); public Select getCategories() { return this.categories; }
/*    */   
/*    */   public ConfigWrapper() {
/* 26 */     for (Category type : Category.values()) {
/* 27 */       if (type != Category.THEMES)
/* 28 */         (new Select.Element(this.categories, type.getDisplayName())).set(true); 
/*    */     } 
/*    */   }
/*    */   
/*    */   public void onEvent(Event event) {}
/*    */   
/*    */   public void onEnable() {}
/*    */   
/*    */   public void onDisable() {}
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\configs\ConfigWrapper.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */