/*     */ package fun.rockstarity.api.autobuy.ui;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.autobuy.logic.items.AutoBuyItem;
/*     */ import fun.rockstarity.api.autobuy.logic.items.MinecraftItem;
/*     */ import fun.rockstarity.api.helpers.math.Hover;
/*     */ import fun.rockstarity.api.helpers.render.Render;
/*     */ import fun.rockstarity.api.helpers.render.Stencil;
/*     */ import fun.rockstarity.api.render.animation.Animation;
/*     */ import fun.rockstarity.api.render.animation.Easing;
/*     */ import fun.rockstarity.api.render.animation.infinity.InfinityAnimation;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.color.themes.Style;
/*     */ import fun.rockstarity.api.render.shaders.list.Round;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import fun.rockstarity.api.render.ui.widgets.InputWidget;
/*     */ import fun.rockstarity.api.render.ui.widgets.NumberInputWidget;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.minecraft.client.gui.widget.Widget;
/*     */ import net.minecraft.enchantment.Enchantment;
/*     */ import net.minecraft.enchantment.Enchantments;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.Items;
/*     */ import net.minecraft.util.IItemProvider;
/*     */ import net.minecraft.util.registry.Registry;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TranslationTextComponent;
/*     */ import org.lwjgl.glfw.GLFW;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ public class AutoBuyRenderer
/*     */   implements IAccess
/*     */ {
/*     */   private FixColor bgColor;
/*     */   private FixColor settingsBg;
/*     */   private FixColor separatorColor;
/*     */   private FixColor moduleColor;
/*     */   private FixColor text;
/*     */   private FixColor black;
/*     */   private FixColor white;
/*     */   
/*     */   public FixColor getBgColor() {
/*  48 */     return this.bgColor; } public FixColor getSettingsBg() { return this.settingsBg; } public FixColor getSeparatorColor() { return this.separatorColor; } public FixColor getModuleColor() { return this.moduleColor; } public FixColor getText() { return this.text; } public FixColor getBlack() { return this.black; } public FixColor getWhite() { return this.white; }
/*     */   
/*  50 */   private Animation swapText = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public Animation getSwapText() { return this.swapText; } private Animation opening = (new Animation())
/*  51 */     .setEasing(Easing.BOTH_SINE).setSpeed(300).setForward(false).finish(); public Animation getOpening() { return this.opening; }
/*  52 */    private Animation separatorAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public Animation getSeparatorAnim() { return this.separatorAnim; }
/*  53 */    private Animation selectEnchantAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public Animation getSelectEnchantAnim() { return this.selectEnchantAnim; }
/*  54 */    private Animation selectingAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public Animation getSelectingAnim() { return this.selectingAnim; }
/*     */   
/*  56 */   private String swapping = "Добавление предмета"; public String getSwapping() { return this.swapping; }
/*  57 */    private boolean selecting; private boolean selectEnchant; private float yaw; private float pitch; private Rect window; private AutoBuyItem currentItem; private String displayText = "Добавление предмета"; private InputWidget searchInput; private NumberInputWidget priceInput; private NumberInputWidget countInput; private NumberInputWidget durabilityInput; private NumberInputWidget sellInput; public String getDisplayText() { return this.displayText; }
/*  58 */   public boolean isSelecting() { return this.selecting; } public boolean isSelectEnchant() { return this.selectEnchant; } public void setSelecting(boolean selecting) { this.selecting = selecting; } public void setSelectEnchant(boolean selectEnchant) { this.selectEnchant = selectEnchant; }
/*  59 */   public float getYaw() { return this.yaw; } public float getPitch() { return this.pitch; }
/*  60 */   public Rect getWindow() { return this.window; }
/*  61 */   public AutoBuyItem getCurrentItem() { return this.currentItem; } public void setCurrentItem(AutoBuyItem currentItem) { this.currentItem = currentItem; }
/*  62 */   public InputWidget getSearchInput() { return this.searchInput; }
/*  63 */   public NumberInputWidget getPriceInput() { return this.priceInput; } public NumberInputWidget getCountInput() { return this.countInput; } public NumberInputWidget getDurabilityInput() { return this.durabilityInput; } public NumberInputWidget getSellInput() { return this.sellInput; }
/*  64 */    private final InfinityAnimation scrollAnim = new InfinityAnimation(); private final InfinityAnimation enchantScrollAnim = new InfinityAnimation(); private final InfinityAnimation itemScrollAnim = new InfinityAnimation(); private float scroll; private float enchantScroll; private float itemScroll; public InfinityAnimation getScrollAnim() { return this.scrollAnim; } public InfinityAnimation getEnchantScrollAnim() { return this.enchantScrollAnim; } public InfinityAnimation getItemScrollAnim() { return this.itemScrollAnim; }
/*  65 */   public float getScroll() { return this.scroll; } public float getEnchantScroll() { return this.enchantScroll; } public float getItemScroll() { return this.itemScroll; } public void setScroll(float scroll) { this.scroll = scroll; } public void setEnchantScroll(float enchantScroll) { this.enchantScroll = enchantScroll; } public void setItemScroll(float itemScroll) { this.itemScroll = itemScroll; }
/*  66 */    private final List<MinecraftItem> selected = new ArrayList<>(); public List<MinecraftItem> getSelected() { return this.selected; }
/*  67 */    private final List<Enchantment> selectedEnchants = new ArrayList<>(); public List<Enchantment> getSelectedEnchants() { return this.selectedEnchants; }
/*  68 */    private final List<Widget> inputs = new ArrayList<>(); private Rect addEnchantButton; private Rect confirmEnchantButton; private Rect cancelEnchantButton; public List<Widget> getInputs() { return this.inputs; }
/*     */   
/*  70 */   public Rect getAddEnchantButton() { return this.addEnchantButton; } public Rect getConfirmEnchantButton() { return this.confirmEnchantButton; } public Rect getCancelEnchantButton() { return this.cancelEnchantButton; }
/*     */   
/*     */   public AutoBuyRenderer(Rect window) {
/*  73 */     this.window = window;
/*     */     
/*  75 */     this.currentItem = new AutoBuyItem(Items.DIAMOND, 5000, 0, false);
/*  76 */     this.priceInput = new NumberInputWidget(bold.get(12), 0, 0, 0, 0, (ITextComponent)new TranslationTextComponent("Price"), false);
/*  77 */     this.priceInput.setText("10000");
/*  78 */     this.priceInput.setEndText(" $");
/*  79 */     this.priceInput.setMin(10);
/*  80 */     this.inputs.add(this.priceInput);
/*     */     
/*  82 */     this.countInput = new NumberInputWidget(bold.get(12), 0, 0, 0, 0, (ITextComponent)new TranslationTextComponent("Count"), false);
/*  83 */     this.countInput.setText("1");
/*  84 */     this.countInput.setEndText(" шт");
/*  85 */     this.countInput.setMin(1);
/*  86 */     this.countInput.setMax(64);
/*  87 */     this.inputs.add(this.countInput);
/*     */     
/*  89 */     this.durabilityInput = new NumberInputWidget(bold.get(12), 0, 0, 0, 0, (ITextComponent)new TranslationTextComponent("Durability"), false);
/*  90 */     this.durabilityInput.setText("100");
/*  91 */     this.durabilityInput.setEndText(" %");
/*  92 */     this.durabilityInput.setMin(0);
/*  93 */     this.durabilityInput.setMax(100);
/*  94 */     this.inputs.add(this.durabilityInput);
/*     */     
/*  96 */     this.sellInput = new NumberInputWidget(bold.get(12), 0, 0, 0, 0, (ITextComponent)new TranslationTextComponent("Sell"), false);
/*  97 */     this.sellInput.setText("15000");
/*  98 */     this.sellInput.setEndText(" $");
/*  99 */     this.sellInput.setMin(10);
/* 100 */     this.inputs.add(this.sellInput);
/*     */     
/* 102 */     this.searchInput = new InputWidget(bold.get(12), 0, 0, 0, 0, (ITextComponent)new TranslationTextComponent("Search"));
/* 103 */     this.inputs.add(this.searchInput);
/*     */   }
/*     */   
/*     */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/* 107 */     this.bgColor = rock.getThemes().getFirstColor().alpha(this.opening.get());
/* 108 */     this.settingsBg = rock.getThemes().getSecondColor().alpha((this.opening.get() * this.separatorAnim.get()));
/* 109 */     this.separatorColor = rock.getThemes().getThirdColor().alpha((this.opening.get() * this.separatorAnim.get()));
/* 110 */     this.moduleColor = rock.getThemes().getTextSecondColor().alpha((this.opening.get() * this.separatorAnim.get()));
/* 111 */     this.text = rock.getThemes().getTextFirstColor().alpha((this.opening.get() * this.separatorAnim.get()));
/* 112 */     this.black = FixColor.BLACK.alpha(this.opening.get());
/* 113 */     this.white = FixColor.WHITE.alpha(this.opening.get());
/*     */     
/* 115 */     this.separatorAnim.setForward(this.opening.finished());
/* 116 */     this.selectingAnim.setForward(this.selecting);
/* 117 */     this.scrollAnim.animate(this.scroll, 150);
/* 118 */     this.enchantScrollAnim.animate(this.enchantScroll, 150);
/* 119 */     this.itemScrollAnim.animate(this.itemScroll, 150);
/*     */ 
/*     */     
/* 122 */     float modif = 4.0F;
/*     */     
/* 124 */     if (this.opening.isForward() && mc.player != null) {
/* 125 */       this.yaw = mc.player.rotationYaw * modif;
/* 126 */       this.pitch = mc.player.rotationPitch * modif;
/*     */     } 
/*     */     
/* 129 */     GL11.glPushMatrix();
/* 130 */     GL11.glTranslatef(this.yaw - mc.player.rotationYaw * modif, this.pitch - mc.player.rotationPitch * modif, 0.0F);
/*     */ 
/*     */     
/* 133 */     Render.scale(rock.getClickGui().getWindow().getX() + this.window.getWidth() / 2.0F, this.window.getY() + this.window.getHeight() / 2.0F, 0.5F + this.opening.get() * 0.5F);
/*     */     
/* 135 */     renderWindow(matrixStack, mouseX, mouseY, partialTicks);
/*     */     
/* 137 */     Render.end();
/*     */     
/* 139 */     GL11.glPopMatrix();
/*     */   }
/*     */   
/*     */   private void renderWindow(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/* 143 */     float x = this.window.getX();
/* 144 */     float y = this.window.getY();
/* 145 */     float width = this.window.getWidth();
/* 146 */     float height = this.window.getHeight();
/*     */     
/* 148 */     Round.draw(matrixStack, this.window, 12.0F, this.bgColor);
/*     */     
/* 150 */     GL11.glEnable(3089);
/* 151 */     Render.scissor(this.window.getX(), this.window.getY(), this.window.getWidth(), this.window.getHeight());
/*     */     
/* 153 */     Rect leftPanelRect = new Rect(x + 12.0F, y + 29.0F, 315.0F * this.separatorAnim.get(), height - 41.0F);
/* 154 */     Round.draw(matrixStack, leftPanelRect, 10.0F, this.settingsBg);
/*     */     
/* 156 */     float rightPanelWidth = 151.0F * this.separatorAnim.get();
/* 157 */     Rect rightPanelRect = new Rect(x + width - rightPanelWidth - 12.0F, y + 29.0F, rightPanelWidth, height - 41.0F);
/* 158 */     Round.draw(matrixStack, rightPanelRect, 10.0F, this.settingsBg);
/*     */     
/* 160 */     bold.get(20).draw(matrixStack, "Rockstar AutoBuy", x + 12.0F, y + 8.0F, this.text);
/*     */     
/* 162 */     if (!this.swapping.equals(this.displayText) && this.swapText.finished(false)) {
/* 163 */       this.displayText = this.swapping;
/* 164 */       this.swapText.setForward(true);
/*     */     } 
/*     */     
/* 167 */     if (this.swapping.equals(this.displayText)) {
/* 168 */       this.swapText.setForward(true);
/*     */     }
/*     */     
/* 171 */     bold.get(20).draw(matrixStack, this.displayText, x + width - bold.get(20).getWidth(this.displayText) - 12.0F, y - 12.0F + 20.0F * this.swapText.get(), this.text);
/*     */     
/* 173 */     GL11.glDisable(3089);
/*     */ 
/*     */ 
/*     */     
/* 177 */     GL11.glEnable(3089);
/* 178 */     Render.scissor(rightPanelRect.getX(), rightPanelRect.getY(), rightPanelRect.getWidth(), rightPanelRect.getHeight());
/*     */     
/* 180 */     this.selectEnchantAnim.setForward(this.selectEnchant);
/*     */     
/* 182 */     float selectX = rightPanelRect.getWidth() * (1.0F - this.selectEnchantAnim.get());
/* 183 */     float listX = rightPanelRect.getWidth() * (1.0F - this.selectEnchantAnim.get()) - rightPanelRect.getWidth();
/*     */     
/* 185 */     if (this.currentItem.getItems().isEmpty()) {
/* 186 */       this.currentItem.getItems().add(new MinecraftItem(Items.DIAMOND));
/*     */     }
/*     */     
/* 189 */     if (!this.selectEnchantAnim.finished() && !this.currentItem.getItems().isEmpty()) {
/* 190 */       if (!this.selectingAnim.finished(false))
/* 191 */         Round.draw(matrixStack, new Rect(rightPanelRect.getX() + 10.0F + listX, rightPanelRect.getY() + 10.0F + this.itemScrollAnim.get(), 30.0F, 30.0F), 7.0F, this.separatorColor.alpha(this.separatorAnim.get())); 
/* 192 */       Round.draw(matrixStack, (new Rect(rightPanelRect.getX() + 10.0F + listX, rightPanelRect.getY() + 10.0F + this.itemScrollAnim.get(), 30.0F, 30.0F)).size(2.0F * this.selectingAnim.get()), 7.0F - 2.0F * this.selectingAnim.get(), this.bgColor.alpha(this.separatorAnim.get()));
/* 193 */       Render.drawStack(new ItemStack((IItemProvider)((MinecraftItem)this.currentItem.getItems().stream().findFirst().get()).getItem()), rightPanelRect.getX() + 14.0F + listX, rightPanelRect.getY() + 13.0F + this.itemScrollAnim.get(), 1.4F);
/*     */       
/* 195 */       bold.get(14).draw(matrixStack, "Имя предмета", rightPanelRect.getX() + 50.0F + listX, rightPanelRect.getY() + 15.0F + this.itemScrollAnim.get(), this.moduleColor);
/* 196 */       bold.get(20).draw(matrixStack, ((MinecraftItem)this.currentItem.getItems().get(0)).getItem().getName().getString(), rightPanelRect.getX() + 50.0F + listX, rightPanelRect.getY() + 21.0F + this.itemScrollAnim.get(), this.text);
/*     */       
/* 198 */       Round.draw(matrixStack, new Rect(rightPanelRect.getX() + rightPanelWidth - 50.0F, rightPanelRect.getY() + 21.0F + this.itemScrollAnim.get(), 40.0F, 20.0F), 0.1F, this.settingsBg.alpha(0.0D), this.settingsBg, this.settingsBg.alpha(0.0D), this.settingsBg);
/* 199 */       Round.draw(matrixStack, new Rect(rightPanelRect.getX() + rightPanelWidth - 10.0F, rightPanelRect.getY() + 21.0F + this.itemScrollAnim.get(), 10.0F, 20.0F), 0.1F, this.settingsBg);
/*     */       
/* 201 */       float yOff = rightPanelRect.getY() + 45.0F + this.itemScrollAnim.get();
/* 202 */       float startX = rightPanelRect.getX() + 10.0F + listX;
/* 203 */       float xOff = startX;
/* 204 */       float inputWidth = 83.0F;
/*     */       
/* 206 */       bold.get(14).draw(matrixStack, "Минимальная цена за штуку", xOff, yOff - 1.0F, this.moduleColor);
/* 207 */       yOff += 13.0F;
/* 208 */       Round.draw(matrixStack, new Rect(xOff, yOff, inputWidth, 15.0F), 3.0F, this.bgColor.alpha(this.separatorAnim.get()));
/* 209 */       this.priceInput.set(xOff, yOff, inputWidth, 19.0F);
/* 210 */       this.priceInput.renderButton(matrixStack, mouseX, mouseY, partialTicks);
/* 211 */       yOff += 20.0F;
/*     */       
/* 213 */       bold.get(14).draw(matrixStack, "Минимальное кол-во предмета", xOff, yOff - 1.0F, this.moduleColor);
/* 214 */       yOff += 13.0F;
/* 215 */       Round.draw(matrixStack, new Rect(xOff, yOff, inputWidth, 15.0F), 3.0F, this.bgColor.alpha(this.separatorAnim.get()));
/* 216 */       this.countInput.set(xOff, yOff, inputWidth, 19.0F);
/* 217 */       this.countInput.renderButton(matrixStack, mouseX, mouseY, partialTicks);
/* 218 */       yOff += 20.0F;
/*     */       
/* 220 */       boolean damage = false;
/* 221 */       for (MinecraftItem item : this.currentItem.getItems()) {
/* 222 */         if (item.getItem().isDamageable()) {
/* 223 */           damage = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 228 */       if (damage) {
/* 229 */         bold.get(14).draw(matrixStack, "Минимальная прочность", xOff, yOff - 1.0F, this.moduleColor);
/* 230 */         yOff += 13.0F;
/* 231 */         Round.draw(matrixStack, new Rect(xOff, yOff, inputWidth, 15.0F), 3.0F, this.bgColor.alpha(this.separatorAnim.get()));
/* 232 */         this.durabilityInput.set(xOff, yOff, inputWidth, 19.0F);
/* 233 */         this.durabilityInput.renderButton(matrixStack, mouseX, mouseY, partialTicks);
/* 234 */         yOff += 20.0F;
/*     */       } 
/*     */       
/* 237 */       bold.get(14).draw(matrixStack, "Цена продажи одной штуки", xOff, yOff - 1.0F, this.moduleColor);
/* 238 */       yOff += 13.0F;
/* 239 */       Round.draw(matrixStack, new Rect(xOff, yOff, inputWidth, 15.0F), 3.0F, this.bgColor.alpha(this.separatorAnim.get()));
/* 240 */       this.sellInput.set(xOff, yOff, inputWidth, 19.0F);
/* 241 */       this.sellInput.renderButton(matrixStack, mouseX, mouseY, partialTicks);
/* 242 */       yOff += 20.0F;
/*     */ 
/*     */       
/* 245 */       this.currentItem.setMaxPrice((int)this.priceInput.getFloat());
/* 246 */       this.currentItem.setMinCount((int)this.countInput.getFloat());
/* 247 */       this.currentItem.setMinDurability((int)this.durabilityInput.getFloat());
/* 248 */       this.currentItem.setSellPrice((int)this.sellInput.getFloat());
/*     */       
/* 250 */       bold.get(14).draw(matrixStack, "Зачарования", xOff, yOff - 1.0F, this.moduleColor);
/* 251 */       yOff += 13.0F;
/*     */       
/* 253 */       for (Map.Entry<String, Integer> enchant : (Iterable<Map.Entry<String, Integer>>)this.currentItem.getEnchants().entrySet()) {
/* 254 */         String name = ((Enchantment)Registry.ENCHANTMENT.getByValue(Integer.parseInt(enchant.getKey()))).getDisplayName(((Integer)enchant.getValue()).intValue()).getString();
/*     */         
/* 256 */         if (xOff + bold.get(12).getWidth(name) + 10.0F > rightPanelRect.getX() + rightPanelRect.getWidth()) {
/* 257 */           xOff = startX;
/* 258 */           yOff += 14.0F;
/*     */         } 
/*     */         
/* 261 */         Round.draw(matrixStack, new Rect(xOff, yOff, bold.get(12).getWidth(name) + 8.0F, 12.0F), 3.0F, this.bgColor.alpha((this.separatorAnim.get() * this.selectEnchantAnim.reversed())));
/* 262 */         bold.get(12).draw(matrixStack, name, xOff + 4.0F, yOff + 1.5F, this.text.alpha(this.selectEnchantAnim.reversed()));
/*     */         
/* 264 */         xOff += bold.get(12).getWidth(name) + 10.0F;
/* 265 */         if (xOff + bold.get(12).getWidth(name) + 10.0F > rightPanelRect.getX() + rightPanelRect.getWidth()) {
/* 266 */           xOff = startX;
/* 267 */           yOff += 14.0F;
/*     */         } 
/*     */       } 
/*     */       
/* 271 */       String addString = "Изменить";
/* 272 */       Round.draw(matrixStack, this.addEnchantButton = new Rect(xOff, yOff, bold.get(12).getWidth(addString) + 9.0F, 12.0F), 3.0F, this.bgColor.alpha((this.separatorAnim.get() * this.selectEnchantAnim.reversed())));
/* 273 */       bold.get(12).draw(matrixStack, addString, xOff + 4.0F, yOff + 1.5F, this.moduleColor.alpha(this.selectEnchantAnim.reversed()));
/*     */       
/* 275 */       float btnHeight = 15.0F;
/*     */       
/* 277 */       if (!this.swapText.finished(false) && !this.displayText.equals("Изменение предмета")) {
/* 278 */         String add = "Добавить";
/* 279 */         float btnWidth = bold.get(14).getWidth(add) + 10.0F;
/* 280 */         Round.draw(matrixStack, new Rect(rightPanelRect.getX() + rightPanelRect.getWidth() - 10.0F - btnWidth + listX, rightPanelRect.getY() + 50.0F - 50.0F * this.swapText.get() + rightPanelRect.getHeight() - 10.0F - btnHeight, btnWidth, btnHeight), 3.0F, this.bgColor.alpha(this.separatorAnim.get()));
/* 281 */         bold.get(14).draw(matrixStack, add, rightPanelRect.getX() + rightPanelRect.getWidth() - 10.0F - btnWidth + 4.5F + listX, rightPanelRect.getY() + 50.0F - 50.0F * this.swapText.get() + rightPanelRect.getHeight() - 7.5F - btnHeight, this.text);
/*     */       } 
/*     */       
/* 284 */       if (!this.swapText.finished(false) && this.displayText.equals("Изменение предмета")) {
/* 285 */         String cancel = "Отмена";
/* 286 */         float cancelbtnWidth = bold.get(14).getWidth(cancel) + 10.0F;
/* 287 */         Round.draw(matrixStack, new Rect(rightPanelRect.getX() + 10.0F + listX, rightPanelRect.getY() + 50.0F - 50.0F * this.swapText.get() + rightPanelRect.getHeight() - 10.0F - btnHeight, cancelbtnWidth, btnHeight), 3.0F, this.bgColor.alpha(this.separatorAnim.get()));
/* 288 */         bold.get(14).draw(matrixStack, cancel, rightPanelRect.getX() + 10.0F + 4.5F + listX, rightPanelRect.getY() + 50.0F - 50.0F * this.swapText.get() + rightPanelRect.getHeight() - 7.5F - btnHeight, this.text);
/*     */ 
/*     */         
/* 291 */         String delete = "Удалить";
/* 292 */         float deletebtnWidth = bold.get(14).getWidth(delete) + 10.0F;
/* 293 */         Round.draw(matrixStack, new Rect(rightPanelRect.getX() + rightPanelRect.getWidth() - 10.0F - deletebtnWidth + listX, rightPanelRect.getY() + 50.0F - 50.0F * this.swapText.get() + rightPanelRect.getHeight() - 10.0F - btnHeight, deletebtnWidth, btnHeight), 3.0F, this.bgColor.alpha(this.separatorAnim.get()));
/* 294 */         bold.get(14).draw(matrixStack, delete, rightPanelRect.getX() + rightPanelRect.getWidth() - 10.0F - deletebtnWidth + 4.5F + listX, rightPanelRect.getY() + 50.0F - 50.0F * this.swapText.get() + rightPanelRect.getHeight() - 7.5F - btnHeight, this.text);
/*     */       } 
/*     */       
/* 297 */       if (this.itemScrollAnim.get() > 0.0F) {
/* 298 */         this.itemScroll = 0.0F;
/*     */       }
/* 300 */       if (this.itemScrollAnim.get() < -(yOff - rightPanelRect.getY() + 45.0F + this.itemScrollAnim.get())) {
/* 301 */         this.itemScroll = -(yOff - rightPanelRect.getY() + 45.0F + this.itemScrollAnim.get());
/*     */       }
/*     */     } 
/* 304 */     if (!this.selectEnchantAnim.finished(false)) {
/*     */       
/* 306 */       float xOff = rightPanelRect.getX() + 10.0F + selectX;
/* 307 */       float yOff = rightPanelRect.getY() + 10.0F + this.enchantScrollAnim.get();
/* 308 */       float scrollOff = -rightPanelRect.getHeight() + 40.0F;
/*     */       
/* 310 */       Rect stencilRect = rightPanelRect.size(10.0F).height(rightPanelRect.getHeight() - 40.0F);
/*     */       
/* 312 */       Stencil.init();
/* 313 */       Round.draw(matrixStack, stencilRect, 3.0F, this.bgColor.alpha(this.separatorAnim.get()));
/* 314 */       Stencil.read(1);
/*     */       
/* 316 */       for (Map.Entry<String, Enchantment> enchant : (Iterable<Map.Entry<String, Enchantment>>)Enchantments.AUTOBUY.entrySet()) {
/* 317 */         if (Hover.isHovered(stencilRect.height(rightPanelRect.getHeight() - 15.0F), xOff, (yOff + 25.0F))) {
/* 318 */           ((Enchantment)enchant.getValue()).getSelectAnim().setForward(this.selectedEnchants.contains(enchant.getValue()));
/*     */           
/* 320 */           Round.draw(matrixStack, new Rect(xOff, yOff, rightPanelWidth - 20.0F, 20.0F), 3.0F, this.bgColor.alpha(this.separatorAnim.get()));
/* 321 */           bold.get(14).draw(matrixStack, ((Enchantment)enchant.getValue()).getDisplayName(0).getString().replace("enchantment.level.0", ""), xOff + 6.0F + 11.0F * ((Enchantment)enchant.getValue()).getSelectAnim().get(), yOff + 5.0F, this.text);
/* 322 */           Render.image("icons/yes.png", xOff + 7.0F * ((Enchantment)enchant.getValue()).getSelectAnim().get(), yOff + 7.5F, 6.0F, 6.0F, (Color)this.text.alpha(((Enchantment)enchant.getValue()).getSelectAnim().get()));
/*     */           
/* 324 */           String lvl = "" + ((Enchantment)enchant.getValue()).getAbLvl();
/* 325 */           float lvlWidth = bold.get(14).getWidth(lvl);
/*     */           
/* 327 */           bold.get(14).draw(matrixStack, "-", xOff + rightPanelWidth - 35.0F - bold.get(14).getWidth("-+") - lvlWidth, yOff + 5.0F, this.text);
/*     */           
/* 329 */           bold.get(14).draw(matrixStack, lvl, xOff + rightPanelWidth - 32.0F - bold.get(14).getWidth("+") - lvlWidth, yOff + 5.0F, this.text);
/*     */           
/* 331 */           bold.get(14).draw(matrixStack, "+", xOff + rightPanelWidth - 28.0F - bold.get(14).getWidth("+"), yOff + 5.0F, this.text);
/*     */         } 
/*     */         
/* 334 */         scrollOff += 25.0F;
/* 335 */         yOff += 25.0F;
/*     */       } 
/*     */       
/* 338 */       if (-scrollOff > this.enchantScroll) {
/* 339 */         this.enchantScroll = -scrollOff;
/*     */       }
/*     */       
/* 342 */       if (this.enchantScroll > 0.0F) this.enchantScroll = 0.0F;
/*     */       
/* 344 */       Stencil.finish();
/*     */       
/* 346 */       String add = "Добавить";
/* 347 */       float btnWidth = bold.get(14).getWidth(add) + 10.0F;
/* 348 */       float btnHeight = 15.0F;
/* 349 */       Round.draw(matrixStack, this.confirmEnchantButton = new Rect(rightPanelRect.getX() + rightPanelRect.getWidth() - 10.0F - btnWidth + selectX, rightPanelRect.getY() + rightPanelRect.getHeight() - 10.0F - btnHeight, btnWidth, btnHeight), 3.0F, this.bgColor.alpha(this.separatorAnim.get()));
/* 350 */       bold.get(14).draw(matrixStack, add, rightPanelRect.getX() + rightPanelRect.getWidth() - 10.0F - btnWidth + 4.5F + selectX, rightPanelRect.getY() + rightPanelRect.getHeight() - 7.5F - btnHeight, this.text);
/*     */       
/* 352 */       String cancel = "Отмена";
/* 353 */       float cancelbtnWidth = bold.get(14).getWidth(cancel) + 10.0F;
/* 354 */       Round.draw(matrixStack, this.cancelEnchantButton = new Rect(rightPanelRect.getX() + 10.0F + selectX, rightPanelRect.getY() + rightPanelRect.getHeight() - 10.0F - btnHeight, cancelbtnWidth, btnHeight), 3.0F, this.bgColor.alpha(this.separatorAnim.get()));
/* 355 */       bold.get(14).draw(matrixStack, cancel, rightPanelRect.getX() + 10.0F + 4.5F + selectX, rightPanelRect.getY() + rightPanelRect.getHeight() - 7.5F - btnHeight, this.text);
/*     */     } 
/*     */ 
/*     */     
/* 359 */     GL11.glDisable(3089);
/*     */ 
/*     */ 
/*     */     
/* 363 */     Stencil.init();
/* 364 */     Round.draw(matrixStack, leftPanelRect, 10.0F, this.settingsBg);
/* 365 */     Stencil.read(1);
/*     */     
/* 367 */     selectX = leftPanelRect.getWidth() * (1.0F - this.selectingAnim.get());
/* 368 */     listX = leftPanelRect.getWidth() * (1.0F - this.selectingAnim.get()) - leftPanelRect.getWidth();
/*     */     
/* 370 */     if (!this.selectingAnim.finished(false)) {
/* 371 */       float btnWidth = 80.0F;
/* 372 */       float btnHeight = 15.0F;
/* 373 */       Round.draw(matrixStack, new Rect(leftPanelRect.getX() + leftPanelRect.getWidth() + selectX - 10.0F - btnWidth, leftPanelRect.getY() + 10.0F, btnWidth, btnHeight), 3.0F, this.bgColor.alpha(this.separatorAnim.get()));
/* 374 */       Render.image("category/search.png", leftPanelRect.getX() + leftPanelRect.getWidth() + selectX - 6.0F - btnWidth + 0.5F, leftPanelRect.getY() + 14.5F, 6.0F, 6.0F, (Color)this.text);
/*     */       
/* 376 */       bold.get(20).draw(matrixStack, "Выбор предмета", leftPanelRect.getX() + 10.0F + selectX, leftPanelRect.getY() + 11.0F, this.text);
/*     */       
/* 378 */       if (!this.searchInput.isFocused() && this.searchInput.getText().isEmpty()) {
/* 379 */         bold.get(12).draw(matrixStack, "Найти предмет", leftPanelRect.getX() + leftPanelRect.getWidth() + selectX + 3.0F - btnWidth, leftPanelRect.getY() + 13.0F, this.text);
/*     */       }
/* 381 */       btnWidth -= 10.0F;
/* 382 */       this.searchInput.set(leftPanelRect.getX() + leftPanelRect.getWidth() + selectX - 10.0F - btnWidth, leftPanelRect.getY() + 12.0F, btnWidth, btnHeight);
/* 383 */       this.searchInput.renderButton(matrixStack, mouseX, mouseY, partialTicks);
/*     */ 
/*     */       
/* 386 */       GL11.glEnable(3089);
/* 387 */       Render.scissor(leftPanelRect.getX(), (leftPanelRect.getY() + 30.0F), leftPanelRect.getWidth(), (leftPanelRect.getHeight() - 30.0F));
/*     */       
/* 389 */       float xOff = 0.0F;
/* 390 */       float yOff = 25.0F + this.scrollAnim.get();
/* 391 */       float scrollOff = 0.0F;
/* 392 */       for (MinecraftItem item : Items.getMinecraftItems()) {
/* 393 */         if (!item.getName().toLowerCase().contains(this.searchInput.getText()))
/*     */           continue; 
/* 395 */         if (Hover.isHovered(leftPanelRect, (leftPanelRect.getX() + 10.0F + xOff + selectX), (leftPanelRect.getY() + 10.0F + yOff))) {
/* 396 */           item.getSelectAnim().setForward(this.selected.contains(item));
/*     */           
/* 398 */           if (!item.getSelectAnim().finished(false))
/* 399 */             Round.draw(matrixStack, new Rect(leftPanelRect.getX() + 10.0F + xOff + selectX, leftPanelRect.getY() + 10.0F + yOff, 30.0F, 30.0F), 7.0F, Style.getMain().alpha(this.separatorAnim.get())); 
/* 400 */           Round.draw(matrixStack, (new Rect(leftPanelRect.getX() + 10.0F + xOff + selectX, leftPanelRect.getY() + 10.0F + yOff, 30.0F, 30.0F)).size(item.getSelectAnim().get()), 7.0F - item.getSelectAnim().get(), this.bgColor.alpha(this.separatorAnim.get()));
/* 401 */           Render.drawStack(new ItemStack((IItemProvider)item.getItem()), leftPanelRect.getX() + 14.0F + xOff + selectX, leftPanelRect.getY() + 13.0F + yOff, 1.4F);
/*     */         } 
/*     */         
/* 404 */         xOff += 33.0F;
/* 405 */         if (xOff + 33.0F > leftPanelRect.getWidth()) {
/* 406 */           xOff = 0.0F;
/* 407 */           yOff += 33.0F;
/* 408 */           scrollOff += 33.0F;
/*     */         } 
/*     */       } 
/*     */       
/* 412 */       if (-scrollOff > this.scroll) {
/* 413 */         this.scroll = -scrollOff;
/*     */       }
/*     */       
/* 416 */       if (this.scroll > 0.0F) this.scroll = 0.0F;
/*     */       
/* 418 */       GL11.glDisable(3089);
/*     */     } 
/*     */ 
/*     */     
/* 422 */     if (!this.selectingAnim.finished()) {
/* 423 */       bold.get(20).draw(matrixStack, "Список предметов", leftPanelRect.getX() + 10.0F + listX, leftPanelRect.getY() + 11.0F, this.text);
/*     */       
/* 425 */       GL11.glEnable(3089);
/* 426 */       Render.scissor(leftPanelRect.getX(), (leftPanelRect.getY() + 30.0F), leftPanelRect.getWidth(), (leftPanelRect.getHeight() - 30.0F));
/*     */       
/* 428 */       float xOff = 0.0F;
/* 429 */       float yOff = 25.0F + this.scrollAnim.get();
/* 430 */       float scrollOff = 0.0F;
/* 431 */       for (AutoBuyItem item : rock.getAutoBuy().getItems()) {
/*     */ 
/*     */         
/* 434 */         if (Hover.isHovered(leftPanelRect, (leftPanelRect.getX() + 10.0F + xOff + listX), (leftPanelRect.getY() + 10.0F + yOff)) && !this.selectingAnim.finished(true)) {
/* 435 */           ((MinecraftItem)item.getItems().get(0)).getSelectAnim().setForward((this.currentItem == item));
/*     */           
/* 437 */           if (!((MinecraftItem)item.getItems().get(0)).getSelectAnim().finished(false)) {
/* 438 */             Round.draw(matrixStack, new Rect(leftPanelRect.getX() + 10.0F + xOff + listX, leftPanelRect.getY() + 10.0F + yOff, 30.0F, 30.0F), 7.0F, Style.getMain().alpha(this.separatorAnim.get()));
/*     */           }
/* 440 */           Round.draw(matrixStack, (new Rect(leftPanelRect.getX() + 10.0F + xOff + listX, leftPanelRect.getY() + 10.0F + yOff, 30.0F, 30.0F)).size(((MinecraftItem)item.getItems().get(0)).getSelectAnim().get()), 7.0F - ((MinecraftItem)item.getItems().get(0)).getSelectAnim().get(), this.bgColor.alpha(this.separatorAnim.get()));
/* 441 */           Render.drawStack(new ItemStack((IItemProvider)((MinecraftItem)item.getItems().stream().findFirst().get()).getItem()), leftPanelRect.getX() + 14.0F + xOff + listX, leftPanelRect.getY() + 13.0F + yOff, 1.4F);
/*     */         } 
/*     */         
/* 444 */         xOff += 33.0F;
/* 445 */         if (xOff + 33.0F > leftPanelRect.getWidth()) {
/* 446 */           xOff = 0.0F;
/* 447 */           yOff += 33.0F;
/* 448 */           scrollOff += 33.0F;
/*     */         } 
/*     */       } 
/*     */       
/* 452 */       if (-scrollOff > this.scroll) {
/* 453 */         this.scroll = -scrollOff;
/*     */       }
/*     */       
/* 456 */       if (this.scroll > 0.0F) this.scroll = 0.0F;
/*     */       
/* 458 */       GL11.glDisable(3089);
/*     */     } 
/*     */     
/* 461 */     Stencil.finish();
/*     */   }
/*     */ 
/*     */   
/*     */   public void swapText(String text) {
/* 466 */     this.swapText.setSpeed(150);
/* 467 */     this.swapping = text;
/*     */     
/* 469 */     if (!this.swapping.equals(this.displayText)) {
/* 470 */       this.swapText.setForward(false);
/*     */     }
/*     */   }
/*     */   
/*     */   public void handleSelect(MinecraftItem item) {
/* 475 */     if (!this.selecting)
/*     */       return; 
/* 477 */     if (GLFW.glfwGetKey(mc.getMainWindow().getHandle(), 341) != 1) {
/* 478 */       this.selected.clear();
/*     */     }
/* 480 */     if (this.selected.contains(item)) {
/* 481 */       if (this.selected.size() == 1 && this.selected.get(0) == item) {
/*     */         return;
/*     */       }
/* 484 */       this.selected.remove(item);
/*     */     } else {
/* 486 */       this.selected.add(item);
/*     */     } 
/* 488 */     this.currentItem.updateItems(this.selected);
/*     */   }
/*     */   
/*     */   public void handleItemsSelectButtonClick() {
/* 492 */     this.selecting = !this.selecting;
/*     */     
/* 494 */     if (this.selecting) {
/* 495 */       for (MinecraftItem item : Items.getMinecraftItems()) {
/* 496 */         item.getSelectAnim().setForward(false);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void handleAddButtonClick() {
/* 502 */     rock.getAutoBuy().getItems().add(this.currentItem);
/* 503 */     this.currentItem = new AutoBuyItem(Items.DIAMOND, 5000, 0, false);
/* 504 */     this.selectedEnchants.clear();
/*     */     
/* 506 */     for (Map.Entry<String, Enchantment> enchant : (Iterable<Map.Entry<String, Enchantment>>)Enchantments.AUTOBUY.entrySet())
/* 507 */       ((Enchantment)enchant.getValue()).setAbLvl(1); 
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\autobu\\ui\AutoBuyRenderer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */