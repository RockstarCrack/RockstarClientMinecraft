/*     */ package fun.rockstarity.api.autobuy.ui;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.autobuy.logic.items.AutoBuyItem;
/*     */ import fun.rockstarity.api.autobuy.logic.items.MinecraftItem;
/*     */ import fun.rockstarity.api.helpers.math.Hover;
/*     */ import fun.rockstarity.api.render.ui.alerts.AlertType;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.screen.Screen;
/*     */ import net.minecraft.client.gui.widget.Widget;
/*     */ import net.minecraft.enchantment.Enchantment;
/*     */ import net.minecraft.enchantment.Enchantments;
/*     */ import net.minecraft.item.Items;
/*     */ import net.minecraft.util.registry.Registry;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TranslationTextComponent;
/*     */ import org.lwjgl.glfw.GLFW;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AutoBuyScreen
/*     */   extends Screen
/*     */   implements IAccess
/*     */ {
/*     */   private Rect window;
/*     */   private AutoBuyRenderer renderer;
/*     */   
/*     */   public Rect getWindow() {
/*  36 */     return this.window; } public AutoBuyRenderer getRenderer() {
/*  37 */     return this.renderer;
/*     */   }
/*     */   public AutoBuyScreen() {
/*  40 */     super((ITextComponent)new TranslationTextComponent("Auto Buy"));
/*     */     
/*  42 */     float width = 500.0F;
/*  43 */     float height = 300.0F;
/*     */     
/*  45 */     this.window = new Rect((sr.getScaledWidth() / 2) - width / 2.0F, (sr.getScaledHeight() / 2) - height / 2.0F, width, height);
/*  46 */     this.renderer = new AutoBuyRenderer(this.window);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {}
/*     */ 
/*     */   
/*     */   public void tick() {
/*  55 */     for (Widget input : this.renderer.getInputs()) {
/*  56 */       input.tick();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/*  62 */     this.renderer.render(matrixStack, mouseX, mouseY, partialTicks);
/*     */     
/*  64 */     super.render(matrixStack, mouseX, mouseY, partialTicks);
/*     */     
/*  66 */     boolean up = (GLFW.glfwGetKey(mc.getMainWindow().getHandle(), 265) == 1);
/*  67 */     boolean down = (GLFW.glfwGetKey(mc.getMainWindow().getHandle(), 264) == 1);
/*  68 */     float offset = 0.1F / Math.max(Minecraft.debugFPS, 5.0F) * 500.0F;
/*     */     
/*  70 */     if (up || down) {
/*  71 */       mouseScrolled(mouseX, mouseY, up ? offset : (down ? -offset : 0.0D));
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean charTyped(char typedChar, int keyCode) {
/*  76 */     for (Widget input : this.renderer.getInputs()) {
/*  77 */       input.charTyped(typedChar, keyCode);
/*     */     }
/*  79 */     return false;
/*     */   }
/*     */   
/*     */   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
/*  83 */     for (Widget input : this.renderer.getInputs()) {
/*  84 */       input.keyPressed(keyCode, scanCode, modifiers);
/*     */     }
/*     */     
/*  87 */     if (keyCode == 65 && GLFW.glfwGetKey(mc.getMainWindow().getHandle(), 341) == 1 && !this.renderer.getSearchInput().isFocused()) {
/*  88 */       this.renderer.getSelected().clear();
/*     */       
/*  90 */       for (MinecraftItem item : Items.getMinecraftItems()) {
/*  91 */         if (!item.getName().toLowerCase().contains(this.renderer.getSearchInput().getText()))
/*  92 */           continue;  this.renderer.getSelected().add(item);
/*     */       } 
/*     */       
/*  95 */       this.renderer.getCurrentItem().updateItems(this.renderer.getSelected());
/*     */     } 
/*     */     
/*  98 */     if (keyCode == 256) {
/*  99 */       closeScreen();
/* 100 */       this.renderer.getOpening().setForward(false);
/* 101 */       return true;
/*     */     } 
/* 103 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
/* 108 */     float x = this.window.getX();
/* 109 */     float y = this.window.getY();
/* 110 */     float width = this.window.getWidth();
/* 111 */     float height = this.window.getHeight();
/* 112 */     float rightPanelWidth = 151.0F * this.renderer.getSeparatorAnim().get();
/* 113 */     Rect rightPanelRect = new Rect(x + width - rightPanelWidth - 12.0F, y + 29.0F, rightPanelWidth, height - 41.0F);
/* 114 */     Rect leftPanelRect = new Rect(x + 12.0F, y + 29.0F, 315.0F * this.renderer.getSeparatorAnim().get(), height - 41.0F);
/*     */     
/* 116 */     if (Hover.isHovered(leftPanelRect, mouseX, mouseY)) {
/* 117 */       this.renderer.setScroll((float)(this.renderer.getScroll() + delta * 15.0D));
/*     */     }
/*     */     
/* 120 */     if (Hover.isHovered(rightPanelRect, mouseX, mouseY)) {
/* 121 */       if (this.renderer.isSelectEnchant()) {
/* 122 */         this.renderer.setEnchantScroll((float)(this.renderer.getEnchantScroll() + delta * 15.0D));
/*     */       } else {
/* 124 */         this.renderer.setItemScroll((float)(this.renderer.getItemScroll() + delta * 15.0D));
/*     */       } 
/*     */     }
/*     */     
/* 128 */     return super.mouseScrolled(mouseX, mouseY, delta);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
/* 133 */     if (button == 0 && Hover.isHovered(this.window, mouseX, mouseY)) {
/* 134 */       this.window.setX((float)(this.window.getX() + dragX));
/* 135 */       this.window.setY((float)(this.window.getY() + dragY));
/*     */     } 
/* 137 */     return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean mouseClicked(double mouseX, double mouseY, int button) {
/* 142 */     for (Widget input : this.renderer.getInputs()) {
/* 143 */       input.mouseClicked(mouseX, mouseY, button);
/*     */     }
/*     */     
/* 146 */     float x = this.window.getX();
/* 147 */     float y = this.window.getY();
/* 148 */     float width = this.window.getWidth();
/* 149 */     float height = this.window.getHeight();
/* 150 */     float rightPanelWidth = 151.0F * this.renderer.getSeparatorAnim().get();
/* 151 */     Rect rightPanelRect = new Rect(x + width - rightPanelWidth - 12.0F, y + 29.0F, rightPanelWidth, height - 41.0F);
/* 152 */     String add = "Добавить";
/* 153 */     float btnWidth = bold.get(14).getWidth(add) + 10.0F;
/* 154 */     float btnHeight = 15.0F;
/*     */     
/* 156 */     Rect leftPanelRect = new Rect(x + 12.0F, y + 29.0F, 315.0F * this.renderer.getSeparatorAnim().get(), height - 41.0F);
/*     */     
/* 158 */     if (Hover.isHovered(leftPanelRect, mouseX, mouseY) && this.renderer.isSelecting()) {
/* 159 */       float selectX = leftPanelRect.getWidth() * (1.0F - this.renderer.getSeparatorAnim().get());
/*     */       
/* 161 */       float xOff = 0.0F;
/* 162 */       float yOff = 25.0F + this.renderer.getScrollAnim().get();
/* 163 */       float scrollOff = 0.0F;
/* 164 */       for (MinecraftItem item : Items.getMinecraftItems()) {
/* 165 */         if (!item.getName().toLowerCase().contains(this.renderer.getSearchInput().getText()))
/*     */           continue; 
/* 167 */         if (Hover.isHovered(leftPanelRect, (leftPanelRect.getX() + 10.0F + xOff + selectX), (leftPanelRect.getY() + 10.0F + yOff)) && 
/* 168 */           Hover.isHovered((leftPanelRect.getX() + 10.0F + xOff + selectX), (leftPanelRect.getY() + 10.0F + yOff), 30.0D, 30.0D, mouseX, mouseY)) {
/* 169 */           this.renderer.handleSelect(item);
/*     */         }
/*     */ 
/*     */         
/* 173 */         xOff += 33.0F;
/* 174 */         if (xOff + 33.0F > leftPanelRect.getWidth()) {
/* 175 */           xOff = 0.0F;
/* 176 */           yOff += 33.0F;
/* 177 */           scrollOff += 33.0F;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 182 */     if (Hover.isHovered(leftPanelRect, mouseX, mouseY) && !this.renderer.isSelecting()) {
/* 183 */       float listX = leftPanelRect.getWidth() * (1.0F - this.renderer.getSeparatorAnim().get()) - leftPanelRect.getWidth();
/*     */       
/* 185 */       float xOff = 0.0F;
/* 186 */       float yOff = 25.0F + this.renderer.getScrollAnim().get();
/* 187 */       float scrollOff = 0.0F;
/* 188 */       for (AutoBuyItem item : rock.getAutoBuy().getItems()) {
/* 189 */         for (MinecraftItem item1 : item.getItems()) {
/* 190 */           if (!item1.getName().toLowerCase().contains(this.renderer.getSearchInput().getText()));
/*     */         } 
/*     */         
/* 193 */         if (Hover.isHovered(leftPanelRect, mouseX, mouseY) && 
/* 194 */           Hover.isHovered((leftPanelRect.getX() + 10.0F + xOff), (leftPanelRect.getY() + 10.0F + yOff), 30.0D, 30.0D, mouseX, mouseY)) {
/* 195 */           if (this.renderer.getCurrentItem() == item) {
/* 196 */             reset();
/*     */           } else {
/* 198 */             this.renderer.setCurrentItem(item);
/* 199 */             this.renderer.getSelected().clear();
/* 200 */             this.renderer.getSelected().addAll(item.getItems());
/* 201 */             this.renderer.getSelectedEnchants().clear();
/* 202 */             for (Map.Entry<String, Integer> set : (Iterable<Map.Entry<String, Integer>>)item.getEnchants().entrySet()) {
/* 203 */               int enchantmentId = Integer.parseInt(((String)set.getKey()).replace(String.valueOf(set.getValue()), ""));
/* 204 */               Enchantment enchantment = Enchantment.getEnchantmentByID(enchantmentId);
/* 205 */               if (enchantment != null) {
/* 206 */                 this.renderer.getSelectedEnchants().add(enchantment);
/*     */               }
/*     */             } 
/*     */             
/* 210 */             this.renderer.getPriceInput().setText("" + item.getMaxPrice());
/* 211 */             this.renderer.getCountInput().setText("" + item.getMinCount());
/* 212 */             this.renderer.getDurabilityInput().setText("" + item.getMinDurability());
/* 213 */             this.renderer.getSellInput().setText("" + item.getSellPrice());
/*     */             
/* 215 */             this.renderer.swapText("Изменение предмета");
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/* 220 */         xOff += 33.0F;
/* 221 */         if (xOff + 33.0F > leftPanelRect.getWidth()) {
/* 222 */           xOff = 0.0F;
/* 223 */           yOff += 33.0F;
/* 224 */           scrollOff += 33.0F;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 229 */     if (Hover.isHovered(rightPanelRect, mouseX, mouseY)) {
/*     */       
/* 231 */       float selectX = rightPanelRect.getWidth() * (1.0F - this.renderer.getSelectEnchantAnim().get());
/* 232 */       float listX = rightPanelRect.getWidth() * (1.0F - this.renderer.getSelectEnchantAnim().get()) - rightPanelRect.getWidth();
/*     */       
/* 234 */       Rect stencilRect = rightPanelRect.size(10.0F).height(rightPanelRect.getHeight() - 40.0F);
/*     */       
/* 236 */       float xOff = rightPanelRect.getX() + 10.0F + selectX;
/* 237 */       float yOff = rightPanelRect.getY() + 10.0F + this.renderer.getEnchantScrollAnim().get();
/* 238 */       float scrollOff = 0.0F;
/*     */       
/* 240 */       if (Hover.isHovered(stencilRect, mouseX, mouseY)) {
/* 241 */         for (Map.Entry<String, Enchantment> enchant : (Iterable<Map.Entry<String, Enchantment>>)Enchantments.AUTOBUY.entrySet()) {
/* 242 */           if (Hover.isHovered(xOff, yOff, (rightPanelWidth - 20.0F), 20.0D, mouseX, mouseY)) {
/* 243 */             String lvl = "" + ((Enchantment)enchant.getValue()).getAbLvl();
/* 244 */             float lvlWidth = bold.get(14).getWidth(lvl);
/*     */             
/* 246 */             if (Hover.isHovered((xOff + rightPanelWidth - 40.0F - bold.get(14).getWidth("-+") - lvlWidth), (yOff + 3.0F), 15.0D, 15.0D, mouseX, mouseY)) {
/* 247 */               ((Enchantment)enchant.getValue()).setAbLvl(Math.max(1, ((Enchantment)enchant.getValue()).getAbLvl() - 1));
/* 248 */             } else if (Hover.isHovered((xOff + rightPanelWidth - 30.0F - bold.get(14).getWidth("+")), (yOff + 3.0F), 15.0D, 15.0D, mouseX, mouseY)) {
/* 249 */               ((Enchantment)enchant.getValue()).setAbLvl(Math.min(10, ((Enchantment)enchant.getValue()).getAbLvl() + 1));
/*     */             }
/* 251 */             else if (this.renderer.getSelectedEnchants().contains(enchant.getValue())) {
/* 252 */               this.renderer.getSelectedEnchants().remove(enchant.getValue());
/*     */             } else {
/* 254 */               this.renderer.getSelectedEnchants().add(enchant.getValue());
/*     */             } 
/*     */           } 
/*     */           
/* 258 */           scrollOff += 25.0F;
/* 259 */           yOff += 25.0F;
/*     */         } 
/*     */       }
/*     */       
/* 263 */       if (Hover.isHovered(this.renderer.getCancelEnchantButton(), mouseX, mouseY)) {
/* 264 */         this.renderer.setSelectEnchant(false);
/*     */       }
/*     */       
/* 267 */       if (Hover.isHovered(this.renderer.getConfirmEnchantButton(), mouseX, mouseY) && this.renderer.isSelectEnchant()) {
/* 268 */         if (this.renderer.getSelectedEnchants().isEmpty()) {
/* 269 */           rock.getAlertHandler().alert("Зачарование не выбрано", AlertType.ERROR);
/*     */         } else {
/* 271 */           this.renderer.setSelectEnchant(false);
/*     */           
/* 273 */           Map<String, Integer> enchants = new HashMap<>();
/* 274 */           for (Enchantment enchant : this.renderer.getSelectedEnchants()) {
/* 275 */             enchants.put("" + Registry.ENCHANTMENT.getId(enchant), Integer.valueOf(enchant.getAbLvl()));
/*     */           }
/* 277 */           this.renderer.getCurrentItem().update(enchants);
/*     */         } 
/*     */       }
/*     */       
/* 281 */       if (Hover.isHovered(this.renderer.getAddEnchantButton(), mouseX, mouseY)) {
/* 282 */         this.renderer.setSelectEnchant(true);
/*     */       }
/*     */       
/* 285 */       if (Hover.isHovered((rightPanelRect.getX() + 10.0F), (rightPanelRect.getY() + 10.0F + listX + this.renderer.getItemScrollAnim().get()), 30.0D, 30.0D, mouseX, mouseY)) {
/* 286 */         this.renderer.handleItemsSelectButtonClick();
/*     */       }
/*     */       
/* 289 */       if (!this.renderer.getSwapText().finished(false) && !this.renderer.getDisplayText().equals("Изменение предмета") && 
/* 290 */         Hover.isHovered((rightPanelRect.getX() + rightPanelRect.getWidth() - 10.0F - btnWidth + listX), (rightPanelRect.getY() + rightPanelRect.getHeight() - 10.0F - btnHeight + this.renderer.getItemScrollAnim().get()), btnWidth, btnHeight, mouseX, mouseY)) {
/* 291 */         this.renderer.handleAddButtonClick();
/*     */         
/* 293 */         this.renderer.swapText("Изменение предмета");
/* 294 */         reset();
/*     */       } 
/*     */ 
/*     */       
/* 298 */       if (!this.renderer.getSwapText().finished(false) && this.renderer.getDisplayText().equals("Изменение предмета")) {
/* 299 */         String cancel = "Отмена";
/* 300 */         float cancelbtnWidth = bold.get(14).getWidth(cancel) + 10.0F;
/* 301 */         if (Hover.isHovered((rightPanelRect.getX() + 10.0F + listX), (rightPanelRect.getY() + 50.0F - 50.0F * this.renderer.getSwapText().get() + rightPanelRect.getHeight() - 10.0F - btnHeight), cancelbtnWidth, btnHeight, mouseX, mouseY)) {
/* 302 */           this.renderer.swapText("Изменение предмета");
/* 303 */           reset();
/*     */         } 
/*     */         
/* 306 */         String delete = "Удалить";
/* 307 */         float deletebtnWidth = bold.get(14).getWidth(delete) + 10.0F;
/* 308 */         if (Hover.isHovered((rightPanelRect.getX() + rightPanelRect.getWidth() - 10.0F - deletebtnWidth + listX), (rightPanelRect.getY() + 50.0F - 50.0F * this.renderer.getSwapText().get() + rightPanelRect.getHeight() - 10.0F - btnHeight), deletebtnWidth, btnHeight, mouseX, mouseY)) {
/* 309 */           rock.getAutoBuy().getItems().remove(this.renderer.getCurrentItem());
/* 310 */           reset();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 315 */     super.mouseClicked(mouseX, mouseY, button);
/* 316 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private void reset() {
/* 321 */     this.renderer.swapText("Изменение предмета");
/*     */     
/* 323 */     AutoBuyItem defItem = new AutoBuyItem(Items.DIAMOND, 5000, 0, false);
/* 324 */     this.renderer.setCurrentItem(defItem);
/* 325 */     this.renderer.swapText("Добавление предмета");
/*     */     
/* 327 */     this.renderer.getPriceInput().setText("10000");
/* 328 */     this.renderer.getCountInput().setText("1");
/* 329 */     this.renderer.getDurabilityInput().setText("100");
/* 330 */     this.renderer.getSellInput().setText("15000");
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\autobu\\ui\AutoBuyScreen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */