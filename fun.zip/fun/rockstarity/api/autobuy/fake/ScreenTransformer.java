/*    */ package fun.rockstarity.api.autobuy.fake;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.screen.Screen;
/*    */ import net.minecraft.client.gui.screen.inventory.ChestScreen;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ScreenTransformer
/*    */ {
/*    */   private ScreenTransformer() {
/* 15 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*    */   }
/*    */   public static Screen transform(Screen screen) {
/* 18 */     if (screen instanceof ChestScreen) ChestScreen chestScreen = (ChestScreen)screen;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 38 */     Minecraft.getInstance().displayGuiScreen(screen);
/*    */     
/* 40 */     return screen;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\autobuy\fake\ScreenTransformer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */