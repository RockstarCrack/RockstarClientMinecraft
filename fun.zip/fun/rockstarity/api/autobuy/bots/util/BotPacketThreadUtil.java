/*    */ package fun.rockstarity.api.autobuy.bots.util;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.network.INetHandler;
/*    */ import net.minecraft.network.IPacket;
/*    */ import net.minecraft.network.ThreadQuickExitException;
/*    */ import net.minecraft.network.play.server.SJoinGamePacket;
/*    */ import net.minecraft.network.play.server.SRespawnPacket;
/*    */ import net.minecraft.util.RegistryKey;
/*    */ import net.minecraft.util.concurrent.ThreadTaskExecutor;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraft.world.server.ServerWorld;
/*    */ import net.optifine.util.PacketRunnable;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BotPacketThreadUtil
/*    */ {
/* 22 */   protected static Minecraft mc = Minecraft.getInstance();
/* 23 */   private static final Logger LOGGER = LogManager.getLogger();
/* 24 */   public static RegistryKey<World> lastDimensionType = null;
/*    */ 
/*    */   
/*    */   public static <T extends INetHandler> void checkThreadAndEnqueue(IPacket<T> packetIn, T processor, ServerWorld worldIn) throws ThreadQuickExitException {
/* 28 */     checkThreadAndEnqueue(packetIn, processor, (ThreadTaskExecutor<?>)worldIn.getServer());
/*    */   }
/*    */ 
/*    */   
/*    */   public static <T extends INetHandler> void checkThreadAndEnqueue(IPacket<T> packetIn, T processor, ThreadTaskExecutor<?> executor) throws ThreadQuickExitException {
/* 33 */     if (!executor.isOnExecutionThread()) {
/*    */       
/* 35 */       executor.execute((Runnable)new PacketRunnable(packetIn, () -> {
/*    */               clientPreProcessPacket(packetIn);
/*    */ 
/*    */               
/*    */               if (processor.getNetworkManager().isChannelOpen()) {
/*    */                 packetIn.processPacket(processor);
/*    */               } else {
/*    */                 LOGGER.debug("Ignoring packet due to disconnection: " + String.valueOf(packetIn));
/*    */               } 
/*    */             }));
/*    */ 
/*    */       
/* 47 */       throw ThreadQuickExitException.INSTANCE;
/*    */     } 
/*    */ 
/*    */     
/* 51 */     clientPreProcessPacket(packetIn);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected static void clientPreProcessPacket(IPacket p_clientPreProcessPacket_0_) {
/* 57 */     if (p_clientPreProcessPacket_0_ instanceof net.minecraft.network.play.server.SPlayerPositionLookPacket)
/*    */     {
/* 59 */       mc.worldRenderer.onPlayerPositionSet();
/*    */     }
/*    */     
/* 62 */     if (p_clientPreProcessPacket_0_ instanceof SRespawnPacket) {
/*    */       
/* 64 */       SRespawnPacket srespawnpacket = (SRespawnPacket)p_clientPreProcessPacket_0_;
/* 65 */       lastDimensionType = srespawnpacket.func_240827_c_();
/*    */     }
/* 67 */     else if (p_clientPreProcessPacket_0_ instanceof SJoinGamePacket) {
/*    */       
/* 69 */       SJoinGamePacket sjoingamepacket = (SJoinGamePacket)p_clientPreProcessPacket_0_;
/* 70 */       lastDimensionType = sjoingamepacket.func_240819_i_();
/*    */     }
/*    */     else {
/*    */       
/* 74 */       lastDimensionType = null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\autobuy\bot\\util\BotPacketThreadUtil.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */