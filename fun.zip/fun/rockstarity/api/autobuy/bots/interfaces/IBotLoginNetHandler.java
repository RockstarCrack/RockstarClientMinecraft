package fun.rockstarity.api.autobuy.bots.interfaces;

import net.minecraft.network.login.server.SCustomPayloadLoginPacket;
import net.minecraft.network.login.server.SDisconnectLoginPacket;
import net.minecraft.network.login.server.SEnableCompressionPacket;
import net.minecraft.network.login.server.SEncryptionRequestPacket;
import net.minecraft.network.login.server.SLoginSuccessPacket;

public interface IBotLoginNetHandler extends IBotNetHandler {
  void handleEncryptionRequest(SEncryptionRequestPacket paramSEncryptionRequestPacket);
  
  void handleLoginSuccess(SLoginSuccessPacket paramSLoginSuccessPacket);
  
  void handleDisconnect(SDisconnectLoginPacket paramSDisconnectLoginPacket);
  
  void handleEnableCompression(SEnableCompressionPacket paramSEnableCompressionPacket);
  
  void handleCustomPayloadLogin(SCustomPayloadLoginPacket paramSCustomPayloadLoginPacket);
}


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\autobuy\bots\interfaces\IBotLoginNetHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */