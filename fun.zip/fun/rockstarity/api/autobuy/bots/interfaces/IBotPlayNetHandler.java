package fun.rockstarity.api.autobuy.bots.interfaces;

import net.minecraft.network.play.server.SAdvancementInfoPacket;
import net.minecraft.network.play.server.SAnimateBlockBreakPacket;
import net.minecraft.network.play.server.SAnimateHandPacket;
import net.minecraft.network.play.server.SBlockActionPacket;
import net.minecraft.network.play.server.SCameraPacket;
import net.minecraft.network.play.server.SChangeBlockPacket;
import net.minecraft.network.play.server.SChangeGameStatePacket;
import net.minecraft.network.play.server.SChatPacket;
import net.minecraft.network.play.server.SChunkDataPacket;
import net.minecraft.network.play.server.SCloseWindowPacket;
import net.minecraft.network.play.server.SCollectItemPacket;
import net.minecraft.network.play.server.SCombatPacket;
import net.minecraft.network.play.server.SCommandListPacket;
import net.minecraft.network.play.server.SConfirmTransactionPacket;
import net.minecraft.network.play.server.SCooldownPacket;
import net.minecraft.network.play.server.SCustomPayloadPlayPacket;
import net.minecraft.network.play.server.SDestroyEntitiesPacket;
import net.minecraft.network.play.server.SDisconnectPacket;
import net.minecraft.network.play.server.SDisplayObjectivePacket;
import net.minecraft.network.play.server.SEntityEquipmentPacket;
import net.minecraft.network.play.server.SEntityHeadLookPacket;
import net.minecraft.network.play.server.SEntityMetadataPacket;
import net.minecraft.network.play.server.SEntityPacket;
import net.minecraft.network.play.server.SEntityPropertiesPacket;
import net.minecraft.network.play.server.SEntityStatusPacket;
import net.minecraft.network.play.server.SEntityTeleportPacket;
import net.minecraft.network.play.server.SEntityVelocityPacket;
import net.minecraft.network.play.server.SExplosionPacket;
import net.minecraft.network.play.server.SHeldItemChangePacket;
import net.minecraft.network.play.server.SJoinGamePacket;
import net.minecraft.network.play.server.SKeepAlivePacket;
import net.minecraft.network.play.server.SMapDataPacket;
import net.minecraft.network.play.server.SMerchantOffersPacket;
import net.minecraft.network.play.server.SMountEntityPacket;
import net.minecraft.network.play.server.SMoveVehiclePacket;
import net.minecraft.network.play.server.SMultiBlockChangePacket;
import net.minecraft.network.play.server.SOpenBookWindowPacket;
import net.minecraft.network.play.server.SOpenHorseWindowPacket;
import net.minecraft.network.play.server.SOpenSignMenuPacket;
import net.minecraft.network.play.server.SOpenWindowPacket;
import net.minecraft.network.play.server.SPlaceGhostRecipePacket;
import net.minecraft.network.play.server.SPlayEntityEffectPacket;
import net.minecraft.network.play.server.SPlaySoundEffectPacket;
import net.minecraft.network.play.server.SPlaySoundEventPacket;
import net.minecraft.network.play.server.SPlaySoundPacket;
import net.minecraft.network.play.server.SPlayerAbilitiesPacket;
import net.minecraft.network.play.server.SPlayerDiggingPacket;
import net.minecraft.network.play.server.SPlayerListHeaderFooterPacket;
import net.minecraft.network.play.server.SPlayerListItemPacket;
import net.minecraft.network.play.server.SPlayerLookPacket;
import net.minecraft.network.play.server.SPlayerPositionLookPacket;
import net.minecraft.network.play.server.SQueryNBTResponsePacket;
import net.minecraft.network.play.server.SRecipeBookPacket;
import net.minecraft.network.play.server.SRemoveEntityEffectPacket;
import net.minecraft.network.play.server.SRespawnPacket;
import net.minecraft.network.play.server.SScoreboardObjectivePacket;
import net.minecraft.network.play.server.SSelectAdvancementsTabPacket;
import net.minecraft.network.play.server.SSendResourcePackPacket;
import net.minecraft.network.play.server.SServerDifficultyPacket;
import net.minecraft.network.play.server.SSetExperiencePacket;
import net.minecraft.network.play.server.SSetPassengersPacket;
import net.minecraft.network.play.server.SSetSlotPacket;
import net.minecraft.network.play.server.SSpawnExperienceOrbPacket;
import net.minecraft.network.play.server.SSpawnMobPacket;
import net.minecraft.network.play.server.SSpawnMovingSoundEffectPacket;
import net.minecraft.network.play.server.SSpawnObjectPacket;
import net.minecraft.network.play.server.SSpawnPaintingPacket;
import net.minecraft.network.play.server.SSpawnParticlePacket;
import net.minecraft.network.play.server.SSpawnPlayerPacket;
import net.minecraft.network.play.server.SStatisticsPacket;
import net.minecraft.network.play.server.SStopSoundPacket;
import net.minecraft.network.play.server.STabCompletePacket;
import net.minecraft.network.play.server.STagsListPacket;
import net.minecraft.network.play.server.STeamsPacket;
import net.minecraft.network.play.server.STitlePacket;
import net.minecraft.network.play.server.SUnloadChunkPacket;
import net.minecraft.network.play.server.SUpdateBossInfoPacket;
import net.minecraft.network.play.server.SUpdateChunkPositionPacket;
import net.minecraft.network.play.server.SUpdateHealthPacket;
import net.minecraft.network.play.server.SUpdateLightPacket;
import net.minecraft.network.play.server.SUpdateRecipesPacket;
import net.minecraft.network.play.server.SUpdateScorePacket;
import net.minecraft.network.play.server.SUpdateTileEntityPacket;
import net.minecraft.network.play.server.SUpdateTimePacket;
import net.minecraft.network.play.server.SUpdateViewDistancePacket;
import net.minecraft.network.play.server.SWindowItemsPacket;
import net.minecraft.network.play.server.SWindowPropertyPacket;
import net.minecraft.network.play.server.SWorldBorderPacket;
import net.minecraft.network.play.server.SWorldSpawnChangedPacket;

public interface IBotPlayNetHandler extends IBotNetHandler {
  void handleSpawnObject(SSpawnObjectPacket paramSSpawnObjectPacket);
  
  void handleSpawnExperienceOrb(SSpawnExperienceOrbPacket paramSSpawnExperienceOrbPacket);
  
  void handleSpawnMob(SSpawnMobPacket paramSSpawnMobPacket);
  
  void handleScoreboardObjective(SScoreboardObjectivePacket paramSScoreboardObjectivePacket);
  
  void handleSpawnPainting(SSpawnPaintingPacket paramSSpawnPaintingPacket);
  
  void handleSpawnPlayer(SSpawnPlayerPacket paramSSpawnPlayerPacket);
  
  void handleAnimation(SAnimateHandPacket paramSAnimateHandPacket);
  
  void handleStatistics(SStatisticsPacket paramSStatisticsPacket);
  
  void handleRecipeBook(SRecipeBookPacket paramSRecipeBookPacket);
  
  void handleBlockBreakAnim(SAnimateBlockBreakPacket paramSAnimateBlockBreakPacket);
  
  void handleSignEditorOpen(SOpenSignMenuPacket paramSOpenSignMenuPacket);
  
  void handleUpdateTileEntity(SUpdateTileEntityPacket paramSUpdateTileEntityPacket);
  
  void handleBlockAction(SBlockActionPacket paramSBlockActionPacket);
  
  void handleBlockChange(SChangeBlockPacket paramSChangeBlockPacket);
  
  void handleChat(SChatPacket paramSChatPacket);
  
  void handleMultiBlockChange(SMultiBlockChangePacket paramSMultiBlockChangePacket);
  
  void handleMaps(SMapDataPacket paramSMapDataPacket);
  
  void handleConfirmTransaction(SConfirmTransactionPacket paramSConfirmTransactionPacket);
  
  void handleCloseWindow(SCloseWindowPacket paramSCloseWindowPacket);
  
  void handleWindowItems(SWindowItemsPacket paramSWindowItemsPacket);
  
  void handleOpenHorseWindow(SOpenHorseWindowPacket paramSOpenHorseWindowPacket);
  
  void handleWindowProperty(SWindowPropertyPacket paramSWindowPropertyPacket);
  
  void handleSetSlot(SSetSlotPacket paramSSetSlotPacket);
  
  void handleCustomPayload(SCustomPayloadPlayPacket paramSCustomPayloadPlayPacket);
  
  void handleDisconnect(SDisconnectPacket paramSDisconnectPacket);
  
  void handleEntityStatus(SEntityStatusPacket paramSEntityStatusPacket);
  
  void handleEntityAttach(SMountEntityPacket paramSMountEntityPacket);
  
  void handleSetPassengers(SSetPassengersPacket paramSSetPassengersPacket);
  
  void handleExplosion(SExplosionPacket paramSExplosionPacket);
  
  void handleChangeGameState(SChangeGameStatePacket paramSChangeGameStatePacket);
  
  void handleKeepAlive(SKeepAlivePacket paramSKeepAlivePacket);
  
  void handleChunkData(SChunkDataPacket paramSChunkDataPacket);
  
  void processChunkUnload(SUnloadChunkPacket paramSUnloadChunkPacket);
  
  void handleEffect(SPlaySoundEventPacket paramSPlaySoundEventPacket);
  
  void handleJoinGame(SJoinGamePacket paramSJoinGamePacket);
  
  void handleEntityMovement(SEntityPacket paramSEntityPacket);
  
  void handlePlayerPosLook(SPlayerPositionLookPacket paramSPlayerPositionLookPacket);
  
  void handleParticles(SSpawnParticlePacket paramSSpawnParticlePacket);
  
  void handlePlayerAbilities(SPlayerAbilitiesPacket paramSPlayerAbilitiesPacket);
  
  void handlePlayerListItem(SPlayerListItemPacket paramSPlayerListItemPacket);
  
  void handleDestroyEntities(SDestroyEntitiesPacket paramSDestroyEntitiesPacket);
  
  void handleRemoveEntityEffect(SRemoveEntityEffectPacket paramSRemoveEntityEffectPacket);
  
  void handleRespawn(SRespawnPacket paramSRespawnPacket);
  
  void handleEntityHeadLook(SEntityHeadLookPacket paramSEntityHeadLookPacket);
  
  void handleHeldItemChange(SHeldItemChangePacket paramSHeldItemChangePacket);
  
  void handleDisplayObjective(SDisplayObjectivePacket paramSDisplayObjectivePacket);
  
  void handleEntityMetadata(SEntityMetadataPacket paramSEntityMetadataPacket);
  
  void handleEntityVelocity(SEntityVelocityPacket paramSEntityVelocityPacket);
  
  void handleEntityEquipment(SEntityEquipmentPacket paramSEntityEquipmentPacket);
  
  void handleSetExperience(SSetExperiencePacket paramSSetExperiencePacket);
  
  void handleUpdateHealth(SUpdateHealthPacket paramSUpdateHealthPacket);
  
  void handleTeams(STeamsPacket paramSTeamsPacket);
  
  void handleUpdateScore(SUpdateScorePacket paramSUpdateScorePacket);
  
  void func_230488_a_(SWorldSpawnChangedPacket paramSWorldSpawnChangedPacket);
  
  void handleTimeUpdate(SUpdateTimePacket paramSUpdateTimePacket);
  
  void handleSoundEffect(SPlaySoundEffectPacket paramSPlaySoundEffectPacket);
  
  void handleSpawnMovingSoundEffect(SSpawnMovingSoundEffectPacket paramSSpawnMovingSoundEffectPacket);
  
  void handleCustomSound(SPlaySoundPacket paramSPlaySoundPacket);
  
  void handleCollectItem(SCollectItemPacket paramSCollectItemPacket);
  
  void handleEntityTeleport(SEntityTeleportPacket paramSEntityTeleportPacket);
  
  void handleEntityProperties(SEntityPropertiesPacket paramSEntityPropertiesPacket);
  
  void handleEntityEffect(SPlayEntityEffectPacket paramSPlayEntityEffectPacket);
  
  void handleTags(STagsListPacket paramSTagsListPacket);
  
  void handleCombatEvent(SCombatPacket paramSCombatPacket);
  
  void handleServerDifficulty(SServerDifficultyPacket paramSServerDifficultyPacket);
  
  void handleCamera(SCameraPacket paramSCameraPacket);
  
  void handleWorldBorder(SWorldBorderPacket paramSWorldBorderPacket);
  
  void handleTitle(STitlePacket paramSTitlePacket);
  
  void handlePlayerListHeaderFooter(SPlayerListHeaderFooterPacket paramSPlayerListHeaderFooterPacket);
  
  void handleResourcePack(SSendResourcePackPacket paramSSendResourcePackPacket);
  
  void handleUpdateBossInfo(SUpdateBossInfoPacket paramSUpdateBossInfoPacket);
  
  void handleCooldown(SCooldownPacket paramSCooldownPacket);
  
  void handleMoveVehicle(SMoveVehiclePacket paramSMoveVehiclePacket);
  
  void handleAdvancementInfo(SAdvancementInfoPacket paramSAdvancementInfoPacket);
  
  void handleSelectAdvancementsTab(SSelectAdvancementsTabPacket paramSSelectAdvancementsTabPacket);
  
  void handlePlaceGhostRecipe(SPlaceGhostRecipePacket paramSPlaceGhostRecipePacket);
  
  void handleCommandList(SCommandListPacket paramSCommandListPacket);
  
  void handleStopSound(SStopSoundPacket paramSStopSoundPacket);
  
  void handleTabComplete(STabCompletePacket paramSTabCompletePacket);
  
  void handleUpdateRecipes(SUpdateRecipesPacket paramSUpdateRecipesPacket);
  
  void handlePlayerLook(SPlayerLookPacket paramSPlayerLookPacket);
  
  void handleNBTQueryResponse(SQueryNBTResponsePacket paramSQueryNBTResponsePacket);
  
  void handleUpdateLight(SUpdateLightPacket paramSUpdateLightPacket);
  
  void handleOpenBookPacket(SOpenBookWindowPacket paramSOpenBookWindowPacket);
  
  void handleOpenWindowPacket(SOpenWindowPacket paramSOpenWindowPacket);
  
  void handleMerchantOffers(SMerchantOffersPacket paramSMerchantOffersPacket);
  
  void handleUpdateViewDistancePacket(SUpdateViewDistancePacket paramSUpdateViewDistancePacket);
  
  void handleChunkPositionPacket(SUpdateChunkPositionPacket paramSUpdateChunkPositionPacket);
  
  void handleAcknowledgePlayerDigging(SPlayerDiggingPacket paramSPlayerDiggingPacket);
}


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\autobuy\bots\interfaces\IBotPlayNetHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */