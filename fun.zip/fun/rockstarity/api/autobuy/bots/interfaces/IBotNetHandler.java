package fun.rockstarity.api.autobuy.bots.interfaces;

import fun.rockstarity.api.autobuy.bots.connection.BotNetworkManager;
import net.minecraft.util.text.ITextComponent;

public interface IBotNetHandler {
  void onDisconnect(ITextComponent paramITextComponent);
  
  BotNetworkManager getNetworkManager();
}


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\autobuy\bots\interfaces\IBotNetHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */