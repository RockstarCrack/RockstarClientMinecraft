/*    */ package fun.rockstarity.api.autobuy.bots;
/*    */ 
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.autobuy.bots.player.BotPlayer;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.secure.Debugger;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BotsHandler
/*    */   implements IAccess
/*    */ {
/*    */   private BotPlayer lastBot;
/*    */   private String lastName;
/* 24 */   private final ArrayList<Bot> bots = new ArrayList<>(); public ArrayList<Bot> getBots() { return this.bots; }
/*    */ 
/*    */   
/* 27 */   public BotPlayer getLastBot() { return this.lastBot; } public void setLastBot(BotPlayer lastBot) { this.lastBot = lastBot; }
/* 28 */   public String getLastName() { return this.lastName; } public void setLastName(String lastName) { this.lastName = lastName; }
/*    */   
/*    */   public void onEvent(Event event) {
/* 31 */     if (event instanceof fun.rockstarity.api.events.list.player.EventUpdate) {
/*    */       try {
/* 33 */         for (Bot bot : this.bots) {
/* 34 */           BotPlayer player = bot.getPlayer();
/*    */           
/* 36 */           if (player.getHealth() <= 0.0F) {
/* 37 */             player.respawnPlayer();
/*    */           }
/*    */         }
/*    */       
/*    */       }
/* 42 */       catch (Exception e) {
/* 43 */         Debugger.print(e);
/*    */       } 
/*    */     }
/*    */   }
/*    */   
/*    */   public void tickEntities() {
/*    */     try {
/* 50 */       for (Bot bot : this.bots) {
/* 51 */         bot.getWorld().tickEntities();
/* 52 */         bot.getWorld().removeEntityFromWorld(mc.player.getEntityId());
/*    */       } 
/* 54 */     } catch (Exception e) {
/* 55 */       Debugger.print(e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void worldTick() {
/*    */     try {
/* 61 */       for (Bot bot : this.bots) {
/* 62 */         bot.getWorld().tick(() -> true);
/*    */       
/*    */       }
/*    */     
/*    */     }
/* 67 */     catch (Exception e) {
/* 68 */       Debugger.print(e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void tick() {
/*    */     try {
/* 74 */       for (Bot bot : this.bots);
/*    */     
/*    */     }
/* 77 */     catch (Exception e) {
/* 78 */       Debugger.print(e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void controllerTick() {
/*    */     try {
/* 84 */       for (Bot bot : this.bots) {
/* 85 */         bot.getController().tick();
/*    */       }
/* 87 */     } catch (Exception e) {
/* 88 */       Debugger.print(e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\autobuy\bots\BotsHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */