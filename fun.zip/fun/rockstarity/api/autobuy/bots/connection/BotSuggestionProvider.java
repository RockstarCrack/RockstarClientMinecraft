/*     */ package fun.rockstarity.api.autobuy.bots.connection;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.mojang.brigadier.context.CommandContext;
/*     */ import com.mojang.brigadier.suggestion.Suggestions;
/*     */ import com.mojang.brigadier.suggestion.SuggestionsBuilder;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.stream.Stream;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.player.ClientPlayerEntity;
/*     */ import net.minecraft.client.network.play.NetworkPlayerInfo;
/*     */ import net.minecraft.command.ISuggestionProvider;
/*     */ import net.minecraft.network.IPacket;
/*     */ import net.minecraft.network.play.client.CTabCompletePacket;
/*     */ import net.minecraft.util.RegistryKey;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.BlockRayTraceResult;
/*     */ import net.minecraft.util.math.EntityRayTraceResult;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.util.math.vector.Vector3d;
/*     */ import net.minecraft.util.registry.DynamicRegistries;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ public class BotSuggestionProvider
/*     */   implements ISuggestionProvider
/*     */ {
/*     */   private final BotPlayNetHandler connection;
/*     */   private final Minecraft mc;
/*  36 */   private int currentTransaction = -1;
/*     */   
/*     */   private CompletableFuture<Suggestions> future;
/*     */   
/*     */   public BotSuggestionProvider(BotPlayNetHandler botPlayNetHandler, Minecraft p_i49558_2_) {
/*  41 */     this.connection = botPlayNetHandler;
/*  42 */     this.mc = p_i49558_2_;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<String> getPlayerNames() {
/*  47 */     List<String> list = Lists.newArrayList();
/*     */     
/*  49 */     for (NetworkPlayerInfo networkplayerinfo : this.connection.getPlayerInfoMap())
/*     */     {
/*  51 */       list.add(networkplayerinfo.getGameProfile().getName());
/*     */     }
/*     */     
/*  54 */     return list;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<String> getTargetedEntity() {
/*  59 */     return (this.mc.objectMouseOver != null && this.mc.objectMouseOver.getType() == RayTraceResult.Type.ENTITY) ? Collections.<String>singleton(((EntityRayTraceResult)this.mc.objectMouseOver).getEntity().getCachedUniqueIdString()) : Collections.<String>emptyList();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<String> getTeamNames() {
/*  64 */     return this.connection.getWorld().getScoreboard().getTeamNames();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<ResourceLocation> getSoundResourceLocations() {
/*  69 */     return this.mc.getSoundHandler().getAvailableSounds();
/*     */   }
/*     */ 
/*     */   
/*     */   public Stream<ResourceLocation> getRecipeResourceLocations() {
/*  74 */     return this.connection.getRecipeManager().getKeys();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasPermissionLevel(int level) {
/*  80 */     ClientPlayerEntity clientplayerentity = this.mc.player;
/*  81 */     return (clientplayerentity != null) ? clientplayerentity.hasPermissionLevel(level) : ((level == 0));
/*     */   }
/*     */ 
/*     */   
/*     */   public CompletableFuture<Suggestions> getSuggestionsFromServer(CommandContext<ISuggestionProvider> context, SuggestionsBuilder suggestionsBuilder) {
/*  86 */     if (this.future != null)
/*     */     {
/*  88 */       this.future.cancel(false);
/*     */     }
/*     */     
/*  91 */     this.future = new CompletableFuture<>();
/*  92 */     int i = ++this.currentTransaction;
/*  93 */     this.connection.sendPacket((IPacket<?>)new CTabCompletePacket(i, context.getInput()));
/*  94 */     return this.future;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String formatDouble(double p_209001_0_) {
/*  99 */     return String.format(Locale.ROOT, "%.2f", new Object[] { Double.valueOf(p_209001_0_) });
/*     */   }
/*     */ 
/*     */   
/*     */   private static String formatInt(int p_209002_0_) {
/* 104 */     return Integer.toString(p_209002_0_);
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<ISuggestionProvider.Coordinates> func_217294_q() {
/* 109 */     RayTraceResult raytraceresult = this.mc.objectMouseOver;
/*     */     
/* 111 */     if (raytraceresult != null && raytraceresult.getType() == RayTraceResult.Type.BLOCK) {
/*     */       
/* 113 */       BlockPos blockpos = ((BlockRayTraceResult)raytraceresult).getPos();
/* 114 */       return Collections.singleton(new ISuggestionProvider.Coordinates(formatInt(blockpos.getX()), formatInt(blockpos.getY()), formatInt(blockpos.getZ())));
/*     */     } 
/*     */ 
/*     */     
/* 118 */     return super.func_217294_q();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<ISuggestionProvider.Coordinates> func_217293_r() {
/* 124 */     RayTraceResult raytraceresult = this.mc.objectMouseOver;
/*     */     
/* 126 */     if (raytraceresult != null && raytraceresult.getType() == RayTraceResult.Type.BLOCK) {
/*     */       
/* 128 */       Vector3d vector3d = raytraceresult.getHitVec();
/* 129 */       return Collections.singleton(new ISuggestionProvider.Coordinates(formatDouble(vector3d.x), formatDouble(vector3d.y), formatDouble(vector3d.z)));
/*     */     } 
/*     */ 
/*     */     
/* 133 */     return super.func_217293_r();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<RegistryKey<World>> func_230390_p_() {
/* 139 */     return this.connection.func_239164_m_();
/*     */   }
/*     */ 
/*     */   
/*     */   public DynamicRegistries func_241861_q() {
/* 144 */     return this.connection.func_239165_n_();
/*     */   }
/*     */ 
/*     */   
/*     */   public void handleResponse(int transaction, Suggestions result) {
/* 149 */     if (transaction == this.currentTransaction) {
/*     */       
/* 151 */       this.future.complete(result);
/* 152 */       this.future = null;
/* 153 */       this.currentTransaction = -1;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\autobuy\bots\connection\BotSuggestionProvider.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */