/*      */ package fun.rockstarity.api.autobuy.bots.connection;
/*      */ 
/*      */ import net.minecraft.network.play.server.SPlayerListItemPacket;
/*      */ import net.minecraft.network.play.server.SRecipeBookPacket;
/*      */ import net.minecraft.network.play.server.STitlePacket;
/*      */ import net.minecraft.scoreboard.ServerScoreboard;
/*      */ 


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\autobuy\bots\connection\BotPlayNetHandler$2.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */