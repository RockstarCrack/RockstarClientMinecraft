/*     */ package fun.rockstarity.api.autobuy.bots.connection;
/*     */ 
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import com.mojang.authlib.exceptions.AuthenticationException;
/*     */ import com.mojang.authlib.exceptions.AuthenticationUnavailableException;
/*     */ import com.mojang.authlib.exceptions.InsufficientPrivilegesException;
/*     */ import com.mojang.authlib.exceptions.InvalidCredentialsException;
/*     */ import com.mojang.authlib.minecraft.MinecraftSessionService;
/*     */ import fun.rockstarity.api.helpers.game.Chat;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import java.math.BigInteger;
/*     */ import java.security.PublicKey;
/*     */ import java.util.function.Consumer;
/*     */ import javax.annotation.Nullable;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.SecretKey;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.DialogTexts;
/*     */ import net.minecraft.client.gui.screen.DisconnectedScreen;
/*     */ import net.minecraft.client.gui.screen.Screen;
/*     */ import net.minecraft.client.network.login.IClientLoginNetHandler;
/*     */ import net.minecraft.network.INetHandler;
/*     */ import net.minecraft.network.IPacket;
/*     */ import net.minecraft.network.NetworkManager;
/*     */ import net.minecraft.network.PacketBuffer;
/*     */ import net.minecraft.network.ProtocolType;
/*     */ import net.minecraft.network.login.client.CCustomPayloadLoginPacket;
/*     */ import net.minecraft.network.login.client.CEncryptionResponsePacket;
/*     */ import net.minecraft.network.login.server.SCustomPayloadLoginPacket;
/*     */ import net.minecraft.network.login.server.SDisconnectLoginPacket;
/*     */ import net.minecraft.network.login.server.SEnableCompressionPacket;
/*     */ import net.minecraft.network.login.server.SEncryptionRequestPacket;
/*     */ import net.minecraft.network.login.server.SLoginSuccessPacket;
/*     */ import net.minecraft.realms.DisconnectedRealmsScreen;
/*     */ import net.minecraft.util.CryptException;
/*     */ import net.minecraft.util.CryptManager;
/*     */ import net.minecraft.util.HTTPUtil;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TranslationTextComponent;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BotLoginNetHandler
/*     */   implements IClientLoginNetHandler
/*     */ {
/*  49 */   private static final Logger LOGGER = LogManager.getLogger();
/*     */   
/*     */   private final Minecraft mc;
/*     */   @Nullable
/*     */   private final Screen previousGuiScreen;
/*     */   private final Consumer<ITextComponent> statusMessageConsumer;
/*     */   private final BotNetworkManager networkManager;
/*     */   private GameProfile gameProfile;
/*     */   
/*     */   public BotLoginNetHandler(BotNetworkManager networkManager2, Minecraft mcIn, @Nullable Screen previousScreen, Consumer<ITextComponent> statusMessageConsumerIn) {
/*  59 */     this.networkManager = networkManager2;
/*  60 */     this.mc = mcIn;
/*  61 */     this.previousGuiScreen = previousScreen;
/*  62 */     this.statusMessageConsumer = statusMessageConsumerIn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleEncryptionRequest(SEncryptionRequestPacket packetIn) {
/*     */     Cipher cipher, cipher1;
/*     */     String s;
/*     */     CEncryptionResponsePacket cencryptionresponsepacket;
/*     */     try {
/*  74 */       SecretKey secretkey = CryptManager.createNewSharedKey();
/*  75 */       PublicKey publickey = packetIn.getPublicKey();
/*  76 */       s = (new BigInteger(CryptManager.getServerIdHash(packetIn.getServerId(), publickey, secretkey))).toString(16);
/*  77 */       cipher = CryptManager.createNetCipherInstance(2, secretkey);
/*  78 */       cipher1 = CryptManager.createNetCipherInstance(1, secretkey);
/*  79 */       cencryptionresponsepacket = new CEncryptionResponsePacket(secretkey, publickey, packetIn.getVerifyToken());
/*     */     }
/*  81 */     catch (CryptException cryptexception) {
/*     */       
/*  83 */       throw new IllegalStateException("Protocol error", cryptexception);
/*     */     } 
/*     */     
/*  86 */     this.statusMessageConsumer.accept(new TranslationTextComponent("connect.authorizing"));
/*  87 */     HTTPUtil.DOWNLOADER_EXECUTOR.submit(() -> {
/*     */           ITextComponent itextcomponent = joinServer(s);
/*     */           if (itextcomponent != null) {
/*     */             if (this.mc.getCurrentServerData() == null || !this.mc.getCurrentServerData().isOnLAN()) {
/*     */               this.networkManager.closeChannel(itextcomponent);
/*     */               return;
/*     */             } 
/*     */             LOGGER.warn(itextcomponent.getString());
/*     */           } 
/*     */           this.statusMessageConsumer.accept(new TranslationTextComponent("connect.encrypting"));
/*     */           this.networkManager.sendPacket((IPacket<?>)cencryptionresponsepacket, ());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private ITextComponent joinServer(String serverHash) {
/*     */     try {
/* 114 */       getSessionService().joinServer(this.mc.getSession().getProfile(), this.mc.getSession().getToken(), serverHash);
/* 115 */       return null;
/*     */     }
/* 117 */     catch (AuthenticationUnavailableException authenticationunavailableexception) {
/*     */       
/* 119 */       return (ITextComponent)new TranslationTextComponent("disconnect.loginFailedInfo", new Object[] { new TranslationTextComponent("disconnect.loginFailedInfo.serversUnavailable") });
/*     */     }
/* 121 */     catch (InvalidCredentialsException invalidcredentialsexception) {
/*     */       
/* 123 */       return (ITextComponent)new TranslationTextComponent("disconnect.loginFailedInfo", new Object[] { new TranslationTextComponent("disconnect.loginFailedInfo.invalidSession") });
/*     */     }
/* 125 */     catch (InsufficientPrivilegesException insufficientprivilegesexception) {
/*     */       
/* 127 */       return (ITextComponent)new TranslationTextComponent("disconnect.loginFailedInfo", new Object[] { new TranslationTextComponent("disconnect.loginFailedInfo.insufficientPrivileges") });
/*     */     }
/* 129 */     catch (AuthenticationException authenticationexception) {
/*     */       
/* 131 */       return (ITextComponent)new TranslationTextComponent("disconnect.loginFailedInfo", new Object[] { authenticationexception.getMessage() });
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private MinecraftSessionService getSessionService() {
/* 137 */     return this.mc.getSessionService();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleLoginSuccess(SLoginSuccessPacket packetIn) {
/* 143 */     this.gameProfile = packetIn.getProfile();
/* 144 */     this.networkManager.setConnectionState(ProtocolType.PLAY);
/* 145 */     BotPlayNetHandler playHandler = new BotPlayNetHandler(this.mc, this.previousGuiScreen, this.networkManager, this.gameProfile);
/* 146 */     this.networkManager.playHandler = playHandler;
/* 147 */     this.networkManager.setNetHandler((INetHandler)playHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onDisconnect(ITextComponent reason) {
/* 155 */     Chat.msg("Отконектило");
/*     */     
/* 157 */     if (this.previousGuiScreen != null && this.previousGuiScreen instanceof net.minecraft.realms.RealmsScreen) {
/*     */       
/* 159 */       this.mc.displayGuiScreen((Screen)new DisconnectedRealmsScreen(this.previousGuiScreen, DialogTexts.CONNECTION_FAILED, reason));
/*     */     }
/*     */     else {
/*     */       
/* 163 */       this.mc.displayGuiScreen((Screen)new DisconnectedScreen(this.previousGuiScreen, DialogTexts.CONNECTION_FAILED, reason));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void handleDisconnect(SDisconnectLoginPacket packetIn) {
/* 169 */     Chat.msg("Отконектило");
/*     */     
/* 171 */     this.networkManager.closeChannel(packetIn.getReason());
/*     */   }
/*     */ 
/*     */   
/*     */   public void handleEnableCompression(SEnableCompressionPacket packetIn) {
/* 176 */     if (!this.networkManager.isLocalChannel())
/*     */     {
/* 178 */       this.networkManager.setCompressionThreshold(packetIn.getCompressionThreshold());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void handleCustomPayloadLogin(SCustomPayloadLoginPacket packetIn) {
/* 184 */     this.statusMessageConsumer.accept(new TranslationTextComponent("connect.negotiating"));
/* 185 */     this.networkManager.sendPacket((IPacket<?>)new CCustomPayloadLoginPacket(packetIn.getTransaction(), (PacketBuffer)null));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NetworkManager getNetworkManager() {
/* 191 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\autobuy\bots\connection\BotLoginNetHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */