/*      */ package fun.rockstarity.api.autobuy.bots.world;
/*      */ import com.google.common.collect.Lists;
/*      */ import com.google.common.collect.Maps;
/*      */ import fun.rockstarity.api.autobuy.bots.connection.BotPlayNetHandler;
/*      */ import fun.rockstarity.api.autobuy.bots.player.BotPlayer;
/*      */ import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
/*      */ import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
/*      */ import it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap;
/*      */ import it.unimi.dsi.fastutil.objects.ObjectIterator;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Random;
/*      */ import java.util.function.BooleanSupplier;
/*      */ import java.util.function.Supplier;
/*      */ import javax.annotation.Nullable;
/*      */ import net.minecraft.block.Block;
/*      */ import net.minecraft.block.BlockState;
/*      */ import net.minecraft.block.Blocks;
/*      */ import net.minecraft.client.Minecraft;
/*      */ import net.minecraft.client.audio.EntityTickableSound;
/*      */ import net.minecraft.client.audio.ISound;
/*      */ import net.minecraft.client.audio.SimpleSound;
/*      */ import net.minecraft.client.entity.player.AbstractClientPlayerEntity;
/*      */ import net.minecraft.client.multiplayer.PlayerController;
/*      */ import net.minecraft.client.renderer.WorldRenderer;
/*      */ import net.minecraft.client.renderer.color.ColorCache;
/*      */ import net.minecraft.client.world.ClientWorld;
/*      */ import net.minecraft.client.world.DimensionRenderInfo;
/*      */ import net.minecraft.crash.CrashReport;
/*      */ import net.minecraft.crash.CrashReportCategory;
/*      */ import net.minecraft.crash.ReportedException;
/*      */ import net.minecraft.entity.Entity;
/*      */ import net.minecraft.entity.player.PlayerEntity;
/*      */ import net.minecraft.fluid.Fluid;
/*      */ import net.minecraft.fluid.FluidState;
/*      */ import net.minecraft.item.ItemStack;
/*      */ import net.minecraft.item.crafting.RecipeManager;
/*      */ import net.minecraft.network.IPacket;
/*      */ import net.minecraft.particles.IParticleData;
/*      */ import net.minecraft.particles.ParticleTypes;
/*      */ import net.minecraft.profiler.IProfiler;
/*      */ import net.minecraft.scoreboard.Scoreboard;
/*      */ import net.minecraft.server.MinecraftServer;
/*      */ import net.minecraft.tags.BlockTags;
/*      */ import net.minecraft.tags.ITag;
/*      */ import net.minecraft.util.Direction;
/*      */ import net.minecraft.util.RegistryKey;
/*      */ import net.minecraft.util.SoundCategory;
/*      */ import net.minecraft.util.SoundEvent;
/*      */ import net.minecraft.util.Util;
/*      */ import net.minecraft.util.math.BlockPos;
/*      */ import net.minecraft.util.math.CubeCoordinateIterator;
/*      */ import net.minecraft.util.math.MathHelper;
/*      */ import net.minecraft.util.math.shapes.VoxelShape;
/*      */ import net.minecraft.util.math.vector.Vector3d;
/*      */ import net.minecraft.util.registry.DynamicRegistries;
/*      */ import net.minecraft.util.registry.Registry;
/*      */ import net.minecraft.util.text.ITextComponent;
/*      */ import net.minecraft.util.text.TranslationTextComponent;
/*      */ import net.minecraft.world.Difficulty;
/*      */ import net.minecraft.world.DimensionType;
/*      */ import net.minecraft.world.EmptyTickList;
/*      */ import net.minecraft.world.GameRules;
/*      */ import net.minecraft.world.GameType;
/*      */ import net.minecraft.world.IBlockReader;
/*      */ import net.minecraft.world.ITickList;
/*      */ import net.minecraft.world.World;
/*      */ import net.minecraft.world.biome.Biome;
/*      */ import net.minecraft.world.biome.BiomeColors;
/*      */ import net.minecraft.world.biome.Biomes;
/*      */ import net.minecraft.world.biome.ParticleEffectAmbience;
/*      */ import net.minecraft.world.chunk.AbstractChunkProvider;
/*      */ import net.minecraft.world.chunk.Chunk;
/*      */ import net.minecraft.world.chunk.ChunkStatus;
/*      */ import net.minecraft.world.gen.Heightmap;
/*      */ import net.minecraft.world.level.ColorResolver;
/*      */ import net.minecraft.world.storage.ISpawnWorldInfo;
/*      */ import net.minecraft.world.storage.IWorldInfo;
/*      */ import net.minecraft.world.storage.MapData;
/*      */ import net.optifine.Config;
/*      */ import net.optifine.CustomGuis;
/*      */ import net.optifine.DynamicLights;
/*      */ import net.optifine.RandomEntities;
/*      */ import net.optifine.override.PlayerControllerOF;
/*      */ import net.optifine.reflect.Reflector;
/*      */ import net.optifine.reflect.ReflectorForge;
/*      */ import net.optifine.shaders.Shaders;
/*      */ 
/*      */ public class BotWorld extends World {
/*      */   private BotPlayer bot;
/*      */   
/*      */   public void setBot(BotPlayer bot) {
/*   94 */     this.bot = bot;
/*      */   }
/*   96 */   private final Int2ObjectMap<Entity> entitiesById = (Int2ObjectMap<Entity>)new Int2ObjectOpenHashMap();
/*      */   private final BotPlayNetHandler connection;
/*      */   private final WorldRenderer worldRenderer;
/*      */   private final ClientWorld.ClientWorldInfo field_239130_d_;
/*      */   private final DimensionRenderInfo field_239131_x_;
/*  101 */   private final Minecraft mc = Minecraft.getInstance();
/*  102 */   private final List<AbstractClientPlayerEntity> players = Lists.newArrayList();
/*  103 */   private Scoreboard scoreboard = new Scoreboard();
/*  104 */   private final Map<String, MapData> maps = Maps.newHashMap();
/*      */ 
/*      */   
/*      */   private int timeLightningFlash;
/*      */   
/*      */   private final Object2ObjectArrayMap<ColorResolver, ColorCache> colorCaches;
/*      */   
/*      */   private final BotChunkProvider field_239129_E_;
/*      */   
/*      */   private boolean playerUpdate;
/*      */ 
/*      */   
/*      */   public BotWorld(BotPlayNetHandler botPlayNetHandler, ClientWorld.ClientWorldInfo p_i242067_2_, RegistryKey<World> p_i242067_3_, DimensionType p_i242067_4_, int p_i242067_5_, Supplier<IProfiler> p_i242067_6_, WorldRenderer p_i242067_7_, boolean p_i242067_8_, long p_i242067_9_) {
/*  117 */     super((ISpawnWorldInfo)p_i242067_2_, p_i242067_3_, p_i242067_4_, p_i242067_6_, true, p_i242067_8_, p_i242067_9_); this.colorCaches = (Object2ObjectArrayMap<ColorResolver, ColorCache>)Util.make(new Object2ObjectArrayMap(3), p_lambda$new$0_0_ -> { p_lambda$new$0_0_.put(BiomeColors.GRASS_COLOR, new ColorCache()); p_lambda$new$0_0_.put(BiomeColors.FOLIAGE_COLOR, new ColorCache()); p_lambda$new$0_0_.put(BiomeColors.WATER_COLOR, new ColorCache());
/*  118 */         }); this.playerUpdate = false; this.connection = botPlayNetHandler;
/*  119 */     this.field_239129_E_ = new BotChunkProvider(this, p_i242067_5_);
/*  120 */     this.field_239130_d_ = p_i242067_2_;
/*  121 */     this.worldRenderer = p_i242067_7_;
/*  122 */     this.field_239131_x_ = DimensionRenderInfo.func_243495_a(p_i242067_4_);
/*  123 */     func_239136_a_(new BlockPos(8, 64, 8), 0.0F);
/*  124 */     calculateInitialSkylight();
/*  125 */     calculateInitialWeather();
/*      */     
/*  127 */     if (Reflector.CapabilityProvider_gatherCapabilities.exists())
/*      */     {
/*  129 */       Reflector.call(this, Reflector.CapabilityProvider_gatherCapabilities, new Object[0]);
/*      */     }
/*      */     
/*  132 */     Reflector.postForgeBusEvent(Reflector.WorldEvent_Load_Constructor, new Object[] { this });
/*      */     
/*  134 */     if (this.mc.playerController != null && this.mc.playerController.getClass() == PlayerController.class)
/*      */     {
/*      */       
/*  137 */       CustomGuis.setPlayerControllerOF((PlayerControllerOF)this.mc.playerController);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public DimensionRenderInfo func_239132_a_() {
/*  143 */     return this.field_239131_x_;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void tick(BooleanSupplier hasTimeLeft) {
/*  151 */     getWorldBorder().tick();
/*  152 */     func_239141_x_();
/*  153 */     getProfiler().startSection("blocks");
/*  154 */     this.field_239129_E_.tick(hasTimeLeft);
/*  155 */     getProfiler().endSection();
/*      */   }
/*      */ 
/*      */   
/*      */   private void func_239141_x_() {
/*  160 */     func_239134_a_(this.worldInfo.getGameTime() + 1L);
/*      */     
/*  162 */     if (this.worldInfo.getGameRulesInstance().getBoolean(GameRules.DO_DAYLIGHT_CYCLE))
/*      */     {
/*  164 */       setDayTime(this.worldInfo.getDayTime() + 1L);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void func_239134_a_(long p_239134_1_) {
/*  170 */     this.field_239130_d_.setGameTime(p_239134_1_);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDayTime(long time) {
/*  178 */     if (time < 0L) {
/*      */       
/*  180 */       time = -time;
/*  181 */       ((GameRules.BooleanValue)getGameRules().get(GameRules.DO_DAYLIGHT_CYCLE)).set(false, (MinecraftServer)null);
/*      */     }
/*      */     else {
/*      */       
/*  185 */       ((GameRules.BooleanValue)getGameRules().get(GameRules.DO_DAYLIGHT_CYCLE)).set(true, (MinecraftServer)null);
/*      */     } 
/*      */     
/*  188 */     this.field_239130_d_.setDayTime(time);
/*      */   }
/*      */ 
/*      */   
/*      */   public Iterable<Entity> getAllEntities() {
/*  193 */     return (Iterable<Entity>)this.entitiesById.values();
/*      */   }
/*      */ 
/*      */   
/*      */   public void tickEntities() {
/*  198 */     IProfiler iprofiler = getProfiler();
/*  199 */     iprofiler.startSection("entities");
/*  200 */     ObjectIterator<Int2ObjectMap.Entry<Entity>> objectiterator = this.entitiesById.int2ObjectEntrySet().iterator();
/*      */     
/*  202 */     while (objectiterator.hasNext()) {
/*      */       
/*      */       try {
/*  205 */         Int2ObjectMap.Entry<Entity> entry = (Int2ObjectMap.Entry<Entity>)objectiterator.next();
/*  206 */         Entity entity = (Entity)entry.getValue();
/*      */         
/*  208 */         if (!entity.isPassenger()) {
/*      */           
/*  210 */           iprofiler.startSection("tick");
/*      */           
/*  212 */           if (!entity.removed)
/*      */           {
/*  214 */             guardEntityTick(this::updateEntity, entity);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*  219 */           iprofiler.endSection();
/*  220 */           iprofiler.startSection("remove");
/*      */           
/*  222 */           if (entity.removed) {
/*      */             
/*  224 */             objectiterator.remove();
/*  225 */             removeEntity(entity);
/*      */           } 
/*      */           
/*  228 */           iprofiler.endSection();
/*      */         } 
/*  230 */       } catch (Exception exception) {}
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  235 */     if (!this.bot.isPassenger()) {
/*      */       
/*  237 */       if (!this.bot.removed)
/*      */       {
/*  239 */         guardEntityTick(this::updateEntity, (Entity)this.bot);
/*      */       }
/*      */       
/*  242 */       iprofiler.endSection();
/*  243 */       iprofiler.startSection("remove");
/*      */       
/*  245 */       if (this.bot.removed)
/*      */       {
/*      */         
/*  248 */         removeEntity((Entity)this.bot);
/*      */       }
/*      */       
/*  251 */       iprofiler.endSection();
/*      */     } 
/*      */     
/*  254 */     tickBlockEntities();
/*  255 */     iprofiler.endSection();
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateEntity(Entity entityIn) {
/*  260 */     if (!(entityIn instanceof PlayerEntity) && !getChunkProvider().isChunkLoaded(entityIn)) {
/*      */       
/*  262 */       checkChunk(entityIn);
/*      */     }
/*      */     else {
/*      */       
/*  266 */       entityIn.forceSetPosition(entityIn.getPosX(), entityIn.getPosY(), entityIn.getPosZ());
/*  267 */       entityIn.prevRotationYaw = entityIn.rotationYaw;
/*  268 */       entityIn.prevRotationPitch = entityIn.rotationPitch;
/*      */       
/*  270 */       if (entityIn.addedToChunk || entityIn.isSpectator()) {
/*      */         
/*  272 */         entityIn.ticksExisted++;
/*  273 */         getProfiler().startSection(() -> Registry.ENTITY_TYPE.getKey(entityIn.getType()).toString());
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  278 */         if (ReflectorForge.canUpdate(entityIn))
/*      */         {
/*  280 */           entityIn.tick();
/*      */         }
/*      */         
/*  283 */         getProfiler().endSection();
/*      */       } 
/*      */       
/*  286 */       checkChunk(entityIn);
/*      */       
/*  288 */       if (entityIn.addedToChunk)
/*      */       {
/*  290 */         for (Entity entity : entityIn.getPassengers())
/*      */         {
/*  292 */           updateEntityRidden(entityIn, entity);
/*      */         }
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateEntityRidden(Entity p_217420_1_, Entity p_217420_2_) {
/*  300 */     if (!p_217420_2_.removed && p_217420_2_.getRidingEntity() == p_217420_1_) {
/*      */       
/*  302 */       if (p_217420_2_ instanceof PlayerEntity || getChunkProvider().isChunkLoaded(p_217420_2_))
/*      */       {
/*  304 */         p_217420_2_.forceSetPosition(p_217420_2_.getPosX(), p_217420_2_.getPosY(), p_217420_2_.getPosZ());
/*  305 */         p_217420_2_.prevRotationYaw = p_217420_2_.rotationYaw;
/*  306 */         p_217420_2_.prevRotationPitch = p_217420_2_.rotationPitch;
/*      */         
/*  308 */         if (p_217420_2_.addedToChunk) {
/*      */           
/*  310 */           p_217420_2_.ticksExisted++;
/*  311 */           p_217420_2_.updateRidden();
/*      */         } 
/*      */         
/*  314 */         checkChunk(p_217420_2_);
/*      */         
/*  316 */         if (p_217420_2_.addedToChunk)
/*      */         {
/*  318 */           for (Entity entity : p_217420_2_.getPassengers())
/*      */           {
/*  320 */             updateEntityRidden(p_217420_2_, entity);
/*      */           }
/*      */         }
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/*  327 */       p_217420_2_.stopRiding();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void checkChunk(Entity entityIn) {
/*  333 */     if (entityIn.func_233578_ci_()) {
/*      */       
/*  335 */       getProfiler().startSection("chunkCheck");
/*  336 */       int i = MathHelper.floor(entityIn.getPosX() / 16.0D);
/*  337 */       int j = MathHelper.floor(entityIn.getPosY() / 16.0D);
/*  338 */       int k = MathHelper.floor(entityIn.getPosZ() / 16.0D);
/*      */       
/*  340 */       if (!entityIn.addedToChunk || entityIn.chunkCoordX != i || entityIn.chunkCoordY != j || entityIn.chunkCoordZ != k) {
/*      */         
/*  342 */         if (entityIn.addedToChunk && chunkExists(entityIn.chunkCoordX, entityIn.chunkCoordZ))
/*      */         {
/*  344 */           getChunk(entityIn.chunkCoordX, entityIn.chunkCoordZ).removeEntityAtIndex(entityIn, entityIn.chunkCoordY);
/*      */         }
/*      */         
/*  347 */         if (!entityIn.func_233577_ch_() && !chunkExists(i, k)) {
/*      */           
/*  349 */           if (entityIn.addedToChunk)
/*      */           {
/*  351 */             LOGGER.warn("Entity {} left loaded chunk area", entityIn);
/*      */           }
/*      */           
/*  354 */           entityIn.addedToChunk = false;
/*      */         }
/*      */         else {
/*      */           
/*  358 */           getChunk(i, k).addEntity(entityIn);
/*      */         } 
/*      */       } 
/*      */       
/*  362 */       getProfiler().endSection();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void onChunkUnloaded(Chunk chunkIn) {
/*      */     Collection collection;
/*  370 */     if (Reflector.ForgeWorld_tileEntitiesToBeRemoved.exists()) {
/*      */       
/*  372 */       collection = (Collection)Reflector.getFieldValue(this, Reflector.ForgeWorld_tileEntitiesToBeRemoved);
/*      */     }
/*      */     else {
/*      */       
/*  376 */       collection = this.tileEntitiesToBeRemoved;
/*      */     } 
/*      */     
/*  379 */     collection.addAll(chunkIn.getTileEntityMap().values());
/*  380 */     this.field_239129_E_.getLightManager().enableLightSources(chunkIn.getPos(), false);
/*      */   }
/*      */ 
/*      */   
/*      */   public void onChunkLoaded(int chunkX, int chunkZ) {
/*  385 */     this.colorCaches.forEach((p_lambda$onChunkLoaded$2_2_, p_lambda$onChunkLoaded$2_3_) -> p_lambda$onChunkLoaded$2_3_.invalidateChunk(chunkX, chunkZ));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearColorCaches() {
/*  393 */     this.colorCaches.forEach((p_lambda$clearColorCaches$3_0_, p_lambda$clearColorCaches$3_1_) -> p_lambda$clearColorCaches$3_1_.invalidateAll());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean chunkExists(int chunkX, int chunkZ) {
/*  401 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getCountLoadedEntities() {
/*  406 */     return this.entitiesById.size();
/*      */   }
/*      */ 
/*      */   
/*      */   public void addPlayer(int playerId, AbstractClientPlayerEntity playerEntityIn) {
/*  411 */     addEntityImpl(playerId, (Entity)playerEntityIn);
/*  412 */     this.players.add(playerEntityIn);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addEntity(int entityIdIn, Entity entityToSpawn) {
/*  417 */     addEntityImpl(entityIdIn, entityToSpawn);
/*      */   }
/*      */ 
/*      */   
/*      */   private void addEntityImpl(int entityIdIn, Entity entityToSpawn) {
/*  422 */     if (!Reflector.EntityJoinWorldEvent_Constructor.exists() || !Reflector.postForgeBusEvent(Reflector.EntityJoinWorldEvent_Constructor, new Object[] { entityToSpawn, this })) {
/*      */       
/*  424 */       removeEntityFromWorld(entityIdIn);
/*  425 */       this.entitiesById.put(entityIdIn, entityToSpawn);
/*  426 */       getChunkProvider().getChunk(MathHelper.floor(entityToSpawn.getPosX() / 16.0D), MathHelper.floor(entityToSpawn.getPosZ() / 16.0D), ChunkStatus.FULL, true).addEntity(entityToSpawn);
/*      */       
/*  428 */       if (Reflector.IForgeEntity_onAddedToWorld.exists())
/*      */       {
/*  430 */         Reflector.call(entityToSpawn, Reflector.IForgeEntity_onAddedToWorld, new Object[0]);
/*      */       }
/*      */       
/*  433 */       onEntityAdded(entityToSpawn);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeEntityFromWorld(int eid) {
/*  439 */     Entity entity = (Entity)this.entitiesById.remove(eid);
/*      */     
/*  441 */     if (entity != null) {
/*      */       
/*  443 */       entity.remove();
/*  444 */       removeEntity(entity);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void removeEntity(Entity entityIn) {
/*  450 */     entityIn.detach();
/*      */     
/*  452 */     if (entityIn.addedToChunk)
/*      */     {
/*  454 */       getChunk(entityIn.chunkCoordX, entityIn.chunkCoordZ).removeEntity(entityIn);
/*      */     }
/*      */     
/*  457 */     this.players.remove(entityIn);
/*      */     
/*  459 */     if (Reflector.IForgeEntity_onRemovedFromWorld.exists())
/*      */     {
/*  461 */       Reflector.call(entityIn, Reflector.IForgeEntity_onRemovedFromWorld, new Object[0]);
/*      */     }
/*      */     
/*  464 */     if (Reflector.EntityLeaveWorldEvent_Constructor.exists())
/*      */     {
/*  466 */       Reflector.postForgeBusEvent(Reflector.EntityLeaveWorldEvent_Constructor, new Object[] { entityIn, this });
/*      */     }
/*      */     
/*  469 */     onEntityRemoved(entityIn);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addEntitiesToChunk(Chunk chunkIn) {
/*  474 */     for (ObjectIterator<Int2ObjectMap.Entry<Entity>> objectIterator = this.entitiesById.int2ObjectEntrySet().iterator(); objectIterator.hasNext(); ) { Int2ObjectMap.Entry<Entity> entry = objectIterator.next();
/*      */       
/*  476 */       Entity entity = (Entity)entry.getValue();
/*  477 */       int i = MathHelper.floor(entity.getPosX() / 16.0D);
/*  478 */       int j = MathHelper.floor(entity.getPosZ() / 16.0D);
/*      */       
/*  480 */       if (i == (chunkIn.getPos()).x && j == (chunkIn.getPos()).z)
/*      */       {
/*  482 */         chunkIn.addEntity(entity);
/*      */       } }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Entity getEntityByID(int id) {
/*  494 */     return (Entity)this.entitiesById.get(id);
/*      */   }
/*      */ 
/*      */   
/*      */   public void invalidateRegionAndSetBlock(BlockPos pos, BlockState state) {
/*  499 */     setBlockState(pos, state, 19);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void sendQuittingDisconnectingPacket() {
/*  507 */     this.connection.getNetworkManager().closeChannel((ITextComponent)new TranslationTextComponent("multiplayer.status.quitting"));
/*      */   }
/*      */ 
/*      */   
/*      */   public void animateTick(int posX, int posY, int posZ) {
/*  512 */     int i = 32;
/*  513 */     Random random = new Random();
/*  514 */     boolean flag = false;
/*      */     
/*  516 */     if (this.mc.playerController.getCurrentGameType() == GameType.CREATIVE)
/*      */     {
/*  518 */       for (ItemStack itemstack : this.mc.player.getHeldEquipment()) {
/*      */         
/*  520 */         if (itemstack.getItem() == Blocks.BARRIER.asItem()) {
/*      */           
/*  522 */           flag = true;
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     }
/*  528 */     BlockPos.Mutable blockpos$mutable = new BlockPos.Mutable();
/*      */     
/*  530 */     for (int j = 0; j < 667; j++) {
/*      */       
/*  532 */       animateTick(posX, posY, posZ, 16, random, flag, blockpos$mutable);
/*  533 */       animateTick(posX, posY, posZ, 32, random, flag, blockpos$mutable);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void animateTick(int x, int y, int z, int offset, Random random, boolean holdingBarrier, BlockPos.Mutable pos) {
/*  539 */     int i = x + this.rand.nextInt(offset) - this.rand.nextInt(offset);
/*  540 */     int j = y + this.rand.nextInt(offset) - this.rand.nextInt(offset);
/*  541 */     int k = z + this.rand.nextInt(offset) - this.rand.nextInt(offset);
/*  542 */     pos.setPos(i, j, k);
/*  543 */     BlockState blockstate = getBlockState((BlockPos)pos);
/*  544 */     blockstate.getBlock().animateTick(blockstate, this, (BlockPos)pos, random);
/*  545 */     FluidState fluidstate = getFluidState((BlockPos)pos);
/*      */     
/*  547 */     if (!fluidstate.isEmpty()) {
/*      */       
/*  549 */       fluidstate.animateTick(this, (BlockPos)pos, random);
/*  550 */       IParticleData iparticledata = fluidstate.getDripParticleData();
/*      */       
/*  552 */       if (iparticledata != null && this.rand.nextInt(10) == 0) {
/*      */         
/*  554 */         boolean flag = blockstate.isSolidSide((IBlockReader)this, (BlockPos)pos, Direction.DOWN);
/*  555 */         BlockPos blockpos = pos.down();
/*  556 */         spawnFluidParticle(blockpos, getBlockState(blockpos), iparticledata, flag);
/*      */       } 
/*      */     } 
/*      */     
/*  560 */     if (holdingBarrier && blockstate.isIn(Blocks.BARRIER))
/*      */     {
/*  562 */       addParticle((IParticleData)ParticleTypes.BARRIER, i + 0.5D, j + 0.5D, k + 0.5D, 0.0D, 0.0D, 0.0D);
/*      */     }
/*      */     
/*  565 */     if (!blockstate.hasOpaqueCollisionShape((IBlockReader)this, (BlockPos)pos))
/*      */     {
/*  567 */       getBiome((BlockPos)pos).getAmbientParticle().ifPresent(p_lambda$animateTick$4_2_ -> {
/*      */             if (p_lambda$animateTick$4_2_.shouldParticleSpawn(this.rand)) {
/*      */               addParticle(p_lambda$animateTick$4_2_.getParticleOptions(), pos.getX() + this.rand.nextDouble(), pos.getY() + this.rand.nextDouble(), pos.getZ() + this.rand.nextDouble(), 0.0D, 0.0D, 0.0D);
/*      */             }
/*      */           });
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void spawnFluidParticle(BlockPos blockPosIn, BlockState blockStateIn, IParticleData particleDataIn, boolean shapeDownSolid) {
/*  579 */     if (blockStateIn.getFluidState().isEmpty()) {
/*      */       
/*  581 */       VoxelShape voxelshape = blockStateIn.getCollisionShape((IBlockReader)this, blockPosIn);
/*  582 */       double d0 = voxelshape.getEnd(Direction.Axis.Y);
/*      */       
/*  584 */       if (d0 < 1.0D) {
/*      */         
/*  586 */         if (shapeDownSolid)
/*      */         {
/*  588 */           spawnParticle(blockPosIn.getX(), (blockPosIn.getX() + 1), blockPosIn.getZ(), (blockPosIn.getZ() + 1), (blockPosIn.getY() + 1) - 0.05D, particleDataIn);
/*      */         }
/*      */       }
/*  591 */       else if (!blockStateIn.isIn((ITag)BlockTags.IMPERMEABLE)) {
/*      */         
/*  593 */         double d1 = voxelshape.getStart(Direction.Axis.Y);
/*      */         
/*  595 */         if (d1 > 0.0D) {
/*      */           
/*  597 */           spawnParticle(blockPosIn, particleDataIn, voxelshape, blockPosIn.getY() + d1 - 0.05D);
/*      */         }
/*      */         else {
/*      */           
/*  601 */           BlockPos blockpos = blockPosIn.down();
/*  602 */           BlockState blockstate = getBlockState(blockpos);
/*  603 */           VoxelShape voxelshape1 = blockstate.getCollisionShape((IBlockReader)this, blockpos);
/*  604 */           double d2 = voxelshape1.getEnd(Direction.Axis.Y);
/*      */           
/*  606 */           if (d2 < 1.0D && blockstate.getFluidState().isEmpty())
/*      */           {
/*  608 */             spawnParticle(blockPosIn, particleDataIn, voxelshape, blockPosIn.getY() - 0.05D);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void spawnParticle(BlockPos posIn, IParticleData particleDataIn, VoxelShape voxelShapeIn, double y) {
/*  617 */     spawnParticle(posIn.getX() + voxelShapeIn.getStart(Direction.Axis.X), posIn.getX() + voxelShapeIn.getEnd(Direction.Axis.X), posIn.getZ() + voxelShapeIn.getStart(Direction.Axis.Z), posIn.getZ() + voxelShapeIn.getEnd(Direction.Axis.Z), y, particleDataIn);
/*      */   }
/*      */ 
/*      */   
/*      */   private void spawnParticle(double xStart, double xEnd, double zStart, double zEnd, double y, IParticleData particleDataIn) {
/*  622 */     addParticle(particleDataIn, MathHelper.lerp(this.rand.nextDouble(), xStart, xEnd), y, MathHelper.lerp(this.rand.nextDouble(), zStart, zEnd), 0.0D, 0.0D, 0.0D);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeAllEntities() {
/*  630 */     ObjectIterator<Int2ObjectMap.Entry<Entity>> objectiterator = this.entitiesById.int2ObjectEntrySet().iterator();
/*      */     
/*  632 */     while (objectiterator.hasNext()) {
/*      */       
/*  634 */       Int2ObjectMap.Entry<Entity> entry = (Int2ObjectMap.Entry<Entity>)objectiterator.next();
/*  635 */       Entity entity = (Entity)entry.getValue();
/*      */       
/*  637 */       if (entity.removed) {
/*      */         
/*  639 */         objectiterator.remove();
/*  640 */         removeEntity(entity);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CrashReportCategory fillCrashReport(CrashReport report) {
/*  650 */     CrashReportCategory crashreportcategory = super.fillCrashReport(report);
/*  651 */     crashreportcategory.addDetail("Server brand", () -> this.mc.player.getServerBrand());
/*      */ 
/*      */ 
/*      */     
/*  655 */     crashreportcategory.addDetail("Server type", () -> (this.mc.getIntegratedServer() == null) ? "Non-integrated multiplayer server" : "Integrated singleplayer server");
/*      */ 
/*      */ 
/*      */     
/*  659 */     return crashreportcategory;
/*      */   }
/*      */ 
/*      */   
/*      */   public void playSound(@Nullable PlayerEntity player, double x, double y, double z, SoundEvent soundIn, SoundCategory category, float volume, float pitch) {
/*  664 */     if (player == this.mc.player)
/*      */     {
/*  666 */       playSound(x, y, z, soundIn, category, volume, pitch, false);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void playMovingSound(@Nullable PlayerEntity playerIn, Entity entityIn, SoundEvent eventIn, SoundCategory categoryIn, float volume, float pitch) {
/*  672 */     if (playerIn == this.mc.player)
/*      */     {
/*  674 */       this.mc.getSoundHandler().play((ISound)new EntityTickableSound(eventIn, categoryIn, entityIn));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void playSound(BlockPos pos, SoundEvent soundIn, SoundCategory category, float volume, float pitch, boolean distanceDelay) {
/*  680 */     playSound(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D, soundIn, category, volume, pitch, distanceDelay);
/*      */   }
/*      */ 
/*      */   
/*      */   public void playSound(double x, double y, double z, SoundEvent soundIn, SoundCategory category, float volume, float pitch, boolean distanceDelay) {
/*  685 */     double d0 = this.mc.gameRenderer.getActiveRenderInfo().getProjectedView().squareDistanceTo(x, y, z);
/*  686 */     SimpleSound simplesound = new SimpleSound(soundIn, category, volume, pitch, x, y, z);
/*      */     
/*  688 */     if (distanceDelay && d0 > 100.0D) {
/*      */       
/*  690 */       double d1 = Math.sqrt(d0) / 40.0D;
/*  691 */       this.mc.getSoundHandler().playDelayed((ISound)simplesound, (int)(d1 * 20.0D));
/*      */     }
/*      */     else {
/*      */       
/*  695 */       this.mc.getSoundHandler().play((ISound)simplesound);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void sendPacketToServer(IPacket<?> packetIn) {
/*  701 */     this.connection.sendPacket(packetIn);
/*      */   }
/*      */ 
/*      */   
/*      */   public RecipeManager getRecipeManager() {
/*  706 */     return this.connection.getRecipeManager();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setScoreboard(Scoreboard scoreboardIn) {
/*  711 */     this.scoreboard = scoreboardIn;
/*      */   }
/*      */ 
/*      */   
/*      */   public ITickList<Block> getPendingBlockTicks() {
/*  716 */     return (ITickList<Block>)EmptyTickList.get();
/*      */   }
/*      */ 
/*      */   
/*      */   public ITickList<Fluid> getPendingFluidTicks() {
/*  721 */     return (ITickList<Fluid>)EmptyTickList.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BotChunkProvider getChunkProvider() {
/*  729 */     return this.field_239129_E_;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean setBlockState(BlockPos pos, BlockState newState, int flags) {
/*  745 */     this.playerUpdate = isPlayerActing();
/*  746 */     boolean flag = super.setBlockState(pos, newState, flags);
/*  747 */     this.playerUpdate = false;
/*  748 */     return flag;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean isPlayerActing() {
/*  753 */     if (this.mc.playerController instanceof PlayerControllerOF) {
/*      */       
/*  755 */       PlayerControllerOF playercontrollerof = (PlayerControllerOF)this.mc.playerController;
/*  756 */       return playercontrollerof.isActing();
/*      */     } 
/*      */ 
/*      */     
/*  760 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isPlayerUpdate() {
/*  766 */     return this.playerUpdate;
/*      */   }
/*      */ 
/*      */   
/*      */   public void onEntityAdded(Entity p_onEntityAdded_1_) {
/*  771 */     RandomEntities.entityLoaded(p_onEntityAdded_1_, this);
/*      */     
/*  773 */     if (Config.isDynamicLights())
/*      */     {
/*  775 */       DynamicLights.entityAdded(p_onEntityAdded_1_, Config.getRenderGlobal());
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void onEntityRemoved(Entity p_onEntityRemoved_1_) {
/*  781 */     RandomEntities.entityUnloaded(p_onEntityRemoved_1_, this);
/*      */     
/*  783 */     if (Config.isDynamicLights())
/*      */     {
/*  785 */       DynamicLights.entityRemoved(p_onEntityRemoved_1_, Config.getRenderGlobal());
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public MapData getMapData(String mapName) {
/*  792 */     return this.maps.get(mapName);
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerMapData(MapData mapDataIn) {
/*  797 */     this.maps.put(mapDataIn.getName(), mapDataIn);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getNextMapId() {
/*  802 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public Scoreboard getScoreboard() {
/*  807 */     return this.scoreboard;
/*      */   }
/*      */ 
/*      */   
/*      */   public ITagCollectionSupplier getTags() {
/*  812 */     return this.connection.getTags();
/*      */   }
/*      */ 
/*      */   
/*      */   public DynamicRegistries func_241828_r() {
/*  817 */     return this.connection.func_239165_n_();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void notifyBlockUpdate(BlockPos pos, BlockState oldState, BlockState newState, int flags) {
/*  825 */     this.worldRenderer.notifyBlockUpdate((IBlockReader)this, pos, oldState, newState, flags);
/*      */   }
/*      */ 
/*      */   
/*      */   public void markBlockRangeForRenderUpdate(BlockPos blockPosIn, BlockState oldState, BlockState newState) {
/*  830 */     this.worldRenderer.markBlockRangeForRenderUpdate(blockPosIn, oldState, newState);
/*      */   }
/*      */ 
/*      */   
/*      */   public void markSurroundingsForRerender(int sectionX, int sectionY, int sectionZ) {
/*  835 */     this.worldRenderer.markSurroundingsForRerender(sectionX, sectionY, sectionZ);
/*      */   }
/*      */ 
/*      */   
/*      */   public void sendBlockBreakProgress(int breakerId, BlockPos pos, int progress) {
/*  840 */     this.worldRenderer.sendBlockBreakProgress(breakerId, pos, progress);
/*      */   }
/*      */ 
/*      */   
/*      */   public void playBroadcastSound(int id, BlockPos pos, int data) {
/*  845 */     this.worldRenderer.broadcastSound(id, pos, data);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void playEvent(@Nullable PlayerEntity player, int type, BlockPos pos, int data) {
/*      */     try {
/*  852 */       this.worldRenderer.playEvent(player, type, pos, data);
/*      */     }
/*  854 */     catch (Throwable throwable) {
/*      */       
/*  856 */       CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Playing level event");
/*  857 */       CrashReportCategory crashreportcategory = crashreport.makeCategory("Level event being played");
/*  858 */       crashreportcategory.addDetail("Block coordinates", CrashReportCategory.getCoordinateInfo(pos));
/*  859 */       crashreportcategory.addDetail("Event source", player);
/*  860 */       crashreportcategory.addDetail("Event type", Integer.valueOf(type));
/*  861 */       crashreportcategory.addDetail("Event data", Integer.valueOf(data));
/*  862 */       throw new ReportedException(crashreport);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void addParticle(IParticleData particleData, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
/*  868 */     this.worldRenderer.addParticle(particleData, particleData.getType().getAlwaysShow(), x, y, z, xSpeed, ySpeed, zSpeed);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addParticle(IParticleData particleData, boolean forceAlwaysRender, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
/*  873 */     this.worldRenderer.addParticle(particleData, (particleData.getType().getAlwaysShow() || forceAlwaysRender), x, y, z, xSpeed, ySpeed, zSpeed);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addOptionalParticle(IParticleData particleData, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
/*  878 */     this.worldRenderer.addParticle(particleData, false, true, x, y, z, xSpeed, ySpeed, zSpeed);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addOptionalParticle(IParticleData particleData, boolean ignoreRange, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
/*  883 */     this.worldRenderer.addParticle(particleData, (particleData.getType().getAlwaysShow() || ignoreRange), true, x, y, z, xSpeed, ySpeed, zSpeed);
/*      */   }
/*      */ 
/*      */   
/*      */   public List<AbstractClientPlayerEntity> getPlayers() {
/*  888 */     return this.players;
/*      */   }
/*      */ 
/*      */   
/*      */   public Biome getNoiseBiomeRaw(int x, int y, int z) {
/*  893 */     return (Biome)func_241828_r().getRegistry(Registry.BIOME_KEY).getOrThrow(Biomes.PLAINS);
/*      */   }
/*      */ 
/*      */   
/*      */   public float getSunBrightness(float partialTicks) {
/*  898 */     float f = func_242415_f(partialTicks);
/*  899 */     float f1 = 1.0F - MathHelper.cos(f * 6.2831855F) * 2.0F + 0.2F;
/*  900 */     f1 = MathHelper.clamp(f1, 0.0F, 1.0F);
/*  901 */     f1 = 1.0F - f1;
/*  902 */     f1 = (float)(f1 * (1.0D - (getRainStrength(partialTicks) * 5.0F) / 16.0D));
/*  903 */     f1 = (float)(f1 * (1.0D - (getThunderStrength(partialTicks) * 5.0F) / 16.0D));
/*  904 */     return f1 * 0.8F + 0.2F;
/*      */   }
/*      */ 
/*      */   
/*      */   public Vector3d getSkyColor(BlockPos blockPosIn, float partialTicks) {
/*  909 */     float f = func_242415_f(partialTicks);
/*  910 */     float f1 = MathHelper.cos(f * 6.2831855F) * 2.0F + 0.5F;
/*  911 */     f1 = MathHelper.clamp(f1, 0.0F, 1.0F);
/*  912 */     Biome biome = getBiome(blockPosIn);
/*  913 */     int i = biome.getSkyColor();
/*  914 */     float f2 = (i >> 16 & 0xFF) / 255.0F;
/*  915 */     float f3 = (i >> 8 & 0xFF) / 255.0F;
/*  916 */     float f4 = (i & 0xFF) / 255.0F;
/*  917 */     f2 *= f1;
/*  918 */     f3 *= f1;
/*  919 */     f4 *= f1;
/*  920 */     float f5 = getRainStrength(partialTicks);
/*      */     
/*  922 */     if (f5 > 0.0F) {
/*      */       
/*  924 */       float f6 = (f2 * 0.3F + f3 * 0.59F + f4 * 0.11F) * 0.6F;
/*  925 */       float f7 = 1.0F - f5 * 0.75F;
/*  926 */       f2 = f2 * f7 + f6 * (1.0F - f7);
/*  927 */       f3 = f3 * f7 + f6 * (1.0F - f7);
/*  928 */       f4 = f4 * f7 + f6 * (1.0F - f7);
/*      */     } 
/*      */     
/*  931 */     float f9 = getThunderStrength(partialTicks);
/*      */     
/*  933 */     if (f9 > 0.0F) {
/*      */       
/*  935 */       float f10 = (f2 * 0.3F + f3 * 0.59F + f4 * 0.11F) * 0.2F;
/*  936 */       float f8 = 1.0F - f9 * 0.75F;
/*  937 */       f2 = f2 * f8 + f10 * (1.0F - f8);
/*  938 */       f3 = f3 * f8 + f10 * (1.0F - f8);
/*  939 */       f4 = f4 * f8 + f10 * (1.0F - f8);
/*      */     } 
/*      */     
/*  942 */     if (this.timeLightningFlash > 0) {
/*      */       
/*  944 */       float f11 = this.timeLightningFlash - partialTicks;
/*      */       
/*  946 */       if (f11 > 1.0F)
/*      */       {
/*  948 */         f11 = 1.0F;
/*      */       }
/*      */       
/*  951 */       f11 *= 0.45F;
/*  952 */       f2 = f2 * (1.0F - f11) + 0.8F * f11;
/*  953 */       f3 = f3 * (1.0F - f11) + 0.8F * f11;
/*  954 */       f4 = f4 * (1.0F - f11) + 1.0F * f11;
/*      */     } 
/*      */     
/*  957 */     return new Vector3d(f2, f3, f4);
/*      */   }
/*      */ 
/*      */   
/*      */   public Vector3d getCloudColor(float partialTicks) {
/*  962 */     float f = func_242415_f(partialTicks);
/*  963 */     float f1 = MathHelper.cos(f * 6.2831855F) * 2.0F + 0.5F;
/*  964 */     f1 = MathHelper.clamp(f1, 0.0F, 1.0F);
/*  965 */     float f2 = 1.0F;
/*  966 */     float f3 = 1.0F;
/*  967 */     float f4 = 1.0F;
/*  968 */     float f5 = getRainStrength(partialTicks);
/*      */     
/*  970 */     if (f5 > 0.0F) {
/*      */       
/*  972 */       float f6 = (f2 * 0.3F + f3 * 0.59F + f4 * 0.11F) * 0.6F;
/*  973 */       float f7 = 1.0F - f5 * 0.95F;
/*  974 */       f2 = f2 * f7 + f6 * (1.0F - f7);
/*  975 */       f3 = f3 * f7 + f6 * (1.0F - f7);
/*  976 */       f4 = f4 * f7 + f6 * (1.0F - f7);
/*      */     } 
/*      */     
/*  979 */     f2 *= f1 * 0.9F + 0.1F;
/*  980 */     f3 *= f1 * 0.9F + 0.1F;
/*  981 */     f4 *= f1 * 0.85F + 0.15F;
/*  982 */     float f9 = getThunderStrength(partialTicks);
/*      */     
/*  984 */     if (f9 > 0.0F) {
/*      */       
/*  986 */       float f10 = (f2 * 0.3F + f3 * 0.59F + f4 * 0.11F) * 0.2F;
/*  987 */       float f8 = 1.0F - f9 * 0.95F;
/*  988 */       f2 = f2 * f8 + f10 * (1.0F - f8);
/*  989 */       f3 = f3 * f8 + f10 * (1.0F - f8);
/*  990 */       f4 = f4 * f8 + f10 * (1.0F - f8);
/*      */     } 
/*      */     
/*  993 */     return new Vector3d(f2, f3, f4);
/*      */   }
/*      */ 
/*      */   
/*      */   public float getStarBrightness(float partialTicks) {
/*  998 */     float f = func_242415_f(partialTicks);
/*  999 */     float f1 = 1.0F - MathHelper.cos(f * 6.2831855F) * 2.0F + 0.25F;
/* 1000 */     f1 = MathHelper.clamp(f1, 0.0F, 1.0F);
/* 1001 */     return f1 * f1 * 0.5F;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getTimeLightningFlash() {
/* 1006 */     return this.timeLightningFlash;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTimeLightningFlash(int timeFlashIn) {
/* 1011 */     this.timeLightningFlash = timeFlashIn;
/*      */   }
/*      */ 
/*      */   
/*      */   public float func_230487_a_(Direction p_230487_1_, boolean p_230487_2_) {
/* 1016 */     boolean flag = func_239132_a_().func_239217_c_();
/* 1017 */     boolean flag1 = Config.isShaders();
/*      */     
/* 1019 */     if (!p_230487_2_)
/*      */     {
/* 1021 */       return flag ? 0.9F : 1.0F;
/*      */     }
/*      */ 
/*      */     
/* 1025 */     switch (p_230487_1_) {
/*      */       
/*      */       case DOWN:
/* 1028 */         return flag ? 0.9F : (flag1 ? Shaders.blockLightLevel05 : 0.5F);
/*      */       
/*      */       case UP:
/* 1031 */         return flag ? 0.9F : 1.0F;
/*      */       
/*      */       case NORTH:
/*      */       case SOUTH:
/* 1035 */         if (Config.isShaders())
/*      */         {
/* 1037 */           return Shaders.blockLightLevel08;
/*      */         }
/*      */         
/* 1040 */         return 0.8F;
/*      */       
/*      */       case WEST:
/*      */       case EAST:
/* 1044 */         if (Config.isShaders())
/*      */         {
/* 1046 */           return Shaders.blockLightLevel06;
/*      */         }
/*      */         
/* 1049 */         return 0.6F;
/*      */     } 
/*      */     
/* 1052 */     return 1.0F;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getBlockColor(BlockPos blockPosIn, ColorResolver colorResolverIn) {
/* 1059 */     ColorCache colorcache = (ColorCache)this.colorCaches.get(colorResolverIn);
/* 1060 */     return colorcache.getColor(blockPosIn, () -> getBlockColorRaw(blockPosIn, colorResolverIn));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getBlockColorRaw(BlockPos blockPosIn, ColorResolver colorResolverIn) {
/* 1068 */     int i = (this.mc.getGameSettings()).biomeBlendRadius;
/*      */     
/* 1070 */     if (i == 0)
/*      */     {
/* 1072 */       return colorResolverIn.getColor(getBiome(blockPosIn), blockPosIn.getX(), blockPosIn.getZ());
/*      */     }
/*      */ 
/*      */     
/* 1076 */     int j = (i * 2 + 1) * (i * 2 + 1);
/* 1077 */     int k = 0;
/* 1078 */     int l = 0;
/* 1079 */     int i1 = 0;
/* 1080 */     CubeCoordinateIterator cubecoordinateiterator = new CubeCoordinateIterator(blockPosIn.getX() - i, blockPosIn.getY(), blockPosIn.getZ() - i, blockPosIn.getX() + i, blockPosIn.getY(), blockPosIn.getZ() + i);
/*      */ 
/*      */     
/* 1083 */     for (BlockPos.Mutable blockpos$mutable = new BlockPos.Mutable(); cubecoordinateiterator.hasNext(); i1 += j1 & 0xFF) {
/*      */       
/* 1085 */       blockpos$mutable.setPos(cubecoordinateiterator.getX(), cubecoordinateiterator.getY(), cubecoordinateiterator.getZ());
/* 1086 */       int j1 = colorResolverIn.getColor(getBiome((BlockPos)blockpos$mutable), blockpos$mutable.getX(), blockpos$mutable.getZ());
/* 1087 */       k += (j1 & 0xFF0000) >> 16;
/* 1088 */       l += (j1 & 0xFF00) >> 8;
/*      */     } 
/*      */     
/* 1091 */     return (k / j & 0xFF) << 16 | (l / j & 0xFF) << 8 | i1 / j & 0xFF;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BlockPos func_239140_u_() {
/* 1097 */     BlockPos blockpos = new BlockPos(this.worldInfo.getSpawnX(), this.worldInfo.getSpawnY(), this.worldInfo.getSpawnZ());
/*      */     
/* 1099 */     if (!getWorldBorder().contains(blockpos))
/*      */     {
/* 1101 */       blockpos = getHeight(Heightmap.Type.MOTION_BLOCKING, new BlockPos(getWorldBorder().getCenterX(), 0.0D, getWorldBorder().getCenterZ()));
/*      */     }
/*      */     
/* 1104 */     return blockpos;
/*      */   }
/*      */ 
/*      */   
/*      */   public float func_243489_v() {
/* 1109 */     return this.worldInfo.getSpawnAngle();
/*      */   }
/*      */ 
/*      */   
/*      */   public void func_239136_a_(BlockPos p_239136_1_, float p_239136_2_) {
/* 1114 */     this.worldInfo.setSpawn(p_239136_1_, p_239136_2_);
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1119 */     return "ClientLevel";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ClientWorld.ClientWorldInfo getWorldInfo() {
/* 1127 */     return this.field_239130_d_;
/*      */   }
/*      */   
/*      */   public static class ClientWorldInfo
/*      */     implements ISpawnWorldInfo
/*      */   {
/*      */     private final boolean hardcore;
/*      */     private final GameRules gameRules;
/*      */     private final boolean flatWorld;
/*      */     private int spawnX;
/*      */     private int spawnY;
/*      */     private int spawnZ;
/*      */     private float field_243490_g;
/*      */     private long gameTime;
/*      */     private long dayTime;
/*      */     private boolean raining;
/*      */     private Difficulty difficulty;
/*      */     private boolean field_239154_k_;
/*      */     
/*      */     public ClientWorldInfo(Difficulty p_i232338_1_, boolean p_i232338_2_, boolean flatWorld) {
/* 1147 */       this.difficulty = p_i232338_1_;
/* 1148 */       this.hardcore = p_i232338_2_;
/* 1149 */       this.flatWorld = flatWorld;
/* 1150 */       this.gameRules = new GameRules();
/*      */     }
/*      */ 
/*      */     
/*      */     public int getSpawnX() {
/* 1155 */       return this.spawnX;
/*      */     }
/*      */ 
/*      */     
/*      */     public int getSpawnY() {
/* 1160 */       return this.spawnY;
/*      */     }
/*      */ 
/*      */     
/*      */     public int getSpawnZ() {
/* 1165 */       return this.spawnZ;
/*      */     }
/*      */ 
/*      */     
/*      */     public float getSpawnAngle() {
/* 1170 */       return this.field_243490_g;
/*      */     }
/*      */ 
/*      */     
/*      */     public long getGameTime() {
/* 1175 */       return this.gameTime;
/*      */     }
/*      */ 
/*      */     
/*      */     public long getDayTime() {
/* 1180 */       return this.dayTime;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setSpawnX(int x) {
/* 1185 */       this.spawnX = x;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setSpawnY(int y) {
/* 1190 */       this.spawnY = y;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setSpawnZ(int z) {
/* 1195 */       this.spawnZ = z;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setSpawnAngle(float angle) {
/* 1200 */       this.field_243490_g = angle;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setGameTime(long time) {
/* 1205 */       this.gameTime = time;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setDayTime(long time) {
/* 1210 */       this.dayTime = time;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setSpawn(BlockPos spawnPoint, float angle) {
/* 1215 */       this.spawnX = spawnPoint.getX();
/* 1216 */       this.spawnY = spawnPoint.getY();
/* 1217 */       this.spawnZ = spawnPoint.getZ();
/* 1218 */       this.field_243490_g = angle;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isThundering() {
/* 1223 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isRaining() {
/* 1228 */       return this.raining;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setRaining(boolean isRaining) {
/* 1233 */       this.raining = isRaining;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isHardcore() {
/* 1238 */       return this.hardcore;
/*      */     }
/*      */ 
/*      */     
/*      */     public GameRules getGameRulesInstance() {
/* 1243 */       return this.gameRules;
/*      */     }
/*      */ 
/*      */     
/*      */     public Difficulty getDifficulty() {
/* 1248 */       return this.difficulty;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isDifficultyLocked() {
/* 1253 */       return this.field_239154_k_;
/*      */     }
/*      */ 
/*      */     
/*      */     public void addToCrashReport(CrashReportCategory category) {
/* 1258 */       super.addToCrashReport(category);
/*      */     }
/*      */ 
/*      */     
/*      */     public void setDifficulty(Difficulty difficulty) {
/* 1263 */       this.difficulty = difficulty;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setDifficultyLocked(boolean difficultyLocked) {
/* 1268 */       this.field_239154_k_ = difficultyLocked;
/*      */     }
/*      */ 
/*      */     
/*      */     public double getVoidFogHeight() {
/* 1273 */       return this.flatWorld ? 0.0D : 63.0D;
/*      */     }
/*      */ 
/*      */     
/*      */     public double getFogDistance() {
/* 1278 */       return this.flatWorld ? 1.0D : 0.03125D;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\autobuy\bots\world\BotWorld.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */