/*    */ package fun.rockstarity.api.autobuy.bots;
/*    */ 
/*    */ import fun.rockstarity.api.autobuy.bots.connection.BotNetworkManager;
/*    */ import fun.rockstarity.api.autobuy.bots.player.BotController;
/*    */ import fun.rockstarity.api.autobuy.bots.player.BotPlayer;
/*    */ import fun.rockstarity.api.autobuy.bots.world.BotWorld;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Bot
/*    */ {
/*    */   private String name;
/*    */   private BotNetworkManager networkManager;
/*    */   private BotController controller;
/*    */   private BotPlayer player;
/*    */   private BotWorld world;
/*    */   
/*    */   public Bot(String name, BotNetworkManager networkManager, BotController controller, BotPlayer player, BotWorld world) {
/* 19 */     this.name = name; this.networkManager = networkManager; this.controller = controller; this.player = player; this.world = world;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 23 */     return this.name;
/* 24 */   } public BotNetworkManager getNetworkManager() { return this.networkManager; }
/* 25 */   public BotController getController() { return this.controller; }
/* 26 */   public BotPlayer getPlayer() { return this.player; } public BotWorld getWorld() {
/* 27 */     return this.world;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\autobuy\bots\Bot.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */