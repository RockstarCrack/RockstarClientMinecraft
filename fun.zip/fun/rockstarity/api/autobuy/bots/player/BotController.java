/*     */ package fun.rockstarity.api.autobuy.bots.player;
/*     */ 
/*     */ import com.mojang.datafixers.util.Pair;
/*     */ import fun.rockstarity.api.autobuy.bots.connection.BotPlayNetHandler;
/*     */ import fun.rockstarity.api.autobuy.bots.world.BotWorld;
/*     */ import fun.rockstarity.api.events.list.player.EventAttack;
/*     */ import fun.rockstarity.api.events.list.player.EventInteractBlock;
/*     */ import it.unimi.dsi.fastutil.objects.Object2ObjectLinkedOpenHashMap;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockState;
/*     */ import net.minecraft.block.SoundType;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.audio.ISound;
/*     */ import net.minecraft.client.audio.SimpleSound;
/*     */ import net.minecraft.client.entity.player.ClientPlayerEntity;
/*     */ import net.minecraft.client.util.ClientRecipeBook;
/*     */ import net.minecraft.client.world.ClientWorld;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.LivingEntity;
/*     */ import net.minecraft.entity.player.PlayerEntity;
/*     */ import net.minecraft.fluid.FluidState;
/*     */ import net.minecraft.inventory.container.ClickType;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.ItemUseContext;
/*     */ import net.minecraft.item.crafting.IRecipe;
/*     */ import net.minecraft.network.IPacket;
/*     */ import net.minecraft.network.play.client.CClickWindowPacket;
/*     */ import net.minecraft.network.play.client.CCreativeInventoryActionPacket;
/*     */ import net.minecraft.network.play.client.CEnchantItemPacket;
/*     */ import net.minecraft.network.play.client.CPickItemPacket;
/*     */ import net.minecraft.network.play.client.CPlaceRecipePacket;
/*     */ import net.minecraft.network.play.client.CPlayerDiggingPacket;
/*     */ import net.minecraft.network.play.client.CPlayerTryUseItemOnBlockPacket;
/*     */ import net.minecraft.network.play.client.CPlayerTryUseItemPacket;
/*     */ import net.minecraft.network.play.client.CUseEntityPacket;
/*     */ import net.minecraft.stats.StatisticsManager;
/*     */ import net.minecraft.util.ActionResult;
/*     */ import net.minecraft.util.ActionResultType;
/*     */ import net.minecraft.util.Direction;
/*     */ import net.minecraft.util.Hand;
/*     */ import net.minecraft.util.SoundCategory;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.BlockRayTraceResult;
/*     */ import net.minecraft.util.math.EntityRayTraceResult;
/*     */ import net.minecraft.util.math.vector.Vector3d;
/*     */ import net.minecraft.world.GameType;
/*     */ import net.minecraft.world.IBlockReader;
/*     */ import net.minecraft.world.IWorld;
/*     */ import net.minecraft.world.World;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BotController
/*     */ {
/*  60 */   private static final Logger LOGGER = LogManager.getLogger();
/*     */   private final Minecraft mc;
/*     */   private final BotPlayNetHandler connection;
/*  63 */   private BlockPos currentBlock = new BlockPos(-1, -1, -1);
/*  64 */   private ItemStack currentItemHittingBlock = ItemStack.EMPTY;
/*     */   private float curBlockDamageMP;
/*     */   private float stepSoundTickCounter;
/*     */   private int blockHitDelay;
/*     */   private boolean isHittingBlock;
/*  69 */   private GameType currentGameType = GameType.SURVIVAL;
/*  70 */   private GameType field_239166_k_ = GameType.NOT_SET;
/*  71 */   private final Object2ObjectLinkedOpenHashMap<Pair<BlockPos, CPlayerDiggingPacket.Action>, Vector3d> unacknowledgedDiggingPackets = new Object2ObjectLinkedOpenHashMap();
/*     */   
/*     */   private int currentPlayerItem;
/*     */   private BotPlayer bot;
/*     */   
/*     */   public BotController(Minecraft mcIn, BotPlayNetHandler netHandler) {
/*  77 */     this.mc = mcIn;
/*  78 */     this.connection = netHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPlayerCapabilities(PlayerEntity player) {
/*  86 */     this.currentGameType.configurePlayerCapabilities(player.abilities);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_241675_a_(GameType p_241675_1_) {
/*  91 */     this.field_239166_k_ = p_241675_1_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGameType(GameType type) {
/*  99 */     if (type != this.currentGameType)
/*     */     {
/* 101 */       this.field_239166_k_ = this.currentGameType;
/*     */     }
/*     */     
/* 104 */     this.currentGameType = type;
/* 105 */     this.currentGameType.configurePlayerCapabilities(this.mc.player.abilities);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean shouldDrawHUD() {
/* 110 */     return this.currentGameType.isSurvivalOrAdventure();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean onPlayerDestroyBlock(BlockPos pos) {
/* 115 */     if (this.mc.player.blockActionRestricted((World)this.mc.world, pos, this.currentGameType))
/*     */     {
/* 117 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 121 */     ClientWorld clientWorld = this.mc.world;
/* 122 */     BlockState blockstate = clientWorld.getBlockState(pos);
/*     */     
/* 124 */     if (!this.mc.player.getHeldItemMainhand().getItem().canPlayerBreakBlockWhileHolding(blockstate, (World)clientWorld, pos, (PlayerEntity)this.mc.player))
/*     */     {
/* 126 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 130 */     Block block = blockstate.getBlock();
/*     */     
/* 132 */     if ((block instanceof net.minecraft.block.CommandBlockBlock || block instanceof net.minecraft.block.StructureBlock || block instanceof net.minecraft.block.JigsawBlock) && !this.mc.player.canUseCommandBlock())
/*     */     {
/* 134 */       return false;
/*     */     }
/* 136 */     if (blockstate.isAir())
/*     */     {
/* 138 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 142 */     block.onBlockHarvested((World)clientWorld, pos, blockstate, (PlayerEntity)this.mc.player);
/* 143 */     FluidState fluidstate = clientWorld.getFluidState(pos);
/* 144 */     boolean flag = clientWorld.setBlockState(pos, fluidstate.getBlockState(), 11);
/*     */     
/* 146 */     if (flag)
/*     */     {
/* 148 */       block.onPlayerDestroy((IWorld)clientWorld, pos, blockstate);
/*     */     }
/*     */     
/* 151 */     return flag;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean clickBlock(BlockPos loc, Direction face) {
/* 162 */     if (this.mc.player.blockActionRestricted((World)this.mc.world, loc, this.currentGameType))
/*     */     {
/* 164 */       return false;
/*     */     }
/* 166 */     if (!this.mc.world.getWorldBorder().contains(loc))
/*     */     {
/* 168 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 172 */     if (this.currentGameType.isCreative()) {
/*     */       
/* 174 */       BlockState blockstate = this.mc.world.getBlockState(loc);
/* 175 */       sendDiggingPacket(CPlayerDiggingPacket.Action.START_DESTROY_BLOCK, loc, face);
/* 176 */       onPlayerDestroyBlock(loc);
/* 177 */       this.blockHitDelay = 5;
/*     */     }
/* 179 */     else if (!this.isHittingBlock || !isHittingPosition(loc)) {
/*     */       
/* 181 */       if (this.isHittingBlock)
/*     */       {
/* 183 */         sendDiggingPacket(CPlayerDiggingPacket.Action.ABORT_DESTROY_BLOCK, this.currentBlock, face);
/*     */       }
/*     */       
/* 186 */       BlockState blockstate1 = this.mc.world.getBlockState(loc);
/* 187 */       sendDiggingPacket(CPlayerDiggingPacket.Action.START_DESTROY_BLOCK, loc, face);
/* 188 */       boolean flag = !blockstate1.isAir();
/*     */       
/* 190 */       if (flag && this.curBlockDamageMP == 0.0F)
/*     */       {
/* 192 */         blockstate1.onBlockClicked((World)this.mc.world, loc, (PlayerEntity)this.mc.player);
/*     */       }
/*     */       
/* 195 */       if (flag && blockstate1.getPlayerRelativeBlockHardness((PlayerEntity)this.mc.player, (IBlockReader)this.mc.player.world, loc) >= 1.0F) {
/*     */         
/* 197 */         onPlayerDestroyBlock(loc);
/*     */       }
/*     */       else {
/*     */         
/* 201 */         this.isHittingBlock = true;
/* 202 */         this.currentBlock = loc;
/* 203 */         this.currentItemHittingBlock = this.mc.player.getHeldItemMainhand();
/* 204 */         this.curBlockDamageMP = 0.0F;
/* 205 */         this.stepSoundTickCounter = 0.0F;
/* 206 */         this.mc.world.sendBlockBreakProgress(this.mc.player.getEntityId(), this.currentBlock, (int)(this.curBlockDamageMP * 10.0F) - 1);
/*     */       } 
/*     */     } 
/*     */     
/* 210 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetBlockRemoving() {
/* 219 */     if (this.isHittingBlock) {
/*     */       
/* 221 */       BlockState blockstate = this.mc.world.getBlockState(this.currentBlock);
/* 222 */       sendDiggingPacket(CPlayerDiggingPacket.Action.ABORT_DESTROY_BLOCK, this.currentBlock, Direction.DOWN);
/* 223 */       this.isHittingBlock = false;
/* 224 */       this.curBlockDamageMP = 0.0F;
/* 225 */       this.mc.world.sendBlockBreakProgress(this.mc.player.getEntityId(), this.currentBlock, -1);
/* 226 */       this.mc.player.resetCooldown();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean onPlayerDamageBlock(BlockPos posBlock, Direction directionFacing) {
/* 232 */     syncCurrentPlayItem();
/* 233 */     EventInteractBlock event = new EventInteractBlock(posBlock, directionFacing);
/* 234 */     if (event.isCancel()) {
/* 235 */       return false;
/*     */     }
/* 237 */     if (this.blockHitDelay > 0) {
/*     */       
/* 239 */       this.blockHitDelay--;
/* 240 */       return true;
/*     */     } 
/* 242 */     if (this.currentGameType.isCreative() && this.mc.world.getWorldBorder().contains(posBlock)) {
/*     */       
/* 244 */       this.blockHitDelay = 5;
/* 245 */       BlockState blockstate1 = this.mc.world.getBlockState(posBlock);
/* 246 */       sendDiggingPacket(CPlayerDiggingPacket.Action.START_DESTROY_BLOCK, posBlock, directionFacing);
/* 247 */       onPlayerDestroyBlock(posBlock);
/* 248 */       return true;
/*     */     } 
/* 250 */     if (isHittingPosition(posBlock)) {
/*     */       
/* 252 */       BlockState blockstate = this.mc.world.getBlockState(posBlock);
/*     */       
/* 254 */       if (blockstate.isAir()) {
/*     */         
/* 256 */         this.isHittingBlock = false;
/* 257 */         return false;
/*     */       } 
/*     */ 
/*     */       
/* 261 */       this.curBlockDamageMP += blockstate.getPlayerRelativeBlockHardness((PlayerEntity)this.mc.player, (IBlockReader)this.mc.player.world, posBlock);
/*     */       
/* 263 */       if (this.stepSoundTickCounter % 4.0F == 0.0F) {
/*     */         
/* 265 */         SoundType soundtype = blockstate.getSoundType();
/* 266 */         this.mc.getSoundHandler().play((ISound)new SimpleSound(soundtype.getHitSound(), SoundCategory.BLOCKS, (soundtype.getVolume() + 1.0F) / 8.0F, soundtype.getPitch() * 0.5F, posBlock));
/*     */       } 
/*     */       
/* 269 */       this.stepSoundTickCounter++;
/*     */       
/* 271 */       if (this.curBlockDamageMP >= 1.0F) {
/*     */         
/* 273 */         this.isHittingBlock = false;
/* 274 */         sendDiggingPacket(CPlayerDiggingPacket.Action.STOP_DESTROY_BLOCK, posBlock, directionFacing);
/* 275 */         onPlayerDestroyBlock(posBlock);
/* 276 */         this.curBlockDamageMP = 0.0F;
/* 277 */         this.stepSoundTickCounter = 0.0F;
/* 278 */         this.blockHitDelay = 5;
/*     */       } 
/*     */       
/* 281 */       this.mc.world.sendBlockBreakProgress(this.mc.player.getEntityId(), this.currentBlock, (int)(this.curBlockDamageMP * 10.0F) - 1);
/* 282 */       return true;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 287 */     return clickBlock(posBlock, directionFacing);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getBlockReachDistance() {
/* 296 */     return this.currentGameType.isCreative() ? 5.0F : 4.5F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void tick() {
/* 303 */     if (this.connection.getBotNetworkManager().isChannelOpen()) {
/*     */       
/* 305 */       this.connection.getBotNetworkManager().tick();
/*     */     }
/*     */     else {
/*     */       
/* 309 */       this.connection.getBotNetworkManager().handleDisconnection();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isHittingPosition(BlockPos pos) {
/* 316 */     ItemStack itemstack = this.mc.player.getHeldItemMainhand();
/* 317 */     boolean flag = (this.currentItemHittingBlock.isEmpty() && itemstack.isEmpty());
/*     */     
/* 319 */     if (!this.currentItemHittingBlock.isEmpty() && !itemstack.isEmpty())
/*     */     {
/* 321 */       flag = (itemstack.getItem() == this.currentItemHittingBlock.getItem() && ItemStack.areItemStackTagsEqual(itemstack, this.currentItemHittingBlock) && (itemstack.isDamageable() || itemstack.getDamage() == this.currentItemHittingBlock.getDamage()));
/*     */     }
/*     */     
/* 324 */     return (pos.equals(this.currentBlock) && flag);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void syncCurrentPlayItem() {
/* 332 */     int i = this.mc.player.inventory.currentItem;
/*     */     
/* 334 */     if (i != this.currentPlayerItem)
/*     */     {
/* 336 */       this.currentPlayerItem = i;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ActionResultType func_217292_a(ClientPlayerEntity p_217292_1_, BotWorld p_217292_2_, Hand p_217292_3_, BlockRayTraceResult p_217292_4_) {
/* 343 */     syncCurrentPlayItem();
/* 344 */     BlockPos blockpos = p_217292_4_.getPos();
/*     */     
/* 346 */     if (!this.mc.world.getWorldBorder().contains(blockpos)) {
/* 347 */       return ActionResultType.FAIL;
/*     */     }
/* 349 */     ItemStack itemstack = p_217292_1_.getHeldItem(p_217292_3_);
/*     */     
/* 351 */     if (this.currentGameType == GameType.SPECTATOR) {
/* 352 */       this.connection.sendPacket((IPacket)new CPlayerTryUseItemOnBlockPacket(p_217292_3_, p_217292_4_));
/* 353 */       return ActionResultType.SUCCESS;
/*     */     } 
/*     */     
/* 356 */     boolean flag = (!p_217292_1_.getHeldItemMainhand().isEmpty() || !p_217292_1_.getHeldItemOffhand().isEmpty());
/* 357 */     boolean flag1 = (p_217292_1_.isSneaking() && flag);
/*     */     
/* 359 */     if (!flag1) {
/*     */       
/* 361 */       ActionResultType actionresulttype = p_217292_2_.getBlockState(blockpos).onBlockActivated((World)p_217292_2_, (PlayerEntity)p_217292_1_, p_217292_3_, p_217292_4_);
/*     */       
/* 363 */       if (actionresulttype.isSuccessOrConsume()) {
/* 364 */         this.connection.sendPacket((IPacket)new CPlayerTryUseItemOnBlockPacket(p_217292_3_, p_217292_4_));
/* 365 */         return actionresulttype;
/*     */       } 
/*     */     } 
/* 368 */     this.connection.sendPacket((IPacket)new CPlayerTryUseItemOnBlockPacket(p_217292_3_, p_217292_4_));
/*     */     
/* 370 */     if (!itemstack.isEmpty() && !p_217292_1_.getCooldownTracker().hasCooldown(itemstack.getItem())) {
/* 371 */       ActionResultType actionresulttype1; ItemUseContext itemusecontext = new ItemUseContext((PlayerEntity)p_217292_1_, p_217292_3_, p_217292_4_);
/*     */ 
/*     */       
/* 374 */       if (this.currentGameType.isCreative()) {
/* 375 */         int i = itemstack.getCount();
/* 376 */         actionresulttype1 = itemstack.onItemUse(itemusecontext);
/* 377 */         itemstack.setCount(i);
/*     */       } else {
/* 379 */         actionresulttype1 = itemstack.onItemUse(itemusecontext);
/*     */       } 
/*     */       
/* 382 */       return actionresulttype1;
/*     */     } 
/* 384 */     return ActionResultType.PASS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActionResultType processRightClick(PlayerEntity player, World worldIn, Hand hand) {
/* 392 */     if (this.currentGameType == GameType.SPECTATOR)
/*     */     {
/* 394 */       return ActionResultType.PASS;
/*     */     }
/*     */ 
/*     */     
/* 398 */     syncCurrentPlayItem();
/* 399 */     this.connection.sendPacket((IPacket)new CPlayerTryUseItemPacket(hand));
/* 400 */     ItemStack itemstack = player.getHeldItem(hand);
/*     */     
/* 402 */     if (player.getCooldownTracker().hasCooldown(itemstack.getItem()))
/*     */     {
/* 404 */       return ActionResultType.PASS;
/*     */     }
/*     */ 
/*     */     
/* 408 */     int i = itemstack.getCount();
/* 409 */     ActionResult<ItemStack> actionresult = itemstack.useItemRightClick(worldIn, player, hand);
/* 410 */     ItemStack itemstack1 = (ItemStack)actionresult.getResult();
/*     */     
/* 412 */     if (itemstack1 != itemstack)
/*     */     {
/* 414 */       player.setHeldItem(hand, itemstack1);
/*     */     }
/*     */     
/* 417 */     return actionresult.getType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BotPlayer createPlayer(BotWorld worldIn, StatisticsManager statsManager, ClientRecipeBook recipes) {
/* 424 */     return func_239167_a_(worldIn, statsManager, recipes, false, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public BotPlayer func_239167_a_(BotWorld p_239167_1_, StatisticsManager p_239167_2_, ClientRecipeBook p_239167_3_, boolean p_239167_4_, boolean p_239167_5_) {
/* 429 */     this.bot = new BotPlayer(this.mc, p_239167_1_, this.connection, p_239167_2_, p_239167_3_, p_239167_4_, p_239167_5_);
/* 430 */     return this.bot;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void attackEntity(PlayerEntity playerIn, Entity targetEntity) {
/* 438 */     LivingEntity living = (LivingEntity)targetEntity; if (targetEntity instanceof LivingEntity && (new EventAttack(living)).hook().isCancel())
/*     */       return; 
/* 440 */     syncCurrentPlayItem();
/* 441 */     this.connection.sendPacket((IPacket)new CUseEntityPacket(targetEntity, playerIn.isSneaking()));
/*     */     
/* 443 */     if (this.currentGameType != GameType.SPECTATOR) {
/*     */       
/* 445 */       playerIn.attackTargetEntityWithCurrentItem(targetEntity);
/* 446 */       playerIn.resetCooldown();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActionResultType interactWithEntity(PlayerEntity player, Entity target, Hand hand) {
/* 455 */     syncCurrentPlayItem();
/* 456 */     this.connection.sendPacket((IPacket)new CUseEntityPacket(target, hand, player.isSneaking()));
/* 457 */     return (this.currentGameType == GameType.SPECTATOR) ? ActionResultType.PASS : player.interactOn(target, hand);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActionResultType interactWithEntity(PlayerEntity player, Entity target, EntityRayTraceResult ray, Hand hand) {
/* 465 */     syncCurrentPlayItem();
/* 466 */     Vector3d vector3d = ray.getHitVec().subtract(target.getPosX(), target.getPosY(), target.getPosZ());
/* 467 */     this.connection.sendPacket((IPacket)new CUseEntityPacket(target, hand, vector3d, player.isSneaking()));
/* 468 */     return (this.currentGameType == GameType.SPECTATOR) ? ActionResultType.PASS : target.applyPlayerInteraction(player, vector3d, hand);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack windowClick(int windowId, int slotId, int mouseButton, ClickType type, PlayerEntity player) {
/* 476 */     short short1 = player.openContainer.getNextTransactionID(player.inventory);
/* 477 */     ItemStack itemstack = player.openContainer.slotClick(slotId, mouseButton, type, player);
/* 478 */     this.connection.sendPacket((IPacket)new CClickWindowPacket(windowId, slotId, mouseButton, type, itemstack, short1));
/* 479 */     return itemstack;
/*     */   }
/*     */ 
/*     */   
/*     */   public void sendPlaceRecipePacket(int p_203413_1_, IRecipe<?> p_203413_2_, boolean p_203413_3_) {
/* 484 */     this.connection.sendPacket((IPacket)new CPlaceRecipePacket(p_203413_1_, p_203413_2_, p_203413_3_));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendEnchantPacket(int windowID, int button) {
/* 493 */     this.connection.sendPacket((IPacket)new CEnchantItemPacket(windowID, button));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendSlotPacket(ItemStack itemStackIn, int slotId) {
/* 501 */     if (this.currentGameType.isCreative())
/*     */     {
/* 503 */       this.connection.sendPacket((IPacket)new CCreativeInventoryActionPacket(slotId, itemStackIn));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendPacketDropItem(ItemStack itemStackIn) {
/* 512 */     if (this.currentGameType.isCreative() && !itemStackIn.isEmpty())
/*     */     {
/* 514 */       this.connection.sendPacket((IPacket)new CCreativeInventoryActionPacket(-1, itemStackIn));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onStoppedUsingItem(PlayerEntity playerIn) {
/* 520 */     syncCurrentPlayItem();
/* 521 */     this.connection.sendPacket((IPacket)new CPlayerDiggingPacket(CPlayerDiggingPacket.Action.RELEASE_USE_ITEM, BlockPos.ZERO, Direction.DOWN));
/* 522 */     playerIn.stopActiveHand();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean gameIsSurvivalOrAdventure() {
/* 527 */     return this.currentGameType.isSurvivalOrAdventure();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNotCreative() {
/* 535 */     return !this.currentGameType.isCreative();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInCreativeMode() {
/* 543 */     return this.currentGameType.isCreative();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean extendedReach() {
/* 551 */     return this.currentGameType.isCreative();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRidingHorse() {
/* 559 */     return (this.mc.player.isPassenger() && this.mc.player.getRidingEntity() instanceof net.minecraft.entity.passive.horse.AbstractHorseEntity);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSpectatorMode() {
/* 564 */     return (this.currentGameType == GameType.SPECTATOR);
/*     */   }
/*     */ 
/*     */   
/*     */   public GameType func_241822_k() {
/* 569 */     return this.field_239166_k_;
/*     */   }
/*     */ 
/*     */   
/*     */   public GameType getCurrentGameType() {
/* 574 */     return this.currentGameType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getIsHittingBlock() {
/* 582 */     return this.isHittingBlock;
/*     */   }
/*     */ 
/*     */   
/*     */   public void pickItem(int index) {
/* 587 */     this.connection.sendPacket((IPacket)new CPickItemPacket(index));
/*     */   }
/*     */ 
/*     */   
/*     */   private void sendDiggingPacket(CPlayerDiggingPacket.Action action, BlockPos pos, Direction dir) {
/* 592 */     ClientPlayerEntity clientplayerentity = this.mc.player;
/* 593 */     this.unacknowledgedDiggingPackets.put(Pair.of(pos, action), clientplayerentity.getPositionVec());
/* 594 */     this.connection.sendPacket((IPacket)new CPlayerDiggingPacket(action, pos, dir));
/*     */   }
/*     */ 
/*     */   
/*     */   public void acknowledgePlayerDiggingReceived(BotWorld worldIn, BlockPos pos, BlockState blockIn, CPlayerDiggingPacket.Action action, boolean successful) {
/* 599 */     Vector3d vector3d = (Vector3d)this.unacknowledgedDiggingPackets.remove(Pair.of(pos, action));
/* 600 */     BlockState blockstate = worldIn.getBlockState(pos);
/*     */     
/* 602 */     if ((vector3d == null || !successful || (action != CPlayerDiggingPacket.Action.START_DESTROY_BLOCK && blockstate != blockIn)) && blockstate != blockIn) {
/*     */       
/* 604 */       worldIn.invalidateRegionAndSetBlock(pos, blockIn);
/* 605 */       ClientPlayerEntity clientPlayerEntity = this.mc.player;
/*     */       
/* 607 */       if (vector3d != null && worldIn == ((PlayerEntity)clientPlayerEntity).world && clientPlayerEntity.func_242278_a(pos, blockIn))
/*     */       {
/* 609 */         clientPlayerEntity.func_242281_f(vector3d.x, vector3d.y, vector3d.z);
/*     */       }
/*     */     } 
/*     */     
/* 613 */     while (this.unacknowledgedDiggingPackets.size() >= 50) {
/*     */       
/* 615 */       Pair<BlockPos, CPlayerDiggingPacket.Action> pair = (Pair<BlockPos, CPlayerDiggingPacket.Action>)this.unacknowledgedDiggingPackets.firstKey();
/* 616 */       this.unacknowledgedDiggingPackets.removeFirst();
/* 617 */       LOGGER.error("Too many unacked block actions, dropping " + String.valueOf(pair));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\autobuy\bots\player\BotController.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */