/*      */ package fun.rockstarity.api.autobuy.bots.player;
/*      */ 
/*      */ import com.google.common.collect.Lists;
/*      */ import fun.rockstarity.api.autobuy.bots.connection.BotPlayNetHandler;
/*      */ import fun.rockstarity.api.autobuy.bots.world.BotWorld;
/*      */ import fun.rockstarity.api.helpers.math.TimerUtility;
/*      */ import fun.rockstarity.api.helpers.player.Move;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.UUID;
/*      */ import java.util.stream.Stream;
/*      */ import javax.annotation.Nullable;
/*      */ import net.minecraft.block.BlockState;
/*      */ import net.minecraft.client.Minecraft;
/*      */ import net.minecraft.client.audio.BiomeSoundHandler;
/*      */ import net.minecraft.client.audio.IAmbientSoundHandler;
/*      */ import net.minecraft.client.audio.ISound;
/*      */ import net.minecraft.client.audio.RidingMinecartTickableSound;
/*      */ import net.minecraft.client.audio.SimpleSound;
/*      */ import net.minecraft.client.entity.player.AbstractClientPlayerEntity;
/*      */ import net.minecraft.client.gui.screen.CommandBlockScreen;
/*      */ import net.minecraft.client.gui.screen.EditBookScreen;
/*      */ import net.minecraft.client.gui.screen.EditMinecartCommandBlockScreen;
/*      */ import net.minecraft.client.gui.screen.EditSignScreen;
/*      */ import net.minecraft.client.gui.screen.EditStructureScreen;
/*      */ import net.minecraft.client.gui.screen.JigsawScreen;
/*      */ import net.minecraft.client.gui.screen.Screen;
/*      */ import net.minecraft.client.util.ClientRecipeBook;
/*      */ import net.minecraft.entity.Entity;
/*      */ import net.minecraft.entity.IJumpingMount;
/*      */ import net.minecraft.entity.MoverType;
/*      */ import net.minecraft.entity.Pose;
/*      */ import net.minecraft.entity.item.BoatEntity;
/*      */ import net.minecraft.entity.item.minecart.AbstractMinecartEntity;
/*      */ import net.minecraft.entity.player.PlayerEntity;
/*      */ import net.minecraft.inventory.EquipmentSlotType;
/*      */ import net.minecraft.item.ElytraItem;
/*      */ import net.minecraft.item.Item;
/*      */ import net.minecraft.item.ItemStack;
/*      */ import net.minecraft.item.Items;
/*      */ import net.minecraft.item.crafting.IRecipe;
/*      */ import net.minecraft.network.IPacket;
/*      */ import net.minecraft.network.datasync.DataParameter;
/*      */ import net.minecraft.network.play.client.CAnimateHandPacket;
/*      */ import net.minecraft.network.play.client.CChatMessagePacket;
/*      */ import net.minecraft.network.play.client.CClientStatusPacket;
/*      */ import net.minecraft.network.play.client.CCloseWindowPacket;
/*      */ import net.minecraft.network.play.client.CEntityActionPacket;
/*      */ import net.minecraft.network.play.client.CInputPacket;
/*      */ import net.minecraft.network.play.client.CMarkRecipeSeenPacket;
/*      */ import net.minecraft.network.play.client.CMoveVehiclePacket;
/*      */ import net.minecraft.network.play.client.CPlayerAbilitiesPacket;
/*      */ import net.minecraft.network.play.client.CPlayerDiggingPacket;
/*      */ import net.minecraft.network.play.client.CPlayerPacket;
/*      */ import net.minecraft.particles.IParticleData;
/*      */ import net.minecraft.particles.ParticleTypes;
/*      */ import net.minecraft.potion.Effect;
/*      */ import net.minecraft.potion.EffectInstance;
/*      */ import net.minecraft.potion.Effects;
/*      */ import net.minecraft.stats.StatisticsManager;
/*      */ import net.minecraft.tags.FluidTags;
/*      */ import net.minecraft.tags.ITag;
/*      */ import net.minecraft.tileentity.CommandBlockLogic;
/*      */ import net.minecraft.tileentity.CommandBlockTileEntity;
/*      */ import net.minecraft.tileentity.JigsawTileEntity;
/*      */ import net.minecraft.tileentity.SignTileEntity;
/*      */ import net.minecraft.tileentity.StructureBlockTileEntity;
/*      */ import net.minecraft.util.DamageSource;
/*      */ import net.minecraft.util.Direction;
/*      */ import net.minecraft.util.Hand;
/*      */ import net.minecraft.util.HandSide;
/*      */ import net.minecraft.util.MovementInput;
/*      */ import net.minecraft.util.SoundCategory;
/*      */ import net.minecraft.util.SoundEvent;
/*      */ import net.minecraft.util.SoundEvents;
/*      */ import net.minecraft.util.math.AxisAlignedBB;
/*      */ import net.minecraft.util.math.BlockPos;
/*      */ import net.minecraft.util.math.MathHelper;
/*      */ import net.minecraft.util.math.shapes.ISelectionContext;
/*      */ import net.minecraft.util.math.shapes.VoxelShape;
/*      */ import net.minecraft.util.math.vector.Vector2f;
/*      */ import net.minecraft.util.math.vector.Vector3d;
/*      */ import net.minecraft.util.text.ITextComponent;
/*      */ import net.minecraft.world.IBlockReader;
/*      */ 
/*      */ public class BotPlayer
/*      */   extends AbstractClientPlayerEntity
/*      */ {
/*   89 */   final TimerUtility updateTimer = new TimerUtility(); public TimerUtility getUpdateTimer() { return this.updateTimer; }
/*   90 */    final TimerUtility antiAfkTimer = new TimerUtility(); public TimerUtility getAntiAfkTimer() { return this.antiAfkTimer; }
/*      */   
/*      */   public final BotPlayNetHandler connection;
/*      */   private final StatisticsManager stats;
/*      */   private final ClientRecipeBook recipeBook;
/*   95 */   private final List<IAmbientSoundHandler> ambientSoundHandlers = Lists.newArrayList();
/*   96 */   private int permissionLevel = 0;
/*      */   
/*      */   public boolean FORWARD;
/*      */   
/*      */   public boolean BACKWARD;
/*      */   
/*      */   public boolean LEFT;
/*      */   
/*      */   public boolean RIGHT;
/*      */   
/*      */   public boolean JUMP;
/*      */   
/*      */   public boolean SNEAK;
/*      */   
/*      */   public Screen currentScreen;
/*      */   
/*      */   private double lastReportedPosX;
/*      */   
/*      */   private double lastReportedPosY;
/*      */   
/*      */   private double lastReportedPosZ;
/*      */   
/*      */   private float lastReportedYaw;
/*      */   
/*      */   private float lastReportedPitch;
/*      */   
/*      */   private boolean prevOnGround;
/*      */   
/*      */   private boolean isCrouching;
/*      */   
/*      */   private boolean clientSneakState;
/*      */   
/*      */   public boolean serverSprintState;
/*      */   
/*      */   private int positionUpdateTicks;
/*      */   
/*      */   private boolean hasValidHealth;
/*      */   
/*      */   private String serverBrand;
/*      */   
/*      */   public MovementInput movementInput;
/*      */   
/*      */   protected final Minecraft mc;
/*      */   
/*      */   protected int sprintToggleTimer;
/*      */   
/*      */   public int sprintingTicksLeft;
/*      */   
/*      */   public float renderArmYaw;
/*      */   
/*      */   public float renderArmPitch;
/*      */   
/*      */   public float prevRenderArmYaw;
/*      */   
/*      */   public float prevRenderArmPitch;
/*      */   
/*      */   private int horseJumpPowerCounter;
/*      */   
/*      */   private float horseJumpPower;
/*      */   public float timeInPortal;
/*      */   public float prevTimeInPortal;
/*      */   private boolean handActive;
/*      */   private Hand activeHand;
/*      */   private boolean rowingBoat;
/*      */   private boolean autoJumpEnabled = true;
/*      */   private int autoJumpTime;
/*      */   private boolean wasFallFlying;
/*      */   private int counterInWater;
/*      */   private boolean showDeathScreen = true;
/*      */   
/*      */   public BotPlayer(Minecraft mc, BotWorld world, BotPlayNetHandler connection, StatisticsManager stats, ClientRecipeBook recipeBook, boolean clientSneakState, boolean clientSprintState) {
/*  167 */     super(world, connection.getGameProfile());
/*  168 */     this.mc = mc;
/*  169 */     this.connection = connection;
/*  170 */     this.stats = stats;
/*  171 */     this.recipeBook = recipeBook;
/*  172 */     this.clientSneakState = clientSneakState;
/*  173 */     this.serverSprintState = clientSprintState;
/*      */   }
/*      */   
/*      */   public BotPlayer(BotPlayNetHandler botPlayClient) {
/*  177 */     super(botPlayClient.getWorld(), botPlayClient.getGameProfile());
/*  178 */     this.permissionLevel = 0;
/*      */     
/*  180 */     this.connection = botPlayClient;
/*      */ 
/*      */     
/*  183 */     this.stats = new StatisticsManager();
/*  184 */     this.recipeBook = new ClientRecipeBook();
/*  185 */     this.mc = Minecraft.getInstance();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean attackEntityFrom(DamageSource source, float amount) {
/*  193 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void heal(float healAmount) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean startRiding(Entity entityIn, boolean force) {
/*  205 */     if (!super.startRiding(entityIn, force))
/*      */     {
/*  207 */       return false;
/*      */     }
/*      */ 
/*      */     
/*  211 */     if (entityIn instanceof AbstractMinecartEntity)
/*      */     {
/*  213 */       this.mc.getSoundHandler().play((ISound)new RidingMinecartTickableSound((PlayerEntity)this, (AbstractMinecartEntity)entityIn));
/*      */     }
/*      */     
/*  216 */     if (entityIn instanceof BoatEntity) {
/*      */       
/*  218 */       this.prevRotationYaw = entityIn.rotationYaw;
/*  219 */       this.rotationYaw = entityIn.rotationYaw;
/*  220 */       setRotationYawHead(entityIn.rotationYaw);
/*      */     } 
/*      */     
/*  223 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void dismount() {
/*  229 */     super.dismount();
/*  230 */     this.rowingBoat = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getPitch(float partialTicks) {
/*  238 */     return this.rotationPitch;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getYaw(float partialTicks) {
/*  246 */     return isPassenger() ? super.getYaw(partialTicks) : this.rotationYaw;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void tick() {
/*  254 */     if (this.world.isBlockLoaded(new BlockPos(getPosX(), 0.0D, getPosZ()))) {
/*      */       
/*  256 */       super.tick();
/*      */       
/*  258 */       if (isPassenger()) {
/*      */         
/*  260 */         this.connection.sendPacket((IPacket)new CPlayerPacket.RotationPacket(this.rotationYaw, this.rotationPitch, this.onGround));
/*  261 */         this.connection.sendPacket((IPacket)new CInputPacket(this.moveStrafing, this.moveForward, this.movementInput.jump, this.movementInput.sneaking));
/*  262 */         Entity entity = getLowestRidingEntity();
/*      */         
/*  264 */         if (entity != this && entity.canPassengerSteer())
/*      */         {
/*  266 */           this.connection.sendPacket((IPacket)new CMoveVehiclePacket(entity));
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/*  271 */         onUpdateWalkingPlayer();
/*      */       } 
/*      */       
/*  274 */       for (IAmbientSoundHandler iambientsoundhandler : this.ambientSoundHandlers)
/*      */       {
/*  276 */         iambientsoundhandler.tick();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public float getDarknessAmbience() {
/*  283 */     for (IAmbientSoundHandler iambientsoundhandler : this.ambientSoundHandlers) {
/*      */       
/*  285 */       if (iambientsoundhandler instanceof BiomeSoundHandler)
/*      */       {
/*  287 */         return ((BiomeSoundHandler)iambientsoundhandler).getDarknessAmbienceChance();
/*      */       }
/*      */     } 
/*      */     
/*  291 */     return 0.0F;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void onUpdateWalkingPlayer() {
/*  299 */     boolean flag = isSprinting();
/*      */     
/*  301 */     if (flag != this.serverSprintState) {
/*      */       
/*  303 */       CEntityActionPacket.Action centityactionpacket$action = flag ? CEntityActionPacket.Action.START_SPRINTING : CEntityActionPacket.Action.STOP_SPRINTING;
/*  304 */       this.connection.sendPacket((IPacket)new CEntityActionPacket((Entity)this, centityactionpacket$action));
/*  305 */       this.serverSprintState = flag;
/*      */     } 
/*      */     
/*  308 */     boolean flag3 = isSneaking();
/*      */     
/*  310 */     if (flag3 != this.clientSneakState) {
/*      */       
/*  312 */       CEntityActionPacket.Action centityactionpacket$action1 = flag3 ? CEntityActionPacket.Action.PRESS_SHIFT_KEY : CEntityActionPacket.Action.RELEASE_SHIFT_KEY;
/*  313 */       this.connection.sendPacket((IPacket)new CEntityActionPacket((Entity)this, centityactionpacket$action1));
/*  314 */       this.clientSneakState = flag3;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  319 */     double d4 = getPosX() - this.lastReportedPosX;
/*  320 */     double d0 = getPosY() - this.lastReportedPosY;
/*  321 */     double d1 = getPosZ() - this.lastReportedPosZ;
/*  322 */     double d2 = (this.rotationYaw - this.lastReportedYaw);
/*  323 */     double d3 = (this.rotationPitch - this.lastReportedPitch);
/*  324 */     this.positionUpdateTicks++;
/*  325 */     boolean flag1 = (d4 * d4 + d0 * d0 + d1 * d1 > 9.0E-4D || this.positionUpdateTicks >= 20);
/*  326 */     boolean flag2 = (d2 != 0.0D || d3 != 0.0D);
/*      */     
/*  328 */     if (Math.abs(getPosX()) < 1.0D)
/*      */       return; 
/*  330 */     if (isPassenger()) {
/*      */       
/*  332 */       Vector3d vector3d = getMotion();
/*  333 */       this.connection.sendPacket((IPacket)new CPlayerPacket.PositionRotationPacket(vector3d.x, -999.0D, vector3d.z, this.rotationYaw, this.rotationPitch, this.onGround));
/*  334 */       flag1 = false;
/*      */     }
/*  336 */     else if (flag1 && flag2) {
/*      */       
/*  338 */       this.connection.sendPacket((IPacket)new CPlayerPacket.PositionRotationPacket(getPosX(), getPosY(), getPosZ(), this.rotationYaw, this.rotationPitch, this.onGround));
/*      */     }
/*  340 */     else if (flag1) {
/*      */       
/*  342 */       this.connection.sendPacket((IPacket)new CPlayerPacket.PositionPacket(getPosX(), getPosY(), getPosZ(), this.onGround));
/*      */     }
/*  344 */     else if (flag2) {
/*      */       
/*  346 */       this.connection.sendPacket((IPacket)new CPlayerPacket.RotationPacket(this.rotationYaw, this.rotationPitch, this.onGround));
/*      */     }
/*  348 */     else if (this.prevOnGround != this.onGround) {
/*      */       
/*  350 */       this.connection.sendPacket((IPacket)new CPlayerPacket(this.onGround));
/*      */     } 
/*      */     
/*  353 */     if (flag1) {
/*      */       
/*  355 */       this.lastReportedPosX = getPosX();
/*  356 */       this.lastReportedPosY = getPosY();
/*  357 */       this.lastReportedPosZ = getPosZ();
/*  358 */       this.positionUpdateTicks = 0;
/*      */     } 
/*      */     
/*  361 */     if (flag2) {
/*      */       
/*  363 */       this.lastReportedYaw = this.rotationYaw;
/*  364 */       this.lastReportedPitch = this.rotationPitch;
/*      */     } 
/*      */     
/*  367 */     this.prevOnGround = this.onGround;
/*  368 */     this.autoJumpEnabled = (this.mc.getGameSettings()).autoJump;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean drop(boolean p_225609_1_) {
/*  374 */     CPlayerDiggingPacket.Action cplayerdiggingpacket$action = p_225609_1_ ? CPlayerDiggingPacket.Action.DROP_ALL_ITEMS : CPlayerDiggingPacket.Action.DROP_ITEM;
/*  375 */     this.connection.sendPacket((IPacket)new CPlayerDiggingPacket(cplayerdiggingpacket$action, BlockPos.ZERO, Direction.DOWN));
/*  376 */     return (this.inventory.decrStackSize(this.inventory.currentItem, (p_225609_1_ && !this.inventory.getCurrentItem().isEmpty()) ? this.inventory.getCurrentItem().getCount() : 1) != ItemStack.EMPTY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void sendChatMessage(String message) {
/*  384 */     this.connection.sendPacket((IPacket)new CChatMessagePacket(message));
/*      */   }
/*      */ 
/*      */   
/*      */   public void swingArm(Hand hand) {
/*  389 */     super.swingArm(hand);
/*  390 */     this.connection.sendPacket((IPacket)new CAnimateHandPacket(hand));
/*      */   }
/*      */ 
/*      */   
/*      */   public void respawnPlayer() {
/*  395 */     this.connection.sendPacket((IPacket)new CClientStatusPacket(CClientStatusPacket.State.PERFORM_RESPAWN));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void damageEntity(DamageSource damageSrc, float damageAmount) {
/*  404 */     if (!isInvulnerableTo(damageSrc))
/*      */     {
/*  406 */       setHealth(getHealth() - damageAmount);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void closeScreen() {
/*  415 */     this.connection.sendPacket((IPacket)new CCloseWindowPacket(this.openContainer.windowId));
/*  416 */     closeScreenAndDropStack();
/*      */   }
/*      */ 
/*      */   
/*      */   public void closeScreenAndDropStack() {
/*  421 */     this.inventory.setItemStack(ItemStack.EMPTY);
/*  422 */     super.closeScreen();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPlayerSPHealth(float health) {
/*  431 */     if (this.hasValidHealth) {
/*      */       
/*  433 */       float f = getHealth() - health;
/*      */       
/*  435 */       if (f <= 0.0F)
/*      */       {
/*  437 */         setHealth(health);
/*      */         
/*  439 */         if (f < 0.0F)
/*      */         {
/*  441 */           this.hurtResistantTime = 10;
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  446 */         this.lastDamage = f;
/*  447 */         setHealth(getHealth());
/*  448 */         this.hurtResistantTime = 20;
/*  449 */         damageEntity(DamageSource.GENERIC, f);
/*  450 */         this.maxHurtTime = 10;
/*  451 */         this.hurtTime = this.maxHurtTime;
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/*  456 */       setHealth(health);
/*  457 */       this.hasValidHealth = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void sendPlayerAbilities() {
/*  466 */     this.connection.sendPacket((IPacket)new CPlayerAbilitiesPacket(this.abilities));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isUser() {
/*  474 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasStoppedClimbing() {
/*  479 */     return (!this.abilities.isFlying && super.hasStoppedClimbing());
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean func_230269_aK_() {
/*  484 */     return (!this.abilities.isFlying && super.func_230269_aK_());
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getMovementSpeed() {
/*  489 */     return (!this.abilities.isFlying && super.getMovementSpeed());
/*      */   }
/*      */ 
/*      */   
/*      */   protected void sendHorseJump() {
/*  494 */     this.connection.sendPacket((IPacket)new CEntityActionPacket((Entity)this, CEntityActionPacket.Action.START_RIDING_JUMP, MathHelper.floor(getHorseJumpPower() * 100.0F)));
/*      */   }
/*      */ 
/*      */   
/*      */   public void sendHorseInventory() {
/*  499 */     this.connection.sendPacket((IPacket)new CEntityActionPacket((Entity)this, CEntityActionPacket.Action.OPEN_INVENTORY));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setServerBrand(String brand) {
/*  508 */     this.serverBrand = brand;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getServerBrand() {
/*  518 */     return this.serverBrand;
/*      */   }
/*      */ 
/*      */   
/*      */   public StatisticsManager getStats() {
/*  523 */     return this.stats;
/*      */   }
/*      */ 
/*      */   
/*      */   public ClientRecipeBook getRecipeBook() {
/*  528 */     return this.recipeBook;
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeRecipeHighlight(IRecipe<?> recipe) {
/*  533 */     if (this.recipeBook.isNew(recipe)) {
/*      */       
/*  535 */       this.recipeBook.markSeen(recipe);
/*  536 */       this.connection.sendPacket((IPacket)new CMarkRecipeSeenPacket(recipe));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected int getPermissionLevel() {
/*  542 */     return this.permissionLevel;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setPermissionLevel(int permissionLevel) {
/*  547 */     this.permissionLevel = permissionLevel;
/*      */   }
/*      */ 
/*      */   
/*      */   public void sendStatusMessage(ITextComponent chatComponent, boolean actionBar) {
/*  552 */     if (actionBar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setPlayerOffsetMotion(double x, double z) {
/*  564 */     BlockPos blockpos = new BlockPos(x, getPosY(), z);
/*      */     
/*  566 */     if (shouldBlockPushPlayer(blockpos)) {
/*      */       
/*  568 */       double d0 = x - blockpos.getX();
/*  569 */       double d1 = z - blockpos.getZ();
/*  570 */       Direction direction = null;
/*  571 */       double d2 = Double.MAX_VALUE;
/*  572 */       Direction[] adirection = { Direction.WEST, Direction.EAST, Direction.NORTH, Direction.SOUTH };
/*      */       
/*  574 */       for (Direction direction1 : adirection) {
/*      */         
/*  576 */         double d3 = direction1.getAxis().getCoordinate(d0, 0.0D, d1);
/*  577 */         double d4 = (direction1.getAxisDirection() == Direction.AxisDirection.POSITIVE) ? (1.0D - d3) : d3;
/*      */         
/*  579 */         if (d4 < d2 && !shouldBlockPushPlayer(blockpos.offset(direction1))) {
/*      */           
/*  581 */           d2 = d4;
/*  582 */           direction = direction1;
/*      */         } 
/*      */       } 
/*      */       
/*  586 */       if (direction != null) {
/*      */         
/*  588 */         Vector3d vector3d = getMotion();
/*      */         
/*  590 */         if (direction.getAxis() == Direction.Axis.X) {
/*      */           
/*  592 */           setMotion(0.1D * direction.getXOffset(), vector3d.y, vector3d.z);
/*      */         }
/*      */         else {
/*      */           
/*  596 */           setMotion(vector3d.x, vector3d.y, 0.1D * direction.getZOffset());
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean shouldBlockPushPlayer(BlockPos pos) {
/*  604 */     AxisAlignedBB axisalignedbb = getBoundingBox();
/*  605 */     AxisAlignedBB axisalignedbb1 = (new AxisAlignedBB(pos.getX(), axisalignedbb.minY, pos.getZ(), pos.getX() + 1.0D, axisalignedbb.maxY, pos.getZ() + 1.0D)).shrink(1.0E-7D);
/*  606 */     return !this.world.func_242405_a((Entity)this, axisalignedbb1, (state, pos2) -> state.isSuffocating((IBlockReader)this.world, pos2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSprinting(boolean sprinting) {
/*  617 */     super.setSprinting(sprinting);
/*  618 */     this.sprintingTicksLeft = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setXPStats(float currentXP, int maxXP, int level) {
/*  626 */     this.experience = currentXP;
/*  627 */     this.experienceTotal = maxXP;
/*  628 */     this.experienceLevel = level;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void sendMessage(ITextComponent component, UUID senderUUID) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addChatMessage(String msg) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleStatusUpdate(byte id) {
/*  648 */     if (id >= 24 && id <= 28) {
/*      */       
/*  650 */       setPermissionLevel(id - 24);
/*      */     }
/*      */     else {
/*      */       
/*  654 */       super.handleStatusUpdate(id);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setShowDeathScreen(boolean show) {
/*  660 */     this.showDeathScreen = show;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isShowDeathScreen() {
/*  665 */     return this.showDeathScreen;
/*      */   }
/*      */ 
/*      */   
/*      */   public void playSound(SoundEvent soundIn, float volume, float pitch) {
/*  670 */     this.world.playSound(getPosX(), getPosY(), getPosZ(), soundIn, getSoundCategory(), volume, pitch, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public void playSound(SoundEvent p_213823_1_, SoundCategory p_213823_2_, float p_213823_3_, float p_213823_4_) {
/*  675 */     this.world.playSound(getPosX(), getPosY(), getPosZ(), p_213823_1_, p_213823_2_, p_213823_3_, p_213823_4_, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isServerWorld() {
/*  683 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setActiveHand(Hand hand) {
/*  688 */     ItemStack itemstack = getHeldItem(hand);
/*      */     
/*  690 */     if (!itemstack.isEmpty() && !isHandActive()) {
/*      */       
/*  692 */       super.setActiveHand(hand);
/*  693 */       this.handActive = true;
/*  694 */       this.activeHand = hand;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isHandActive() {
/*  700 */     return this.handActive;
/*      */   }
/*      */ 
/*      */   
/*      */   public void resetActiveHand() {
/*  705 */     super.resetActiveHand();
/*  706 */     this.handActive = false;
/*      */   }
/*      */ 
/*      */   
/*      */   public Hand getActiveHand() {
/*  711 */     return this.activeHand;
/*      */   }
/*      */ 
/*      */   
/*      */   public void notifyDataManagerChange(DataParameter<?> key) {
/*  716 */     super.notifyDataManagerChange(key);
/*      */     
/*  718 */     if (LIVING_FLAGS.equals(key)) {
/*      */       
/*  720 */       boolean flag = ((((Byte)this.dataManager.get(LIVING_FLAGS)).byteValue() & 0x1) > 0);
/*  721 */       Hand hand = ((((Byte)this.dataManager.get(LIVING_FLAGS)).byteValue() & 0x2) > 0) ? Hand.OFF_HAND : Hand.MAIN_HAND;
/*      */       
/*  723 */       if (flag && !this.handActive) {
/*      */         
/*  725 */         setActiveHand(hand);
/*      */       }
/*  727 */       else if (!flag && this.handActive) {
/*      */         
/*  729 */         resetActiveHand();
/*      */       } 
/*      */     } 
/*      */     
/*  733 */     if (!FLAGS.equals(key) || !isElytraFlying() || !this.wasFallFlying);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isRidingHorse() {
/*  740 */     Entity entity = getRidingEntity();
/*  741 */     return (isPassenger() && entity instanceof IJumpingMount && ((IJumpingMount)entity).canJump());
/*      */   }
/*      */ 
/*      */   
/*      */   public float getHorseJumpPower() {
/*  746 */     return this.horseJumpPower;
/*      */   }
/*      */ 
/*      */   
/*      */   public void openSignEditor(SignTileEntity signTile) {
/*  751 */     this.mc.displayGuiScreen((Screen)new EditSignScreen(signTile));
/*      */   }
/*      */ 
/*      */   
/*      */   public void openMinecartCommandBlock(CommandBlockLogic commandBlock) {
/*  756 */     this.mc.displayGuiScreen((Screen)new EditMinecartCommandBlockScreen(commandBlock));
/*      */   }
/*      */ 
/*      */   
/*      */   public void openCommandBlock(CommandBlockTileEntity commandBlock) {
/*  761 */     this.mc.displayGuiScreen((Screen)new CommandBlockScreen(commandBlock));
/*      */   }
/*      */ 
/*      */   
/*      */   public void openStructureBlock(StructureBlockTileEntity structure) {
/*  766 */     this.mc.displayGuiScreen((Screen)new EditStructureScreen(structure));
/*      */   }
/*      */ 
/*      */   
/*      */   public void openJigsaw(JigsawTileEntity p_213826_1_) {
/*  771 */     this.mc.displayGuiScreen((Screen)new JigsawScreen(p_213826_1_));
/*      */   }
/*      */ 
/*      */   
/*      */   public void openBook(ItemStack stack, Hand hand) {
/*  776 */     Item item = stack.getItem();
/*      */     
/*  778 */     if (item == Items.WRITABLE_BOOK)
/*      */     {
/*  780 */       this.mc.displayGuiScreen((Screen)new EditBookScreen((PlayerEntity)this, stack, hand));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void onCriticalHit(Entity entityHit) {
/*  789 */     this.mc.particles.addParticleEmitter(entityHit, (IParticleData)ParticleTypes.CRIT);
/*      */   }
/*      */ 
/*      */   
/*      */   public void onEnchantmentCritical(Entity entityHit) {
/*  794 */     this.mc.particles.addParticleEmitter(entityHit, (IParticleData)ParticleTypes.ENCHANTED_HIT);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isSneaking() {
/*  799 */     return (this.movementInput != null && this.movementInput.sneaking);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isCrouching() {
/*  804 */     return this.isCrouching;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isForcedDown() {
/*  809 */     return (isCrouching() || isVisuallySwimming());
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateEntityActionState() {
/*  814 */     super.updateEntityActionState();
/*      */ 
/*      */ 
/*      */     
/*  818 */     this.moveStrafing = this.movementInput.moveStrafe;
/*  819 */     this.moveForward = this.movementInput.moveForward;
/*  820 */     this.isJumping = this.movementInput.jump;
/*  821 */     this.prevRenderArmYaw = this.renderArmYaw;
/*  822 */     this.prevRenderArmPitch = this.renderArmPitch;
/*  823 */     this.renderArmPitch = (float)(this.renderArmPitch + (this.rotationPitch - this.renderArmPitch) * 0.5D);
/*  824 */     this.renderArmYaw = (float)(this.renderArmYaw + (this.rotationYaw - this.renderArmYaw) * 0.5D);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isCurrentViewEntity() {
/*  830 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void livingTick() {
/*  839 */     this.sprintingTicksLeft++;
/*      */     
/*  841 */     if (this.sprintToggleTimer > 0)
/*      */     {
/*  843 */       this.sprintToggleTimer--;
/*      */     }
/*      */     
/*  846 */     handlePortalTeleportation();
/*  847 */     boolean flag = this.movementInput.jump;
/*  848 */     boolean flag1 = this.movementInput.sneaking;
/*  849 */     boolean flag2 = isUsingSwimmingAnimation();
/*  850 */     this.isCrouching = (!this.abilities.isFlying && !isSwimming() && isPoseClear(Pose.CROUCHING) && (isSneaking() || (!isSleeping() && !isPoseClear(Pose.STANDING))));
/*  851 */     this.movementInput.tickMovement(isForcedDown());
/*      */     
/*  853 */     if (isHandActive() && !isPassenger()) {
/*      */       
/*  855 */       this.movementInput.moveStrafe *= 0.2F;
/*  856 */       this.movementInput.moveForward *= 0.2F;
/*  857 */       this.sprintToggleTimer = 0;
/*      */     } 
/*      */     
/*  860 */     boolean flag3 = false;
/*      */     
/*  862 */     if (this.autoJumpTime > 0) {
/*      */       
/*  864 */       this.autoJumpTime--;
/*  865 */       flag3 = true;
/*  866 */       this.movementInput.jump = true;
/*      */     } 
/*      */     
/*  869 */     if (!this.noClip) {
/*      */       
/*  871 */       setPlayerOffsetMotion(getPosX() - getWidth() * 0.35D, getPosZ() + getWidth() * 0.35D);
/*  872 */       setPlayerOffsetMotion(getPosX() - getWidth() * 0.35D, getPosZ() - getWidth() * 0.35D);
/*  873 */       setPlayerOffsetMotion(getPosX() + getWidth() * 0.35D, getPosZ() - getWidth() * 0.35D);
/*  874 */       setPlayerOffsetMotion(getPosX() + getWidth() * 0.35D, getPosZ() + getWidth() * 0.35D);
/*      */     } 
/*      */     
/*  877 */     if (flag1)
/*      */     {
/*  879 */       this.sprintToggleTimer = 0;
/*      */     }
/*      */     
/*  882 */     boolean flag4 = (getFoodStats().getFoodLevel() > 6.0F || this.abilities.allowFlying);
/*      */     
/*  884 */     if ((this.onGround || canSwim()) && !flag1 && !flag2 && isUsingSwimmingAnimation() && !isSprinting() && flag4 && !isHandActive() && !isPotionActive(Effects.BLINDNESS))
/*      */     {
/*  886 */       if (this.sprintToggleTimer <= 0 && !(this.mc.getGameSettings()).keyBindSprint.isKeyDown()) {
/*      */         
/*  888 */         this.sprintToggleTimer = 7;
/*      */       }
/*      */       else {
/*      */         
/*  892 */         setSprinting(true);
/*      */       } 
/*      */     }
/*      */     
/*  896 */     if (!isSprinting() && (!isInWater() || canSwim()) && isUsingSwimmingAnimation() && flag4 && !isHandActive() && !isPotionActive(Effects.BLINDNESS) && (this.mc.getGameSettings()).keyBindSprint.isKeyDown())
/*      */     {
/*  898 */       setSprinting(true);
/*      */     }
/*      */     
/*  901 */     if (isSprinting()) {
/*      */       
/*  903 */       boolean flag5 = (!this.movementInput.isMovingForward() || !flag4);
/*  904 */       boolean flag6 = (flag5 || this.collidedHorizontally || (isInWater() && !canSwim()));
/*      */       
/*  906 */       if (isSwimming()) {
/*      */         
/*  908 */         if ((!this.onGround && !this.movementInput.sneaking && flag5) || !isInWater())
/*      */         {
/*  910 */           setSprinting(false);
/*      */         }
/*      */       }
/*  913 */       else if (flag6) {
/*      */         
/*  915 */         setSprinting(false);
/*      */       } 
/*      */     } 
/*      */     
/*  919 */     boolean flag7 = false;
/*      */     
/*  921 */     if (this.abilities.allowFlying)
/*      */     {
/*  923 */       if (this.mc.playerController.isSpectatorMode()) {
/*      */         
/*  925 */         if (!this.abilities.isFlying)
/*      */         {
/*  927 */           this.abilities.isFlying = true;
/*  928 */           flag7 = true;
/*  929 */           sendPlayerAbilities();
/*      */         }
/*      */       
/*  932 */       } else if (!flag && this.movementInput.jump && !flag3) {
/*      */         
/*  934 */         if (this.flyToggleTimer == 0) {
/*      */           
/*  936 */           this.flyToggleTimer = 7;
/*      */         }
/*  938 */         else if (!isSwimming()) {
/*      */           
/*  940 */           this.abilities.isFlying = !this.abilities.isFlying;
/*  941 */           flag7 = true;
/*  942 */           sendPlayerAbilities();
/*  943 */           this.flyToggleTimer = 0;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*  948 */     if (this.movementInput.jump && !flag7 && !flag && !this.abilities.isFlying && !isPassenger() && !isOnLadder()) {
/*      */       
/*  950 */       ItemStack itemstack = getItemStackFromSlot(EquipmentSlotType.CHEST);
/*      */       
/*  952 */       if (itemstack.getItem() == Items.ELYTRA && ElytraItem.isUsable(itemstack) && tryToStartFallFlying())
/*      */       {
/*  954 */         this.connection.sendPacket((IPacket)new CEntityActionPacket((Entity)this, CEntityActionPacket.Action.START_FALL_FLYING));
/*      */       }
/*      */     } 
/*      */     
/*  958 */     this.wasFallFlying = isElytraFlying();
/*      */     
/*  960 */     if (isInWater() && this.movementInput.sneaking && func_241208_cS_())
/*      */     {
/*  962 */       handleFluidSneak();
/*      */     }
/*      */     
/*  965 */     if (areEyesInFluid((ITag)FluidTags.WATER)) {
/*      */       
/*  967 */       int i = isSpectator() ? 10 : 1;
/*  968 */       this.counterInWater = MathHelper.clamp(this.counterInWater + i, 0, 600);
/*      */     }
/*  970 */     else if (this.counterInWater > 0) {
/*      */       
/*  972 */       areEyesInFluid((ITag)FluidTags.WATER);
/*  973 */       this.counterInWater = MathHelper.clamp(this.counterInWater - 10, 0, 600);
/*      */     } 
/*      */     
/*  976 */     if (this.abilities.isFlying && isCurrentViewEntity()) {
/*      */       
/*  978 */       int j = 0;
/*      */       
/*  980 */       if (this.movementInput.sneaking)
/*      */       {
/*  982 */         j--;
/*      */       }
/*      */       
/*  985 */       if (this.movementInput.jump)
/*      */       {
/*  987 */         j++;
/*      */       }
/*      */       
/*  990 */       if (j != 0)
/*      */       {
/*  992 */         setMotion(getMotion().add(0.0D, (j * this.abilities.getFlySpeed() * 3.0F), 0.0D));
/*      */       }
/*      */     } 
/*      */     
/*  996 */     if (isRidingHorse()) {
/*      */       
/*  998 */       IJumpingMount ijumpingmount = (IJumpingMount)getRidingEntity();
/*      */       
/* 1000 */       if (this.horseJumpPowerCounter < 0) {
/*      */         
/* 1002 */         this.horseJumpPowerCounter++;
/*      */         
/* 1004 */         if (this.horseJumpPowerCounter == 0)
/*      */         {
/* 1006 */           this.horseJumpPower = 0.0F;
/*      */         }
/*      */       } 
/*      */       
/* 1010 */       if (flag && !this.movementInput.jump) {
/*      */         
/* 1012 */         this.horseJumpPowerCounter = -10;
/* 1013 */         ijumpingmount.setJumpPower(MathHelper.floor(getHorseJumpPower() * 100.0F));
/* 1014 */         sendHorseJump();
/*      */       }
/* 1016 */       else if (!flag && this.movementInput.jump) {
/*      */         
/* 1018 */         this.horseJumpPowerCounter = 0;
/* 1019 */         this.horseJumpPower = 0.0F;
/*      */       }
/* 1021 */       else if (flag) {
/*      */         
/* 1023 */         this.horseJumpPowerCounter++;
/*      */         
/* 1025 */         if (this.horseJumpPowerCounter < 10)
/*      */         {
/* 1027 */           this.horseJumpPower = this.horseJumpPowerCounter * 0.1F;
/*      */         }
/*      */         else
/*      */         {
/* 1031 */           this.horseJumpPower = 0.8F + 2.0F / (this.horseJumpPowerCounter - 9) * 0.1F;
/*      */         }
/*      */       
/*      */       } 
/*      */     } else {
/*      */       
/* 1037 */       this.horseJumpPower = 0.0F;
/*      */     } 
/*      */     
/* 1040 */     super.livingTick();
/*      */     
/* 1042 */     if (this.onGround && this.abilities.isFlying && !this.mc.playerController.isSpectatorMode()) {
/*      */       
/* 1044 */       this.abilities.isFlying = false;
/* 1045 */       sendPlayerAbilities();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void handlePortalTeleportation() {
/* 1051 */     this.prevTimeInPortal = this.timeInPortal;
/*      */     
/* 1053 */     if (this.inPortal) {
/*      */       
/* 1055 */       if (this.mc.currentScreen != null && !this.mc.currentScreen.isPauseScreen()) {
/*      */         
/* 1057 */         if (this.mc.currentScreen instanceof net.minecraft.client.gui.screen.inventory.ContainerScreen)
/*      */         {
/* 1059 */           closeScreen();
/*      */         }
/*      */         
/* 1062 */         this.mc.displayGuiScreen((Screen)null);
/*      */       } 
/*      */       
/* 1065 */       if (this.timeInPortal == 0.0F)
/*      */       {
/* 1067 */         this.mc.getSoundHandler().play((ISound)SimpleSound.ambientWithoutAttenuation(SoundEvents.BLOCK_PORTAL_TRIGGER, this.rand.nextFloat() * 0.4F + 0.8F, 0.25F));
/*      */       }
/*      */       
/* 1070 */       this.timeInPortal += 0.0125F;
/*      */       
/* 1072 */       if (this.timeInPortal >= 1.0F)
/*      */       {
/* 1074 */         this.timeInPortal = 1.0F;
/*      */       }
/*      */       
/* 1077 */       this.inPortal = false;
/*      */     }
/* 1079 */     else if (isPotionActive(Effects.NAUSEA) && getActivePotionEffect(Effects.NAUSEA).getDuration() > 60) {
/*      */       
/* 1081 */       this.timeInPortal += 0.006666667F;
/*      */       
/* 1083 */       if (this.timeInPortal > 1.0F)
/*      */       {
/* 1085 */         this.timeInPortal = 1.0F;
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/* 1090 */       if (this.timeInPortal > 0.0F)
/*      */       {
/* 1092 */         this.timeInPortal -= 0.05F;
/*      */       }
/*      */       
/* 1095 */       if (this.timeInPortal < 0.0F)
/*      */       {
/* 1097 */         this.timeInPortal = 0.0F;
/*      */       }
/*      */     } 
/*      */     
/* 1101 */     decrementTimeUntilPortal();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateRidden() {
/* 1109 */     super.updateRidden();
/* 1110 */     this.rowingBoat = false;
/*      */     
/* 1112 */     if (getRidingEntity() instanceof BoatEntity) {
/*      */       
/* 1114 */       BoatEntity boatentity = (BoatEntity)getRidingEntity();
/* 1115 */       boatentity.updateInputs(this.movementInput.leftKeyDown, this.movementInput.rightKeyDown, this.movementInput.forwardKeyDown, this.movementInput.backKeyDown);
/* 1116 */       this.rowingBoat |= (this.movementInput.leftKeyDown || this.movementInput.rightKeyDown || this.movementInput.forwardKeyDown || this.movementInput.backKeyDown) ? 1 : 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isRowingBoat() {
/* 1122 */     return this.rowingBoat;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public EffectInstance removeActivePotionEffect(@Nullable Effect potioneffectin) {
/* 1133 */     if (potioneffectin == Effects.NAUSEA) {
/*      */       
/* 1135 */       this.prevTimeInPortal = 0.0F;
/* 1136 */       this.timeInPortal = 0.0F;
/*      */     } 
/*      */     
/* 1139 */     return super.removeActivePotionEffect(potioneffectin);
/*      */   }
/*      */ 
/*      */   
/*      */   public void move(MoverType typeIn, Vector3d pos) {
/* 1144 */     double d0 = getPosX();
/* 1145 */     double d1 = getPosZ();
/* 1146 */     super.move(typeIn, pos);
/*      */     
/* 1148 */     updateAutoJump((float)(getPosX() - d0), (float)(getPosZ() - d1));
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isAutoJumpEnabled() {
/* 1153 */     return this.autoJumpEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void updateAutoJump(float movementX, float movementZ) {
/* 1158 */     if (canAutoJump()) {
/*      */       
/* 1160 */       Vector3d vector3d = getPositionVec();
/* 1161 */       Vector3d vector3d1 = vector3d.add(movementX, 0.0D, movementZ);
/* 1162 */       Vector3d vector3d2 = new Vector3d(movementX, 0.0D, movementZ);
/* 1163 */       float f = getAIMoveSpeed();
/* 1164 */       float f1 = (float)vector3d2.lengthSquared();
/*      */       
/* 1166 */       if (f1 <= 0.001F) {
/*      */         
/* 1168 */         Vector2f vector2f = this.movementInput.getMoveVector();
/* 1169 */         float f2 = f * vector2f.x;
/* 1170 */         float f3 = f * vector2f.y;
/* 1171 */         float f4 = MathHelper.sin(this.rotationYaw * 0.017453292F);
/* 1172 */         float f5 = MathHelper.cos(this.rotationYaw * 0.017453292F);
/* 1173 */         vector3d2 = new Vector3d((f2 * f5 - f3 * f4), vector3d2.y, (f3 * f5 + f2 * f4));
/* 1174 */         f1 = (float)vector3d2.lengthSquared();
/*      */         
/* 1176 */         if (f1 <= 0.001F) {
/*      */           return;
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 1182 */       float f12 = MathHelper.fastInvSqrt(f1);
/* 1183 */       Vector3d vector3d12 = vector3d2.scale(f12);
/* 1184 */       Vector3d vector3d13 = getForward();
/* 1185 */       float f13 = (float)(vector3d13.x * vector3d12.x + vector3d13.z * vector3d12.z);
/*      */       
/* 1187 */       if (f13 >= -0.15F) {
/*      */         
/* 1189 */         ISelectionContext iselectioncontext = ISelectionContext.forEntity((Entity)this);
/* 1190 */         BlockPos blockpos = new BlockPos(getPosX(), (getBoundingBox()).maxY, getPosZ());
/* 1191 */         BlockState blockstate = this.world.getBlockState(blockpos);
/*      */         
/* 1193 */         if (blockstate.getCollisionShape((IBlockReader)this.world, blockpos, iselectioncontext).isEmpty()) {
/*      */           
/* 1195 */           blockpos = blockpos.up();
/* 1196 */           BlockState blockstate1 = this.world.getBlockState(blockpos);
/*      */           
/* 1198 */           if (blockstate1.getCollisionShape((IBlockReader)this.world, blockpos, iselectioncontext).isEmpty()) {
/*      */             
/* 1200 */             float f6 = 7.0F;
/* 1201 */             float f7 = 1.2F;
/*      */             
/* 1203 */             if (isPotionActive(Effects.JUMP_BOOST))
/*      */             {
/* 1205 */               f7 += (getActivePotionEffect(Effects.JUMP_BOOST).getAmplifier() + 1) * 0.75F;
/*      */             }
/*      */             
/* 1208 */             float f8 = Math.max(f * 7.0F, 1.0F / f12);
/* 1209 */             Vector3d vector3d4 = vector3d1.add(vector3d12.scale(f8));
/* 1210 */             float f9 = getWidth();
/* 1211 */             float f10 = getHeight();
/* 1212 */             AxisAlignedBB axisalignedbb = (new AxisAlignedBB(vector3d, vector3d4.add(0.0D, f10, 0.0D))).grow(f9, 0.0D, f9);
/* 1213 */             Vector3d lvt_19_1_ = vector3d.add(0.0D, 0.5099999904632568D, 0.0D);
/* 1214 */             vector3d4 = vector3d4.add(0.0D, 0.5099999904632568D, 0.0D);
/* 1215 */             Vector3d vector3d5 = vector3d12.crossProduct(new Vector3d(0.0D, 1.0D, 0.0D));
/* 1216 */             Vector3d vector3d6 = vector3d5.scale((f9 * 0.5F));
/* 1217 */             Vector3d vector3d7 = lvt_19_1_.subtract(vector3d6);
/* 1218 */             Vector3d vector3d8 = vector3d4.subtract(vector3d6);
/* 1219 */             Vector3d vector3d9 = lvt_19_1_.add(vector3d6);
/* 1220 */             Vector3d vector3d10 = vector3d4.add(vector3d6);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1227 */             Iterator<AxisAlignedBB> iterator = this.world.func_234867_d_((Entity)this, axisalignedbb, entity -> true).flatMap(shape -> shape.toBoundingBoxList().stream()).iterator();
/* 1228 */             float f11 = Float.MIN_VALUE;
/*      */             
/* 1230 */             while (iterator.hasNext()) {
/*      */               
/* 1232 */               AxisAlignedBB axisalignedbb1 = iterator.next();
/*      */               
/* 1234 */               if (axisalignedbb1.intersects(vector3d7, vector3d8) || axisalignedbb1.intersects(vector3d9, vector3d10)) {
/*      */                 
/* 1236 */                 f11 = (float)axisalignedbb1.maxY;
/* 1237 */                 Vector3d vector3d11 = axisalignedbb1.getCenter();
/* 1238 */                 BlockPos blockpos1 = new BlockPos(vector3d11);
/*      */                 
/* 1240 */                 for (int i = 1; i < f7; i++) {
/*      */                   
/* 1242 */                   BlockPos blockpos2 = blockpos1.up(i);
/* 1243 */                   BlockState blockstate2 = this.world.getBlockState(blockpos2);
/*      */                   
/*      */                   VoxelShape voxelshape;
/* 1246 */                   if (!(voxelshape = blockstate2.getCollisionShape((IBlockReader)this.world, blockpos2, iselectioncontext)).isEmpty()) {
/*      */                     
/* 1248 */                     f11 = (float)voxelshape.getEnd(Direction.Axis.Y) + blockpos2.getY();
/*      */                     
/* 1250 */                     if (f11 - getPosY() > f7) {
/*      */                       return;
/*      */                     }
/*      */                   } 
/*      */ 
/*      */                   
/* 1256 */                   if (i > 1) {
/*      */                     
/* 1258 */                     blockpos = blockpos.up();
/* 1259 */                     BlockState blockstate3 = this.world.getBlockState(blockpos);
/*      */                     
/* 1261 */                     if (!blockstate3.getCollisionShape((IBlockReader)this.world, blockpos, iselectioncontext).isEmpty()) {
/*      */                       return;
/*      */                     }
/*      */                   } 
/*      */                 } 
/*      */ 
/*      */                 
/*      */                 break;
/*      */               } 
/*      */             } 
/*      */             
/* 1272 */             if (f11 != Float.MIN_VALUE) {
/*      */               
/* 1274 */               float f14 = (float)(f11 - getPosY());
/*      */               
/* 1276 */               if (f14 > 0.5F && f14 <= f7)
/*      */               {
/* 1278 */                 this.autoJumpTime = 1;
/*      */               }
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean canAutoJump() {
/* 1289 */     return (isAutoJumpEnabled() && this.autoJumpTime <= 0 && this.onGround && !isSneaking() && !isPassenger() && Move.isMoving() && getJumpFactor() >= 1.0D);
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean isUsingSwimmingAnimation() {
/* 1294 */     double d0 = 0.8D;
/* 1295 */     return canSwim() ? this.movementInput.isMovingForward() : ((this.movementInput.moveForward >= 0.8D));
/*      */   }
/*      */ 
/*      */   
/*      */   public float getWaterBrightness() {
/* 1300 */     if (!areEyesInFluid((ITag)FluidTags.WATER))
/*      */     {
/* 1302 */       return 0.0F;
/*      */     }
/*      */ 
/*      */     
/* 1306 */     float f = 600.0F;
/* 1307 */     float f1 = 100.0F;
/*      */     
/* 1309 */     if (this.counterInWater >= 600.0F)
/*      */     {
/* 1311 */       return 1.0F;
/*      */     }
/*      */ 
/*      */     
/* 1315 */     float f2 = MathHelper.clamp(this.counterInWater / 100.0F, 0.0F, 1.0F);
/* 1316 */     float f3 = (this.counterInWater < 100.0F) ? 0.0F : MathHelper.clamp((this.counterInWater - 100.0F) / 500.0F, 0.0F, 1.0F);
/* 1317 */     return f2 * 0.6F + f3 * 0.39999998F;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canSwim() {
/* 1324 */     return this.eyesInWaterPlayer;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean updateEyesInWaterPlayer() {
/* 1329 */     boolean flag = this.eyesInWaterPlayer;
/* 1330 */     boolean flag1 = super.updateEyesInWaterPlayer();
/*      */     
/* 1332 */     if (isSpectator())
/*      */     {
/* 1334 */       return this.eyesInWaterPlayer;
/*      */     }
/*      */ 
/*      */     
/* 1338 */     if (!flag && flag1)
/*      */     {
/* 1340 */       this.world.playSound(getPosX(), getPosY(), getPosZ(), SoundEvents.AMBIENT_UNDERWATER_ENTER, SoundCategory.AMBIENT, 1.0F, 1.0F, false);
/*      */     }
/*      */     
/* 1343 */     if (flag && !flag1)
/*      */     {
/* 1345 */       this.world.playSound(getPosX(), getPosY(), getPosZ(), SoundEvents.AMBIENT_UNDERWATER_EXIT, SoundCategory.AMBIENT, 1.0F, 1.0F, false);
/*      */     }
/*      */     
/* 1348 */     return this.eyesInWaterPlayer;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Vector3d getLeashPosition(float partialTicks) {
/* 1354 */     if (this.mc.getGameSettings().getPointOfView().func_243192_a()) {
/*      */       
/* 1356 */       float f = MathHelper.lerp(partialTicks * 0.5F, this.rotationYaw, this.prevRotationYaw) * 0.017453292F;
/* 1357 */       float f1 = MathHelper.lerp(partialTicks * 0.5F, this.rotationPitch, this.prevRotationPitch) * 0.017453292F;
/* 1358 */       double d0 = (getPrimaryHand() == HandSide.RIGHT) ? -1.0D : 1.0D;
/* 1359 */       Vector3d vector3d = new Vector3d(0.39D * d0, -0.6D, 0.3D);
/* 1360 */       return vector3d.rotatePitch(-f1).rotateYaw(-f).add(getEyePosition(partialTicks));
/*      */     } 
/*      */ 
/*      */     
/* 1364 */     return super.getLeashPosition(partialTicks);
/*      */   }
/*      */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\autobuy\bots\player\BotPlayer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */