/*     */ package fun.rockstarity.api.autobuy.logic;
/*     */ 
/*     */ import fun.rockstarity.api.autobuy.AutoBuy;
/*     */ import fun.rockstarity.api.autobuy.logic.interfaces.ILogicHandler;
/*     */ import fun.rockstarity.api.autobuy.logic.items.AutoBuyItem;
/*     */ import fun.rockstarity.api.autobuy.logic.items.MinecraftItem;
/*     */ import fun.rockstarity.api.autobuy.logic.tasks.CheckTask;
/*     */ import fun.rockstarity.api.events.Event;
/*     */ import fun.rockstarity.api.events.list.game.packet.EventReceivePacket;
/*     */ import fun.rockstarity.api.events.list.player.EventMessage;
/*     */ import fun.rockstarity.api.helpers.game.Chat;
/*     */ import fun.rockstarity.api.helpers.game.ItemUtility;
/*     */ import fun.rockstarity.api.helpers.game.Server;
/*     */ import fun.rockstarity.api.helpers.math.TimerUtility;
/*     */ import fun.rockstarity.client.modules.other.AutoBuy;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.minecraft.client.gui.screen.inventory.ChestScreen;
/*     */ import net.minecraft.enchantment.Enchantment;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.inventory.container.ClickType;
/*     */ import net.minecraft.inventory.container.Slot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.IPacket;
/*     */ import net.minecraft.network.play.client.CClickWindowPacket;
/*     */ import net.minecraft.network.play.client.CHeldItemChangePacket;
/*     */ import net.minecraft.network.play.server.SChatPacket;
/*     */ import net.minecraft.util.text.TextFormatting;
/*     */ import net.minecraft.world.Difficulty;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlayerLogic
/*     */   implements ILogicHandler
/*     */ {
/*     */   private String ah;
/*     */   private final AutoBuy autoBuy;
/*  50 */   private final TimerUtility openAucTimer = new TimerUtility();
/*  51 */   private final TimerUtility resetTimer = new TimerUtility();
/*  52 */   private final TimerUtility antiAfkTimer = new TimerUtility();
/*  53 */   private final TimerUtility updateTimer = new TimerUtility();
/*     */   
/*  55 */   private final List<AutoBuyItem> toSell = new ArrayList<>();
/*  56 */   private final TimerUtility buyTimer = new TimerUtility();
/*     */   
/*     */   private boolean selling;
/*     */   private boolean refresh;
/*     */   private String lastAn;
/*     */   
/*     */   public PlayerLogic(AutoBuy autoBuy) {
/*  63 */     this.autoBuy = autoBuy;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEvent(Event event) {
/*  68 */     AutoBuy module = (AutoBuy)rock.getModules().get(AutoBuy.class);
/*     */     
/*  70 */     String an1 = module.getAn1().get();
/*  71 */     String an2 = module.getAn2().get();
/*     */     
/*  73 */     if (rock.getBotsHandler().getBots().isEmpty() || module
/*  74 */       .getParser().get())
/*     */       return; 
/*  76 */     if (event instanceof fun.rockstarity.api.events.list.player.EventUpdate) {
/*  77 */       if (mc.world.getDifficulty() == Difficulty.EASY && 
/*  78 */         this.openAucTimer.passed(2500L)) {
/*  79 */         mc.player.sendChatMessage("/an" + Server.FT_ANARCHY);
/*  80 */         this.openAucTimer.reset();
/*     */       } 
/*     */ 
/*     */       
/*  84 */       if (this.selling && this.buyTimer.passed(300L)) {
/*  85 */         for (int i = 0; i < 44; i++) {
/*  86 */           ItemStack stack = mc.player.inventory.getStackInSlot(i);
/*  87 */           for (AutoBuyItem item : rock.getAutoBuy().getItems()) {
/*  88 */             label129: for (MinecraftItem item1 : item.getItems()) {
/*  89 */               if (stack.getItem() == item1.getItem()) {
/*     */ 
/*     */                 
/*  92 */                 if (item.getEnchants().entrySet().isEmpty()) {
/*  93 */                   mc.player.closeScreen();
/*  94 */                   if (i < 9) {
/*  95 */                     mc.player.connection.sendPacket((IPacket)new CHeldItemChangePacket(i));
/*  96 */                     mc.player.inventory.currentItem = i;
/*     */                   } else {
/*  98 */                     mc.playerController.pickItem(i);
/*     */                   } 
/* 100 */                   mc.player.sendChatMessage("/ah sell " + item.getSellPrice());
/* 101 */                   this.resetTimer.reset();
/* 102 */                   this.openAucTimer.reset();
/*     */                   
/*     */                   break;
/*     */                 } 
/* 106 */                 for (Map.Entry<String, Integer> set : (Iterable<Map.Entry<String, Integer>>)item.getEnchants().entrySet()) {
/* 107 */                   int enchantmentId = Integer.parseInt(((String)set.getKey()).replace(String.valueOf(set.getValue()), ""));
/* 108 */                   Enchantment enchantment = Enchantment.getEnchantmentByID(enchantmentId);
/* 109 */                   if (enchantment != null && 
/* 110 */                     EnchantmentHelper.getEnchantmentLevel(enchantment, stack) >= ((Integer)set.getValue()).intValue() && 
/* 111 */                     Enchantment.getEnchantmentByID(Integer.parseInt(((String)set.getKey()).replace(String.valueOf(set.getValue()), ""))) == enchantment) {
/* 112 */                     mc.player.closeScreen();
/* 113 */                     if (i < 9) {
/* 114 */                       mc.player.connection.sendPacket((IPacket)new CHeldItemChangePacket(i));
/* 115 */                       mc.player.inventory.currentItem = i; continue label129;
/*     */                     } 
/* 117 */                     mc.playerController.pickItem(i);
/*     */                     
/* 119 */                     mc.player.sendChatMessage("/ah sell " + item.getSellPrice());
/* 120 */                     this.resetTimer.reset();
/* 121 */                     this.openAucTimer.reset();
/*     */                   } 
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 132 */         this.selling = false;
/*     */       } 
/*     */       
/* 135 */       if (mc.player.openContainer instanceof net.minecraft.inventory.container.ChestContainer) {
/* 136 */         ChestScreen chest = (ChestScreen)mc.currentScreen;
/* 137 */         String chestName = chest.getTitle().getString();
/*     */         
/* 139 */         if (chestName.contains("Аукционы") || chestName.contains("Поиск")) {
/* 140 */           if (this.refresh) {
/* 141 */             mc.player.connection.sendPacket((IPacket)new CClickWindowPacket(mc.player.openContainer.windowId, 46, 0, ClickType.SWAP, mc.player.openContainer.getSlot(46).getStack(), mc.player.openContainer.getNextTransactionID(mc.player.inventory)));
/* 142 */             this.refresh = false;
/*     */           } 
/*     */           
/* 145 */           if (this.updateTimer
/* 146 */             .passed(module.getSpeed().get()) && !this.autoBuy.getTaskManager().haveTasks() && !this.selling) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 153 */             this.updateTimer.reset();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 160 */             mc.player.connection.sendPacket((IPacket)new CClickWindowPacket(mc.player.openContainer.windowId, 49, 0, ClickType.SWAP, mc.player.openContainer.getSlot(49).getStack(), mc.player.openContainer.getNextTransactionID(mc.player.inventory)));
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 166 */           for (Slot s : mc.player.openContainer.inventorySlots) {
/* 167 */             ItemStack stack = s.getStack();
/* 168 */             String displayName = stack.getDisplayName().getString().toLowerCase();
/*     */             
/* 170 */             if (canBuy(stack)) {
/* 171 */               String name = stack.getDisplayName().getString();
/* 172 */               int price = ItemUtility.getPrice(stack);
/* 173 */               String seller = ItemUtility.getSeller(stack);
/*     */               
/* 175 */               for (CheckTask task : this.autoBuy.getTaskManager()) {
/* 176 */                 if (task.getSeller().equals(seller) && task
/* 177 */                   .getName().equals(name) && task
/* 178 */                   .getPrice() == price)
/*     */                   return; 
/* 180 */               }  for (CheckTask task : this.autoBuy.getTaskManager().getBlackList()) {
/* 181 */                 if (task.getSeller().equals(seller) && task
/* 182 */                   .getName().equals(name) && task
/* 183 */                   .getPrice() == price)
/*     */                   return; 
/* 185 */               }  Chat.debug(String.valueOf(TextFormatting.GRAY) + "Отправляю предмет " + String.valueOf(TextFormatting.GRAY) + " за " + name + " на проверку");
/*     */               
/* 187 */               this.resetTimer.reset();
/*     */               
/* 189 */               this.autoBuy.getTaskManager().createTask(seller, name, price, () -> buy(seller, name, price, s));
/*     */             }
/*     */           
/*     */           }
/*     */         
/* 194 */         } else if (chestName.contains("Хранилище")) {
/* 195 */           mc.player.connection.sendPacket((IPacket)new CClickWindowPacket(mc.player.openContainer.windowId, 52, 0, ClickType.SWAP, mc.player.openContainer.getSlot(52).getStack(), mc.player.openContainer.getNextTransactionID(mc.player.inventory)));
/* 196 */           mc.player.closeScreen();
/*     */         } else {
/* 198 */           this.updateTimer.reset();
/*     */         }
/*     */       
/* 201 */       } else if (this.openAucTimer.passed(2500L) && this.ah != null) {
/* 202 */         mc.player.sendChatMessage(this.ah);
/* 203 */         this.resetTimer.reset();
/* 204 */         this.openAucTimer.reset();
/*     */       } 
/*     */ 
/*     */       
/* 208 */       if (this.antiAfkTimer.passed(2500L) && !rock.getBotsHandler().getBots().isEmpty())
/*     */       {
/* 210 */         this.antiAfkTimer.reset();
/*     */       }
/*     */     } 
/*     */     
/* 214 */     if (event instanceof EventReceivePacket) { EventReceivePacket e = (EventReceivePacket)event; IPacket iPacket = e.getPacket(); if (iPacket instanceof SChatPacket) { SChatPacket packet = (SChatPacket)iPacket;
/* 215 */         String message = packet.getChatComponent().getString().toLowerCase();
/*     */         
/* 217 */         if (message.contains("успешно купили")) {
/* 218 */           this.selling = true;
/* 219 */           this.buyTimer.reset();
/*     */         } 
/*     */         
/* 222 */         if (message.contains("освободите хранилище")) {
/* 223 */           mc.player.sendChatMessage(this.ah);
/* 224 */           this.refresh = true;
/*     */         }  }
/*     */        }
/*     */     
/* 228 */     if (event instanceof EventReceivePacket) { EventReceivePacket e = (EventReceivePacket)event;
/* 229 */       if (e.getPacket() instanceof net.minecraft.network.play.server.SOpenWindowPacket && !this.autoBuy.getTaskManager().haveTasks() && module.getSwapAn().get()) {
/* 230 */         if (this.resetTimer.passed(module.getAcSpeed().get())) {
/* 231 */           Chat.msg("Слишком медленное обновление аукциона, перезапускаюсь");
/* 232 */           if (this.lastAn == null || this.lastAn.equals(an1)) {
/* 233 */             mc.player.sendChatMessage(an2);
/* 234 */             this.lastAn = an2;
/*     */           } else {
/* 236 */             mc.player.sendChatMessage(an1);
/* 237 */             this.lastAn = an1;
/*     */           } 
/*     */           
/* 240 */           this.openAucTimer.reset();
/*     */         } 
/* 242 */         this.resetTimer.reset();
/*     */       }  }
/*     */ 
/*     */     
/* 246 */     if (event instanceof EventMessage) { EventMessage e = (EventMessage)event;
/* 247 */       if (e.getMessage().toLowerCase().startsWith("/ah") && !e.getMessage().toLowerCase().contains("sell")) {
/* 248 */         this.ah = e.getMessage();
/* 249 */         this.resetTimer.reset();
/* 250 */         this.openAucTimer.reset();
/*     */       }  }
/*     */ 
/*     */     
/* 254 */     if (event instanceof EventReceivePacket) { EventReceivePacket e = (EventReceivePacket)event; if (this.ah == null || 
/* 255 */         !(e.getPacket() instanceof net.minecraft.network.play.server.SOpenWindowPacket) || this.autoBuy.getTaskManager().haveTasks() || this.resetTimer.passed(5000L)); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void buy(String seller, String name, int price, Slot s) {
/* 264 */     if (!canBuy(mc.player.openContainer.getSlot(s.slotNumber).getStack())) {
/* 265 */       Chat.debug(String.valueOf(TextFormatting.RED) + "Обнаружена фейк информация у " + String.valueOf(TextFormatting.RED) + "." + name + " Реал: " + String.valueOf(TextFormatting.GREEN) + "." + ItemUtility.getPrice(mc.player.openContainer.getSlot(s.slotNumber).getStack()) + " Фейк: " + String.valueOf(TextFormatting.RED));
/*     */       
/*     */       return;
/*     */     } 
/* 269 */     this.resetTimer.reset();
/*     */     
/* 271 */     Chat.debug(String.valueOf(TextFormatting.GREEN) + "Подтвержден предмет " + String.valueOf(TextFormatting.GREEN) + " за " + name + ", покупаю");
/* 272 */     mc.player.connection.sendPacket((IPacket)new CClickWindowPacket(mc.player.openContainer.windowId, s.slotNumber, 0, ClickType.QUICK_MOVE, mc.player.openContainer.getSlot(s.slotNumber).getStack(), mc.player.openContainer.getNextTransactionID(mc.player.inventory)));
/*     */   }
/*     */   
/*     */   private boolean canBuy(ItemStack stack) {
/* 276 */     for (AutoBuyItem item : rock.getAutoBuy().getItems()) {
/* 277 */       for (MinecraftItem item1 : item.getItems()) {
/* 278 */         if (stack.getItem() == item1.getItem() && 
/* 279 */           ItemUtility.getPrice(stack) / stack.getCount() <= item.getMaxPrice() && stack
/* 280 */           .getCount() >= item.getMinCount() && ItemUtility.getPrice(stack) > 0 && this.openAucTimer
/* 281 */           .passed(1000L)) {
/*     */ 
/*     */           
/* 284 */           if (item.getEnchants().entrySet().isEmpty()) {
/* 285 */             return true;
/*     */           }
/*     */           
/* 288 */           for (Map.Entry<String, Integer> set : (Iterable<Map.Entry<String, Integer>>)item.getEnchants().entrySet()) {
/* 289 */             int enchantmentId = Integer.parseInt(((String)set.getKey()).replace(String.valueOf(set.getValue()), ""));
/* 290 */             Enchantment enchantment = Enchantment.getEnchantmentByID(enchantmentId);
/* 291 */             if (enchantment != null && 
/* 292 */               EnchantmentHelper.getEnchantmentLevel(enchantment, stack) >= ((Integer)set.getValue()).intValue() && 
/* 293 */               Enchantment.getEnchantmentByID(Integer.parseInt(((String)set.getKey()).replace(String.valueOf(set.getValue()), ""))) == enchantment) {
/* 294 */               return true;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 303 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\autobuy\logic\PlayerLogic.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */