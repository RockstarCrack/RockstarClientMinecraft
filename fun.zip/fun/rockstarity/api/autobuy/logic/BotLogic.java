/*     */ package fun.rockstarity.api.autobuy.logic;
/*     */ 
/*     */ import fun.rockstarity.api.autobuy.AutoBuy;
/*     */ import fun.rockstarity.api.autobuy.bots.Bot;
/*     */ import fun.rockstarity.api.autobuy.bots.player.BotController;
/*     */ import fun.rockstarity.api.autobuy.bots.player.BotPlayer;
/*     */ import fun.rockstarity.api.autobuy.bots.world.BotWorld;
/*     */ import fun.rockstarity.api.autobuy.logic.interfaces.ILogicHandler;
/*     */ import fun.rockstarity.api.autobuy.logic.tasks.CheckTask;
/*     */ import fun.rockstarity.api.events.Event;
/*     */ import fun.rockstarity.api.helpers.game.Chat;
/*     */ import fun.rockstarity.api.helpers.game.ItemUtility;
/*     */ import fun.rockstarity.api.helpers.game.Server;
/*     */ import fun.rockstarity.api.helpers.math.TimerUtility;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.gui.screen.inventory.ChestScreen;
/*     */ import net.minecraft.client.util.ITooltipFlag;
/*     */ import net.minecraft.inventory.container.ChestContainer;
/*     */ import net.minecraft.inventory.container.Slot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TextFormatting;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BotLogic
/*     */   implements ILogicHandler
/*     */ {
/*  46 */   final TimerUtility openAuctionTimer = new TimerUtility();
/*     */   private CheckTask active;
/*     */   private final AutoBuy autoBuy;
/*     */   
/*     */   public BotLogic(AutoBuy autoBuy) {
/*  51 */     this.autoBuy = autoBuy;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEvent(Event event) {
/*  56 */     if (event instanceof fun.rockstarity.api.events.list.player.EventUpdate) {
/*     */       try {
/*  58 */         int i1 = 0;
/*  59 */         for (Bot bot : rock.getBotsHandler().getBots()) {
/*  60 */           BotPlayer player = bot.getPlayer();
/*  61 */           BotController controller = bot.getController();
/*  62 */           BotWorld world = bot.getWorld();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  73 */           if (player.getAntiAfkTimer().passed(10000L)) {
/*  74 */             Chat.bot(player.getNameClear(), String.valueOf(TextFormatting.GRAY) + "Смотрю баланс..");
/*  75 */             player.sendChatMessage("/bal");
/*  76 */             player.sendChatMessage("/an" + Server.FT_ANARCHY);
/*  77 */             player.getAntiAfkTimer().reset();
/*     */           } 
/*     */           
/*  80 */           if (Math.abs(player.getPosX()) < 1.0D) {
/*     */             continue;
/*     */           }
/*  83 */           handleOpenAuction(player);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  89 */           if (player.openContainer instanceof ChestContainer) {
/*  90 */             ChestScreen chest = (ChestScreen)player.currentScreen;
/*  91 */             ChestContainer container = (ChestContainer)chest.getContainer();
/*  92 */             String chestName = chest.getTitle().getString();
/*     */             
/*  94 */             if (player.openContainer == null) {
/*     */               return;
/*     */             }
/*  97 */             if (chestName.contains("Аукционы (")) {
/*  98 */               for (Slot s : player.openContainer.inventorySlots) {
/*  99 */                 if (s.slotNumber == 0);
/*     */ 
/*     */                 
/* 102 */                 ItemStack stack = s.getStack();
/* 103 */                 List<ITextComponent> itemTooltip = stack.getTooltip(null, (ITooltipFlag)ITooltipFlag.TooltipFlags.NORMAL);
/* 104 */                 String displayName = stack.getDisplayName().getString().toLowerCase();
/*     */                 
/* 106 */                 String seller = ItemUtility.getSeller(stack);
/*     */                 
/* 108 */                 if (this.active != null && this.active.check(stack)) {
/* 109 */                   this.active.getOnSuccess().run();
/* 110 */                   this.autoBuy.getTaskManager().remove(this.active);
/* 111 */                   this.active = null;
/* 112 */                   player.closeScreen();
/*     */                 } 
/*     */                 
/* 115 */                 if (s.slotNumber == 49 && !player.openContainer.getSlot(s.slotNumber).getStack().isEmpty() && 
/* 116 */                   this.active != null) {
/* 117 */                   Chat.bot(player.getNameClear(), String.valueOf(TextFormatting.RED) + "Предмет " + String.valueOf(TextFormatting.RED) + " за " + this.active.getName() + " по всей видимости фейк. Удаляю задачу");
/* 118 */                   if (this.active.getOnFake() != null)
/* 119 */                     this.active.getOnFake().run(); 
/* 120 */                   this.autoBuy.getTaskManager().getBlackList().add(this.active);
/* 121 */                   this.autoBuy.getTaskManager().remove(this.active);
/* 122 */                   this.active = null;
/* 123 */                   player.closeScreen();
/* 124 */                   this.openAuctionTimer.reset();
/*     */                 } 
/*     */               } 
/*     */             }
/*     */           } 
/*     */ 
/*     */           
/* 131 */           if (this.openAuctionTimer.passed(100L) && 
/* 132 */             this.active != null) {
/* 133 */             Chat.bot(player.getNameClear(), String.valueOf(TextFormatting.GOLD) + "Предмет " + String.valueOf(TextFormatting.GOLD) + " за " + this.active.getName() + " по всей видимости фейк. Удаляю задачу");
/* 134 */             if (this.active.getOnFake() != null)
/* 135 */               this.active.getOnFake().run(); 
/* 136 */             this.autoBuy.getTaskManager().getBlackList().add(this.active);
/* 137 */             this.autoBuy.getTaskManager().remove(this.active);
/* 138 */             this.active = null;
/* 139 */             player.closeScreen();
/* 140 */             this.openAuctionTimer.reset();
/*     */           }
/*     */         
/*     */         } 
/* 144 */       } catch (Exception e) {
/* 145 */         e.printStackTrace();
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private void handleOpenAuction(BotPlayer player) {
/* 151 */     if (!this.autoBuy.getTaskManager().haveTasks() || !this.openAuctionTimer.passed(1000L) || this.active != null)
/*     */       return; 
/* 153 */     CheckTask task = this.autoBuy.getTaskManager().getNearestTask();
/*     */     
/* 155 */     Chat.bot(player.getNameClear(), String.valueOf(TextFormatting.YELLOW) + "Беру задачу на " + String.valueOf(TextFormatting.YELLOW) + " за " + task.getName());
/*     */     
/* 157 */     player.sendChatMessage("/ah " + task.getSeller());
/*     */     
/* 159 */     this.active = task;
/*     */     
/* 161 */     this.openAuctionTimer.reset();
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\autobuy\logic\BotLogic.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */