/*    */ package fun.rockstarity.api.autobuy.logic.items;
/*    */ 
/*    */ import net.minecraft.enchantment.Enchantment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AutoBuyEnchantment
/*    */ {
/*    */   private Enchantment enchantment;
/*    */   private int lvl;
/*    */   
/*    */   public void setEnchantment(Enchantment enchantment) {
/* 14 */     this.enchantment = enchantment; } public void setLvl(int lvl) { this.lvl = lvl; } public AutoBuyEnchantment(Enchantment enchantment, int lvl) {
/* 15 */     this.enchantment = enchantment; this.lvl = lvl;
/*    */   }
/*    */   
/* 18 */   public Enchantment getEnchantment() { return this.enchantment; } public int getLvl() {
/* 19 */     return this.lvl;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\autobuy\logic\items\AutoBuyEnchantment.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */