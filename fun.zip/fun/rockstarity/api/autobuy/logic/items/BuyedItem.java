/*    */ package fun.rockstarity.api.autobuy.logic.items;public class BuyedItem implements IAutoBuyItem { private final String name; private final Item item; private final int price;
/*    */   private final int count;
/*    */   private final boolean enchanted;
/*    */   private final Map<String, Integer> enchants;
/*    */   private final boolean status;
/*    */   private final long time;
/*    */   private final AutoBuyItem autoBuyItem;
/*    */   
/*    */   public String getName() {
/*    */     return this.name;
/*    */   }
/*    */   
/*    */   public Item getItem() {
/*    */     return this.item;
/*    */   }
/*    */   
/*    */   public int getPrice() {
/*    */     return this.price;
/*    */   }
/*    */   
/* 21 */   public BuyedItem(String name, Item item, int price, int count, boolean enchanted, boolean status, long time, AutoBuyItem autoBuyItem) { this.enchants = new HashMap<>(); this.name = name; this.item = item; this.price = price; this.count = count; this.enchanted = enchanted; this.status = status; this.time = time; this.autoBuyItem = autoBuyItem; } public int getCount() { return this.count; } public Map<String, Integer> getEnchants() { return this.enchants; }
/* 22 */   public boolean isEnchanted() { return this.enchanted; } public boolean isStatus() { return this.status; }
/* 23 */   public long getTime() { return this.time; } public AutoBuyItem getAutoBuyItem() {
/* 24 */     return this.autoBuyItem;
/*    */   }
/*    */   public void update(Map<String, Integer> enchants) {
/* 27 */     this.enchants.clear();
/* 28 */     for (Map.Entry<String, Integer> set : enchants.entrySet())
/* 29 */       this.enchants.put(set.getKey(), set.getValue()); 
/*    */   } }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\autobuy\logic\items\BuyedItem.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */