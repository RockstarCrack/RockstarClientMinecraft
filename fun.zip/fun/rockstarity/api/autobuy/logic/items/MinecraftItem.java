/*    */ package fun.rockstarity.api.autobuy.logic.items;
/*    */ 
/*    */ import fun.rockstarity.api.render.animation.Animation;
/*    */ import fun.rockstarity.api.render.animation.Easing;
/*    */ import net.minecraft.item.Item;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MinecraftItem
/*    */ {
/*    */   private final Item item;
/*    */   private final Animation selectAnim;
/*    */   
/*    */   public MinecraftItem(Item item) {
/* 24 */     this.selectAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); this.item = item; } public Animation getSelectAnim() { return this.selectAnim; } public Item getItem() {
/*    */     return this.item;
/*    */   } public String getName() {
/* 27 */     return this.item.getName().getString();
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\autobuy\logic\items\MinecraftItem.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */