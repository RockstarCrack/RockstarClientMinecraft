/*     */ package fun.rockstarity.api.autobuy.logic.items;
/*     */ 
/*     */ import fun.rockstarity.api.autobuy.logic.interfaces.IAutoBuyItem;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.minecraft.item.Item;
/*     */ import org.json.simple.JSONArray;
/*     */ import org.json.simple.JSONObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AutoBuyItem
/*     */   implements IAutoBuyItem
/*     */ {
/*     */   public void setMaxPrice(int maxPrice) {
/*  21 */     this.maxPrice = maxPrice; } public void setMinCount(int minCount) { this.minCount = minCount; } public void setMinDurability(int minDurability) { this.minDurability = minDurability; } public void setSellPrice(int sellPrice) { this.sellPrice = sellPrice; } public void setEnchanted(boolean enchanted) { this.enchanted = enchanted; } public void setParsed(boolean parsed) { this.parsed = parsed; } public void setUpdates(int updates) { this.updates = updates; }
/*     */    public AutoBuyItem(int maxPrice, int minCount, int minDurability, int sellPrice, boolean enchanted, boolean parsed, int updates) {
/*  23 */     this.maxPrice = maxPrice; this.minCount = minCount; this.minDurability = minDurability; this.sellPrice = sellPrice; this.enchanted = enchanted; this.parsed = parsed; this.updates = updates;
/*     */   }
/*     */   private int maxPrice; private int minCount;
/*  26 */   private final ArrayList<MinecraftItem> items = new ArrayList<>(); private int minDurability; public ArrayList<MinecraftItem> getItems() { return this.items; }
/*  27 */   public int getMaxPrice() { return this.maxPrice; }
/*  28 */   public int getMinCount() { return this.minCount; } public int getMinDurability() {
/*  29 */     return this.minDurability;
/*  30 */   } private int sellPrice = 0; private boolean enchanted; public int getSellPrice() { return this.sellPrice; } public boolean isEnchanted() {
/*  31 */     return this.enchanted;
/*  32 */   } private final Map<String, Integer> enchants = new HashMap<>(); private boolean parsed; private int updates; public Map<String, Integer> getEnchants() { return this.enchants; }
/*  33 */   public boolean isParsed() { return this.parsed; } public int getUpdates() {
/*  34 */     return this.updates;
/*     */   }
/*     */   public AutoBuyItem(Item item, int maxPrice, int sellPrice, boolean enchanted) {
/*  37 */     this.items.add(new MinecraftItem(item));
/*  38 */     this.maxPrice = maxPrice;
/*  39 */     this.sellPrice = sellPrice;
/*  40 */     this.enchanted = enchanted;
/*     */   }
/*     */   
/*     */   public MinecraftItem getFirst() {
/*  44 */     return this.items.get(0);
/*     */   }
/*     */   
/*     */   public void update(Map<String, Integer> enchants) {
/*  48 */     this.enchants.clear();
/*  49 */     for (Map.Entry<String, Integer> set : enchants.entrySet()) {
/*  50 */       this.enchants.put(set.getKey(), set.getValue());
/*     */     }
/*     */   }
/*     */   
/*     */   public void updateItems(List<MinecraftItem> items) {
/*  55 */     this.items.clear();
/*  56 */     for (MinecraftItem set : items) {
/*  57 */       this.items.add(set);
/*     */     }
/*     */   }
/*     */   
/*     */   public JSONObject toJson() {
/*  62 */     JSONObject json = new JSONObject();
/*  63 */     json.put("maxPrice", Integer.valueOf(this.maxPrice));
/*  64 */     json.put("minCount", Integer.valueOf(this.minCount));
/*  65 */     json.put("minDurability", Integer.valueOf(this.minDurability));
/*  66 */     json.put("sellPrice", Integer.valueOf(this.sellPrice));
/*  67 */     json.put("enchanted", Boolean.valueOf(this.enchanted));
/*     */     
/*  69 */     JSONArray itemsArray = new JSONArray();
/*  70 */     for (MinecraftItem entry : this.items) {
/*  71 */       JSONObject itemJson = new JSONObject();
/*     */       
/*  73 */       itemJson.put("item", Integer.valueOf(Item.getIdFromItem(entry.getItem())));
/*  74 */       itemsArray.add(itemJson);
/*     */     } 
/*  76 */     json.put("items", itemsArray);
/*     */     
/*  78 */     JSONArray enchantsArray = new JSONArray();
/*  79 */     for (Map.Entry<String, Integer> entry : this.enchants.entrySet()) {
/*  80 */       JSONObject enchantJson = new JSONObject();
/*  81 */       enchantJson.put("id", entry.getKey());
/*  82 */       enchantJson.put("lvl", entry.getValue());
/*  83 */       enchantsArray.add(enchantJson);
/*     */     } 
/*  85 */     json.put("enchants", enchantsArray);
/*     */     
/*  87 */     return json;
/*     */   }
/*     */   
/*     */   public static AutoBuyItem fromJson(JSONObject json) {
/*  91 */     int maxPrice = ((Long)json.get("maxPrice")).intValue();
/*  92 */     int minCount = ((Long)json.get("minCount")).intValue();
/*  93 */     int minDurability = ((Long)json.get("minDurability")).intValue();
/*  94 */     int sellPrice = ((Long)json.get("sellPrice")).intValue();
/*  95 */     boolean enchanted = ((Boolean)json.get("enchanted")).booleanValue();
/*     */     
/*  97 */     ArrayList<MinecraftItem> items = new ArrayList<>();
/*  98 */     JSONArray itemsArray = (JSONArray)json.get("items");
/*  99 */     if (itemsArray != null) {
/* 100 */       for (Object obj : itemsArray) {
/* 101 */         JSONObject itemJson = (JSONObject)obj;
/* 102 */         long id = ((Long)itemJson.get("item")).longValue();
/*     */         
/* 104 */         items.add(new MinecraftItem(Item.getItemById((int)id)));
/*     */       } 
/*     */     }
/*     */     
/* 108 */     Map<String, Integer> enchants = new HashMap<>();
/* 109 */     JSONArray enchantsArray = (JSONArray)json.get("enchants");
/* 110 */     if (enchantsArray != null) {
/* 111 */       for (Object obj : enchantsArray) {
/* 112 */         JSONObject enchantJson = (JSONObject)obj;
/* 113 */         long enchantmentLvl = ((Long)enchantJson.get("lvl")).longValue();
/* 114 */         String enchantName = (String)enchantJson.get("id");
/* 115 */         enchants.put(enchantName, Integer.valueOf((int)enchantmentLvl));
/*     */       } 
/*     */     }
/*     */     
/* 119 */     AutoBuyItem item1 = new AutoBuyItem(maxPrice, minCount, minDurability, sellPrice, enchanted, false, 0);
/* 120 */     item1.update(enchants);
/* 121 */     item1.updateItems(items);
/* 122 */     return item1;
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\autobuy\logic\items\AutoBuyItem.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */