package fun.rockstarity.api.autobuy.logic.interfaces;

import fun.rockstarity.api.IAccess;
import fun.rockstarity.api.events.Event;

public interface ILogicHandler extends IAccess {
  void onEvent(Event paramEvent);
}


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\autobuy\logic\interfaces\ILogicHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */