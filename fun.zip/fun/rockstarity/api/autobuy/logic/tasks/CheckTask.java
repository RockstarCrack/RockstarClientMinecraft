/*    */ package fun.rockstarity.api.autobuy.logic.tasks;
/*    */ 
/*    */ import fun.rockstarity.api.helpers.game.ItemUtility;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CheckTask
/*    */ {
/*    */   private final String seller;
/*    */   private final String name;
/*    */   private final int price;
/*    */   private final Runnable onSuccess;
/*    */   private final Runnable onFake;
/*    */   
/*    */   public CheckTask(String seller, String name, int price, Runnable onSuccess, Runnable onFake) {
/* 20 */     this.seller = seller; this.name = name; this.price = price; this.onSuccess = onSuccess; this.onFake = onFake;
/*    */   }
/*    */   
/* 23 */   public String getSeller() { return this.seller; }
/* 24 */   public String getName() { return this.name; }
/* 25 */   public int getPrice() { return this.price; }
/* 26 */   public Runnable getOnSuccess() { return this.onSuccess; } public Runnable getOnFake() {
/* 27 */     return this.onFake;
/*    */   }
/*    */   public boolean check(ItemStack stack) {
/* 30 */     int price = ItemUtility.getPrice(stack);
/* 31 */     String seller = ItemUtility.getSeller(stack);
/*    */     
/* 33 */     return (this.price == price && this.name
/* 34 */       .equals(stack.getDisplayName().getString()) && this.seller
/* 35 */       .equals(seller));
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\autobuy\logic\tasks\CheckTask.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */