/*    */ package fun.rockstarity.api.autobuy.logic.tasks;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TaskManager
/*    */   extends ArrayList<CheckTask>
/*    */ {
/* 16 */   private final List<CheckTask> blackList = new ArrayList<>(); public List<CheckTask> getBlackList() { return this.blackList; }
/*    */ 
/*    */   
/*    */   public void createTask(String seller, String name, int price, Runnable onSuccess) {
/* 20 */     add(new CheckTask(seller, name, price, onSuccess, () -> {
/*    */           
/*    */           }));
/*    */   } public void createTask(String seller, String name, int price, Runnable onSuccess, Runnable onFake) {
/* 24 */     add(new CheckTask(seller, name, price, onSuccess, onFake));
/*    */   }
/*    */   
/*    */   public boolean haveTasks() {
/* 28 */     return !isEmpty();
/*    */   }
/*    */   
/*    */   public CheckTask getNearestTask() {
/* 32 */     return get(0);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\autobuy\logic\tasks\TaskManager.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */