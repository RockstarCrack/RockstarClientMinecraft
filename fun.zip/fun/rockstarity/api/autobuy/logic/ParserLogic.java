/*     */ package fun.rockstarity.api.autobuy.logic;
/*     */ 
/*     */ import fun.rockstarity.api.autobuy.AutoBuy;
/*     */ import fun.rockstarity.api.autobuy.logic.interfaces.ILogicHandler;
/*     */ import fun.rockstarity.api.autobuy.logic.items.AutoBuyItem;
/*     */ import fun.rockstarity.api.autobuy.logic.items.MinecraftItem;
/*     */ import fun.rockstarity.api.events.Event;
/*     */ import fun.rockstarity.api.helpers.game.Chat;
/*     */ import fun.rockstarity.api.helpers.game.ItemUtility;
/*     */ import fun.rockstarity.api.helpers.game.Server;
/*     */ import fun.rockstarity.api.helpers.math.TimerUtility;
/*     */ import fun.rockstarity.api.render.ui.alerts.AlertType;
/*     */ import fun.rockstarity.client.modules.other.AutoBuy;
/*     */ import java.util.Map;
/*     */ import net.minecraft.client.gui.screen.inventory.ChestScreen;
/*     */ import net.minecraft.enchantment.Enchantment;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.inventory.container.ClickType;
/*     */ import net.minecraft.inventory.container.Slot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.IPacket;
/*     */ import net.minecraft.network.play.client.CClickWindowPacket;
/*     */ import net.minecraft.util.text.TextFormatting;
/*     */ import net.minecraft.world.Difficulty;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParserLogic
/*     */   implements ILogicHandler
/*     */ {
/*     */   private final AutoBuy autoBuy;
/*  39 */   private final TimerUtility openAucTimer = new TimerUtility();
/*     */   private boolean needUpdate;
/*     */   private boolean canCheck;
/*     */   
/*     */   public ParserLogic(AutoBuy autoBuy) {
/*  44 */     this.autoBuy = autoBuy;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEvent(Event event) {
/*  49 */     AutoBuy module = (AutoBuy)rock.getModules().get(AutoBuy.class);
/*     */     
/*  51 */     if (event instanceof fun.rockstarity.api.events.list.player.EventUpdate) {
/*  52 */       if (!module.getParser().get())
/*     */         return; 
/*  54 */       if (mc.world.getDifficulty() == Difficulty.EASY && 
/*  55 */         this.openAucTimer.passed(2500L)) {
/*  56 */         mc.player.sendChatMessage("/an" + Server.FT_ANARCHY);
/*  57 */         this.openAucTimer.reset();
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*  62 */       boolean disable = true;
/*     */       
/*  64 */       for (AutoBuyItem item : rock.getAutoBuy().getItems()) {
/*  65 */         if (!item.isParsed()) {
/*  66 */           disable = false;
/*     */         }
/*     */       } 
/*     */       
/*  70 */       if (disable) {
/*  71 */         module.getParser().set(false);
/*  72 */         rock.getAlertHandler().alert("Анализ цен завершён", AlertType.SUCCESS);
/*     */       } 
/*     */ 
/*     */       
/*  76 */       if (mc.player.openContainer instanceof net.minecraft.inventory.container.ChestContainer) {
/*  77 */         ChestScreen chest = (ChestScreen)mc.currentScreen;
/*  78 */         String chestName = chest.getTitle().getString();
/*     */         
/*  80 */         if (chestName.contains("Поиск")) {
/*  81 */           if (this.needUpdate) {
/*  82 */             mc.player.connection.sendPacket((IPacket)new CClickWindowPacket(mc.player.openContainer.windowId, 49, 0, ClickType.SWAP, mc.player.openContainer.getSlot(49).getStack(), mc.player.openContainer.getNextTransactionID(mc.player.inventory)));
/*  83 */             this.needUpdate = false;
/*     */           } 
/*     */           
/*  86 */           for (Slot s : mc.player.openContainer.inventorySlots) {
/*  87 */             ItemStack stack = s.getStack();
/*  88 */             String displayName = stack.getDisplayName().getString().toLowerCase();
/*     */             
/*  90 */             AutoBuyItem item = getItem(stack);
/*     */             
/*  92 */             if (item != null && this.canCheck) {
/*  93 */               String name = stack.getDisplayName().getString();
/*  94 */               int price = ItemUtility.getPrice(stack);
/*  95 */               String seller = ItemUtility.getSeller(stack);
/*     */               
/*  97 */               Chat.debug(String.valueOf(TextFormatting.GRAY) + "Отправляю предмет " + String.valueOf(TextFormatting.GRAY) + " за " + name + " на проверку");
/*  98 */               this.canCheck = false;
/*     */               
/* 100 */               this.autoBuy.getTaskManager().createTask(seller, name, price, () -> parse(seller, name, price, s), () -> {
/*     */                     stack.fake = true;
/*     */                     
/*     */                     item.setUpdates(item.getUpdates() + 1);
/*     */                     
/*     */                     if (item.getUpdates() > 5) {
/*     */                       item.setUpdates(0);
/*     */                       
/*     */                       this.needUpdate = true;
/*     */                     } 
/*     */                     this.canCheck = true;
/*     */                   });
/*     */             } 
/*     */           } 
/*     */         } else {
/* 115 */           mc.player.closeScreen();
/*     */         }
/*     */       
/* 118 */       } else if (this.openAucTimer.passed(1000L)) {
/* 119 */         for (AutoBuyItem item : rock.getAutoBuy().getItems()) {
/* 120 */           if (item.isParsed())
/*     */             continue; 
/* 122 */           String name = item.getFirst().getName();
/*     */           
/* 124 */           if (name.toLowerCase().contains("шалкер")) {
/* 125 */             name = "Шалкер";
/*     */           }
/* 127 */           mc.player.sendChatMessage("/ah search " + name);
/* 128 */           this.openAucTimer.reset();
/* 129 */           this.canCheck = true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void parse(String seller, String name, int price, Slot s) {
/* 138 */     ItemStack stack = mc.player.openContainer.getSlot(s.slotNumber).getStack();
/* 139 */     AutoBuyItem item = getItem(stack);
/*     */     
/* 141 */     this.canCheck = true;
/*     */     
/* 143 */     if (item == null || price != ItemUtility.getPrice(stack)) {
/* 144 */       Chat.debug(String.valueOf(TextFormatting.RED) + "Обнаружена фейк информация у " + String.valueOf(TextFormatting.RED) + "." + name + " Реал: " + String.valueOf(TextFormatting.GREEN) + "." + ItemUtility.getPrice(mc.player.openContainer.getSlot(s.slotNumber).getStack()) + " Фейк: " + String.valueOf(TextFormatting.RED));
/* 145 */       this.needUpdate = true;
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 151 */     Chat.debug(String.valueOf(TextFormatting.GREEN) + "Подтвержден предмет " + String.valueOf(TextFormatting.GREEN) + " за " + name + ", паршу");
/* 152 */     item.setMaxPrice((int)(price / stack.getCount() * (1.0F - ((AutoBuy)rock.getModules().get(AutoBuy.class)).getParsePercent().get() / 100.0F)));
/* 153 */     item.setSellPrice((int)(price / stack.getCount()));
/*     */ 
/*     */     
/* 156 */     item.setParsed(true);
/* 157 */     mc.player.closeScreen();
/* 158 */     item.setUpdates(0);
/*     */     
/* 160 */     this.needUpdate = true;
/*     */ 
/*     */ 
/*     */     
/* 164 */     rock.getAlertHandler().alert("Для '" + item.getFirst().getName() + "' установлена цена " + item.getMaxPrice() + " $", AlertType.SUCCESS);
/*     */   }
/*     */   
/*     */   private AutoBuyItem getItem(ItemStack stack) {
/* 168 */     for (AutoBuyItem item : rock.getAutoBuy().getItems()) {
/* 169 */       for (MinecraftItem item1 : item.getItems()) {
/* 170 */         if (stack.getItem() == item1.getItem() && ItemUtility.getPrice(stack) > 0 && !item.isParsed()) {
/*     */ 
/*     */           
/* 173 */           if (item.getEnchants().entrySet().isEmpty()) {
/* 174 */             return item;
/*     */           }
/*     */           
/* 177 */           for (Map.Entry<String, Integer> set : (Iterable<Map.Entry<String, Integer>>)item.getEnchants().entrySet()) {
/* 178 */             int enchantmentId = Integer.parseInt(((String)set.getKey()).replace(String.valueOf(set.getValue()), ""));
/* 179 */             Enchantment enchantment = Enchantment.getEnchantmentByID(enchantmentId);
/* 180 */             if (enchantment != null && 
/* 181 */               EnchantmentHelper.getEnchantmentLevel(enchantment, stack) >= ((Integer)set.getValue()).intValue() && 
/* 182 */               Enchantment.getEnchantmentByID(Integer.parseInt(((String)set.getKey()).replace(String.valueOf(set.getValue()), ""))) == enchantment) {
/* 183 */               return item;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 192 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\autobuy\logic\ParserLogic.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */