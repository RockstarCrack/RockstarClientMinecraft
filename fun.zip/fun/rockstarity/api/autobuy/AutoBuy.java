/*    */ package fun.rockstarity.api.autobuy;
/*    */ 
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.autobuy.logic.BotLogic;
/*    */ import fun.rockstarity.api.autobuy.logic.ParserLogic;
/*    */ import fun.rockstarity.api.autobuy.logic.PlayerLogic;
/*    */ import fun.rockstarity.api.autobuy.logic.interfaces.ILogicHandler;
/*    */ import fun.rockstarity.api.autobuy.logic.items.AutoBuyItem;
/*    */ import fun.rockstarity.api.autobuy.logic.tasks.TaskManager;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.helpers.game.Server;
/*    */ import fun.rockstarity.api.helpers.render.AutoBuyWindow;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AutoBuy
/*    */   implements IAccess
/*    */ {
/* 28 */   private final ArrayList<ILogicHandler> handlers = new ArrayList<>();
/* 29 */   private final ArrayList<AutoBuyItem> items = new ArrayList<>(); private final BotLogic botLogicHandler; private final PlayerLogic playerLogicHandler; public ArrayList<AutoBuyItem> getItems() { return this.items; }
/*    */   
/*    */   private final ParserLogic parserLogicHandler; private AutoBuyWindow window; private final TaskManager taskManager;
/*    */   
/*    */   public AutoBuyWindow getWindow() {
/* 34 */     return this.window;
/*    */   } public TaskManager getTaskManager() {
/* 36 */     return this.taskManager;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AutoBuy() {
/* 44 */     Objects.requireNonNull(this.handlers); Arrays.<ILogicHandler>stream(new ILogicHandler[] { (ILogicHandler)(this.botLogicHandler = new BotLogic(this)), (ILogicHandler)(this.playerLogicHandler = new PlayerLogic(this)), (ILogicHandler)(this.parserLogicHandler = new ParserLogic(this)) }).forEach(this.handlers::add);
/*    */     
/* 46 */     this.taskManager = new TaskManager();
/* 47 */     if (rock.isDebugging()) {
/* 48 */       this.window = new AutoBuyWindow(rock.getModules().get(fun.rockstarity.client.modules.other.AutoBuy.class));
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onEvent(Event event) {
/*    */     // Byte code:
/*    */     //   0: getstatic fun/rockstarity/api/autobuy/AutoBuy.rock : Lfun/rockstarity/Rockstar;
/*    */     //   3: invokevirtual getModules : ()Lfun/rockstarity/api/modules/Modules;
/*    */     //   6: ldc fun/rockstarity/client/modules/other/AutoBuy
/*    */     //   8: invokevirtual get : (Ljava/lang/Class;)Lfun/rockstarity/api/modules/Module;
/*    */     //   11: ifnull -> 34
/*    */     //   14: getstatic fun/rockstarity/api/autobuy/AutoBuy.rock : Lfun/rockstarity/Rockstar;
/*    */     //   17: invokevirtual getModules : ()Lfun/rockstarity/api/modules/Modules;
/*    */     //   20: ldc fun/rockstarity/client/modules/other/AutoBuy
/*    */     //   22: invokevirtual get : (Ljava/lang/Class;)Lfun/rockstarity/api/modules/Module;
/*    */     //   25: checkcast fun/rockstarity/client/modules/other/AutoBuy
/*    */     //   28: invokevirtual get : ()Z
/*    */     //   31: ifne -> 35
/*    */     //   34: return
/*    */     //   35: aload_1
/*    */     //   36: instanceof fun/rockstarity/api/events/list/render/EventRender2D
/*    */     //   39: ifeq -> 118
/*    */     //   42: aload_0
/*    */     //   43: getfield window : Lfun/rockstarity/api/helpers/render/AutoBuyWindow;
/*    */     //   46: invokevirtual getOpening : ()Lfun/rockstarity/api/render/animation/Animation;
/*    */     //   49: getstatic fun/rockstarity/api/autobuy/AutoBuy.mc : Lnet/minecraft/client/Minecraft;
/*    */     //   52: getfield currentScreen : Lnet/minecraft/client/gui/screen/Screen;
/*    */     //   55: astore_3
/*    */     //   56: aload_3
/*    */     //   57: instanceof net/minecraft/client/gui/screen/inventory/ContainerScreen
/*    */     //   60: ifeq -> 113
/*    */     //   63: aload_3
/*    */     //   64: checkcast net/minecraft/client/gui/screen/inventory/ContainerScreen
/*    */     //   67: astore_2
/*    */     //   68: aload_0
/*    */     //   69: invokevirtual avaibleServer : ()Z
/*    */     //   72: ifeq -> 113
/*    */     //   75: aload_2
/*    */     //   76: invokevirtual getTitle : ()Lnet/minecraft/util/text/ITextComponent;
/*    */     //   79: invokeinterface getString : ()Ljava/lang/String;
/*    */     //   84: ldc 'Аукцион'
/*    */     //   86: invokevirtual contains : (Ljava/lang/CharSequence;)Z
/*    */     //   89: ifne -> 109
/*    */     //   92: aload_2
/*    */     //   93: invokevirtual getTitle : ()Lnet/minecraft/util/text/ITextComponent;
/*    */     //   96: invokeinterface getString : ()Ljava/lang/String;
/*    */     //   101: ldc 'Поиск'
/*    */     //   103: invokevirtual contains : (Ljava/lang/CharSequence;)Z
/*    */     //   106: ifeq -> 113
/*    */     //   109: iconst_1
/*    */     //   110: goto -> 114
/*    */     //   113: iconst_0
/*    */     //   114: invokevirtual setForward : (Z)Lfun/rockstarity/api/render/animation/Animation;
/*    */     //   117: pop
/*    */     //   118: aload_0
/*    */     //   119: getfield handlers : Ljava/util/ArrayList;
/*    */     //   122: aload_1
/*    */     //   123: <illegal opcode> accept : (Lfun/rockstarity/api/events/Event;)Ljava/util/function/Consumer;
/*    */     //   128: invokevirtual forEach : (Ljava/util/function/Consumer;)V
/*    */     //   131: return
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #53	-> 0
/*    */     //   #55	-> 35
/*    */     //   #56	-> 42
/*    */     //   #59	-> 118
/*    */     //   #60	-> 131
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   68	45	2	screen	Lnet/minecraft/client/gui/screen/inventory/ContainerScreen;
/*    */     //   0	132	0	this	Lfun/rockstarity/api/autobuy/AutoBuy;
/*    */     //   0	132	1	event	Lfun/rockstarity/api/events/Event;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean avaibleServer() {
/* 63 */     return Server.isFT();
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\autobuy\AutoBuy.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */