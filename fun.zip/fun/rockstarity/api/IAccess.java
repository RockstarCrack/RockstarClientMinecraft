/*    */ package fun.rockstarity.api;
/*    */ 
/*    */ import fun.rockstarity.Rockstar;
/*    */ import fun.rockstarity.api.render.ui.fonts.CustomFont;
/*    */ import fun.rockstarity.api.render.ui.rect.Rect;
/*    */ import net.minecraft.client.MainWindow;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.renderer.BufferBuilder;
/*    */ import net.minecraft.client.renderer.Tessellator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IAccess
/*    */ {
/* 21 */   public static final Minecraft mc = Minecraft.getInstance();
/* 22 */   public static final MainWindow sr = mc.getMainWindow();
/*    */   
/* 24 */   public static final Tessellator TESSELLATOR = Tessellator.getInstance();
/* 25 */   public static final BufferBuilder BUILDER = TESSELLATOR.getBuffer();
/*    */ 
/*    */   
/* 28 */   public static final Rockstar rock = (Rockstar)Rockstar.getInstance();
/*    */   
/* 30 */   public static final CustomFont bold = new CustomFont("mulish-bold");
/* 31 */   public static final CustomFont ar = new CustomFont("mulish-bold");
/* 32 */   public static final CustomFont semibold = new CustomFont("mulish-semibold");
/*    */   
/* 34 */   public static final Rect fullScreen = new Rect(0.0F, 0.0F, sr.getScaledWidth(), sr.getScaledHeight());
/*    */ 
/*    */   
/* 37 */   public static final Runtime runTime = Runtime.getRuntime();
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\IAccess.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */