package fun.rockstarity.api.interfaces;

import com.google.gson.JsonElement;

public interface Jsonable {
  void load(JsonElement paramJsonElement);
  
  JsonElement save();
}


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\interfaces\Jsonable.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */