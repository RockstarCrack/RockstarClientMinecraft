/*     */ package fun.rockstarity.api;
/*     */ 
/*     */ import fun.rockstarity.api.helpers.render.Converter;
/*     */ import fun.rockstarity.api.helpers.render.Gifs;
/*     */ import fun.rockstarity.api.helpers.render.gif.GifRender;
/*     */ import fun.rockstarity.api.modules.settings.list.Select;
/*     */ import fun.rockstarity.api.render.globals.emotions.instance.EmotionType;
/*     */ import fun.rockstarity.api.render.ui.alerts.AlertType;
/*     */ import fun.rockstarity.api.render.ui.mainmenu.loading.LoadingScreen;
/*     */ import fun.rockstarity.api.render.ui.mainmenu.loading.LoadingStage;
/*     */ import fun.rockstarity.client.modules.render.Particles;
/*     */ import java.io.InputStream;
/*     */ import ru.kotopushka.antiautistleak.obfuscator.includes.annotations.compile.ReleaseCompileToNativeCalls;
/*     */ import ru.kotopushka.j2c.sdk.annotations.NativeInclude;
/*     */ import ru.kotopushka.j2c.sdk.annotations.VMProtect;
/*     */ import ru.kotopushka.j2c.sdk.enums.VMProtectType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ReleaseCompileToNativeCalls
/*     */ public final class AssetsLoader
/*     */   implements IAccess
/*     */ {
/*     */   public static final String BASE_PATH = "/assets/minecraft/rockstar/files/";
/*     */   
/*     */   private AssetsLoader() {
/*  34 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*     */   }
/*     */   @NativeInclude
/*     */   public static void load() {
/*  38 */     LoadingStage.FONTS.activate();
/*  39 */     bold(17);
/*  40 */     bold(15);
/*  41 */     bold(14);
/*  42 */     bold(12);
/*  43 */     bold(11);
/*  44 */     bold(13);
/*  45 */     bold(10);
/*  46 */     bold(16);
/*  47 */     bold(20);
/*  48 */     bold(24);
/*  49 */     bold(18);
/*  50 */     semibold(16);
/*  51 */     semibold(14);
/*  52 */     semibold(15);
/*  53 */     semibold(13);
/*  54 */     semibold(12);
/*  55 */     semibold(10);
/*  56 */     semibold(17);
/*     */     
/*  58 */     LoadingStage.IMAGES.activate();
/*  59 */     image("icons/menu/setting.png");
/*  60 */     image("masks/models/rabbit.png");
/*  61 */     image("icons/info.png");
/*  62 */     image("icons/xmark.png");
/*  63 */     image("icons/copy.png");
/*  64 */     image("icons/yes.png");
/*  65 */     image("masks/arrow.png");
/*  66 */     image("masks/circle.png");
/*  67 */     image("icons/hud/bind.png");
/*  68 */     image("icons/hud/coords.png");
/*  69 */     image("icons/hud/logo.png");
/*  70 */     image("icons/hud/server.png");
/*  71 */     image("icons/hud/speed.png");
/*  72 */     image("icons/hud/mouse/center.png");
/*  73 */     image("icons/hud/mouse/left.png");
/*  74 */     image("icons/hud/mouse/right.png");
/*  75 */     image("icons/hud/mouse/tail.png");
/*  76 */     image("icons/hud/finger/line1.png");
/*  77 */     image("icons/hud/finger/line2.png");
/*  78 */     image("icons/hud/finger/line3.png");
/*  79 */     image("icons/hud/finger/line4.png");
/*  80 */     image("icons/hud/finger/line5.png");
/*  81 */     image("icons/hud/finger/line6.png");
/*  82 */     image("icons/hud/finger/line7.png");
/*  83 */     image("masks/wheel_element.png");
/*  84 */     image("icons/mainmenu/alt/search.png");
/*  85 */     image("icons/mainmenu/alt/filter.png");
/*  86 */     image("icons/mainmenu/alt/magic.png");
/*  87 */     image("icons/mainmenu/alt/star.png");
/*  88 */     image("icons/mainmenu/alt/ban.png");
/*  89 */     image("icons/mainmenu/alt/trash.png");
/*  90 */     image("icons/mainmenu/alt/small-star.png");
/*  91 */     image("icons/mainmenu/alt/stroke-star.png");
/*  92 */     image("masks/energy.png");
/*  93 */     image("masks/chain.png");
/*  94 */     image("masks/glow.png");
/*  95 */     image("icons/hud/potions.png");
/*  96 */     image("icons/copy.png");
/*  97 */     image("icons/yes.png");
/*  98 */     image("masks/particles/Glow.png");
/*     */     
/* 100 */     Particles particles = (Particles)rock.getModules().get(Particles.class);
/* 101 */     for (Select.Element type : ((Particles.ParticleSettings)particles.getElementSettings().get(particles.getTotem())).select.getElements()) {
/* 102 */       image("masks/particles/" + ((Particles.ParticleSettings)particles.getElementSettings().get(particles.getTotem())).select.getElements().indexOf(type) + ".png");
/*     */     }
/*     */     
/* 105 */     for (int i = 0; i < 8; i++) {
/* 106 */       if (i < (EmotionType.values()).length) {
/* 107 */         image("masks/emotions/" + EmotionType.values()[i].getName() + ".png");
/*     */       }
/*     */     } 
/* 110 */     LoadingStage.IMAGES.getReadyAnim().setForward(true);
/* 111 */     LoadingStage.IMAGES.setStage("Готово!");
/* 112 */     LoadingScreen.FINISH = true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @VMProtect(type = VMProtectType.ULTRA)
/*     */   @NativeInclude
/*     */   private static void image(String path) {
/* 120 */     LoadingStage.stage("Картинка " + path.replace("/", " -> "));
/* 121 */     InputStream stream = AssetsLoader.class.getResourceAsStream("/assets/minecraft/rockstar/files/" + path);
/* 122 */     if (stream != null) {
/* 123 */       Converter.getResourceLocation("/assets/minecraft/rockstar/files/" + path);
/*     */     } else {
/* 125 */       rock.getAlertHandler().alert("Изображение не найдено: " + path, AlertType.ERROR);
/*     */     } 
/*     */   }
/*     */   
/*     */   @VMProtect(type = VMProtectType.ULTRA)
/*     */   @NativeInclude
/*     */   private static void bold(int size) {
/* 132 */     LoadingStage.stage("Шрифт " + size + " с начертанием Bold");
/* 133 */     InputStream stream = AssetsLoader.class.getResourceAsStream("/assets/minecraft/rockstar/files/fonts/bold_" + size + ".ttf");
/* 134 */     if (stream != null) {
/* 135 */       bold.get(size);
/*     */     } else {
/* 137 */       rock.getAlertHandler().alert("Шрифт Bold " + size + " не найден", AlertType.ERROR);
/*     */     } 
/*     */   }
/*     */   
/*     */   @VMProtect(type = VMProtectType.ULTRA)
/*     */   @NativeInclude
/*     */   private static void semibold(int size) {
/* 144 */     LoadingStage.stage("Шрифт " + size + " с начертанием Semibold");
/* 145 */     InputStream stream = AssetsLoader.class.getResourceAsStream("/assets/minecraft/rockstar/files/fonts/semibold_" + size + ".ttf");
/* 146 */     if (stream != null) {
/* 147 */       semibold.get(size);
/*     */     } else {
/* 149 */       rock.getAlertHandler().alert("Шрифт Semibold " + size + " не найден", AlertType.ERROR);
/*     */     } 
/*     */   }
/*     */   
/*     */   @VMProtect(type = VMProtectType.ULTRA)
/*     */   @NativeInclude
/*     */   public static void loadGifs() {
/* 156 */     if (Gifs.idontknow == null) {
/* 157 */       Gifs.idontknow = loadGif("xz");
/* 158 */       Gifs.sleep = loadGif("sleep");
/* 159 */       Gifs.loading = loadGif("wait");
/* 160 */       InputStream cleanStream = AssetsLoader.class.getResourceAsStream("/assets/minecraft/rockstar/files/gifs/clean.gif");
/* 161 */       if (cleanStream != null) {
/* 162 */         Gifs.clean = new GifRender(cleanStream);
/*     */       } else {
/* 164 */         rock.getAlertHandler().alert("GIF clean не найден", AlertType.ERROR);
/*     */       } 
/* 166 */       if (rock.getUser().isGif()) {
/* 167 */         InputStream avatarStream = AssetsLoader.class.getResourceAsStream("/assets/minecraft/rockstar/files/gifs/" + rock.getUser().getAvatar());
/* 168 */         if (avatarStream != null) {
/* 169 */           Gifs.avatar = new GifRender(avatarStream);
/*     */         } else {
/* 171 */           rock.getAlertHandler().alert("Аватар не найден", AlertType.ERROR);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @VMProtect(type = VMProtectType.ULTRA)
/*     */   @NativeInclude
/*     */   private static GifRender loadGif(String name) {
/* 180 */     String word = rock.isNewYear() ? "new" : "";
/* 181 */     InputStream stream = AssetsLoader.class.getResourceAsStream("/assets/minecraft/rockstar/files/gifs/" + word + name + ".gif");
/* 182 */     if (stream != null) {
/* 183 */       return new GifRender(stream);
/*     */     }
/* 185 */     rock.getAlertHandler().alert("GIF не найден: " + name, AlertType.ERROR);
/* 186 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\AssetsLoader.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */