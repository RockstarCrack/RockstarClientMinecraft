/*    */ package fun.rockstarity.api.render.ui.mainmenu.alt;
/*    */ 
/*    */ import fun.rockstarity.api.render.animation.Animation;
/*    */ import fun.rockstarity.api.render.animation.Easing;
/*    */ 
/*    */ public class AltServer {
/*    */   private final Animation hoverAnim;
/*    */   private final String ip;
/*    */   private String ban;
/*    */   
/*    */   public Animation getHoverAnim() {
/*    */     return this.hoverAnim;
/*    */   }
/*    */   
/*    */   public String getIp() {
/*    */     return this.ip;
/*    */   }
/*    */   
/* 19 */   public AltServer(String ip) { this.hoverAnim = (new Animation()).setEasing(Easing.EASE_OUT_CIRC).setSpeed(500);
/*    */     
/* 21 */     this.ban = ""; this.ip = ip; } public String getBan() { return this.ban; } public void setBan(String ban) { this.ban = ban; }
/*    */ 
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\mainmenu\alt\AltServer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */