/*    */ package fun.rockstarity.api.render.ui.mainmenu.alt;
/*    */ public class Alt { private final Animation selectedAnim; private final Animation hoverAnim; private final Animation favoriteAnim; private final Animation deleteAnim; private FixColor donateColor; private String donate; private final String username; private final boolean random; private final List<AltServer> servers; private boolean favorite; private boolean banned; private String note; private Rect favoriteBtn; private Rect deleteBtn;
/*    */   public Animation getSelectedAnim() {
/*    */     return this.selectedAnim;
/*    */   }
/*    */   public Animation getHoverAnim() {
/*    */     return this.hoverAnim;
/*    */   }
/*    */   public Animation getFavoriteAnim() {
/*    */     return this.favoriteAnim;
/*    */   }
/*    */   public Animation getDeleteAnim() {
/*    */     return this.deleteAnim;
/*    */   }
/*    */   public FixColor getDonateColor() {
/*    */     return this.donateColor;
/*    */   }
/*    */   public void setDonateColor(FixColor donateColor) {
/*    */     this.donateColor = donateColor;
/*    */   }
/*    */   public String getDonate() {
/*    */     return this.donate;
/*    */   }
/*    */   public void setDonate(String donate) {
/*    */     this.donate = donate;
/*    */   }
/* 27 */   public Alt(String username, boolean random) { this.selectedAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300);
/* 28 */     this.hoverAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300);
/* 29 */     this.favoriteAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300);
/* 30 */     this.deleteAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 37 */     this.servers = new ArrayList<>();
/*    */ 
/*    */     
/* 40 */     this.note = ""; this.username = username; this.random = random; } public String getUsername() { return this.username; } public boolean isRandom() { return this.random; } public List<AltServer> getServers() { return this.servers; } public boolean isFavorite() { return this.favorite; } public void setFavorite(boolean favorite) { this.favorite = favorite; } public boolean isBanned() { return this.banned; } public void setBanned(boolean banned) { this.banned = banned; } public String getNote() { return this.note; } public void setNote(String note) { this.note = note; }
/*    */   
/* 42 */   public Rect getFavoriteBtn() { return this.favoriteBtn; } public Rect getDeleteBtn() { return this.deleteBtn; } public void setFavoriteBtn(Rect favoriteBtn) { this.favoriteBtn = favoriteBtn; } public void setDeleteBtn(Rect deleteBtn) { this.deleteBtn = deleteBtn; }
/*    */   
/*    */   public JsonObject save() {
/* 45 */     JsonObject json = new JsonObject();
/*    */     
/* 47 */     if (this.donateColor != null) {
/* 48 */       json.addProperty("donate-color", Integer.valueOf(this.donateColor.getRGB()));
/*    */     }
/* 50 */     if (this.donate != null) {
/* 51 */       json.addProperty("donate", this.donate);
/*    */     }
/*    */     
/* 54 */     json.addProperty("username", this.username);
/* 55 */     json.addProperty("banned", Boolean.valueOf(this.banned));
/* 56 */     json.addProperty("favorite", Boolean.valueOf(this.favorite));
/* 57 */     json.addProperty("random", Boolean.valueOf(this.random));
/* 58 */     json.addProperty("note", this.note);
/*    */     
/* 60 */     JsonObject serversJson = new JsonObject();
/* 61 */     for (AltServer server : this.servers) {
/* 62 */       serversJson.addProperty(server.getIp(), server.getBan());
/*    */     }
/* 64 */     json.add("servers", (JsonElement)serversJson);
/*    */     
/* 66 */     return json;
/*    */   }
/*    */   
/*    */   public static Alt load(JsonObject json) {
/* 70 */     Alt alt = new Alt(json.get("username").getAsString().replace("\\", ""), (json.has("random") && json.get("random").getAsBoolean()));
/*    */     
/* 72 */     if (json.has("banned") && !json.get("banned").isJsonNull()) {
/* 73 */       alt.setBanned(json.get("banned").getAsBoolean());
/*    */     }
/* 75 */     if (json.has("favorite") && !json.get("favorite").isJsonNull()) {
/* 76 */       alt.setFavorite(json.get("favorite").getAsBoolean());
/*    */     }
/* 78 */     if (json.has("note") && !json.get("note").isJsonNull()) {
/* 79 */       alt.setNote(json.get("note").getAsString());
/*    */     }
/* 81 */     if (json.has("donate") && !json.get("donate").isJsonNull()) {
/* 82 */       alt.setDonate(json.get("donate").getAsString());
/*    */     }
/* 84 */     if (json.has("donate-color") && !json.get("donate-color").isJsonNull()) {
/* 85 */       alt.setDonateColor(new FixColor(json.get("donate-color").getAsInt()));
/*    */     }
/*    */     
/* 88 */     if (json.has("servers") && json.get("servers").isJsonObject()) {
/* 89 */       JsonObject serversJson = json.getAsJsonObject("servers");
/* 90 */       for (Map.Entry<String, JsonElement> entry : (Iterable<Map.Entry<String, JsonElement>>)serversJson.entrySet()) {
/* 91 */         AltServer server = new AltServer(entry.getKey());
/* 92 */         server.setBan(((JsonElement)entry.getValue()).getAsString());
/* 93 */         alt.getServers().add(server);
/*    */       } 
/*    */     } 
/*    */     
/* 97 */     return alt;
/*    */   } }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\mainmenu\alt\Alt.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */