/*     */ package fun.rockstarity.api.render.ui.clickgui;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.binds.Bindable;
/*     */ import fun.rockstarity.api.configs.ConfigsHandler;
/*     */ import fun.rockstarity.api.helpers.math.Hover;
/*     */ import fun.rockstarity.api.helpers.secure.Web;
/*     */ import fun.rockstarity.api.helpers.system.TextUtility;
/*     */ import fun.rockstarity.api.helpers.system.ThreadManager;
/*     */ import fun.rockstarity.api.modules.Category;
/*     */ import fun.rockstarity.api.modules.Module;
/*     */ import fun.rockstarity.api.render.animation.Animation;
/*     */ import fun.rockstarity.api.render.animation.Easing;
/*     */ import fun.rockstarity.api.render.animation.infinity.InfinityAnimation;
/*     */ import fun.rockstarity.api.render.color.themes.Style;
/*     */ import fun.rockstarity.api.render.color.themes.Theme;
/*     */ import fun.rockstarity.api.render.menufilter.MenuFilter;
/*     */ import fun.rockstarity.api.render.ui.alerts.AlertType;
/*     */ import fun.rockstarity.api.render.ui.clickgui.esp.ESPElement;
/*     */ import fun.rockstarity.api.render.ui.clickgui.esp.ESPSettings;
/*     */ import fun.rockstarity.api.render.ui.clickgui.windows.BindListWindow;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import fun.rockstarity.api.render.ui.widgets.InputWidget;
/*     */ import fun.rockstarity.api.render.ui.widgets.Window;
/*     */ import fun.rockstarity.api.scripts.Script;
/*     */ import fun.rockstarity.api.sounds.Sound;
/*     */ import fun.rockstarity.client.modules.render.ClickGui;
/*     */ import fun.rockstarity.client.modules.render.ESP;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClickGuiWindow
/*     */   extends Rect
/*     */   implements IAccess
/*     */ {
/*  63 */   private final ArrayList<Window> windows = new ArrayList<>(); public ArrayList<Window> getWindows() { return this.windows; }
/*  64 */    private Category current = Category.COMBAT; private int prevIndex; private Module opened; private Module prevOpened; private Module queue; private Category prevCurrent = Category.COMBAT; private ClickGuiRenderer renderer; private boolean drag; private boolean tryDrag; public Category getCurrent() { return this.current; } public Category getPrevCurrent() { return this.prevCurrent; }
/*  65 */   public int getPrevIndex() { return this.prevIndex; }
/*  66 */   public void setOpened(Module opened) { this.opened = opened; } public void setPrevOpened(Module prevOpened) { this.prevOpened = prevOpened; } public void setQueue(Module queue) { this.queue = queue; }
/*  67 */   public Module getOpened() { return this.opened; } public Module getPrevOpened() { return this.prevOpened; } public Module getQueue() { return this.queue; }
/*  68 */   public ClickGuiRenderer getRenderer() { return this.renderer; } private boolean canDrag = true; private boolean searching; private float dragX; private float dragY; private InputWidget input;
/*  69 */   public void setDrag(boolean drag) { this.drag = drag; } public void setTryDrag(boolean tryDrag) { this.tryDrag = tryDrag; } public void setCanDrag(boolean canDrag) { this.canDrag = canDrag; } public void setSearching(boolean searching) { this.searching = searching; }
/*  70 */   public boolean isDrag() { return this.drag; } public boolean isTryDrag() { return this.tryDrag; } public boolean isCanDrag() { return this.canDrag; } public boolean isSearching() { return this.searching; }
/*  71 */   public float getDragX() { return this.dragX; } public float getDragY() { return this.dragY; }
/*  72 */   public void setInput(InputWidget input) { this.input = input; } public InputWidget getInput() {
/*  73 */     return this.input;
/*  74 */   } private final InfinityAnimation scrollValue = new InfinityAnimation(); private final InfinityAnimation settingsScrollValue = new InfinityAnimation(); private float scroll; private float settingsScroll; private ESPSettings espSettings; public InfinityAnimation getScrollValue() { return this.scrollValue; } public InfinityAnimation getSettingsScrollValue() { return this.settingsScrollValue; }
/*  75 */   public void setScroll(float scroll) { this.scroll = scroll; } public void setSettingsScroll(float settingsScroll) { this.settingsScroll = settingsScroll; }
/*  76 */   public float getScroll() { return this.scroll; } public float getSettingsScroll() { return this.settingsScroll; } public ESPSettings getEspSettings() {
/*  77 */     return this.espSettings;
/*     */   }
/*     */   public ClickGuiWindow(float x, float y, float width, float height) {
/*  80 */     super(x, y, width, height);
/*     */     
/*  82 */     this.prevIndex = this.current.getIndex();
/*  83 */     ClickGuiRenderer.changeCurrent = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300).setSize((this.prevIndex - Category.COMBAT.getIndex()));
/*  84 */     ClickGuiRenderer.changeCurrent.setForward(true);
/*  85 */     ClickGuiRenderer.changeCurrentTail = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(500).setSize((this.prevIndex - Category.COMBAT.getIndex()));
/*  86 */     ClickGuiRenderer.changeCurrentTail.setForward(true);
/*  87 */     this.current = Category.COMBAT;
/*  88 */     this.renderer = new ClickGuiRenderer();
/*  89 */     this.espSettings = new ESPSettings();
/*     */   }
/*     */   
/*     */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/*     */     try {
/*  94 */       if (this.drag) {
/*  95 */         this.x = MathHelper.clamp(mouseX + this.dragX, -140.0F, sr.getScaledWidth() - getWidth() + 140.0F);
/*  96 */         this.y = MathHelper.clamp(mouseY + this.dragY, -140.0F, sr.getScaledHeight() - getHeight() + 140.0F);
/*     */       } 
/*     */       
/*  99 */       this.renderer.render(matrixStack, mouseX, mouseY, partialTicks);
/*     */       
/* 101 */       GL11.glPushMatrix();
/* 102 */       GL11.glTranslated(0.0D, 0.0D, 999.0D);
/* 103 */       this.windows.stream().forEach(window -> window.render(matrixStack, mouseX, mouseY, partialTicks));
/* 104 */       GL11.glPopMatrix();
/*     */       
/* 106 */       this.windows.removeIf(window -> window.getOpening().finished(false));
/* 107 */       this.scrollValue.animate(this.scroll, 150);
/* 108 */       this.settingsScrollValue.animate(this.settingsScroll, 150);
/* 109 */       if (this.scroll > 0.0F)
/* 110 */         this.scroll = 0.0F; 
/* 111 */       if (this.settingsScroll > 0.0F) {
/* 112 */         this.settingsScroll = 0.0F;
/*     */       }
/*     */     }
/* 115 */     catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean clicked(double mouseX, double mouseY, int button) {
/* 120 */     if (rock.isDebugging() && Hover.isHovered((sr.getScaledWidth() - 20), (sr.getScaledHeight() - 20), 20.0D, 20.0D, mouseX, mouseY)) {
/* 121 */       ClickGuiRenderer.setLoaded(!ClickGuiRenderer.isLoaded());
/*     */     }
/*     */ 
/*     */     
/* 125 */     if (!ClickGuiRenderer.isLoaded()) return false; 
/* 126 */     if (this.input != null) this.input.mouseClicked(mouseX, mouseY, button); 
/*     */     try {
/* 128 */       for (Window window : this.windows) {
/* 129 */         window.clicked(mouseX, mouseY, button);
/* 130 */         if (!window.canClick(mouseX, mouseY)) {
/* 131 */           for (Window window1 : this.windows) {
/* 132 */             if (window1 != window && window1.getOpening().finished() && ((window1 instanceof BindListWindow && window1 instanceof BindListWindow) || (window1 instanceof fun.rockstarity.api.render.ui.clickgui.windows.SettingsWindow && window instanceof fun.rockstarity.api.render.ui.clickgui.windows.SettingsWindow))) {
/* 133 */               window1.getOpening().setForward(false);
/*     */             }
/*     */           } 
/* 136 */           return true;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 141 */       float yOff = 0.0F;
/* 142 */       for (Category type : Category.values()) {
/* 143 */         if (Hover.isHovered((this.x + 8.0F), (this.y + 49.0F + yOff), 21.0D, 21.0D, mouseX, mouseY) && type != this.current) {
/* 144 */           changeCategory(type);
/*     */         }
/*     */         
/* 147 */         yOff += 24.0F;
/*     */       } 
/*     */       
/* 150 */       if (Hover.isHovered(y(this.y + 30.0F).height(this.height - 30.0F), mouseX, mouseY)) {
/*     */         
/* 152 */         float yOff1 = this.scrollValue.get();
/* 153 */         if (this.current == Category.SCRIPTS) {
/* 154 */           for (Script script : rock.getScriptHandler().getEnabledScripts()) {
/* 155 */             String name = script.getName();
/*     */             
/* 157 */             if (script.getScriptModules().isEmpty())
/*     */               continue; 
/* 159 */             yOff1 += 12.0F;
/*     */             
/* 161 */             for (Module module : script.getScriptModules()) {
/* 162 */               if (Hover.isHovered((this.x + 37.0F), (this.y + 30.5F + yOff1), 118.0D, 13.0D, mouseX, mouseY)) {
/* 163 */                 if (button == 0) {
/* 164 */                   module.toggle();
/* 165 */                 } else if (button == 1 && this.opened != module) {
/* 166 */                   if (this.opened != null) {
/* 167 */                     this.queue = module;
/*     */                   } else {
/* 169 */                     this.opened = module;
/*     */                   } 
/* 171 */                 } else if (button == 2) {
/* 172 */                   this.windows.add(new BindListWindow((Bindable)module, (float)mouseX, (float)mouseY, 60.0F, 100.0F));
/*     */                 } 
/*     */               }
/*     */               
/* 176 */               yOff1 += 13.0F;
/*     */             } 
/*     */           } 
/*     */         } else {
/* 180 */           for (Map.Entry<Character, List<Module>> entry : get(this.current).entrySet()) {
/* 181 */             String name = ((Character)entry.getKey()).toString();
/* 182 */             yOff1 += 12.0F;
/* 183 */             for (Module module : entry.getValue()) {
/* 184 */               if (Hover.isHovered((this.x + 37.0F), (this.y + 30.5F + yOff1), 118.0D, 13.0D, mouseX, mouseY)) {
/* 185 */                 if (button == 0) {
/* 186 */                   module.toggle();
/* 187 */                 } else if (button == 1 && this.opened != module) {
/* 188 */                   if (this.opened != null) {
/* 189 */                     this.queue = module;
/*     */                   } else {
/* 191 */                     this.opened = module;
/*     */                   } 
/* 193 */                 } else if (button == 2) {
/* 194 */                   this.windows.add(new BindListWindow((Bindable)module, (float)mouseX, (float)mouseY, 60.0F, 100.0F));
/*     */                 } 
/*     */               }
/*     */               
/* 198 */               yOff1 += 13.0F;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 204 */         if (Hover.isHovered((this.x + 156.0F), (this.y + 29.0F + 40.0F), (this.width - 156.0F), (this.height - 40.0F - 29.0F), mouseX, mouseY)) {
/* 205 */           for (SettingRect setting : get(this.opened)) {
/* 206 */             setting.clicked(mouseX, mouseY, button, false);
/*     */           }
/*     */         }
/*     */       } 
/*     */       
/* 211 */       if (this.prevOpened instanceof ESP && !ClickGuiRenderer.openedAnim.finished(false)) {
/* 212 */         this.espSettings.clicked(mouseX, mouseY, button);
/*     */       }
/*     */ 
/*     */       
/* 216 */       if (this.current == Category.THEMES) {
/* 217 */         float xOff = 0.0F;
/* 218 */         for (Theme theme : rock.getThemes()) {
/*     */           
/* 220 */           float width = bold.get(18).getWidth(theme.getName()) + 65.0F;
/* 221 */           if (Hover.isHovered((this.x + 45.0F + xOff), (this.y + 37.0F), width, 25.0D, mouseX, mouseY)) {
/* 222 */             rock.getThemes().setCurrent(theme);
/* 223 */             ThreadManager.run(() -> rock.saveTheme());
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 228 */           xOff += width + 5.0F;
/*     */         } 
/*     */         
/* 231 */         xOff = 0.0F;
/* 232 */         float yOff11 = 33.0F;
/* 233 */         for (Style style : Style.values()) {
/* 234 */           float width = 105.0F;
/* 235 */           if (Hover.isHovered((this.x + 45.0F + xOff), (this.y + 37.0F + yOff11), this.width, 33.0D, mouseX, mouseY)) {
/* 236 */             Style.setCurrent(style);
/* 237 */             ThreadManager.run(() -> rock.saveTheme());
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 242 */           xOff += width + 5.0F;
/* 243 */           if (xOff + width + 5.0F > this.width) {
/* 244 */             yOff11 += 38.0F;
/* 245 */             xOff = 0.0F;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 252 */       if (!this.searching && Hover.isHovered((this.x + 166.0F), (this.y + 7.0F - 29.0F - 29.0F * ClickGuiRenderer.upSideAnim.get()), (bold.get(16).getWidth("Сохранить конфиг") + 9.0F), 15.0D, mouseX, mouseY)) {
/* 253 */         ConfigsHandler handler = rock.getConfigHandler();
/* 254 */         handler.save(handler.getCurrent(), false);
/*     */       } 
/*     */ 
/*     */       
/* 258 */       if (Hover.isHovered((this.x + 449.0F), (this.y + 8.0F - 29.0F - 29.0F * ClickGuiRenderer.upSideAnim.get()), 13.0D, 13.0D, mouseX, mouseY));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 278 */       if (Hover.isHovered((this.x + 468.0F), (this.y + 9.0F), 11.0D, 11.0D, mouseX, mouseY)) {
/* 279 */         this.searching = !this.searching;
/* 280 */         this.input.setText("");
/* 281 */         this.input.setFocused2(true);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 288 */       if (this.opened != null && 
/* 289 */         Hover.isHovered((this.x + 171.0F + bold.get(24).getWidth("Настройки " + this.opened.getInfo().name())), (this.y + 43.5F), 9.0D, 9.0D, mouseX, mouseY)) {
/* 290 */         this.windows.add(new BindListWindow((Bindable)this.opened, (float)mouseX, (float)mouseY, 60.0F, 100.0F));
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 295 */       if (Hover.isHovered((this.x + this.width - 21.0F), (this.y + 43.0F), 9.0D, 9.0D, mouseX, mouseY)) {
/* 296 */         this.opened = null;
/*     */       }
/*     */ 
/*     */       
/* 300 */       if (Hover.isHovered((this.x + 9.0F + 30.0F * ClickGuiRenderer.moveAnim.get() - 30.0F - 1.0F), (this.y + this.height - 30.0F - 1.0F), 22.0D, 22.0D, mouseX, mouseY)) {
/* 301 */         Web.openWebpage("http://localhost/profile.php");
/* 302 */         rock.getAlertHandler().alert("Профиль открыт!", AlertType.SUCCESS);
/*     */       } 
/* 304 */     } catch (Exception exception) {}
/*     */     
/* 306 */     return true;
/*     */   }
/*     */   
/*     */   public boolean released(double mouseX, double mouseY, int button) {
/*     */     try {
/* 311 */       this.windows.stream().forEach(window -> window.released(mouseX, mouseY, button));
/* 312 */       for (Window window : this.windows) {
/* 313 */         if (!window.canClick(mouseX, mouseY)) return true; 
/*     */       } 
/* 315 */       this.tryDrag = false;
/* 316 */       this.drag = false;
/* 317 */       for (SettingRect setting : get(this.opened)) {
/* 318 */         setting.clicked(mouseX, mouseY, button, true);
/*     */       }
/* 320 */       if (this.prevOpened instanceof ESP && !ClickGuiRenderer.openedAnim.finished(false)) {
/* 321 */         this.espSettings.released(mouseX, mouseY, button);
/*     */       }
/* 323 */     } catch (Exception exception) {}
/*     */     
/* 325 */     return true;
/*     */   }
/*     */   
/*     */   public boolean dragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
/*     */     try {
/* 330 */       for (Window window : this.windows) {
/* 331 */         window.dragged(mouseX, mouseY, button, dragX, dragY);
/* 332 */         if (!window.canClick(mouseX, mouseY)) return true;
/*     */       
/*     */       } 
/* 335 */       boolean cancel = false;
/*     */       
/* 337 */       for (SettingRect setting : get(this.opened)) {
/* 338 */         if (setting.dragged(mouseX, mouseY, button, dragX, dragY)) cancel = true;
/*     */       
/*     */       } 
/* 341 */       for (ESPElement elmt : rock.getEspSettingsHandler().getEspElements()) {
/* 342 */         if (elmt.isDragging()) cancel = true;
/*     */       
/*     */       } 
/* 345 */       for (Window window : this.windows) {
/* 346 */         cancel = true;
/*     */       }
/*     */       
/* 349 */       if (cancel) return false;
/*     */       
/* 351 */       if (this.opened == rock.getModules().get(ESP.class) && (Hover.isHovered(this.espSettings.getElementsRect(), mouseX, mouseY) || Hover.isHovered(this.espSettings.getPreviewRect(), mouseX, mouseY))) return false;
/*     */       
/* 353 */       if (this.espSettings.isDragESP()) return false;
/*     */       
/* 355 */       if (button == 0 && Hover.isHovered(this, mouseX, mouseY) && !this.drag && !this.tryDrag) {
/* 356 */         if (!this.canDrag) {
/* 357 */           this.tryDrag = true;
/* 358 */           return false;
/*     */         } 
/* 360 */         this.dragX = (float)(this.x - mouseX);
/* 361 */         this.dragY = (float)(this.y - mouseY);
/* 362 */         this.drag = true;
/*     */       } 
/* 364 */     } catch (Exception exception) {}
/*     */     
/* 366 */     return true;
/*     */   }
/*     */   
/*     */   public boolean charTyped(char codePoint, int modifiers) {
/* 370 */     if (this.searching && codePoint == '/' && this.input != null && this.input.getText().isEmpty()) {
/* 371 */       return true;
/*     */     }
/*     */     
/* 374 */     if (this.input != null) this.input.charTyped(codePoint, modifiers);
/*     */     
/* 376 */     for (SettingRect setting : get(this.opened)) {
/* 377 */       setting.charTyped(codePoint, modifiers);
/*     */     }
/* 379 */     for (Window window : this.windows) {
/* 380 */       window.charTyped(codePoint, modifiers);
/*     */     }
/* 382 */     return false;
/*     */   }
/*     */   
/*     */   public void tick() {
/* 386 */     if (this.input != null) this.input.tick(); 
/* 387 */     for (SettingRect setting : get(this.opened)) {
/* 388 */       setting.tick();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean pressed(int keyCode, int scanCode, int modifiers) {
/* 393 */     this.drag = false;
/*     */     
/* 395 */     if (keyCode == 256 && this.searching) {
/* 396 */       this.searching = false;
/* 397 */       if (this.input != null) {
/* 398 */         this.input.setFocused2(false);
/*     */       }
/* 400 */       return true;
/*     */     } 
/*     */     
/* 403 */     if ((keyCode == 47 || (keyCode == 70 && (modifiers & 0x2) != 0)) && !this.searching) {
/* 404 */       this.searching = true;
/* 405 */       if (this.input != null) {
/* 406 */         this.input.setFocused2(true);
/*     */       }
/* 408 */       return true;
/*     */     } 
/*     */     
/* 411 */     if ((keyCode == 257 || keyCode == 335) && 
/* 412 */       this.input != null && this.input.isFocused()) {
/* 413 */       this.input.setFocused2(false);
/* 414 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 418 */     if (this.input != null) this.input.keyPressed(keyCode, scanCode, modifiers); 
/* 419 */     for (SettingRect setting : get(this.opened)) {
/* 420 */       setting.pressed(keyCode, scanCode, modifiers);
/*     */     }
/* 422 */     this.windows.stream().forEach(window -> window.pressed(keyCode, scanCode, modifiers));
/* 423 */     return true;
/*     */   }
/*     */   
/*     */   public boolean scrolled(double mouseX, double mouseY, double delta) {
/* 427 */     for (Window window : this.windows) {
/* 428 */       window.scrolled(mouseX, mouseY, delta);
/* 429 */       if (!window.canClick(mouseX, mouseY)) return true;
/*     */     
/*     */     } 
/* 432 */     if (Hover.isHovered((this.renderer.getLoadedAnimX() + 156.0F - 118.0F * ClickGuiRenderer.themesAnim.get()), (this.y + 29.0F * ClickGuiRenderer.upSideAnim.get()), (this.width - 156.0F + 118.0F * ClickGuiRenderer.themesAnim.get()), (this.height - 29.0F * ClickGuiRenderer.upSideAnim.get()), mouseX, mouseY)) {
/* 433 */       this.settingsScroll += (float)(delta * 15.0D);
/*     */     } else {
/* 435 */       this.scroll += (float)(delta * 15.0D);
/* 436 */     }  return false;
/*     */   }
/*     */   
/*     */   public void close() {
/* 440 */     ClickGuiRenderer.opening.setSpeed(1000);
/* 441 */     this.windows.clear();
/* 442 */     ClickGuiRenderer.opening.setForward(false);
/* 443 */     ClickGuiRenderer.rotationESP.setForward(false);
/* 444 */     this.renderer.setClosePos(mc.gameRenderer.getActiveRenderInfo().getProjectedView());
/* 445 */     MenuFilter.show(false);
/* 446 */     if (((ClickGui)rock.getModules().get(ClickGui.class)).getSound().get()) {
/* 447 */       (new Sound("closemenu")).play();
/*     */     }
/*     */   }
/*     */   
/*     */   public void changeCategory(Category type) {
/* 452 */     if (this.searching) {
/* 453 */       this.searching = false;
/* 454 */       if (this.input != null) {
/* 455 */         this.input.setFocused2(false);
/*     */       }
/*     */     } 
/*     */     
/* 459 */     this.prevCurrent = this.current;
/* 460 */     this.prevIndex = this.current.getIndex();
/* 461 */     ClickGuiRenderer.changeCurrent = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300).setSize((this.prevIndex - type.getIndex()));
/* 462 */     ClickGuiRenderer.changeCurrent.setForward(true);
/* 463 */     ClickGuiRenderer.changeCurrentTail = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(500).setSize((this.prevIndex - type.getIndex()));
/* 464 */     ClickGuiRenderer.changeCurrentTail.setForward(true);
/* 465 */     ClickGuiRenderer.changeCategoryAnim.setForward(false);
/* 466 */     this.current = type;
/* 467 */     if (this.current == Category.THEMES) this.opened = null; 
/*     */   }
/*     */   
/*     */   public GlyphType get(Category myType) {
/* 471 */     if (this.searching && this.input != null && (this.input.isFocused() || !this.input.getText().isEmpty())) {
/* 472 */       GlyphType sumGlyphType = new GlyphType();
/*     */       
/* 474 */       for (Category cat : Category.values()) {
/* 475 */         GlyphType glyphType = ClickGuiRenderer.getGlyphes()[cat.getIndex()];
/* 476 */         if (glyphType != null) {
/* 477 */           for (Map.Entry<Character, List<Module>> entry : glyphType.entrySet()) {
/* 478 */             char key = ((Character)entry.getKey()).charValue();
/* 479 */             List<Module> modules = entry.getValue();
/* 480 */             if (modules != null) {
/* 481 */               Set<Module> uniqueModules = new HashSet<>();
/*     */               
/* 483 */               for (Module module : modules) {
/* 484 */                 boolean added = false;
/*     */                 
/* 486 */                 if (module.getInfo().name().toLowerCase().contains(this.input.getText().toLowerCase()) && 
/* 487 */                   uniqueModules.add(module)) {
/* 488 */                   sumGlyphType.put(Character.valueOf(key), sumGlyphType.getOrDefault(Character.valueOf(key), new ArrayList<>()));
/* 489 */                   sumGlyphType.get(Character.valueOf(key)).add(module);
/* 490 */                   added = true;
/*     */                 } 
/*     */ 
/*     */                 
/* 494 */                 String[] moduleNames = module.getInfo().module();
/* 495 */                 if (moduleNames != null && !added) {
/* 496 */                   for (String mod : moduleNames) {
/* 497 */                     if (mod != null && !mod.isEmpty()) {
/* 498 */                       if (mod.toLowerCase().contains(this.input.getText().toLowerCase())) {
/* 499 */                         if (uniqueModules.add(module)) {
/* 500 */                           sumGlyphType.put(Character.valueOf(key), sumGlyphType.getOrDefault(Character.valueOf(key), new ArrayList<>()));
/* 501 */                           sumGlyphType.get(Character.valueOf(key)).add(module);
/*     */                         } 
/*     */                         
/*     */                         break;
/*     */                       } 
/* 506 */                       int distance = TextUtility.levenshteinDistance(mod.toLowerCase(), this.input.getText().toLowerCase());
/* 507 */                       if (distance <= 2) {
/* 508 */                         if (uniqueModules.add(module)) {
/* 509 */                           sumGlyphType.put(Character.valueOf(key), sumGlyphType.getOrDefault(Character.valueOf(key), new ArrayList<>()));
/* 510 */                           sumGlyphType.get(Character.valueOf(key)).add(module);
/*     */                         } 
/*     */                         
/*     */                         break;
/*     */                       } 
/*     */                     } 
/*     */                   } 
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         }
/*     */       } 
/* 523 */       return sumGlyphType;
/*     */     } 
/*     */     
/* 526 */     return ClickGuiRenderer.getGlyphes()[myType.getIndex()];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<SettingRect> get(Module module) {
/*     */     try {
/* 533 */       for (SettingRect settingRect : ClickGuiRenderer.getSettings());
/*     */ 
/*     */ 
/*     */       
/* 537 */       return (List<SettingRect>)ClickGuiRenderer.getSettings().stream()
/* 538 */         .filter(setting -> (setting.getParent().getParent() == module))
/* 539 */         .collect(Collectors.toList());
/* 540 */     } catch (Exception e) {
/* 541 */       return new ArrayList<>();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void screen() {
/* 546 */     int screenWidth = sr.getScaledWidth();
/* 547 */     int screenHeight = sr.getScaledHeight();
/*     */     
/* 549 */     if (this.x < 0.0F || this.x + this.width > screenWidth) {
/* 550 */       this.x = (screenWidth - this.width) / 2.0F;
/*     */     }
/*     */     
/* 553 */     if (this.y < 0.0F || this.y + this.height > screenHeight)
/* 554 */       this.y = (screenHeight - this.height) / 2.0F; 
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\clickgui\ClickGuiWindow.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */