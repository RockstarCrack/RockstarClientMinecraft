package fun.rockstarity.api.render.ui.clickgui;

import fun.rockstarity.api.modules.Module;
import java.util.List;
import java.util.TreeMap;

public class GlyphType extends TreeMap<Character, List<Module>> {}


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\clickgui\GlyphType.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */