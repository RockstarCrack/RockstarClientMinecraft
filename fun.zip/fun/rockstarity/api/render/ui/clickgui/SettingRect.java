/*     */ package fun.rockstarity.api.render.ui.clickgui;
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.binds.Bind;
/*     */ import fun.rockstarity.api.binds.Bindable;
/*     */ import fun.rockstarity.api.helpers.game.Binds;
/*     */ import fun.rockstarity.api.helpers.math.Hover;
/*     */ import fun.rockstarity.api.helpers.render.Render;
/*     */ import fun.rockstarity.api.helpers.system.TextUtility;
/*     */ import fun.rockstarity.api.modules.settings.Setting;
/*     */ import fun.rockstarity.api.modules.settings.list.Binding;
/*     */ import fun.rockstarity.api.modules.settings.list.CheckBox;
/*     */ import fun.rockstarity.api.modules.settings.list.Clickable;
/*     */ import fun.rockstarity.api.modules.settings.list.ColorPicker;
/*     */ import fun.rockstarity.api.modules.settings.list.Input;
/*     */ import fun.rockstarity.api.modules.settings.list.ItemSelect;
/*     */ import fun.rockstarity.api.modules.settings.list.Mode;
/*     */ import fun.rockstarity.api.modules.settings.list.Position;
/*     */ import fun.rockstarity.api.modules.settings.list.Select;
/*     */ import fun.rockstarity.api.modules.settings.list.Slider;
/*     */ import fun.rockstarity.api.render.animation.Animation;
/*     */ import fun.rockstarity.api.render.animation.Easing;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.color.themes.Style;
/*     */ import fun.rockstarity.api.render.shaders.list.Round;
/*     */ import fun.rockstarity.api.render.ui.clickgui.windows.BindListWindow;
/*     */ import fun.rockstarity.api.render.ui.clickgui.windows.ItemSelectWindow;
/*     */ import fun.rockstarity.api.render.ui.clickgui.windows.PickerWindow;
/*     */ import fun.rockstarity.api.render.ui.clickgui.windows.SettingsWindow;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import fun.rockstarity.api.render.ui.widgets.NumberInputWidget;
/*     */ import fun.rockstarity.api.secure.Debugger;
/*     */ import fun.rockstarity.client.modules.player.InvUtils;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TranslationTextComponent;
/*     */ 
/*     */ public class SettingRect extends Rect implements IAccess {
/*     */   private final Setting parent;
/*     */   FixColor bgColor;
/*     */   FixColor settingsBg;
/*     */   FixColor separatorColor;
/*     */   FixColor moduleColor;
/*     */   FixColor black;
/*     */   FixColor white;
/*     */   FixColor text;
/*     */   
/*     */   public Setting getParent() {
/*  51 */     return this.parent;
/*     */   }
/*     */   
/*  54 */   public Animation getHover() { return this.hover; } public Animation getSlowHover() { return this.slowHover; } public Animation getHide() { return this.hide; } private final Animation hover = (new Animation())
/*  55 */     .setEasing(Easing.BOTH_SINE).setSpeed(200);
/*  56 */   private final Animation slowHover = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(500);
/*  57 */   private final Animation hide = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(200);
/*     */   private NumberInputWidget sliderInput;
/*     */   private Slider dragSlider;
/*     */   private Position dragPosition;
/*     */   
/*     */   public SettingRect(Setting parent) {
/*  63 */     this.parent = parent;
/*     */   }
/*     */   
/*     */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks, float anim) {
/*  67 */     render(matrixStack, mouseX, mouseY, partialTicks, anim, false, true);
/*     */   }
/*     */   
/*     */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks, float anim, boolean bind) {
/*  71 */     render(matrixStack, mouseX, mouseY, partialTicks, anim, false, false);
/*     */   }
/*     */   
/*     */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks, float anim, boolean bind, boolean bg) {
/*  75 */     this.bgColor = rock.getThemes().getFirstColor().alpha(anim);
/*  76 */     this.settingsBg = rock.getThemes().getSecondColor().alpha(anim);
/*  77 */     this.separatorColor = rock.getThemes().getThirdColor().alpha(anim);
/*  78 */     this.moduleColor = rock.getThemes().getTextSecondColor().alpha(anim);
/*  79 */     this.text = rock.getThemes().getTextFirstColor().alpha(anim);
/*  80 */     this.black = FixColor.BLACK.alpha(anim);
/*  81 */     this.white = FixColor.WHITE.alpha(anim);
/*     */     
/*  83 */     if (!bind) {
/*  84 */       if (bg) {
/*  85 */         Round.draw(matrixStack, this, 7.0F, this.separatorColor.move((Color)this.bgColor, this.hover.get() * 0.3F));
/*  86 */         Round.draw(matrixStack, size(1.0F), 6.5F, this.bgColor);
/*     */       } 
/*     */       
/*  89 */       StringBuilder displayName = new StringBuilder();
/*  90 */       float xOffset = 0.0F;
/*  91 */       for (char c : this.parent.getName().toCharArray()) {
/*  92 */         displayName.append(c);
/*  93 */         xOffset += bold.get(16).getWidth("" + c);
/*  94 */         if (xOffset > this.width - this.height / 2.0F - 40.0F && this.parent instanceof CheckBox) {
/*  95 */           displayName.append("..");
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 100 */       bold.get(16).draw(matrixStack, displayName.toString(), this.x + 8.5F, this.y + 8.5F, this.moduleColor);
/*     */     } 
/*     */     
/* 103 */     this.hover.setForward(Hover.isHovered(this, mouseX, mouseY));
/* 104 */     this.slowHover.setForward(Hover.isHovered(this, mouseX, mouseY));
/*     */     
/* 106 */     if (Hover.isHovered(this, mouseX, mouseY)) {
/* 107 */       rock.getClickGui().getWindow().setCanDrag(false);
/*     */     }
/*     */     
/* 110 */     Setting setting = this.parent; if (setting instanceof Input) { Input input = (Input)setting;
/* 111 */       Round.draw(matrixStack, new Rect(this.x + 8.5F, this.y + 23.0F, this.width - 17.0F, 12.0F), 2.0F, this.separatorColor.alpha(anim));
/*     */       
/* 113 */       (input.getInput()).x = (int)(this.x + 8.0F);
/* 114 */       (input.getInput()).y = (int)(this.y + 25.0F);
/* 115 */       input.getInput().setWidth((int)(this.width - 17.0F));
/* 116 */       input.getInput().renderButton(matrixStack, mouseX, mouseY, partialTicks, anim);
/*     */       
/* 118 */       bold.get(12).draw(matrixStack, "Введите текст..", this.x + 13.0F, this.y + 25.0F, this.text.alpha(input.getInput().getText().isEmpty() ? (1.0F - this.hover.get() * 0.5F) : 0.0D));
/* 119 */       input.set(input.getInput().getText());
/*     */       
/* 121 */       input.setHeight(44.0F, bind);
/* 122 */       ((InvUtils)rock.getModules().get(InvUtils.class)).setStop(input.getInput().isFocused());
/*     */       
/* 124 */       if (!Hover.isHovered(this.x, this.y, this.width, this.height, mouseX, mouseY)) {
/* 125 */         input.getInput().setFocused2(false);
/*     */       } }
/*     */ 
/*     */     
/* 129 */     setting = this.parent; if (setting instanceof CheckBox) { CheckBox checkbox = (CheckBox)setting;
/* 130 */       checkbox.getEnableAnim(bind).setForward(bind ? checkbox.bind() : checkbox.get());
/* 131 */       checkbox.getSettingsAnim().setForward((checkbox.hasSettings() && (checkbox.get() || !checkbox.ifEnabled())));
/*     */       
/* 133 */       Round.draw(matrixStack, new Rect(this.x + this.width - this.height / 2.0F - 5.0F, this.y + this.height / 2.0F - 5.0F, 10.0F, 10.0F), 2.0F, this.separatorColor.move((Color)Style.getMain().alpha(anim), checkbox.getEnableAnim(bind).get()));
/*     */       
/* 135 */       float checkAnim = checkbox.getEnableAnim(bind).get();
/* 136 */       Render.image("icons/checkmark.png", this.x + this.width - this.height / 2.0F - 3.5F, this.y + this.height / 2.0F - 3.5F + 3.0F - checkAnim * 3.0F, 7.0F, 7.0F, (Color)this.white.alpha(checkAnim));
/*     */       
/* 138 */       Render.image("icons/close.png", this.x + this.width - this.height / 2.0F - 3.0F, this.y + this.height / 2.0F - 3.0F - checkAnim * 3.0F, 6.0F, 6.0F, (Color)rock.getThemes().getTextSecondColor().alpha((anim - checkAnim)));
/*     */       
/* 140 */       Round.draw(matrixStack, new Rect(this.x + this.width - this.height / 2.0F - 5.0F, this.y + this.height / 2.0F - 5.0F, 10.0F, 10.0F), 2.0F, this.separatorColor.alpha(0.0D));
/*     */       
/* 142 */       if (checkbox.canSettings() && !bind) {
/* 143 */         checkbox.setSettingRect(Render.image("icons/menu/setting.png", this.x + this.width - this.height / 2.0F - 17.0F, this.y + this.height / 2.0F - 4.5F, 9.0F, 9.0F, (Color)rock.getThemes().getTextSecondColor().alpha((anim * checkbox.getSettingsAnim().get()))));
/*     */       } }
/*     */     
/* 146 */     setting = this.parent; if (setting instanceof Clickable) { Clickable clickable = (Clickable)setting;
/* 147 */       String display = clickable.getButtonText();
/* 148 */       this.parent.setHeight(47.0F, bind);
/*     */       
/* 150 */       Rect rect = new Rect(this.x + 8.0F, this.y + 23.0F, this.width - 16.0F, 16.0F);
/*     */       
/* 152 */       clickable.getHoverButtonAnim().setForward(Hover.isHovered(rect, mouseX, mouseY));
/*     */       
/* 154 */       Round.draw(matrixStack, rect, 2.0F, this.separatorColor.darker(clickable.getHoverButtonAnim().get() * 0.03F), this.separatorColor.darker(0.03F + clickable.getHoverButtonAnim().get() * 0.03F), this.separatorColor.darker(clickable.getHoverButtonAnim().get() * 0.03F), this.separatorColor.darker(0.03F + clickable.getHoverButtonAnim().get() * 0.03F));
/* 155 */       bold.get(14).draw(matrixStack, display, this.x + this.width / 2.0F - bold.get(14).getWidth(display) / 2.0F, this.y + 26.0F, this.moduleColor); }
/*     */ 
/*     */     
/* 158 */     setting = this.parent; if (setting instanceof Binding) { Binding binding = (Binding)setting;
/* 159 */       String display = binding.getBinds().isEmpty() ? "..." : Binds.getName(((Bind)binding.getBinds().get(0)).getKey(), ((Bind)binding.getBinds().get(0)).getScancode());
/* 160 */       float size = bold.get(12).getWidth(display) + 6.0F;
/*     */       
/* 162 */       Round.draw(matrixStack, new Rect(this.x + this.width - 14.0F + 5.0F - size, this.y + 14.0F - 5.0F, size, 10.0F), 2.0F, this.separatorColor);
/*     */       
/* 164 */       bold.get(12).draw(matrixStack, display, this.x + this.width - 9.5F - bold.get(12).getWidth(display) - 2.5F, this.y + 10.0F, this.moduleColor); }
/*     */ 
/*     */     
/* 167 */     setting = this.parent; if (setting instanceof ColorPicker) { ColorPicker colorPicker = (ColorPicker)setting;
/* 168 */       float off = 1.0F;
/* 169 */       Round.draw(matrixStack, new Rect(this.x + this.width - this.height / 2.0F - 5.0F, this.y + this.height / 2.0F - 5.0F, 10.0F, 10.0F), 5.0F, this.separatorColor);
/* 170 */       Round.draw(matrixStack, new Rect(this.x + this.width - this.height / 2.0F - 5.0F + off, this.y + this.height / 2.0F - 5.0F + off, 10.0F - off * 2.0F, 10.0F - off * 2.0F), 5.0F - off, colorPicker.get().alpha(anim)); }
/*     */ 
/*     */     
/* 173 */     setting = this.parent; if (setting instanceof Slider) { Slider slider = (Slider)setting;
/* 174 */       this.parent.setHeight(39.0F, bind);
/*     */       
/* 176 */       slider.getAnim(bind).animate(bind ? slider.bind() : slider.get(), 100);
/* 177 */       float displayValue = slider.getAnim(bind).get() * (slider.isPercentMode() ? 100 : true);
/* 178 */       String display = (this.sliderInput != null && !this.sliderInput.isFocused() && slider.getTextValues().containsKey(Float.valueOf(Math.round(displayValue * 10.0F) / 10.0F))) ? (String)slider.getTextValues().get(Float.valueOf(Math.round(displayValue * 10.0F) / 10.0F)) : TextUtility.formatNumber(displayValue);
/* 179 */       float size = bold.get(12).getWidth(display) + 5.0F;
/*     */       
/* 181 */       if (this.dragSlider == slider)
/* 182 */         if (bind) {
/* 183 */           slider.bind(Hover.getSliderValue(slider.min(), slider.max(), this.x + 8.5F, this.width - 17.0F, mouseX));
/*     */         } else {
/* 185 */           slider.set(Hover.getSliderValue(slider.min(), slider.max(), this.x + 8.5F, this.width - 17.0F, mouseX));
/*     */         }  
/* 187 */       Round.draw(matrixStack, new Rect(this.x + this.width - 14.0F + 5.0F - size, this.y + 14.0F - 5.0F, size, 10.0F), 2.0F, this.separatorColor);
/*     */       
/* 189 */       if (this.sliderInput == null) {
/* 190 */         this.sliderInput = new NumberInputWidget(bold.get(12), (int)(this.x + this.width - 14.0F + 5.0F - size), (int)(this.y + 14.0F - 5.0F), (int)size * 2, 10, (ITextComponent)new TranslationTextComponent(""), false);
/*     */       }
/*     */       
/* 193 */       this.sliderInput.x = (int)(this.x + this.width - 14.0F + 2.0F - size);
/* 194 */       this.sliderInput.y = (int)(this.y + 14.0F - 3.0F);
/*     */       
/* 196 */       if (this.sliderInput.isFocused()) {
/* 197 */         this.sliderInput.renderButton(matrixStack, mouseX, mouseY, partialTicks);
/* 198 */         if (!this.sliderInput.getText().isEmpty()) {
/*     */           try {
/* 200 */             if (bind)
/* 201 */             { slider.bind(Float.parseFloat(this.sliderInput.getText())); }
/*     */             else
/* 203 */             { slider.set(Float.parseFloat(this.sliderInput.getText())); } 
/* 204 */           } catch (Exception e) {
/* 205 */             this.sliderInput.setText("0");
/*     */           } 
/*     */         }
/*     */       } else {
/*     */         
/* 210 */         bold.get(12).draw(matrixStack, display + display, this.x + this.width - 9.5F - bold.get(12).getWidth(display) - 2.5F, this.y + 10.0F, this.moduleColor);
/* 211 */         this.sliderInput.setText(TextUtility.formatNumber(slider.getAnim(bind).get()));
/*     */       } 
/* 213 */       slider.getMaxAnim().animate(slider.max(), 100);
/*     */       
/* 215 */       Round.draw(matrixStack, new Rect(this.x + 8.5F, this.y + 25.0F, this.width - 17.0F, 4.0F), 2.0F, this.separatorColor);
/* 216 */       Round.draw(matrixStack, new Rect(this.x + 8.5F, this.y + 25.0F, (this.width - 17.0F) * Hover.getPercent(slider.getAnim(bind).get(), slider.min(), slider.getMaxAnim().get()), 4.0F), 2.0F, Style.getMain().alpha(anim), Style.getSecond().alpha(anim), Style.getMain().alpha(anim), Style.getSecond().alpha(anim));
/* 217 */       float circle = 5.0F + this.hover.get();
/* 218 */       Round.draw(matrixStack, new Rect(this.x + 8.5F + (this.width - 17.0F) * Hover.getPercent(slider.getAnim(bind).get(), slider.min(), slider.getMaxAnim().get()) - circle / 2.0F, this.y + 27.0F - circle / 2.0F, circle, circle), circle / 2.0F, this.white.darker(0.3F)); }
/*     */ 
/*     */     
/* 221 */     setting = this.parent; if (setting instanceof Mode) { Mode mode = (Mode)setting;
/* 222 */       float offX = 0.0F, offY = 0.0F;
/*     */       
/* 224 */       for (Mode.Element elmt : mode.getElements()) {
/* 225 */         Rect rect = new Rect(this.x + offX + 8.5F, this.y + 25.0F + offY, bold.get(14).getWidth(elmt.getName()) + 5.0F + (elmt.canSettings() ? (8.0F * elmt.getSettingsAnim().get()) : 0.0F), 10.0F);
/*     */         
/* 227 */         elmt.getAnim(bind).setForward(bind ? mode.isBind(elmt) : mode.is(elmt));
/* 228 */         elmt.getHover(bind).setForward(Hover.isHovered(rect, mouseX, mouseY));
/* 229 */         elmt.getSettingsAnim().setForward((elmt.hasSettings() && (elmt.get() || !elmt.ifEnabled())));
/*     */         
/* 231 */         Round.draw(matrixStack, rect, 2.0F, this.separatorColor.move((Color)Style.getPoint((int)offX).alpha(anim), elmt.getAnim(bind).get()));
/*     */         
/* 233 */         bold.get(14).draw(matrixStack, elmt.getName(), this.x + offX + 10.5F, this.y + 25.0F + offY, this.moduleColor.darker(0.1F).move((Color)this.white, elmt.getAnim(bind).get()));
/*     */         
/* 235 */         if (elmt.canSettings() && !bind) {
/* 236 */           elmt.setSettingRect(Render.image("icons/menu/setting.png", this.x + offX + 7.5F + bold.get(14).getWidth(elmt.getName()) + 5.0F * elmt.getSettingsAnim().get(), this.y + 26.0F + offY, 8.0F, 8.0F, (Color)rock.getThemes().getTextFirstColor().alpha((anim * elmt.getSettingsAnim().get()))));
/*     */         }
/*     */         
/* 239 */         offX += rect.getWidth() + 3.0F;
/* 240 */         if (mode.getElements().indexOf(elmt) + 1 != mode.getElements().size() && offX + bold
/* 241 */           .get(14).getWidth(((Mode.Element)mode.getElements().get(mode.getElements().indexOf(elmt) + 1)).getName()) + 8.0F > this.width - 8.0F) {
/* 242 */           offX = 0.0F;
/* 243 */           offY += 13.0F;
/*     */         } 
/*     */       } 
/*     */       
/* 247 */       mode.setHeight(44.0F + offY, bind); }
/*     */ 
/*     */     
/* 250 */     setting = this.parent; if (setting instanceof Select) { Select select = (Select)setting;
/* 251 */       float offX = 0.0F, offY = 0.0F;
/* 252 */       int count = 0;
/* 253 */       ArrayList<Select.Element> updated = new ArrayList<>(select.getElements());
/*     */       
/* 255 */       for (Select.Element elmt : select.getElements()) {
/* 256 */         elmt.getHideAnim().setForward(elmt.isHide());
/* 257 */         elmt.getSettingsAnim().setForward((elmt.hasSettings() && (elmt.get() || !elmt.ifEnabled())));
/*     */         
/* 259 */         float prevX = offX, prevY = offY;
/*     */         
/* 261 */         if (elmt.isDragging()) {
/* 262 */           offX = MathHelper.clamp(mouseX + elmt.getDragX() + this.x, -8.5F, this.width - 8.5F);
/* 263 */           offY = MathHelper.clamp(mouseY + elmt.getDragY() + this.y, -25.0F, this.height - 25.0F);
/*     */         } 
/*     */         
/* 266 */         Rect rect = new Rect(this.x + offX + 8.5F, this.y + 25.0F + offY, bold.get(14).getWidth(elmt.getName()) + 5.0F + (elmt.canSettings() ? (8.0F * elmt.getSettingsAnim().get()) : 0.0F), 10.0F);
/* 267 */         elmt.getAnim().setForward(elmt.get());
/* 268 */         elmt.getHover().setForward(Hover.isHovered(rect, mouseX, mouseY));
/* 269 */         Round.draw(matrixStack, rect, 2.0F, this.separatorColor.alpha((anim * (1.0F - elmt.getHideAnim().get()))));
/*     */         
/* 271 */         Render.scale(rect.getX() + rect.getWidth() / 2.0F, rect.getY() + rect.getHeight() / 2.0F, 0.5F + elmt.getAnim().get() * 0.5F);
/* 272 */         Round.draw(matrixStack, rect, 2.0F, Style.getPoint((int)offX).alpha((anim * elmt.getAnim().get() * (1.0F - elmt.getHideAnim().get()))));
/* 273 */         Render.end();
/*     */         
/* 275 */         bold.get(14).draw(matrixStack, elmt.getName(), this.x + offX + 10.5F - (bold.get(14).getWidth(elmt.getName()) + 8.0F) / 2.0F * elmt.getHideAnim().get(), this.y + 25.0F + offY, this.moduleColor.darker(0.1F).move((Color)this.white, elmt.getAnim().get()).alpha((1.0F - elmt.getHideAnim().get())));
/* 276 */         elmt.setRect(rect);
/*     */         
/* 278 */         if (elmt.canSettings() && !bind) {
/* 279 */           elmt.setSettingRect(Render.image("icons/menu/setting.png", this.x + offX + 7.5F + bold.get(14).getWidth(elmt.getName()) + 5.0F * elmt.getSettingsAnim().get(), this.y + 26.0F + offY, 8.0F, 8.0F, (Color)rock.getThemes().getTextFirstColor().alpha((anim * elmt.getSettingsAnim().get()))));
/*     */         }
/* 281 */         offX = prevX;
/* 282 */         offY = prevY;
/*     */         
/* 284 */         offX += (rect.getWidth() + 3.0F) * (1.0F - elmt.getHideAnim().get());
/* 285 */         if (select.getElements().indexOf(elmt) + 1 != select.getElements().size() && offX + bold
/* 286 */           .get(14).getWidth(((Select.Element)select.getElements().get(select.getElements().indexOf(elmt) + 1)).getName()) + 8.0F > this.width - 8.0F) {
/* 287 */           offX = 0.0F;
/* 288 */           offY += 13.0F;
/*     */         } 
/* 290 */         if (elmt.get()) count++; 
/*     */       } 
/* 292 */       String displayCount = "" + count + " из " + count;
/* 293 */       bold.get(14).draw(matrixStack, displayCount, this.x + this.width - bold.get(14).getWidth(displayCount) - 8.5F, this.y + 8.5F, this.moduleColor);
/*     */       
/* 295 */       select.getElements().clear();
/* 296 */       select.getElements().addAll(updated);
/*     */       
/* 298 */       select.setHeight(44.0F + offY, bind); }
/*     */ 
/*     */     
/* 301 */     setting = this.parent; if (setting instanceof Position) { Position position = (Position)setting;
/* 302 */       Round.draw(matrixStack, new Rect(this.x + 8.5F, this.y + 25.0F, this.width - 17.0F, this.width - 17.0F), 4.0F, this.separatorColor);
/*     */       
/* 304 */       position.setHeight(this.width - 17.0F + 34.0F, bind);
/*     */       
/* 306 */       position.getXAnim(bind).animate(bind ? position.getBindX() : position.getX(), 70);
/* 307 */       position.getYAnim(bind).animate(bind ? position.getBindY() : position.getY(), 70);
/*     */       
/* 309 */       if (this.dragPosition == position) {
/* 310 */         if (bind) {
/* 311 */           position.bindX(Hover.getSliderValue(position.getMinX(), position.getMaxX(), this.x + 8.5F, this.width - 17.0F, mouseX));
/* 312 */           position.bindY(Hover.getSliderValue(position.getMinY(), position.getMaxY(), this.y + 25.0F, this.width - 17.0F, mouseY));
/*     */         } else {
/* 314 */           position.x(Hover.getSliderValue(position.getMinX(), position.getMaxX(), this.x + 8.5F, this.width - 17.0F, mouseX));
/* 315 */           position.y(Hover.getSliderValue(position.getMinY(), position.getMaxY(), this.y + 25.0F, this.width - 17.0F, mouseY));
/*     */         } 
/*     */       }
/*     */       float x;
/* 319 */       for (x = 0.1F; x <= 1.0F; x += 0.1F) {
/* 320 */         Round.draw(matrixStack, new Rect(this.x + 10.5F + (this.width - 21.0F) * x, this.y + 27.0F, 1.0F, this.width - 21.0F), 0.0F, this.separatorColor.darker(0.1F));
/*     */       }
/*     */       float y;
/* 323 */       for (y = 0.1F; y <= 1.0F; y += 0.1F) {
/* 324 */         Round.draw(matrixStack, new Rect(this.x + 10.5F, this.y + 27.0F + (this.width - 21.0F) * y, this.width - 21.0F, 1.0F), 0.0F, this.separatorColor.darker(0.1F));
/*     */       }
/*     */       
/* 327 */       Round.draw(matrixStack, new Rect(this.x + 10.5F + (this.width - 21.0F) * Hover.getPercent(position.getXAnim(bind).get(), position.getMinX(), position.getMaxX()), this.y + 27.0F, 1.0F, this.width - 21.0F), 0.0F, this.moduleColor);
/* 328 */       Round.draw(matrixStack, new Rect(this.x + 10.5F, this.y + 27.0F + (this.width - 21.0F) * Hover.getPercent(position.getYAnim(bind).get(), position.getMinY(), position.getMaxY()), this.width - 21.0F, 1.0F), 0.0F, this.moduleColor);
/*     */       
/* 330 */       String display = String.format("%.1f", new Object[] { Float.valueOf(position.getXAnim(bind).get()) }).replace(",", ".") + " : " + String.format("%.1f", new Object[] { Float.valueOf(position.getXAnim(bind).get()) }).replace(",", ".");
/* 331 */       float size = bold.get(12).getWidth(display) + 5.0F;
/*     */       
/* 333 */       Round.draw(matrixStack, new Rect(this.x + this.width - 14.0F + 5.0F - size, this.y + 14.0F - 5.0F, size, 10.0F), 2.0F, this.separatorColor);
/*     */       
/* 335 */       bold.get(12).draw(matrixStack, display, this.x + this.width - 9.5F - bold.get(12).getWidth(display) - 2.5F, this.y + 10.0F, this.moduleColor); }
/*     */   
/*     */   }
/*     */   
/*     */   public boolean clicked(double mouseX, double mouseY, int button, boolean release) {
/* 340 */     return clicked(mouseX, mouseY, button, release, false);
/*     */   }
/*     */   
/*     */   public boolean clicked(double mouseX, double mouseY, int button, boolean release, boolean bind) {
/*     */     try {
/* 345 */       if (this.parent.isHide()) return false; 
/* 346 */       if (release) {
/* 347 */         rock.getClickGui().getWindow().setCanDrag(true);
/* 348 */         this.dragPosition = null;
/* 349 */         this.dragSlider = null;
/*     */       } else {
/*     */         
/* 352 */         if (this.sliderInput != null) this.sliderInput.mouseClicked(mouseX, mouseY, button);
/*     */         
/* 354 */         Setting setting = getParent(); if (setting instanceof Input) { Input input = (Input)setting;
/* 355 */           input.getInput().mouseClicked(mouseX, mouseY, button); }
/*     */         
/* 357 */         if ((button == 2 || button == 1 || this.parent instanceof Binding) && Hover.isHovered(this, mouseX, mouseY) && !(this.parent instanceof Select) && !(this.parent instanceof ColorPicker)) rock.getClickGui().getWindow().getWindows().add(new BindListWindow((Bindable)getParent(), (float)mouseX, (float)mouseY, 60.0F, 100.0F)); 
/* 358 */         setting = this.parent; if (setting instanceof ItemSelect) { ItemSelect select = (ItemSelect)setting;
/* 359 */           if (Hover.isHovered(this.x, this.y, this.width, this.height, (float)mouseX, (float)mouseY)) {
/* 360 */             float width = 150.0F;
/* 361 */             float x = (float)((mouseX + width > sr.getScaledWidth()) ? (mouseX - width) : mouseX);
/*     */             
/* 363 */             rock.getClickGui().getWindow().getWindows().add(new ItemSelectWindow(select, x, (float)mouseY, width, 150.0F));
/*     */           }  }
/*     */         
/* 366 */         if (Hover.isHovered(this, mouseX, mouseY) && button == 0) { setting = this.parent; if (setting instanceof ColorPicker) { ColorPicker picker = (ColorPicker)setting; rock.getClickGui().getWindow().getWindows().add(new PickerWindow(picker, (float)mouseX, (float)mouseY, 135.0F, 100.0F)); }  }
/*     */       
/* 368 */       }  if (button == 0) {
/* 369 */         if (Hover.isHovered(this, mouseX, mouseY)) {
/* 370 */           if (release) {
/* 371 */             Setting setting1 = this.parent; if (setting1 instanceof Select) { Select select = (Select)setting1;
/* 372 */               ArrayList<Select.Element> updated = new ArrayList<>(select.getElements());
/*     */               
/* 374 */               for (Select.Element elmt : select.getElements()) {
/* 375 */                 if (elmt.isDragging()) {
/* 376 */                   elmt.setDragging(false);
/* 377 */                   for (Select.Element other : select.getElements()) {
/* 378 */                     if (elmt.isHide() || 
/* 379 */                       other == elmt)
/*     */                       continue; 
/* 381 */                     double elmtX = elmt.getRect().getX();
/* 382 */                     double elmtY = elmt.getRect().getY();
/* 383 */                     double elmtHeight = elmt.getRect().getHeight();
/* 384 */                     double otherX = other.getRect().getX();
/* 385 */                     double otherY = other.getRect().getY();
/* 386 */                     double otherHeight = other.getRect().getHeight();
/*     */                     
/* 388 */                     if (Hover.isHovered(other.getRect(), mouseX, mouseY)) {
/* 389 */                       int currentIndex = select.getElements().indexOf(elmt);
/* 390 */                       int diff = currentIndex + select.getElements().indexOf(other) - currentIndex;
/*     */                       
/* 392 */                       if (diff < select.getElements().size() && diff >= 0) {
/* 393 */                         updated.remove(elmt);
/* 394 */                         updated.add(diff, elmt);
/*     */                       } 
/*     */                     } 
/*     */                   } 
/*     */                 } 
/*     */               } 
/*     */               
/* 401 */               float offX = 0.0F, offY = 0.0F;
/*     */               
/* 403 */               for (Select.Element elmt : select.getElements()) {
/* 404 */                 if (elmt.isHide())
/* 405 */                   continue;  if (elmt.hasSettings() && elmt.canSettings() && Hover.isHovered(elmt.getSettingRect(), mouseX, mouseY)) {
/* 406 */                   rock.getClickGui().getWindow().getWindows().add(new SettingsWindow((Bindable)elmt, (float)mouseX, (float)mouseY));
/* 407 */                   return true;
/*     */                 } 
/*     */                 
/* 410 */                 Rect rect = new Rect(this.x + offX + 8.5F, this.y + 25.0F + offY, bold.get(14).getWidth(elmt.getName()) + 5.0F + (elmt.canSettings() ? (8.0F * elmt.getSettingsAnim().get()) : 0.0F), 10.0F);
/*     */                 
/* 412 */                 if (Hover.isHovered(rect, mouseX, mouseY) && select.getElements().equals(updated)) {
/* 413 */                   elmt.set(!elmt.get());
/*     */                 }
/*     */                 
/* 416 */                 offX += (rect.getWidth() + 3.0F) * (1.0F - elmt.getHideAnim().get());
/* 417 */                 if (select.getElements().indexOf(elmt) + 1 != select.getElements().size() && offX + bold
/* 418 */                   .get(14).getWidth(((Select.Element)select.getElements().get(select.getElements().indexOf(elmt) + 1)).getName()) + 8.0F > this.width - 8.0F) {
/* 419 */                   offX = 0.0F;
/* 420 */                   offY += 13.0F;
/*     */                 } 
/*     */               } 
/*     */               
/* 424 */               select.getElements().clear();
/* 425 */               select.getElements().addAll(updated); }
/*     */             
/* 427 */             return true;
/*     */           } 
/* 429 */           rock.getClickGui().getWindow().setCanDrag(false);
/*     */           
/* 431 */           if (this.parent.hasSettings() && this.parent.canSettings() && Hover.isHovered(this.parent.getSettingRect(), mouseX, mouseY)) {
/* 432 */             rock.getClickGui().getWindow().getWindows().add(new SettingsWindow((Bindable)this.parent, (float)mouseX, (float)mouseY));
/* 433 */             return true;
/*     */           } 
/*     */           
/* 436 */           Setting setting = this.parent; if (setting instanceof CheckBox) { CheckBox checkbox = (CheckBox)setting;
/* 437 */             if (bind) {
/* 438 */               checkbox.bind(!checkbox.bind());
/*     */             } else {
/* 440 */               checkbox.set(!checkbox.get());
/*     */             }  }
/*     */           
/* 443 */           setting = this.parent; if (setting instanceof Slider) { Slider slider = (Slider)setting;
/* 444 */             if (Hover.isHovered(y(this.y + this.height / 2.0F).height(this.height / 2.0F), mouseX, mouseY)) {
/* 445 */               if (bind) {
/* 446 */                 slider.bind(Hover.getSliderValue(slider.min(), slider.max(), this.x + 8.5F, this.width - 17.0F, mouseX));
/*     */               } else {
/* 448 */                 slider.set(Hover.getSliderValue(slider.min(), slider.max(), this.x + 8.5F, this.width - 17.0F, mouseX));
/* 449 */               }  this.dragSlider = slider;
/*     */             }  }
/*     */ 
/*     */           
/* 453 */           setting = this.parent; if (setting instanceof Position) { Position position = (Position)setting;
/* 454 */             if (bind) {
/* 455 */               position.bindX(Hover.getSliderValue(position.getMinX(), position.getMaxX(), this.x + 8.5F, this.width - 17.0F, mouseX));
/* 456 */               position.bindY(Hover.getSliderValue(position.getMinY(), position.getMaxY(), this.y + 25.0F, this.width - 17.0F, mouseY));
/*     */             } else {
/* 458 */               position.x(Hover.getSliderValue(position.getMinX(), position.getMaxX(), this.x + 8.5F, this.width - 17.0F, mouseX));
/* 459 */               position.y(Hover.getSliderValue(position.getMinY(), position.getMaxY(), this.y + 25.0F, this.width - 17.0F, mouseY));
/*     */             } 
/* 461 */             this.dragPosition = position; }
/*     */ 
/*     */           
/* 464 */           setting = this.parent; if (setting instanceof Mode) { Mode mode = (Mode)setting;
/* 465 */             float offX = 0.0F, offY = 0.0F;
/*     */             
/* 467 */             for (Mode.Element elmt : mode.getElements()) {
/* 468 */               if (elmt.hasSettings() && elmt.canSettings() && Hover.isHovered(elmt.getSettingRect(), mouseX, mouseY)) {
/* 469 */                 rock.getClickGui().getWindow().getWindows().add(new SettingsWindow((Bindable)elmt, (float)mouseX, (float)mouseY));
/* 470 */                 return true;
/*     */               } 
/*     */               
/* 473 */               Rect rect = new Rect(this.x + offX + 8.5F, this.y + 25.0F + offY, bold.get(14).getWidth(elmt.getName()) + 5.0F, 10.0F);
/*     */               
/* 475 */               if (Hover.isHovered(rect, mouseX, mouseY)) {
/* 476 */                 if (bind) {
/* 477 */                   mode.bind(elmt);
/*     */                 } else {
/* 479 */                   mode.set(elmt);
/*     */                 } 
/*     */               }
/* 482 */               offX += bold.get(14).getWidth(elmt.getName()) + 8.0F;
/* 483 */               if (mode.getElements().indexOf(elmt) + 1 != mode.getElements().size() && offX + bold
/* 484 */                 .get(14).getWidth(((Mode.Element)mode.getElements().get(mode.getElements().indexOf(elmt) + 1)).getName()) + 8.0F > this.width - 8.0F) {
/* 485 */                 offX = 0.0F;
/* 486 */                 offY += 13.0F;
/*     */               } 
/*     */             }  }
/*     */ 
/*     */           
/* 491 */           setting = this.parent; if (setting instanceof Select) { Select select = (Select)setting;
/* 492 */             float offX = 0.0F, offY = 0.0F;
/*     */             
/* 494 */             for (Select.Element elmt : select.getElements()) {
/* 495 */               if (elmt.isHide())
/*     */                 continue; 
/* 497 */               Rect rect = new Rect(this.x + offX + 8.5F, this.y + 25.0F + offY, bold.get(14).getWidth(elmt.getName()) + 5.0F + (elmt.canSettings() ? (8.0F * elmt.getSettingsAnim().get()) : 0.0F), 10.0F);
/*     */               
/* 499 */               if (Hover.isHovered(rect, mouseX, mouseY) && select.isDraggable()) {
/* 500 */                 elmt.setDragging(true);
/* 501 */                 elmt.setDragX((int)(offX - mouseX - this.x));
/* 502 */                 elmt.setDragY((int)(offY - mouseY - this.y));
/*     */               } 
/*     */               
/* 505 */               offX += (rect.getWidth() + 3.0F) * (1.0F - elmt.getHideAnim().get());
/* 506 */               if (select.getElements().indexOf(elmt) + 1 != select.getElements().size() && offX + bold
/* 507 */                 .get(14).getWidth(((Select.Element)select.getElements().get(select.getElements().indexOf(elmt) + 1)).getName()) + 8.0F > this.width - 8.0F) {
/* 508 */                 offX = 0.0F;
/* 509 */                 offY += 13.0F;
/*     */               } 
/*     */             }  }
/*     */ 
/*     */           
/* 514 */           setting = this.parent; if (setting instanceof Clickable) { Clickable clickable = (Clickable)setting;
/* 515 */             if (Hover.isHovered((this.x + 8.0F), (this.y + 23.0F), (this.width - 16.0F), 16.0D, mouseX, mouseY)) {
/* 516 */               clickable.get().run();
/*     */             } }
/*     */ 
/*     */ 
/*     */           
/* 521 */           return true;
/*     */         } 
/*     */       } else {
/* 524 */         Setting setting = this.parent; if (setting instanceof Select) { Select select = (Select)setting;
/* 525 */           float offX = 0.0F, offY = 0.0F;
/*     */           
/* 527 */           for (Select.Element elmt : select.getElements()) {
/* 528 */             if (elmt.isHide())
/* 529 */               continue;  Rect rect = new Rect(this.x + offX + 8.5F, this.y + 25.0F + offY, bold.get(14).getWidth(elmt.getName()) + 5.0F, 10.0F);
/*     */             
/* 531 */             if (Hover.isHovered(rect, mouseX, mouseY)) {
/* 532 */               rock.getClickGui().getWindow().getWindows().add(new BindListWindow((Bindable)elmt, (float)mouseX, (float)mouseY, 60.0F, 100.0F));
/*     */             }
/*     */             
/* 535 */             offX += bold.get(14).getWidth(elmt.getName()) + 8.0F;
/* 536 */             if (select.getElements().indexOf(elmt) + 1 != select.getElements().size() && offX + bold
/* 537 */               .get(14).getWidth(((Select.Element)select.getElements().get(select.getElements().indexOf(elmt) + 1)).getName()) + 8.0F > this.width - 8.0F) {
/* 538 */               offX = 0.0F;
/* 539 */               offY += 13.0F;
/*     */             } 
/*     */           }  }
/*     */       
/*     */       } 
/* 544 */     } catch (Exception e) {
/* 545 */       Debugger.print(e);
/*     */     } 
/*     */     
/* 548 */     return false;
/*     */   }
/*     */   
/*     */   public boolean dragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
/* 552 */     return dragged(mouseX, mouseY, button, dragX, dragY, false);
/*     */   }
/*     */   
/*     */   public boolean dragged(double mouseX, double mouseY, int button, double dragX, double dragY, boolean bind) {
/*     */     try {
/* 557 */       if (Hover.isHovered(this, mouseX, mouseY) && button == 0) {
/* 558 */         return true;
/*     */       }
/* 560 */     } catch (Exception e) {
/* 561 */       Debugger.print(e);
/*     */     } 
/* 563 */     return false;
/*     */   }
/*     */   
/*     */   public boolean pressed(int keyCode, int scanCode, int modifiers) {
/* 567 */     if (this.sliderInput != null) this.sliderInput.keyPressed(keyCode, scanCode, modifiers); 
/* 568 */     Setting setting = getParent(); if (setting instanceof Input) { Input input = (Input)setting;
/* 569 */       input.getInput().keyPressed(keyCode, scanCode, modifiers); }
/*     */     
/* 571 */     return false;
/*     */   }
/*     */   
/*     */   public boolean charTyped(char codePoint, int modifiers) {
/* 575 */     if (this.sliderInput != null) this.sliderInput.charTyped(codePoint, modifiers); 
/* 576 */     Setting setting = getParent(); if (setting instanceof Input) { Input input = (Input)setting;
/* 577 */       input.getInput().charTyped(codePoint, modifiers); }
/*     */     
/* 579 */     return false;
/*     */   }
/*     */   
/*     */   public void tick() {
/* 583 */     if (this.sliderInput != null) this.sliderInput.tick(); 
/* 584 */     Setting setting = getParent(); if (setting instanceof Input) { Input input = (Input)setting;
/* 585 */       input.getInput().tick(); }
/*     */   
/*     */   }
/*     */   
/*     */   public float getHeight() {
/* 590 */     return this.parent.getHeight();
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\clickgui\SettingRect.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */