/*     */ package fun.rockstarity.api.render.ui.clickgui;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.events.list.game.inputs.EventKey;
/*     */ import fun.rockstarity.client.modules.render.ClickGui;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.screen.Screen;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TranslationTextComponent;
/*     */ import org.lwjgl.glfw.GLFW;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClickGuiScreen
/*     */   extends Screen
/*     */   implements IAccess
/*     */ {
/*     */   private final ClickGuiWindow window;
/*     */   
/*     */   public ClickGuiWindow getWindow() {
/*  23 */     return this.window;
/*     */   }
/*     */   
/*     */   public ClickGuiScreen() {
/*  27 */     super((ITextComponent)new TranslationTextComponent("Click Gui"));
/*     */     
/*  29 */     float width = 488.0F;
/*  30 */     float height = 318.0F;
/*  31 */     this.window = new ClickGuiWindow((sr.getScaledWidth() / 2) - width / 2.0F, (sr.getScaledHeight() / 2) - height / 2.0F, width, height);
/*  32 */     ClickGuiRenderer.opening.getTimer().reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/*  37 */     RenderSystem.runAsFancy(() -> {
/*     */           this.window.render(matrixStack, mouseX, mouseY, partialTicks);
/*     */           
/*     */           super.render(matrixStack, mouseX, mouseY, partialTicks);
/*     */         });
/*  42 */     boolean up = (GLFW.glfwGetKey(mc.getMainWindow().getHandle(), 265) == 1);
/*  43 */     boolean down = (GLFW.glfwGetKey(mc.getMainWindow().getHandle(), 264) == 1);
/*  44 */     float offset = 0.1F / Math.max(Minecraft.debugFPS, 5.0F) * 500.0F;
/*     */     
/*  46 */     if (up || down) {
/*  47 */       mouseScrolled(mouseX, mouseY, up ? offset : (down ? -offset : 0.0D));
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isPauseScreen() {
/*  52 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean mouseClicked(double mouseX, double mouseY, int button) {
/*  57 */     this.window.clicked(mouseX, mouseY, button);
/*  58 */     return super.mouseClicked(mouseX, mouseY, button);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean mouseReleased(double mouseX, double mouseY, int button) {
/*  63 */     this.window.released(mouseX, mouseY, button);
/*  64 */     return super.mouseClicked(mouseX, mouseY, button);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
/*  69 */     this.window.dragged(mouseX, mouseY, button, dragX, dragY);
/*  70 */     return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
/*  75 */     this.window.pressed(keyCode, scanCode, modifiers);
/*  76 */     if ((keyCode == 256 || ((ClickGui)rock.getModules().get(ClickGui.class)).getBindByKey(new EventKey(keyCode, scanCode, false)).isPresent()) && ClickGuiRenderer.opening.finished()) {
/*  77 */       this.window.close();
/*  78 */       mc.displayGuiScreen(null);
/*  79 */       if (this.window.getInput() != null) this.window.getInput().setFocused2(false); 
/*     */     } 
/*  81 */     return super.keyPressed(keyCode, scanCode, modifiers);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
/*  86 */     this.window.scrolled(mouseX, mouseY, delta);
/*  87 */     return super.mouseScrolled(mouseX, mouseY, delta);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean charTyped(char codePoint, int modifiers) {
/*  92 */     this.window.charTyped(codePoint, modifiers);
/*  93 */     return super.charTyped(codePoint, modifiers);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void tick() {
/*  99 */     this.window.tick();
/* 100 */     super.tick();
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\clickgui\ClickGuiScreen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */