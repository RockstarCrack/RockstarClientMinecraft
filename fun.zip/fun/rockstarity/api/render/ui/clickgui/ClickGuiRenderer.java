/*      */ package fun.rockstarity.api.render.ui.clickgui;
/*      */ 
/*      */ import com.mojang.blaze3d.matrix.MatrixStack;
/*      */ import fun.rockstarity.api.IAccess;
/*      */ import fun.rockstarity.api.helpers.math.Hover;
/*      */ import fun.rockstarity.api.helpers.math.MathUtility;
/*      */ import fun.rockstarity.api.helpers.render.Converter;
/*      */ import fun.rockstarity.api.helpers.render.Gifs;
/*      */ import fun.rockstarity.api.helpers.render.Render;
/*      */ import fun.rockstarity.api.helpers.render.Stencil;
/*      */ import fun.rockstarity.api.helpers.system.TextUtility;
/*      */ import fun.rockstarity.api.modules.Category;
/*      */ import fun.rockstarity.api.modules.Module;
/*      */ import fun.rockstarity.api.modules.settings.Setting;
/*      */ import fun.rockstarity.api.render.animation.Animation;
/*      */ import fun.rockstarity.api.render.animation.Easing;
/*      */ import fun.rockstarity.api.render.color.FixColor;
/*      */ import fun.rockstarity.api.render.color.themes.Style;
/*      */ import fun.rockstarity.api.render.color.themes.Theme;
/*      */ import fun.rockstarity.api.render.cursor.CursorType;
/*      */ import fun.rockstarity.api.render.cursor.CursorUtility;
/*      */ import fun.rockstarity.api.render.shaders.list.Round;
/*      */ import fun.rockstarity.api.render.ui.fonts.FontSize;
/*      */ import fun.rockstarity.api.render.ui.rect.Rect;
/*      */ import fun.rockstarity.api.render.ui.widgets.InputWidget;
/*      */ import fun.rockstarity.api.render.ui.widgets.Window;
/*      */ import fun.rockstarity.api.scripts.Script;
/*      */ import fun.rockstarity.api.secure.Debugger;
/*      */ import fun.rockstarity.client.modules.render.ClickGui;
/*      */ import java.awt.Color;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Comparator;
/*      */ import java.util.List;
/*      */ import net.minecraft.util.math.vector.Vector3d;
/*      */ import net.minecraft.util.text.ITextComponent;
/*      */ import net.minecraft.util.text.TranslationTextComponent;
/*      */ import org.lwjgl.opengl.GL11;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ClickGuiRenderer
/*      */   implements IAccess
/*      */ {
/*      */   FixColor bgColor;
/*      */   FixColor settingsBg;
/*      */   FixColor separatorColor;
/*      */   FixColor moduleColor;
/*      */   FixColor text;
/*      */   FixColor black;
/*      */   FixColor white;
/*      */   
/*      */   public ClickGuiRenderer() {
/*   77 */     this.closePos = Vector3d.ZERO;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   83 */     this.loadedAnimX = 0.0F;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   91 */     this
/*      */ 
/*      */       
/*   94 */       .SORT_METHOD = Comparator.<Object, Comparable>comparing(m -> { Module module = (Module)m; return module.getInfo().name(); }).reversed();
/*      */ 
/*      */     
/*   97 */     this.stencil = true;
/*      */   }
/*   99 */   public static Animation opening = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public static Animation tooltip = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public static Animation rotationESP = (new Animation()).setEasing(Easing.EASE_OUT_CIRC).setSpeed(1000); public static Animation dragAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public static Animation changeCurrentTail = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(500); public static Animation changeCurrent = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public static Animation swapAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public static Animation loadedAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(600); public static Animation upSideAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public static Animation separatorAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public static Animation moveAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public static Animation changeCategoryAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(150); public static Animation hoverCloseAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public static Animation hoverSaveConfigAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public static Animation hoverOpenFolderAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public static Animation hoverSearchAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public static Animation searchAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public static Animation searchFocusedAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public static Animation hoverBindAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public static Animation themesAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public static Animation shadowAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public static Animation avatarHoverAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public static Animation openedAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(400); public void setHovered(SettingRect hovered) { this.hovered = hovered; }
/*      */   private Vector3d closePos;
/*      */   private float yaw;
/*      */   private float pitch;
/*  103 */   private ClickGuiWindow window; private float loadedAnimX; public Vector3d getClosePos() { return this.closePos; } public void setClosePos(Vector3d closePos) { this.closePos = closePos; } public float getYaw() { return this.yaw; } public float getPitch() { return this.pitch; } public float getLoadedAnimX() { return this.loadedAnimX; } public static ArrayList<SettingRect> getSettings() { return settings; } private static final ArrayList<SettingRect> settings = new ArrayList<>(); private static boolean loaded; private static boolean apply; private String loadingAction; private final Comparator<Object> SORT_METHOD; public static boolean isLoaded() { return loaded; } public static boolean isApply() { return apply; } public static void setLoaded(boolean loaded) { ClickGuiRenderer.loaded = loaded; } public static void setApply(boolean apply) { ClickGuiRenderer.apply = apply; } public static GlyphType[] getGlyphes() { return glyphes; } private static final GlyphType[] glyphes = new GlyphType[(Category.values()).length]; private boolean stencil; private SettingRect hovered; public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) { opening.setSpeed(300);
/*  104 */     ClickGui clickGui = (ClickGui)rock.getModules().get(ClickGui.class);
/*  105 */     clickGui.getDarkness().setForward(clickGui.getShadow().get());
/*      */     
/*  107 */     if (!clickGui.getDarkness().finished(false)) {
/*  108 */       Round.draw(matrixStack, new Rect(0.0F, 0.0F, sr.getScaledWidth(), sr.getScaledHeight()), 0.0F, FixColor.BLACK
/*  109 */           .alpha((0.5F * clickGui.getDarkness().get() * opening.get())));
/*      */     }
/*  111 */     this.window = rock.getClickGui().getWindow();
/*      */ 
/*      */ 
/*      */     
/*  115 */     dragAnim.setForward(this.window.isDrag());
/*      */ 
/*      */     
/*  118 */     float modif = 4.0F;
/*      */     
/*  120 */     if (opening.isForward() && mc.player != null) {
/*  121 */       this.yaw = mc.player.rotationYaw * modif;
/*  122 */       this.pitch = mc.player.rotationPitch * modif;
/*      */     } 
/*      */     
/*  125 */     GL11.glPushMatrix();
/*  126 */     GL11.glTranslatef(this.yaw - mc.player.rotationYaw * modif, this.pitch - mc.player.rotationPitch * modif, 0.0F);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  131 */     Render.scale(rock.getClickGui().getWindow().getX() + this.window.getWidth() / 2.0F, this.window
/*  132 */         .getY() + this.window.getHeight() / 2.0F, 0.5F + opening
/*  133 */         .get() * 0.5F);
/*      */ 
/*      */     
/*  136 */     renderWindow(matrixStack, mouseX, mouseY, partialTicks);
/*      */     
/*  138 */     Render.end();
/*      */     
/*  140 */     GL11.glPopMatrix();
/*      */     
/*  142 */     if (this.hovered != null && !this.hovered.getParent().isHide() && this.hovered.getParent().getDesc() != null && 
/*  143 */       !this.hovered.getParent().getDesc().isEmpty() && (this.hovered
/*  144 */       .getY() < this.window.getY() + this.window.getHeight() || 
/*  145 */       !(this.hovered.getParent().getParent() instanceof Module))) {
/*  146 */       FontSize font = bold.get(14);
/*  147 */       String[] words = this.hovered.getParent().getDesc().split(" ");
/*      */       
/*  149 */       float xOff = 0.0F;
/*  150 */       float yOff = 10.0F;
/*  151 */       float maxWidth = 110.0F;
/*  152 */       float height = 10.0F;
/*  153 */       float width = 10.0F;
/*  154 */       float indent = 10.0F;
/*      */       
/*  156 */       for (String word : words) {
/*  157 */         xOff += font.getWidth(word + " ");
/*  158 */         width = Math.max(width, xOff);
/*  159 */         if (xOff > maxWidth && Arrays.<String>asList(words).indexOf(word) != words.length - 1) {
/*  160 */           yOff += 8.0F;
/*  161 */           xOff = 0.0F;
/*      */         } 
/*      */       } 
/*      */       
/*  165 */       height = yOff;
/*  166 */       xOff = 0.0F;
/*  167 */       yOff = 0.0F;
/*      */       
/*  169 */       Render.drawTriangle(this.hovered.getX() + this.hovered.getWidth() + indent + xOff - 6.5F, this.hovered
/*  170 */           .getY() + this.hovered.getHeight() / 2.0F + yOff - height / 2.0F + height / 2.0F, 3.0F, 90.0F, this.bgColor
/*  171 */           .move((Color)this.moduleColor, 0.15F).alpha((this.hovered.getSlowHover().get() * 0.9F)).getRGB());
/*  172 */       Round.draw(matrixStack, new Rect(this.hovered.getX() + this.hovered.getWidth() + indent + xOff - 4.0F, this.hovered
/*  173 */             .getY() + this.hovered.getHeight() / 2.0F + yOff - height / 2.0F - 2.0F, width + 5.0F, height + 4.0F), 5.0F, this.bgColor
/*  174 */           .move((Color)this.moduleColor, 0.15F).alpha((this.hovered.getSlowHover().get() * 0.9F)));
/*      */       
/*  176 */       for (String word : words) {
/*  177 */         font.draw(matrixStack, word, this.hovered.getX() + this.hovered.getWidth() + indent + xOff, this.hovered
/*  178 */             .getY() + this.hovered.getHeight() / 2.0F + yOff - height / 2.0F, this.text
/*  179 */             .alpha(this.hovered.getSlowHover().get()));
/*      */         
/*  181 */         xOff += font.getWidth(word + " ");
/*  182 */         if (xOff > maxWidth) {
/*  183 */           yOff += 8.0F;
/*  184 */           xOff = 0.0F;
/*      */         } 
/*      */       } 
/*      */     }  }
/*      */ 
/*      */   
/*      */   public void renderWindow(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/*  191 */     if (this.window == null) {
/*      */       return;
/*      */     }
/*  194 */     this.bgColor = rock.getThemes().getFirstColor().alpha(opening.get());
/*  195 */     this.settingsBg = rock.getThemes().getSecondColor().alpha(opening.get());
/*  196 */     this.separatorColor = rock.getThemes().getThirdColor().alpha((opening.get() * separatorAnim.get()));
/*  197 */     this.moduleColor = rock.getThemes().getTextSecondColor().alpha((opening.get() * separatorAnim.get()));
/*  198 */     this.text = rock.getThemes().getTextFirstColor().alpha(opening.get());
/*  199 */     this.black = FixColor.BLACK.alpha(opening.get());
/*  200 */     this.white = FixColor.WHITE.alpha(opening.get());
/*      */ 
/*      */     
/*  203 */     Round.draw(matrixStack, this.window, 8.0F, this.bgColor);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  213 */     if (rock.isNewYear()) {
/*  214 */       Stencil.init();
/*  215 */       Round.draw(matrixStack, this.window, 8.0F, this.bgColor);
/*  216 */       Stencil.read(1);
/*      */       
/*  218 */       Render.image("events/snow.png", this.window.getX() - 20.0F, this.window.getY() - 15.0F, 47.0F, 47.0F, (Color)this.bgColor.move((Color)this.text, 0.05F));
/*  219 */       Render.image("events/snow.png", this.window.getX() + 23.0F, this.window.getY() - 13.0F, 32.0F, 32.0F, (Color)this.bgColor.move((Color)this.text, 0.05F));
/*      */ 
/*      */       
/*  222 */       Render.image("events/snow.png", this.window.getX() + this.window.getWidth() + 20.0F - 47.0F, this.window.getY() - 15.0F, 47.0F, 47.0F, (Color)this.bgColor
/*  223 */           .move((Color)this.text, 0.05F));
/*  224 */       Render.image("events/snow.png", this.window.getX() + this.window.getWidth() - 23.0F - 32.0F, this.window.getY() - 13.0F, 32.0F, 32.0F, (Color)this.bgColor
/*  225 */           .move((Color)this.text, 0.05F));
/*      */ 
/*      */       
/*  228 */       Render.image("events/snow.png", this.window.getX() - 20.0F, this.window.getY() + this.window.getHeight() + 15.0F - 47.0F, 47.0F, 47.0F, (Color)this.bgColor
/*  229 */           .move((Color)this.text, 0.05F));
/*  230 */       Render.image("events/snow.png", this.window.getX() + 23.0F, this.window.getY() + this.window.getHeight() + 13.0F - 32.0F, 32.0F, 32.0F, (Color)this.bgColor
/*  231 */           .move((Color)this.text, 0.05F));
/*  232 */       Stencil.finish();
/*      */     } 
/*      */     
/*  235 */     swapAnim.setForward(loaded);
/*  236 */     loadedAnim.setForward(swapAnim.finished());
/*  237 */     upSideAnim.setForward(loadedAnim.finished());
/*  238 */     separatorAnim.setForward(upSideAnim.finished());
/*  239 */     moveAnim.setForward(separatorAnim.finished());
/*      */     
/*  241 */     if (!swapAnim.finished()) {
/*  242 */       this.stencil = true;
/*      */     }
/*      */     
/*  245 */     int i1 = 0;
/*  246 */     boolean canStecil = this.stencil;
/*  247 */     for (Category cat : Category.values()) {
/*  248 */       if (cat.getIndex() == 0) {
/*  249 */         cat.getMoveAnim().setForward(moveAnim.finished());
/*      */       } else {
/*  251 */         cat.getMoveAnim().setForward(Category.values()[i1 - 1].getMoveAnim().finished());
/*      */       } 
/*      */       
/*  254 */       if (canStecil && !cat.getMoveAnim().finished()) {
/*  255 */         canStecil = false;
/*      */       }
/*      */       
/*  258 */       cat.setIndex(i1);
/*  259 */       i1++;
/*      */     } 
/*      */     
/*  262 */     if (canStecil) {
/*  263 */       this.stencil = false;
/*      */     }
/*  265 */     this.loadedAnimX = this.window.getX() + this.window.getWidth() - this.window.getWidth() * loadedAnim.get();
/*      */     
/*  267 */     if (!apply) {
/*  268 */       (new Thread(() -> {
/*      */             this.loadingAction = "Загружаем функции";
/*      */             
/*      */             settings.clear();
/*      */             
/*      */             for (Category cat : Category.values()) {
/*      */               int i = cat.getIndex();
/*      */               
/*      */               glyphes[i] = new GlyphType();
/*      */               
/*      */               List<Module> modules = new ArrayList<>();
/*      */               
/*      */               rock.getModules().values().forEach(());
/*      */               
/*      */               for (Script script : rock.getScriptHandler().getEnabledScripts()) {
/*      */                 script.getScriptModules().forEach(());
/*      */               }
/*      */               
/*      */               modules.sort(this.SORT_METHOD);
/*      */               
/*      */               for (Module module : modules) {
/*      */                 if (module.getInfo().type() == cat) {
/*      */                   if (!glyphes[i].containsKey(Character.valueOf(module.getInfo().name().charAt(0)))) {
/*      */                     glyphes[i].put(Character.valueOf(module.getInfo().name().charAt(0)), new ArrayList<>());
/*      */                   }
/*      */                   
/*      */                   glyphes[i].get(Character.valueOf(module.getInfo().name().charAt(0))).add(module);
/*      */                   for (Setting setting : module.getSettings()) {
/*      */                     settings.add(new SettingRect(setting));
/*      */                   }
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */             this.loadingAction = "Загружаем картиночки";
/*      */             for (Category type : Category.values()) {
/*      */               Converter.getResourceLocation("category/" + type.getName().toLowerCase() + ".png");
/*      */             }
/*      */             Converter.getResourceLocation("category/rockstar.png");
/*      */             Converter.getResourceLocation("icons/bind.png");
/*      */             Converter.getResourceLocation("icons/close.png");
/*      */             Converter.getResourceLocation("category/search.png");
/*      */             Converter.getResourceLocation("icons/checkmark.png");
/*      */             Converter.getResourceLocation(rock.getUser().getAvatar());
/*      */             this.loadingAction = "Читекс загружен :D";
/*      */             try {
/*      */               Thread.sleep(1300L);
/*  314 */             } catch (InterruptedException e) {
/*      */               Debugger.print(e);
/*      */             } 
/*      */             
/*      */             loaded = true;
/*  319 */           })).start();
/*  320 */       apply = true;
/*      */     } 
/*      */     
/*  323 */     if (this.stencil) {
/*  324 */       Stencil.init();
/*  325 */       Round.draw(matrixStack, this.window, 8.0F, this.bgColor);
/*  326 */       Stencil.read(1);
/*      */     }
/*  328 */     else if (mc.currentScreen == rock.getClickGui()) {
/*  329 */       GL11.glEnable(3089);
/*  330 */       Render.scissor((this.window.getX() + this.yaw - mc.player.rotationYaw * 4.0F), (this.window
/*  331 */           .getY() + this.pitch - mc.player.rotationPitch * 4.0F), this.window.getWidth(), this.window.getHeight());
/*      */     } 
/*      */ 
/*      */     
/*  335 */     if (!loaded || !swapAnim.finished()) {
/*  336 */       float anim = -this.window.getWidth() * swapAnim.get();
/*      */       
/*  338 */       if (Gifs.loading != null) {
/*  339 */         Gifs.loading.draw(matrixStack, this.window.getX() + 194.0F + anim, this.window.getY() + 95.0F, 100.0F, 100.0F, opening.get(), 20.0D);
/*      */       }
/*  341 */       String wait = "Пожалуйста, подождите";
/*      */       
/*  343 */       if (bold.loaded(24)) {
/*  344 */         bold.get(24).draw(matrixStack, wait, this.window
/*  345 */             .getX() + this.window.getWidth() / 2.0F - bold.get(24).getWidth(wait) / 2.0F + anim, this.window
/*  346 */             .getY() + 192.0F, this.text);
/*      */       }
/*  348 */       if (bold.loaded(16)) {
/*  349 */         bold.get(16).draw(matrixStack, this.loadingAction, this.window
/*  350 */             .getX() + this.window.getWidth() / 2.0F - bold.get(16).getWidth(this.loadingAction) / 2.0F + anim, this.window
/*  351 */             .getY() + 207.0F, (new FixColor(104.0D, 104.0D, 104.0D)).alpha(opening.get()));
/*      */       }
/*  353 */       if (this.stencil) {
/*  354 */         Stencil.finish();
/*      */       }
/*  356 */       else if (mc.currentScreen == rock.getClickGui()) {
/*  357 */         GL11.glDisable(3089);
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/*  362 */     this.window.setCanDrag(true);
/*      */ 
/*      */     
/*  365 */     renderPanel(matrixStack, mouseX, mouseY, partialTicks);
/*      */ 
/*      */     
/*  368 */     renderModules(matrixStack, mouseX, mouseY, partialTicks);
/*      */     
/*  370 */     renderOpened(matrixStack, mouseX, mouseY, partialTicks);
/*      */ 
/*      */ 
/*      */     
/*  374 */     this; Round.draw(matrixStack, this.window.x(this.window.getX() + 155.0F).width(1.0F).height(this.window.getHeight() - 288.0F * themesAnim.get()), 0.0F, this.separatorColor);
/*      */ 
/*      */     
/*  377 */     renderTab(matrixStack, mouseX, mouseY, partialTicks);
/*      */     
/*  379 */     if (this.stencil) {
/*  380 */       Stencil.finish();
/*      */     }
/*  382 */     else if (mc.currentScreen == rock.getClickGui()) {
/*  383 */       GL11.glDisable(3089);
/*      */     } 
/*      */     
/*  386 */     if (!tooltip.finished(false)) {
/*  387 */       List<String> lines = TextUtility.wrapText("Тут может быть то, что вам нужно", semibold.get(16), 100.0F);
/*  388 */       float yOff1 = 0.0F;
/*      */       
/*  390 */       Round.draw(matrixStack, new Rect(this.window.getX() + 98.0F, this.window.getY() + 47.5F + yOff1, 20.0F, 1.0F), 5.0F, this.moduleColor
/*  391 */           .alpha((tooltip.get() * opening.get())));
/*      */       
/*  393 */       for (String line : lines) {
/*  394 */         semibold.get(16).draw(matrixStack, line, this.window.getX() + 118.0F, this.window.getY() + 41.0F + yOff1, this.moduleColor
/*  395 */             .alpha((tooltip.get() * opening.get())));
/*  396 */         yOff1 += 9.0F;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void renderPanel(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/*  404 */     float anim1 = 30.0F * Category.values()[0].getMoveAnim().get() - 30.0F;
/*      */ 
/*      */     
/*  407 */     Render.image("category/rockstar.png", this.window.getX() + 9.0F + 30.0F * moveAnim.get() - 30.0F + 3.5F - 1.5F, this.window
/*  408 */         .getY() + 9.5F + 3.5F - 1.5F, 16.0F, 16.0F, (Color)this.text);
/*      */ 
/*      */     
/*  411 */     float yOff = 0.0F;
/*  412 */     for (Category type : Category.values()) {
/*  413 */       float anim = 30.0F * type.getMoveAnim().get() - 30.0F;
/*      */       
/*  415 */       if (Hover.isHovered((this.window.getX() + 8.0F + anim), (this.window.getY() + 49.0F + yOff), 21.0D, 21.0D, mouseX, mouseY)) {
/*  416 */         this.window.setCanDrag(false);
/*      */       }
/*      */       
/*  419 */       type.getHover().setForward(
/*  420 */           Hover.isHovered((this.window.getX() + 8.0F + anim), (this.window.getY() + 49.0F + yOff), 21.0D, 21.0D, mouseX, mouseY));
/*  421 */       type.getOpen().setForward((type == this.window.getCurrent()));
/*      */       
/*  423 */       Round.draw(matrixStack, new Rect(this.window.getX() + 8.0F + anim, this.window.getY() + 49.0F + yOff, 21.0F, 21.0F), 4.0F, this.separatorColor);
/*      */       
/*  425 */       Round.draw(matrixStack, new Rect(this.window.getX() + 8.0F + anim, this.window.getY() + 49.0F + yOff, 21.0F, 21.0F), 4.0F, this.text
/*  426 */           .alpha((type == this.window.getCurrent()) ? (0.1F + type.getOpen().get() * 0.05F) : (
/*  427 */             type.getHover().get() * 0.1F)));
/*  428 */       Round.draw(matrixStack, new Rect(this.window.getX() + 9.0F + anim, this.window.getY() + 50.0F + yOff, 19.0F, 19.0F), 3.0F, this.bgColor);
/*      */       
/*  430 */       Render.image("category/" + type.getName().toLowerCase() + ".png", this.window.getX() + 12.0F + anim, this.window
/*  431 */           .getY() + 53.0F + yOff, 13.0F, 13.0F, (Color)this.text);
/*      */       
/*  433 */       type.setIndex((int)(yOff / 24.0F));
/*  434 */       yOff += 24.0F;
/*      */     } 
/*      */ 
/*      */     
/*  438 */     this; float off = avatarHoverAnim.get();
/*      */     
/*  440 */     Rect rect = new Rect(this.window.getX() + 9.0F + 30.0F * moveAnim.get() - 30.0F - off, this.window.getY() + this.window.getHeight() - 30.0F - off, 20.0F + off * 2.0F, 20.0F + off * 2.0F);
/*  441 */     this; avatarHoverAnim.setForward(Hover.isHovered(rect, mouseX, mouseY));
/*  442 */     if (Hover.isHovered(rect, mouseX, mouseY)) {
/*  443 */       CursorUtility.setType(CursorType.HAND);
/*  444 */       this.window.setCanDrag(false);
/*      */     } 
/*      */     
/*  447 */     rock.getUser().drawAvatar(matrixStack, rect.getX(), rect.getY(), rect.getWidth(), 5.0F, opening
/*  448 */         .get() * moveAnim.get());
/*      */ 
/*      */     
/*  451 */     Round.draw(matrixStack, new Rect(this.window.getX() + anim1, this.window.getY() + 51.0F + (24 * this.window.getPrevIndex()) - 24.0F * changeCurrent
/*  452 */           .get() - (
/*  453 */           (changeCurrentTail.get() < 0.0F) ? Math.abs(24.0F * changeCurrentTail.get() - 24.0F * changeCurrent.get()) : 
/*  454 */           0.0F), 2.0F, 
/*  455 */           Math.abs(24.0F * changeCurrentTail.get() - 24.0F * changeCurrent.get()) + 17.0F), 0.0F, 2.0F, 0.0F, 2.0F, 
/*  456 */         Style.getMain().alpha(opening.get()));
/*      */ 
/*      */     
/*  459 */     Round.draw(matrixStack, this.window.x(this.window.getX() + 37.0F).width(1.0F), 0.0F, this.separatorColor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void renderModules(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: pop
/*      */     //   2: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.changeCategoryAnim : Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   5: iconst_0
/*      */     //   6: invokevirtual finished : (Z)Z
/*      */     //   9: ifeq -> 22
/*      */     //   12: aload_0
/*      */     //   13: pop
/*      */     //   14: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.changeCategoryAnim : Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   17: iconst_1
/*      */     //   18: invokevirtual setForward : (Z)Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   21: pop
/*      */     //   22: aload_0
/*      */     //   23: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   26: invokevirtual getPrevIndex : ()I
/*      */     //   29: aload_0
/*      */     //   30: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   33: invokevirtual getCurrent : ()Lfun/rockstarity/api/modules/Category;
/*      */     //   36: invokevirtual getIndex : ()I
/*      */     //   39: if_icmple -> 53
/*      */     //   42: aload_0
/*      */     //   43: pop
/*      */     //   44: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.changeCategoryAnim : Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   47: invokevirtual isForward : ()Z
/*      */     //   50: goto -> 69
/*      */     //   53: aload_0
/*      */     //   54: pop
/*      */     //   55: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.changeCategoryAnim : Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   58: invokevirtual isForward : ()Z
/*      */     //   61: ifne -> 68
/*      */     //   64: iconst_1
/*      */     //   65: goto -> 69
/*      */     //   68: iconst_0
/*      */     //   69: istore #5
/*      */     //   71: iload #5
/*      */     //   73: ifeq -> 103
/*      */     //   76: aload_0
/*      */     //   77: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   80: invokevirtual getHeight : ()F
/*      */     //   83: aload_0
/*      */     //   84: pop
/*      */     //   85: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.changeCategoryAnim : Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   88: invokevirtual get : ()F
/*      */     //   91: fmul
/*      */     //   92: aload_0
/*      */     //   93: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   96: invokevirtual getHeight : ()F
/*      */     //   99: fsub
/*      */     //   100: goto -> 121
/*      */     //   103: aload_0
/*      */     //   104: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   107: invokevirtual getHeight : ()F
/*      */     //   110: fconst_1
/*      */     //   111: aload_0
/*      */     //   112: pop
/*      */     //   113: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.changeCategoryAnim : Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   116: invokevirtual get : ()F
/*      */     //   119: fsub
/*      */     //   120: fmul
/*      */     //   121: fstore #6
/*      */     //   123: aload_0
/*      */     //   124: pop
/*      */     //   125: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.changeCategoryAnim : Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   128: invokevirtual isForward : ()Z
/*      */     //   131: ifne -> 155
/*      */     //   134: aload_0
/*      */     //   135: pop
/*      */     //   136: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.changeCategoryAnim : Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   139: invokevirtual finished : ()Z
/*      */     //   142: ifne -> 155
/*      */     //   145: aload_0
/*      */     //   146: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   149: invokevirtual getPrevCurrent : ()Lfun/rockstarity/api/modules/Category;
/*      */     //   152: goto -> 162
/*      */     //   155: aload_0
/*      */     //   156: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   159: invokevirtual getCurrent : ()Lfun/rockstarity/api/modules/Category;
/*      */     //   162: astore #7
/*      */     //   164: invokestatic glPushMatrix : ()V
/*      */     //   167: fconst_0
/*      */     //   168: aload_0
/*      */     //   169: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   172: invokevirtual getHeight : ()F
/*      */     //   175: fneg
/*      */     //   176: ldc_w 40.0
/*      */     //   179: fsub
/*      */     //   180: aload_0
/*      */     //   181: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   184: invokevirtual getHeight : ()F
/*      */     //   187: fload #6
/*      */     //   189: fadd
/*      */     //   190: ldc_w 40.0
/*      */     //   193: fadd
/*      */     //   194: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.moveAnim : Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   197: invokevirtual get : ()F
/*      */     //   200: fmul
/*      */     //   201: fadd
/*      */     //   202: fconst_0
/*      */     //   203: invokestatic glTranslatef : (FFF)V
/*      */     //   206: aload_0
/*      */     //   207: aload #7
/*      */     //   209: invokevirtual isFullScreenCategory : (Lfun/rockstarity/api/modules/Category;)Z
/*      */     //   212: ifeq -> 345
/*      */     //   215: invokestatic init : ()V
/*      */     //   218: aload_1
/*      */     //   219: new fun/rockstarity/api/render/ui/rect/Rect
/*      */     //   222: dup
/*      */     //   223: aload_0
/*      */     //   224: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   227: invokevirtual getX : ()F
/*      */     //   230: ldc_w 156.0
/*      */     //   233: fadd
/*      */     //   234: ldc_w 118.0
/*      */     //   237: aload_0
/*      */     //   238: pop
/*      */     //   239: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.themesAnim : Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   242: invokevirtual get : ()F
/*      */     //   245: fmul
/*      */     //   246: fsub
/*      */     //   247: aload_0
/*      */     //   248: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   251: invokevirtual getY : ()F
/*      */     //   254: aload_0
/*      */     //   255: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   258: invokevirtual getWidth : ()F
/*      */     //   261: ldc_w 156.0
/*      */     //   264: fsub
/*      */     //   265: ldc_w 118.0
/*      */     //   268: aload_0
/*      */     //   269: pop
/*      */     //   270: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.themesAnim : Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   273: invokevirtual get : ()F
/*      */     //   276: fmul
/*      */     //   277: fadd
/*      */     //   278: ldc_w 29.0
/*      */     //   281: invokespecial <init> : (FFFF)V
/*      */     //   284: fconst_1
/*      */     //   285: getstatic fun/rockstarity/api/render/color/FixColor.RED : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   288: invokestatic draw : (Lcom/mojang/blaze3d/matrix/MatrixStack;Lfun/rockstarity/api/render/ui/rect/Rect;FLfun/rockstarity/api/render/color/FixColor;)V
/*      */     //   291: iconst_1
/*      */     //   292: invokestatic read : (I)V
/*      */     //   295: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.bold : Lfun/rockstarity/api/render/ui/fonts/CustomFont;
/*      */     //   298: bipush #24
/*      */     //   300: invokevirtual get : (I)Lfun/rockstarity/api/render/ui/fonts/FontSize;
/*      */     //   303: aload_1
/*      */     //   304: aload #7
/*      */     //   306: invokevirtual getDisplayName : ()Ljava/lang/String;
/*      */     //   309: aload_0
/*      */     //   310: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   313: invokevirtual getX : ()F
/*      */     //   316: ldc_w 48.0
/*      */     //   319: fadd
/*      */     //   320: aload_0
/*      */     //   321: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   324: invokevirtual getY : ()F
/*      */     //   327: ldc_w 7.0
/*      */     //   330: fadd
/*      */     //   331: aload_0
/*      */     //   332: getfield text : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   335: invokevirtual draw : (Lcom/mojang/blaze3d/matrix/MatrixStack;Ljava/lang/String;FFLfun/rockstarity/api/render/color/FixColor;)Lfun/rockstarity/api/render/ui/rect/Rect;
/*      */     //   338: pop
/*      */     //   339: invokestatic finish : ()V
/*      */     //   342: goto -> 509
/*      */     //   345: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.bold : Lfun/rockstarity/api/render/ui/fonts/CustomFont;
/*      */     //   348: bipush #24
/*      */     //   350: invokevirtual get : (I)Lfun/rockstarity/api/render/ui/fonts/FontSize;
/*      */     //   353: invokevirtual start : ()V
/*      */     //   356: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.bold : Lfun/rockstarity/api/render/ui/fonts/CustomFont;
/*      */     //   359: bipush #24
/*      */     //   361: invokevirtual get : (I)Lfun/rockstarity/api/render/ui/fonts/FontSize;
/*      */     //   364: aload_1
/*      */     //   365: aload #7
/*      */     //   367: invokevirtual getDisplayName : ()Ljava/lang/String;
/*      */     //   370: aload_0
/*      */     //   371: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   374: invokevirtual getX : ()F
/*      */     //   377: ldc_w 48.0
/*      */     //   380: fadd
/*      */     //   381: ldc_w 10.0
/*      */     //   384: aload_0
/*      */     //   385: pop
/*      */     //   386: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.searchFocusedAnim : Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   389: invokevirtual get : ()F
/*      */     //   392: fmul
/*      */     //   393: fsub
/*      */     //   394: aload_0
/*      */     //   395: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   398: invokevirtual getY : ()F
/*      */     //   401: ldc_w 9.0
/*      */     //   404: fadd
/*      */     //   405: aload_0
/*      */     //   406: getfield text : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   409: fconst_1
/*      */     //   410: aload_0
/*      */     //   411: pop
/*      */     //   412: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.searchFocusedAnim : Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   415: invokevirtual get : ()F
/*      */     //   418: fsub
/*      */     //   419: f2d
/*      */     //   420: invokevirtual alpha : (D)Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   423: invokevirtual draw : (Lcom/mojang/blaze3d/matrix/MatrixStack;Ljava/lang/String;FFLfun/rockstarity/api/render/color/FixColor;)Lfun/rockstarity/api/render/ui/rect/Rect;
/*      */     //   426: pop
/*      */     //   427: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.bold : Lfun/rockstarity/api/render/ui/fonts/CustomFont;
/*      */     //   430: bipush #24
/*      */     //   432: invokevirtual get : (I)Lfun/rockstarity/api/render/ui/fonts/FontSize;
/*      */     //   435: aload_1
/*      */     //   436: ldc_w 'Поиск..'
/*      */     //   439: aload_0
/*      */     //   440: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   443: invokevirtual getX : ()F
/*      */     //   446: ldc_w 48.0
/*      */     //   449: fadd
/*      */     //   450: ldc_w 10.0
/*      */     //   453: fadd
/*      */     //   454: ldc_w 10.0
/*      */     //   457: aload_0
/*      */     //   458: pop
/*      */     //   459: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.searchFocusedAnim : Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   462: invokevirtual get : ()F
/*      */     //   465: fmul
/*      */     //   466: fsub
/*      */     //   467: aload_0
/*      */     //   468: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   471: invokevirtual getY : ()F
/*      */     //   474: ldc_w 9.0
/*      */     //   477: fadd
/*      */     //   478: aload_0
/*      */     //   479: getfield text : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   482: aload_0
/*      */     //   483: pop
/*      */     //   484: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.searchFocusedAnim : Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   487: invokevirtual get : ()F
/*      */     //   490: f2d
/*      */     //   491: invokevirtual alpha : (D)Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   494: invokevirtual draw : (Lcom/mojang/blaze3d/matrix/MatrixStack;Ljava/lang/String;FFLfun/rockstarity/api/render/color/FixColor;)Lfun/rockstarity/api/render/ui/rect/Rect;
/*      */     //   497: pop
/*      */     //   498: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.bold : Lfun/rockstarity/api/render/ui/fonts/CustomFont;
/*      */     //   501: bipush #24
/*      */     //   503: invokevirtual get : (I)Lfun/rockstarity/api/render/ui/fonts/FontSize;
/*      */     //   506: invokevirtual end : ()V
/*      */     //   509: new fun/rockstarity/api/render/ui/rect/Rect
/*      */     //   512: dup
/*      */     //   513: aload_0
/*      */     //   514: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   517: invokevirtual getX : ()F
/*      */     //   520: ldc_w 38.0
/*      */     //   523: fadd
/*      */     //   524: aload_0
/*      */     //   525: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   528: invokevirtual getY : ()F
/*      */     //   531: ldc_w 29.0
/*      */     //   534: fadd
/*      */     //   535: ldc_w 118.0
/*      */     //   538: aload_0
/*      */     //   539: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   542: invokevirtual getHeight : ()F
/*      */     //   545: ldc_w 29.0
/*      */     //   548: fsub
/*      */     //   549: invokespecial <init> : (FFFF)V
/*      */     //   552: astore #8
/*      */     //   554: aload_0
/*      */     //   555: getfield stencil : Z
/*      */     //   558: ifeq -> 597
/*      */     //   561: sipush #3089
/*      */     //   564: invokestatic glEnable : (I)V
/*      */     //   567: aload #8
/*      */     //   569: invokevirtual getX : ()F
/*      */     //   572: f2d
/*      */     //   573: aload #8
/*      */     //   575: invokevirtual getY : ()F
/*      */     //   578: f2d
/*      */     //   579: aload #8
/*      */     //   581: invokevirtual getWidth : ()F
/*      */     //   584: f2d
/*      */     //   585: aload #8
/*      */     //   587: invokevirtual getHeight : ()F
/*      */     //   590: f2d
/*      */     //   591: invokestatic scissor : (DDDD)V
/*      */     //   594: goto -> 615
/*      */     //   597: invokestatic init : ()V
/*      */     //   600: aload_1
/*      */     //   601: aload #8
/*      */     //   603: fconst_0
/*      */     //   604: aload_0
/*      */     //   605: getfield separatorColor : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   608: invokestatic draw : (Lcom/mojang/blaze3d/matrix/MatrixStack;Lfun/rockstarity/api/render/ui/rect/Rect;FLfun/rockstarity/api/render/color/FixColor;)V
/*      */     //   611: iconst_1
/*      */     //   612: invokestatic read : (I)V
/*      */     //   615: aload_0
/*      */     //   616: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   619: invokevirtual getScrollValue : ()Lfun/rockstarity/api/render/animation/infinity/InfinityAnimation;
/*      */     //   622: invokevirtual get : ()F
/*      */     //   625: fstore #9
/*      */     //   627: aload #7
/*      */     //   629: getstatic fun/rockstarity/api/modules/Category.SCRIPTS : Lfun/rockstarity/api/modules/Category;
/*      */     //   632: if_acmpne -> 1737
/*      */     //   635: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.rock : Lfun/rockstarity/Rockstar;
/*      */     //   638: invokevirtual getScriptHandler : ()Lfun/rockstarity/api/scripts/ScriptHandler;
/*      */     //   641: invokevirtual getEnabledScripts : ()Ljava/util/List;
/*      */     //   644: invokeinterface isEmpty : ()Z
/*      */     //   649: ifeq -> 939
/*      */     //   652: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.semibold : Lfun/rockstarity/api/render/ui/fonts/CustomFont;
/*      */     //   655: bipush #14
/*      */     //   657: invokevirtual get : (I)Lfun/rockstarity/api/render/ui/fonts/FontSize;
/*      */     //   660: invokevirtual start : ()V
/*      */     //   663: fload #9
/*      */     //   665: ldc_w 7.0
/*      */     //   668: fadd
/*      */     //   669: fstore #9
/*      */     //   671: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.semibold : Lfun/rockstarity/api/render/ui/fonts/CustomFont;
/*      */     //   674: bipush #14
/*      */     //   676: invokevirtual get : (I)Lfun/rockstarity/api/render/ui/fonts/FontSize;
/*      */     //   679: aload_1
/*      */     //   680: ldc_w 'Тут будут отображаться'
/*      */     //   683: aload_0
/*      */     //   684: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   687: invokevirtual getX : ()F
/*      */     //   690: ldc_w 48.0
/*      */     //   693: fadd
/*      */     //   694: aload_0
/*      */     //   695: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   698: invokevirtual getY : ()F
/*      */     //   701: ldc_w 30.0
/*      */     //   704: fadd
/*      */     //   705: fload #9
/*      */     //   707: fadd
/*      */     //   708: aload_0
/*      */     //   709: getfield moduleColor : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   712: invokevirtual draw : (Lcom/mojang/blaze3d/matrix/MatrixStack;Ljava/lang/String;FFLfun/rockstarity/api/render/color/FixColor;)Lfun/rockstarity/api/render/ui/rect/Rect;
/*      */     //   715: pop
/*      */     //   716: fload #9
/*      */     //   718: ldc_w 8.0
/*      */     //   721: fadd
/*      */     //   722: fstore #9
/*      */     //   724: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.semibold : Lfun/rockstarity/api/render/ui/fonts/CustomFont;
/*      */     //   727: bipush #14
/*      */     //   729: invokevirtual get : (I)Lfun/rockstarity/api/render/ui/fonts/FontSize;
/*      */     //   732: aload_1
/*      */     //   733: ldc_w 'модули, созданные'
/*      */     //   736: aload_0
/*      */     //   737: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   740: invokevirtual getX : ()F
/*      */     //   743: ldc_w 48.0
/*      */     //   746: fadd
/*      */     //   747: aload_0
/*      */     //   748: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   751: invokevirtual getY : ()F
/*      */     //   754: ldc_w 30.0
/*      */     //   757: fadd
/*      */     //   758: fload #9
/*      */     //   760: fadd
/*      */     //   761: aload_0
/*      */     //   762: getfield moduleColor : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   765: invokevirtual draw : (Lcom/mojang/blaze3d/matrix/MatrixStack;Ljava/lang/String;FFLfun/rockstarity/api/render/color/FixColor;)Lfun/rockstarity/api/render/ui/rect/Rect;
/*      */     //   768: pop
/*      */     //   769: fload #9
/*      */     //   771: ldc_w 8.0
/*      */     //   774: fadd
/*      */     //   775: fstore #9
/*      */     //   777: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.semibold : Lfun/rockstarity/api/render/ui/fonts/CustomFont;
/*      */     //   780: bipush #14
/*      */     //   782: invokevirtual get : (I)Lfun/rockstarity/api/render/ui/fonts/FontSize;
/*      */     //   785: aload_1
/*      */     //   786: ldc_w 'при помощи скриптов'
/*      */     //   789: aload_0
/*      */     //   790: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   793: invokevirtual getX : ()F
/*      */     //   796: ldc_w 48.0
/*      */     //   799: fadd
/*      */     //   800: aload_0
/*      */     //   801: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   804: invokevirtual getY : ()F
/*      */     //   807: ldc_w 30.0
/*      */     //   810: fadd
/*      */     //   811: fload #9
/*      */     //   813: fadd
/*      */     //   814: aload_0
/*      */     //   815: getfield moduleColor : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   818: invokevirtual draw : (Lcom/mojang/blaze3d/matrix/MatrixStack;Ljava/lang/String;FFLfun/rockstarity/api/render/color/FixColor;)Lfun/rockstarity/api/render/ui/rect/Rect;
/*      */     //   821: pop
/*      */     //   822: fload #9
/*      */     //   824: ldc_w 16.0
/*      */     //   827: fadd
/*      */     //   828: fstore #9
/*      */     //   830: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.semibold : Lfun/rockstarity/api/render/ui/fonts/CustomFont;
/*      */     //   833: bipush #14
/*      */     //   835: invokevirtual get : (I)Lfun/rockstarity/api/render/ui/fonts/FontSize;
/*      */     //   838: aload_1
/*      */     //   839: ldc_w 'Посмотреть список'
/*      */     //   842: aload_0
/*      */     //   843: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   846: invokevirtual getX : ()F
/*      */     //   849: ldc_w 48.0
/*      */     //   852: fadd
/*      */     //   853: aload_0
/*      */     //   854: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   857: invokevirtual getY : ()F
/*      */     //   860: ldc_w 30.0
/*      */     //   863: fadd
/*      */     //   864: fload #9
/*      */     //   866: fadd
/*      */     //   867: aload_0
/*      */     //   868: getfield moduleColor : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   871: invokevirtual draw : (Lcom/mojang/blaze3d/matrix/MatrixStack;Ljava/lang/String;FFLfun/rockstarity/api/render/color/FixColor;)Lfun/rockstarity/api/render/ui/rect/Rect;
/*      */     //   874: pop
/*      */     //   875: fload #9
/*      */     //   877: ldc_w 8.0
/*      */     //   880: fadd
/*      */     //   881: fstore #9
/*      */     //   883: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.semibold : Lfun/rockstarity/api/render/ui/fonts/CustomFont;
/*      */     //   886: bipush #14
/*      */     //   888: invokevirtual get : (I)Lfun/rockstarity/api/render/ui/fonts/FontSize;
/*      */     //   891: aload_1
/*      */     //   892: ldc_w 'скриптов - .lua list'
/*      */     //   895: aload_0
/*      */     //   896: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   899: invokevirtual getX : ()F
/*      */     //   902: ldc_w 48.0
/*      */     //   905: fadd
/*      */     //   906: aload_0
/*      */     //   907: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   910: invokevirtual getY : ()F
/*      */     //   913: ldc_w 30.0
/*      */     //   916: fadd
/*      */     //   917: fload #9
/*      */     //   919: fadd
/*      */     //   920: aload_0
/*      */     //   921: getfield moduleColor : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   924: invokevirtual draw : (Lcom/mojang/blaze3d/matrix/MatrixStack;Ljava/lang/String;FFLfun/rockstarity/api/render/color/FixColor;)Lfun/rockstarity/api/render/ui/rect/Rect;
/*      */     //   927: pop
/*      */     //   928: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.semibold : Lfun/rockstarity/api/render/ui/fonts/CustomFont;
/*      */     //   931: bipush #14
/*      */     //   933: invokevirtual get : (I)Lfun/rockstarity/api/render/ui/fonts/FontSize;
/*      */     //   936: invokevirtual end : ()V
/*      */     //   939: fload #9
/*      */     //   941: fstore #10
/*      */     //   943: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.rock : Lfun/rockstarity/Rockstar;
/*      */     //   946: invokevirtual getScriptHandler : ()Lfun/rockstarity/api/scripts/ScriptHandler;
/*      */     //   949: invokevirtual getEnabledScripts : ()Ljava/util/List;
/*      */     //   952: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   957: astore #11
/*      */     //   959: aload #11
/*      */     //   961: invokeinterface hasNext : ()Z
/*      */     //   966: ifeq -> 1230
/*      */     //   969: aload #11
/*      */     //   971: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   976: checkcast fun/rockstarity/api/scripts/Script
/*      */     //   979: astore #12
/*      */     //   981: aload #12
/*      */     //   983: invokevirtual getName : ()Ljava/lang/String;
/*      */     //   986: astore #13
/*      */     //   988: aload #12
/*      */     //   990: invokevirtual getScriptModules : ()Ljava/util/ArrayList;
/*      */     //   993: invokevirtual isEmpty : ()Z
/*      */     //   996: ifeq -> 1002
/*      */     //   999: goto -> 959
/*      */     //   1002: aload_1
/*      */     //   1003: new fun/rockstarity/api/render/ui/rect/Rect
/*      */     //   1006: dup
/*      */     //   1007: aload_0
/*      */     //   1008: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   1011: invokevirtual getX : ()F
/*      */     //   1014: ldc_w 37.0
/*      */     //   1017: fadd
/*      */     //   1018: aload_0
/*      */     //   1019: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   1022: invokevirtual getY : ()F
/*      */     //   1025: ldc_w 35.0
/*      */     //   1028: fadd
/*      */     //   1029: fload #9
/*      */     //   1031: fadd
/*      */     //   1032: ldc_w 13.0
/*      */     //   1035: fconst_1
/*      */     //   1036: invokespecial <init> : (FFFF)V
/*      */     //   1039: fconst_0
/*      */     //   1040: aload_0
/*      */     //   1041: getfield separatorColor : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   1044: invokestatic draw : (Lcom/mojang/blaze3d/matrix/MatrixStack;Lfun/rockstarity/api/render/ui/rect/Rect;FLfun/rockstarity/api/render/color/FixColor;)V
/*      */     //   1047: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.bold : Lfun/rockstarity/api/render/ui/fonts/CustomFont;
/*      */     //   1050: bipush #12
/*      */     //   1052: invokevirtual get : (I)Lfun/rockstarity/api/render/ui/fonts/FontSize;
/*      */     //   1055: aload_1
/*      */     //   1056: aload #13
/*      */     //   1058: aload_0
/*      */     //   1059: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   1062: invokevirtual getX : ()F
/*      */     //   1065: ldc_w 49.0
/*      */     //   1068: fadd
/*      */     //   1069: ldc_w 6.5
/*      */     //   1072: fadd
/*      */     //   1073: aload_0
/*      */     //   1074: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   1077: invokevirtual getY : ()F
/*      */     //   1080: ldc_w 31.0
/*      */     //   1083: fadd
/*      */     //   1084: fload #9
/*      */     //   1086: fadd
/*      */     //   1087: aload_0
/*      */     //   1088: getfield moduleColor : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   1091: invokevirtual draw : (Lcom/mojang/blaze3d/matrix/MatrixStack;Ljava/lang/String;FFLfun/rockstarity/api/render/color/FixColor;)Lfun/rockstarity/api/render/ui/rect/Rect;
/*      */     //   1094: pop
/*      */     //   1095: aload_1
/*      */     //   1096: new fun/rockstarity/api/render/ui/rect/Rect
/*      */     //   1099: dup
/*      */     //   1100: aload_0
/*      */     //   1101: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   1104: invokevirtual getX : ()F
/*      */     //   1107: ldc_w 37.0
/*      */     //   1110: fadd
/*      */     //   1111: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.bold : Lfun/rockstarity/api/render/ui/fonts/CustomFont;
/*      */     //   1114: bipush #12
/*      */     //   1116: invokevirtual get : (I)Lfun/rockstarity/api/render/ui/fonts/FontSize;
/*      */     //   1119: aload #13
/*      */     //   1121: invokevirtual getWidth : (Ljava/lang/String;)F
/*      */     //   1124: fadd
/*      */     //   1125: ldc_w 25.0
/*      */     //   1128: fadd
/*      */     //   1129: aload_0
/*      */     //   1130: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   1133: invokevirtual getY : ()F
/*      */     //   1136: ldc_w 35.0
/*      */     //   1139: fadd
/*      */     //   1140: fload #9
/*      */     //   1142: fadd
/*      */     //   1143: ldc_w 118.0
/*      */     //   1146: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.bold : Lfun/rockstarity/api/render/ui/fonts/CustomFont;
/*      */     //   1149: bipush #12
/*      */     //   1151: invokevirtual get : (I)Lfun/rockstarity/api/render/ui/fonts/FontSize;
/*      */     //   1154: aload #13
/*      */     //   1156: invokevirtual getWidth : (Ljava/lang/String;)F
/*      */     //   1159: ldc_w 25.0
/*      */     //   1162: fadd
/*      */     //   1163: fsub
/*      */     //   1164: fconst_1
/*      */     //   1165: invokespecial <init> : (FFFF)V
/*      */     //   1168: fconst_0
/*      */     //   1169: aload_0
/*      */     //   1170: getfield separatorColor : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   1173: invokestatic draw : (Lcom/mojang/blaze3d/matrix/MatrixStack;Lfun/rockstarity/api/render/ui/rect/Rect;FLfun/rockstarity/api/render/color/FixColor;)V
/*      */     //   1176: fload #9
/*      */     //   1178: ldc_w 12.0
/*      */     //   1181: fadd
/*      */     //   1182: fstore #9
/*      */     //   1184: aload #12
/*      */     //   1186: invokevirtual getScriptModules : ()Ljava/util/ArrayList;
/*      */     //   1189: invokevirtual iterator : ()Ljava/util/Iterator;
/*      */     //   1192: astore #14
/*      */     //   1194: aload #14
/*      */     //   1196: invokeinterface hasNext : ()Z
/*      */     //   1201: ifeq -> 1227
/*      */     //   1204: aload #14
/*      */     //   1206: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   1211: checkcast fun/rockstarity/api/modules/Module
/*      */     //   1214: astore #15
/*      */     //   1216: fload #9
/*      */     //   1218: ldc_w 13.0
/*      */     //   1221: fadd
/*      */     //   1222: fstore #9
/*      */     //   1224: goto -> 1194
/*      */     //   1227: goto -> 959
/*      */     //   1230: fload #10
/*      */     //   1232: fstore #9
/*      */     //   1234: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.semibold : Lfun/rockstarity/api/render/ui/fonts/CustomFont;
/*      */     //   1237: bipush #16
/*      */     //   1239: invokevirtual get : (I)Lfun/rockstarity/api/render/ui/fonts/FontSize;
/*      */     //   1242: invokevirtual start : ()V
/*      */     //   1245: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.rock : Lfun/rockstarity/Rockstar;
/*      */     //   1248: invokevirtual getScriptHandler : ()Lfun/rockstarity/api/scripts/ScriptHandler;
/*      */     //   1251: invokevirtual getEnabledScripts : ()Ljava/util/List;
/*      */     //   1254: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   1259: astore #11
/*      */     //   1261: aload #11
/*      */     //   1263: invokeinterface hasNext : ()Z
/*      */     //   1268: ifeq -> 1723
/*      */     //   1271: aload #11
/*      */     //   1273: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   1278: checkcast fun/rockstarity/api/scripts/Script
/*      */     //   1281: astore #12
/*      */     //   1283: aload #12
/*      */     //   1285: invokevirtual getName : ()Ljava/lang/String;
/*      */     //   1288: astore #13
/*      */     //   1290: aload #12
/*      */     //   1292: invokevirtual getScriptModules : ()Ljava/util/ArrayList;
/*      */     //   1295: invokevirtual isEmpty : ()Z
/*      */     //   1298: ifeq -> 1304
/*      */     //   1301: goto -> 1261
/*      */     //   1304: fload #9
/*      */     //   1306: ldc_w 12.0
/*      */     //   1309: fadd
/*      */     //   1310: fstore #9
/*      */     //   1312: aload #12
/*      */     //   1314: invokevirtual getScriptModules : ()Ljava/util/ArrayList;
/*      */     //   1317: invokevirtual iterator : ()Ljava/util/Iterator;
/*      */     //   1320: astore #14
/*      */     //   1322: aload #14
/*      */     //   1324: invokeinterface hasNext : ()Z
/*      */     //   1329: ifeq -> 1720
/*      */     //   1332: aload #14
/*      */     //   1334: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   1339: checkcast fun/rockstarity/api/modules/Module
/*      */     //   1342: astore #15
/*      */     //   1344: aload #8
/*      */     //   1346: aload_0
/*      */     //   1347: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   1350: invokevirtual getX : ()F
/*      */     //   1353: fconst_2
/*      */     //   1354: aload #15
/*      */     //   1356: invokevirtual getHover : ()Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   1359: invokevirtual get : ()F
/*      */     //   1362: fmul
/*      */     //   1363: fadd
/*      */     //   1364: ldc_w 48.5
/*      */     //   1367: fadd
/*      */     //   1368: f2d
/*      */     //   1369: aload_0
/*      */     //   1370: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   1373: invokevirtual getY : ()F
/*      */     //   1376: ldc_w 35.5
/*      */     //   1379: fadd
/*      */     //   1380: fload #9
/*      */     //   1382: fadd
/*      */     //   1383: f2d
/*      */     //   1384: invokestatic isHovered : (Lfun/rockstarity/api/render/ui/rect/Rect;DD)Z
/*      */     //   1387: ifeq -> 1709
/*      */     //   1390: aload_0
/*      */     //   1391: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   1394: invokevirtual getX : ()F
/*      */     //   1397: ldc_w 37.0
/*      */     //   1400: fadd
/*      */     //   1401: f2d
/*      */     //   1402: aload_0
/*      */     //   1403: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   1406: invokevirtual getY : ()F
/*      */     //   1409: ldc_w 30.0
/*      */     //   1412: fadd
/*      */     //   1413: fload #9
/*      */     //   1415: fadd
/*      */     //   1416: f2d
/*      */     //   1417: ldc2_w 118.0
/*      */     //   1420: ldc2_w 13.0
/*      */     //   1423: iload_2
/*      */     //   1424: i2d
/*      */     //   1425: iload_3
/*      */     //   1426: i2d
/*      */     //   1427: invokestatic isHovered : (DDDDDD)Z
/*      */     //   1430: ifeq -> 1441
/*      */     //   1433: aload_0
/*      */     //   1434: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   1437: iconst_0
/*      */     //   1438: invokevirtual setCanDrag : (Z)V
/*      */     //   1441: aload #15
/*      */     //   1443: invokevirtual getOpened : ()Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   1446: aload_0
/*      */     //   1447: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   1450: invokevirtual getOpened : ()Lfun/rockstarity/api/modules/Module;
/*      */     //   1453: aload #15
/*      */     //   1455: if_acmpne -> 1462
/*      */     //   1458: iconst_1
/*      */     //   1459: goto -> 1463
/*      */     //   1462: iconst_0
/*      */     //   1463: invokevirtual setForward : (Z)Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   1466: pop
/*      */     //   1467: aload #15
/*      */     //   1469: invokevirtual getHover : ()Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   1472: aload_0
/*      */     //   1473: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   1476: invokevirtual getX : ()F
/*      */     //   1479: ldc_w 37.0
/*      */     //   1482: fadd
/*      */     //   1483: f2d
/*      */     //   1484: aload_0
/*      */     //   1485: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   1488: invokevirtual getY : ()F
/*      */     //   1491: ldc_w 30.0
/*      */     //   1494: fadd
/*      */     //   1495: fload #9
/*      */     //   1497: fadd
/*      */     //   1498: f2d
/*      */     //   1499: ldc2_w 118.0
/*      */     //   1502: ldc2_w 13.0
/*      */     //   1505: iload_2
/*      */     //   1506: i2d
/*      */     //   1507: iload_3
/*      */     //   1508: i2d
/*      */     //   1509: invokestatic isHovered : (DDDDDD)Z
/*      */     //   1512: invokevirtual setForward : (Z)Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   1515: pop
/*      */     //   1516: aload #15
/*      */     //   1518: invokevirtual getTogglingAnim : ()Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   1521: aload #15
/*      */     //   1523: invokevirtual get : ()Z
/*      */     //   1526: invokevirtual setForward : (Z)Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   1529: pop
/*      */     //   1530: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.semibold : Lfun/rockstarity/api/render/ui/fonts/CustomFont;
/*      */     //   1533: bipush #16
/*      */     //   1535: invokevirtual get : (I)Lfun/rockstarity/api/render/ui/fonts/FontSize;
/*      */     //   1538: aload_1
/*      */     //   1539: aload #15
/*      */     //   1541: invokevirtual getInfo : ()Lfun/rockstarity/api/modules/ModuleInfo;
/*      */     //   1544: invokevirtual name : ()Ljava/lang/String;
/*      */     //   1547: aload_0
/*      */     //   1548: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   1551: invokevirtual getX : ()F
/*      */     //   1554: fconst_2
/*      */     //   1555: aload #15
/*      */     //   1557: invokevirtual getHover : ()Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   1560: invokevirtual get : ()F
/*      */     //   1563: fmul
/*      */     //   1564: fadd
/*      */     //   1565: ldc 4.0
/*      */     //   1567: aload #15
/*      */     //   1569: invokevirtual getOpened : ()Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   1572: invokevirtual get : ()F
/*      */     //   1575: fmul
/*      */     //   1576: fadd
/*      */     //   1577: ldc_w 48.5
/*      */     //   1580: fadd
/*      */     //   1581: aload_0
/*      */     //   1582: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   1585: invokevirtual getY : ()F
/*      */     //   1588: ldc_w 30.5
/*      */     //   1591: fadd
/*      */     //   1592: fload #9
/*      */     //   1594: fadd
/*      */     //   1595: aload_0
/*      */     //   1596: getfield text : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   1599: ldc2_w 0.30000001192092896
/*      */     //   1602: invokevirtual alpha : (D)Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   1605: invokevirtual draw : (Lcom/mojang/blaze3d/matrix/MatrixStack;Ljava/lang/String;FFLfun/rockstarity/api/render/color/FixColor;)Lfun/rockstarity/api/render/ui/rect/Rect;
/*      */     //   1608: pop
/*      */     //   1609: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.semibold : Lfun/rockstarity/api/render/ui/fonts/CustomFont;
/*      */     //   1612: bipush #16
/*      */     //   1614: invokevirtual get : (I)Lfun/rockstarity/api/render/ui/fonts/FontSize;
/*      */     //   1617: aload_1
/*      */     //   1618: aload #15
/*      */     //   1620: invokevirtual getInfo : ()Lfun/rockstarity/api/modules/ModuleInfo;
/*      */     //   1623: invokevirtual name : ()Ljava/lang/String;
/*      */     //   1626: aload_0
/*      */     //   1627: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   1630: invokevirtual getX : ()F
/*      */     //   1633: fconst_2
/*      */     //   1634: aload #15
/*      */     //   1636: invokevirtual getHover : ()Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   1639: invokevirtual get : ()F
/*      */     //   1642: fmul
/*      */     //   1643: fadd
/*      */     //   1644: ldc 4.0
/*      */     //   1646: aload #15
/*      */     //   1648: invokevirtual getOpened : ()Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   1651: invokevirtual get : ()F
/*      */     //   1654: fmul
/*      */     //   1655: fadd
/*      */     //   1656: ldc_w 48.0
/*      */     //   1659: fadd
/*      */     //   1660: aload_0
/*      */     //   1661: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   1664: invokevirtual getY : ()F
/*      */     //   1667: ldc_w 30.0
/*      */     //   1670: fadd
/*      */     //   1671: fload #9
/*      */     //   1673: fadd
/*      */     //   1674: aload_0
/*      */     //   1675: getfield moduleColor : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   1678: fload #9
/*      */     //   1680: f2i
/*      */     //   1681: invokestatic getPoint : (I)Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   1684: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.opening : Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   1687: invokevirtual get : ()F
/*      */     //   1690: f2d
/*      */     //   1691: invokevirtual alpha : (D)Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   1694: aload #15
/*      */     //   1696: invokevirtual getTogglingAnim : ()Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   1699: invokevirtual get : ()F
/*      */     //   1702: invokevirtual move : (Ljava/awt/Color;F)Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   1705: invokevirtual draw : (Lcom/mojang/blaze3d/matrix/MatrixStack;Ljava/lang/String;FFLfun/rockstarity/api/render/color/FixColor;)Lfun/rockstarity/api/render/ui/rect/Rect;
/*      */     //   1708: pop
/*      */     //   1709: fload #9
/*      */     //   1711: ldc_w 13.0
/*      */     //   1714: fadd
/*      */     //   1715: fstore #9
/*      */     //   1717: goto -> 1322
/*      */     //   1720: goto -> 1261
/*      */     //   1723: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.semibold : Lfun/rockstarity/api/render/ui/fonts/CustomFont;
/*      */     //   1726: bipush #16
/*      */     //   1728: invokevirtual get : (I)Lfun/rockstarity/api/render/ui/fonts/FontSize;
/*      */     //   1731: invokevirtual end : ()V
/*      */     //   1734: goto -> 2587
/*      */     //   1737: aload_0
/*      */     //   1738: aload #7
/*      */     //   1740: invokevirtual get : (Lfun/rockstarity/api/modules/Category;)Lfun/rockstarity/api/render/ui/clickgui/GlyphType;
/*      */     //   1743: invokevirtual entrySet : ()Ljava/util/Set;
/*      */     //   1746: astore #10
/*      */     //   1748: fload #9
/*      */     //   1750: fstore #11
/*      */     //   1752: aload #10
/*      */     //   1754: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   1759: astore #12
/*      */     //   1761: aload #12
/*      */     //   1763: invokeinterface hasNext : ()Z
/*      */     //   1768: ifeq -> 2033
/*      */     //   1771: aload #12
/*      */     //   1773: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   1778: checkcast java/util/Map$Entry
/*      */     //   1781: astore #13
/*      */     //   1783: aload #13
/*      */     //   1785: invokeinterface getKey : ()Ljava/lang/Object;
/*      */     //   1790: checkcast java/lang/Character
/*      */     //   1793: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   1796: astore #14
/*      */     //   1798: aload_1
/*      */     //   1799: new fun/rockstarity/api/render/ui/rect/Rect
/*      */     //   1802: dup
/*      */     //   1803: aload_0
/*      */     //   1804: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   1807: invokevirtual getX : ()F
/*      */     //   1810: ldc_w 37.0
/*      */     //   1813: fadd
/*      */     //   1814: aload_0
/*      */     //   1815: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   1818: invokevirtual getY : ()F
/*      */     //   1821: ldc_w 35.0
/*      */     //   1824: fadd
/*      */     //   1825: fload #9
/*      */     //   1827: fadd
/*      */     //   1828: ldc_w 13.0
/*      */     //   1831: fconst_1
/*      */     //   1832: invokespecial <init> : (FFFF)V
/*      */     //   1835: fconst_0
/*      */     //   1836: aload_0
/*      */     //   1837: getfield separatorColor : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   1840: invokestatic draw : (Lcom/mojang/blaze3d/matrix/MatrixStack;Lfun/rockstarity/api/render/ui/rect/Rect;FLfun/rockstarity/api/render/color/FixColor;)V
/*      */     //   1843: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.bold : Lfun/rockstarity/api/render/ui/fonts/CustomFont;
/*      */     //   1846: bipush #12
/*      */     //   1848: invokevirtual get : (I)Lfun/rockstarity/api/render/ui/fonts/FontSize;
/*      */     //   1851: aload_1
/*      */     //   1852: aload #14
/*      */     //   1854: aload_0
/*      */     //   1855: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   1858: invokevirtual getX : ()F
/*      */     //   1861: ldc_w 49.0
/*      */     //   1864: fadd
/*      */     //   1865: ldc_w 6.5
/*      */     //   1868: fadd
/*      */     //   1869: aload_0
/*      */     //   1870: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   1873: invokevirtual getY : ()F
/*      */     //   1876: ldc_w 31.0
/*      */     //   1879: fadd
/*      */     //   1880: fload #9
/*      */     //   1882: fadd
/*      */     //   1883: aload_0
/*      */     //   1884: getfield moduleColor : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   1887: invokevirtual draw : (Lcom/mojang/blaze3d/matrix/MatrixStack;Ljava/lang/String;FFLfun/rockstarity/api/render/color/FixColor;)Lfun/rockstarity/api/render/ui/rect/Rect;
/*      */     //   1890: pop
/*      */     //   1891: aload_1
/*      */     //   1892: new fun/rockstarity/api/render/ui/rect/Rect
/*      */     //   1895: dup
/*      */     //   1896: aload_0
/*      */     //   1897: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   1900: invokevirtual getX : ()F
/*      */     //   1903: ldc_w 37.0
/*      */     //   1906: fadd
/*      */     //   1907: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.bold : Lfun/rockstarity/api/render/ui/fonts/CustomFont;
/*      */     //   1910: bipush #12
/*      */     //   1912: invokevirtual get : (I)Lfun/rockstarity/api/render/ui/fonts/FontSize;
/*      */     //   1915: aload #14
/*      */     //   1917: invokevirtual getWidth : (Ljava/lang/String;)F
/*      */     //   1920: fadd
/*      */     //   1921: ldc_w 25.0
/*      */     //   1924: fadd
/*      */     //   1925: aload_0
/*      */     //   1926: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   1929: invokevirtual getY : ()F
/*      */     //   1932: ldc_w 35.0
/*      */     //   1935: fadd
/*      */     //   1936: fload #9
/*      */     //   1938: fadd
/*      */     //   1939: ldc_w 118.0
/*      */     //   1942: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.bold : Lfun/rockstarity/api/render/ui/fonts/CustomFont;
/*      */     //   1945: bipush #12
/*      */     //   1947: invokevirtual get : (I)Lfun/rockstarity/api/render/ui/fonts/FontSize;
/*      */     //   1950: aload #14
/*      */     //   1952: invokevirtual getWidth : (Ljava/lang/String;)F
/*      */     //   1955: ldc_w 25.0
/*      */     //   1958: fadd
/*      */     //   1959: fsub
/*      */     //   1960: fconst_1
/*      */     //   1961: invokespecial <init> : (FFFF)V
/*      */     //   1964: fconst_0
/*      */     //   1965: aload_0
/*      */     //   1966: getfield separatorColor : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   1969: invokestatic draw : (Lcom/mojang/blaze3d/matrix/MatrixStack;Lfun/rockstarity/api/render/ui/rect/Rect;FLfun/rockstarity/api/render/color/FixColor;)V
/*      */     //   1972: fload #9
/*      */     //   1974: ldc_w 12.0
/*      */     //   1977: fadd
/*      */     //   1978: fstore #9
/*      */     //   1980: aload #13
/*      */     //   1982: invokeinterface getValue : ()Ljava/lang/Object;
/*      */     //   1987: checkcast java/util/List
/*      */     //   1990: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   1995: astore #15
/*      */     //   1997: aload #15
/*      */     //   1999: invokeinterface hasNext : ()Z
/*      */     //   2004: ifeq -> 2030
/*      */     //   2007: aload #15
/*      */     //   2009: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   2014: checkcast fun/rockstarity/api/modules/Module
/*      */     //   2017: astore #16
/*      */     //   2019: fload #9
/*      */     //   2021: ldc_w 13.0
/*      */     //   2024: fadd
/*      */     //   2025: fstore #9
/*      */     //   2027: goto -> 1997
/*      */     //   2030: goto -> 1761
/*      */     //   2033: fload #11
/*      */     //   2035: fstore #9
/*      */     //   2037: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.semibold : Lfun/rockstarity/api/render/ui/fonts/CustomFont;
/*      */     //   2040: bipush #16
/*      */     //   2042: invokevirtual get : (I)Lfun/rockstarity/api/render/ui/fonts/FontSize;
/*      */     //   2045: invokevirtual start : ()V
/*      */     //   2048: aload #10
/*      */     //   2050: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   2055: astore #12
/*      */     //   2057: aload #12
/*      */     //   2059: invokeinterface hasNext : ()Z
/*      */     //   2064: ifeq -> 2576
/*      */     //   2067: aload #12
/*      */     //   2069: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   2074: checkcast java/util/Map$Entry
/*      */     //   2077: astore #13
/*      */     //   2079: aload #13
/*      */     //   2081: invokeinterface getKey : ()Ljava/lang/Object;
/*      */     //   2086: checkcast java/lang/Character
/*      */     //   2089: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   2092: astore #14
/*      */     //   2094: fload #9
/*      */     //   2096: ldc_w 12.0
/*      */     //   2099: fadd
/*      */     //   2100: fstore #9
/*      */     //   2102: aload #13
/*      */     //   2104: invokeinterface getValue : ()Ljava/lang/Object;
/*      */     //   2109: checkcast java/util/List
/*      */     //   2112: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   2117: astore #15
/*      */     //   2119: aload #15
/*      */     //   2121: invokeinterface hasNext : ()Z
/*      */     //   2126: ifeq -> 2573
/*      */     //   2129: aload #15
/*      */     //   2131: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   2136: checkcast fun/rockstarity/api/modules/Module
/*      */     //   2139: astore #16
/*      */     //   2141: aload #8
/*      */     //   2143: aload_0
/*      */     //   2144: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   2147: invokevirtual getX : ()F
/*      */     //   2150: fconst_2
/*      */     //   2151: aload #16
/*      */     //   2153: invokevirtual getHover : ()Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   2156: invokevirtual get : ()F
/*      */     //   2159: fmul
/*      */     //   2160: fadd
/*      */     //   2161: ldc_w 48.5
/*      */     //   2164: fadd
/*      */     //   2165: f2d
/*      */     //   2166: aload_0
/*      */     //   2167: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   2170: invokevirtual getY : ()F
/*      */     //   2173: ldc_w 35.5
/*      */     //   2176: fadd
/*      */     //   2177: fload #9
/*      */     //   2179: fadd
/*      */     //   2180: f2d
/*      */     //   2181: invokestatic isHovered : (Lfun/rockstarity/api/render/ui/rect/Rect;DD)Z
/*      */     //   2184: ifeq -> 2427
/*      */     //   2187: aload_0
/*      */     //   2188: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   2191: invokevirtual getX : ()F
/*      */     //   2194: ldc_w 37.0
/*      */     //   2197: fadd
/*      */     //   2198: f2d
/*      */     //   2199: aload_0
/*      */     //   2200: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   2203: invokevirtual getY : ()F
/*      */     //   2206: ldc_w 30.0
/*      */     //   2209: fadd
/*      */     //   2210: fload #9
/*      */     //   2212: fadd
/*      */     //   2213: f2d
/*      */     //   2214: ldc2_w 118.0
/*      */     //   2217: ldc2_w 13.0
/*      */     //   2220: iload_2
/*      */     //   2221: i2d
/*      */     //   2222: iload_3
/*      */     //   2223: i2d
/*      */     //   2224: invokestatic isHovered : (DDDDDD)Z
/*      */     //   2227: ifeq -> 2238
/*      */     //   2230: aload_0
/*      */     //   2231: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   2234: iconst_0
/*      */     //   2235: invokevirtual setCanDrag : (Z)V
/*      */     //   2238: aload #16
/*      */     //   2240: invokevirtual getOpened : ()Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   2243: aload_0
/*      */     //   2244: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   2247: invokevirtual getOpened : ()Lfun/rockstarity/api/modules/Module;
/*      */     //   2250: aload #16
/*      */     //   2252: if_acmpne -> 2259
/*      */     //   2255: iconst_1
/*      */     //   2256: goto -> 2260
/*      */     //   2259: iconst_0
/*      */     //   2260: invokevirtual setForward : (Z)Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   2263: pop
/*      */     //   2264: aload #16
/*      */     //   2266: invokevirtual getHover : ()Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   2269: aload_0
/*      */     //   2270: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   2273: invokevirtual getX : ()F
/*      */     //   2276: ldc_w 37.0
/*      */     //   2279: fadd
/*      */     //   2280: f2d
/*      */     //   2281: aload_0
/*      */     //   2282: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   2285: invokevirtual getY : ()F
/*      */     //   2288: ldc_w 30.0
/*      */     //   2291: fadd
/*      */     //   2292: fload #9
/*      */     //   2294: fadd
/*      */     //   2295: f2d
/*      */     //   2296: ldc2_w 118.0
/*      */     //   2299: ldc2_w 13.0
/*      */     //   2302: iload_2
/*      */     //   2303: i2d
/*      */     //   2304: iload_3
/*      */     //   2305: i2d
/*      */     //   2306: invokestatic isHovered : (DDDDDD)Z
/*      */     //   2309: invokevirtual setForward : (Z)Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   2312: pop
/*      */     //   2313: aload #16
/*      */     //   2315: invokevirtual getTogglingAnim : ()Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   2318: aload #16
/*      */     //   2320: invokevirtual get : ()Z
/*      */     //   2323: invokevirtual setForward : (Z)Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   2326: pop
/*      */     //   2327: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.semibold : Lfun/rockstarity/api/render/ui/fonts/CustomFont;
/*      */     //   2330: bipush #16
/*      */     //   2332: invokevirtual get : (I)Lfun/rockstarity/api/render/ui/fonts/FontSize;
/*      */     //   2335: aload_1
/*      */     //   2336: aload #16
/*      */     //   2338: invokevirtual getInfo : ()Lfun/rockstarity/api/modules/ModuleInfo;
/*      */     //   2341: invokevirtual name : ()Ljava/lang/String;
/*      */     //   2344: aload_0
/*      */     //   2345: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   2348: invokevirtual getX : ()F
/*      */     //   2351: fconst_2
/*      */     //   2352: aload #16
/*      */     //   2354: invokevirtual getHover : ()Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   2357: invokevirtual get : ()F
/*      */     //   2360: fmul
/*      */     //   2361: fadd
/*      */     //   2362: ldc 4.0
/*      */     //   2364: aload #16
/*      */     //   2366: invokevirtual getOpened : ()Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   2369: invokevirtual get : ()F
/*      */     //   2372: fmul
/*      */     //   2373: fadd
/*      */     //   2374: ldc_w 48.0
/*      */     //   2377: fadd
/*      */     //   2378: aload_0
/*      */     //   2379: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   2382: invokevirtual getY : ()F
/*      */     //   2385: ldc_w 30.0
/*      */     //   2388: fadd
/*      */     //   2389: fload #9
/*      */     //   2391: fadd
/*      */     //   2392: aload_0
/*      */     //   2393: getfield moduleColor : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   2396: fload #9
/*      */     //   2398: f2i
/*      */     //   2399: invokestatic getPoint : (I)Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   2402: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.opening : Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   2405: invokevirtual get : ()F
/*      */     //   2408: f2d
/*      */     //   2409: invokevirtual alpha : (D)Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   2412: aload #16
/*      */     //   2414: invokevirtual getTogglingAnim : ()Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   2417: invokevirtual get : ()F
/*      */     //   2420: invokevirtual move : (Ljava/awt/Color;F)Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   2423: invokevirtual draw : (Lcom/mojang/blaze3d/matrix/MatrixStack;Ljava/lang/String;FFLfun/rockstarity/api/render/color/FixColor;)Lfun/rockstarity/api/render/ui/rect/Rect;
/*      */     //   2426: pop
/*      */     //   2427: iconst_0
/*      */     //   2428: istore #17
/*      */     //   2430: aload #10
/*      */     //   2432: invokeinterface size : ()I
/*      */     //   2437: iconst_1
/*      */     //   2438: if_icmpne -> 2553
/*      */     //   2441: iconst_1
/*      */     //   2442: anewarray java/util/Set
/*      */     //   2445: dup
/*      */     //   2446: iconst_0
/*      */     //   2447: aload #10
/*      */     //   2449: aastore
/*      */     //   2450: invokestatic asList : ([Ljava/lang/Object;)Ljava/util/List;
/*      */     //   2453: iconst_0
/*      */     //   2454: invokeinterface get : (I)Ljava/lang/Object;
/*      */     //   2459: checkcast java/util/Set
/*      */     //   2462: invokeinterface size : ()I
/*      */     //   2467: iconst_1
/*      */     //   2468: if_icmpne -> 2553
/*      */     //   2471: aload #13
/*      */     //   2473: invokeinterface getValue : ()Ljava/lang/Object;
/*      */     //   2478: checkcast java/util/List
/*      */     //   2481: iconst_0
/*      */     //   2482: invokeinterface get : (I)Ljava/lang/Object;
/*      */     //   2487: checkcast fun/rockstarity/api/modules/Module
/*      */     //   2490: invokevirtual getInfo : ()Lfun/rockstarity/api/modules/ModuleInfo;
/*      */     //   2493: invokevirtual module : ()[Ljava/lang/String;
/*      */     //   2496: astore #18
/*      */     //   2498: aload #18
/*      */     //   2500: arraylength
/*      */     //   2501: istore #19
/*      */     //   2503: iconst_0
/*      */     //   2504: istore #20
/*      */     //   2506: iload #20
/*      */     //   2508: iload #19
/*      */     //   2510: if_icmpge -> 2553
/*      */     //   2513: aload #18
/*      */     //   2515: iload #20
/*      */     //   2517: aaload
/*      */     //   2518: astore #21
/*      */     //   2520: aload #21
/*      */     //   2522: invokevirtual toLowerCase : ()Ljava/lang/String;
/*      */     //   2525: aload_0
/*      */     //   2526: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   2529: invokevirtual getInput : ()Lfun/rockstarity/api/render/ui/widgets/InputWidget;
/*      */     //   2532: invokevirtual getText : ()Ljava/lang/String;
/*      */     //   2535: invokevirtual toLowerCase : ()Ljava/lang/String;
/*      */     //   2538: invokevirtual contains : (Ljava/lang/CharSequence;)Z
/*      */     //   2541: ifeq -> 2547
/*      */     //   2544: iconst_1
/*      */     //   2545: istore #17
/*      */     //   2547: iinc #20, 1
/*      */     //   2550: goto -> 2506
/*      */     //   2553: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.tooltip : Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   2556: iload #17
/*      */     //   2558: invokevirtual setForward : (Z)Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   2561: pop
/*      */     //   2562: fload #9
/*      */     //   2564: ldc_w 13.0
/*      */     //   2567: fadd
/*      */     //   2568: fstore #9
/*      */     //   2570: goto -> 2119
/*      */     //   2573: goto -> 2057
/*      */     //   2576: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.semibold : Lfun/rockstarity/api/render/ui/fonts/CustomFont;
/*      */     //   2579: bipush #16
/*      */     //   2581: invokevirtual get : (I)Lfun/rockstarity/api/render/ui/fonts/FontSize;
/*      */     //   2584: invokevirtual end : ()V
/*      */     //   2587: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.opening : Lfun/rockstarity/api/render/animation/Animation;
/*      */     //   2590: invokevirtual isForward : ()Z
/*      */     //   2593: ifeq -> 2740
/*      */     //   2596: aload_1
/*      */     //   2597: new fun/rockstarity/api/render/ui/rect/Rect
/*      */     //   2600: dup
/*      */     //   2601: aload_0
/*      */     //   2602: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   2605: invokevirtual getX : ()F
/*      */     //   2608: ldc_w 38.0
/*      */     //   2611: fadd
/*      */     //   2612: aload_0
/*      */     //   2613: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   2616: invokevirtual getY : ()F
/*      */     //   2619: ldc_w 27.0
/*      */     //   2622: fadd
/*      */     //   2623: ldc_w 118.0
/*      */     //   2626: ldc_w 15.0
/*      */     //   2629: invokespecial <init> : (FFFF)V
/*      */     //   2632: fconst_1
/*      */     //   2633: aload_0
/*      */     //   2634: getfield bgColor : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   2637: aload_0
/*      */     //   2638: getfield bgColor : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   2641: aload_0
/*      */     //   2642: getfield bgColor : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   2645: dconst_0
/*      */     //   2646: invokevirtual alpha : (D)Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   2649: aload_0
/*      */     //   2650: getfield bgColor : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   2653: dconst_0
/*      */     //   2654: invokevirtual alpha : (D)Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   2657: invokestatic draw : (Lcom/mojang/blaze3d/matrix/MatrixStack;Lfun/rockstarity/api/render/ui/rect/Rect;FLfun/rockstarity/api/render/color/FixColor;Lfun/rockstarity/api/render/color/FixColor;Lfun/rockstarity/api/render/color/FixColor;Lfun/rockstarity/api/render/color/FixColor;)V
/*      */     //   2660: aload_1
/*      */     //   2661: new fun/rockstarity/api/render/ui/rect/Rect
/*      */     //   2664: dup
/*      */     //   2665: aload_0
/*      */     //   2666: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   2669: invokevirtual getX : ()F
/*      */     //   2672: ldc_w 38.0
/*      */     //   2675: fadd
/*      */     //   2676: aload_0
/*      */     //   2677: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   2680: invokevirtual getY : ()F
/*      */     //   2683: ldc_w 29.0
/*      */     //   2686: fadd
/*      */     //   2687: aload_0
/*      */     //   2688: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   2691: invokevirtual getHeight : ()F
/*      */     //   2694: fadd
/*      */     //   2695: ldc_w 29.0
/*      */     //   2698: fsub
/*      */     //   2699: ldc_w 15.0
/*      */     //   2702: fsub
/*      */     //   2703: ldc_w 118.0
/*      */     //   2706: ldc_w 15.0
/*      */     //   2709: invokespecial <init> : (FFFF)V
/*      */     //   2712: fconst_1
/*      */     //   2713: aload_0
/*      */     //   2714: getfield bgColor : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   2717: dconst_0
/*      */     //   2718: invokevirtual alpha : (D)Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   2721: aload_0
/*      */     //   2722: getfield bgColor : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   2725: dconst_0
/*      */     //   2726: invokevirtual alpha : (D)Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   2729: aload_0
/*      */     //   2730: getfield bgColor : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   2733: aload_0
/*      */     //   2734: getfield bgColor : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   2737: invokestatic draw : (Lcom/mojang/blaze3d/matrix/MatrixStack;Lfun/rockstarity/api/render/ui/rect/Rect;FLfun/rockstarity/api/render/color/FixColor;Lfun/rockstarity/api/render/color/FixColor;Lfun/rockstarity/api/render/color/FixColor;Lfun/rockstarity/api/render/color/FixColor;)V
/*      */     //   2740: aload_0
/*      */     //   2741: getfield stencil : Z
/*      */     //   2744: ifeq -> 2756
/*      */     //   2747: sipush #3089
/*      */     //   2750: invokestatic glDisable : (I)V
/*      */     //   2753: goto -> 2759
/*      */     //   2756: invokestatic finish : ()V
/*      */     //   2759: fload #9
/*      */     //   2761: aload_0
/*      */     //   2762: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   2765: invokevirtual getScrollValue : ()Lfun/rockstarity/api/render/animation/infinity/InfinityAnimation;
/*      */     //   2768: invokevirtual get : ()F
/*      */     //   2771: fsub
/*      */     //   2772: fstore #9
/*      */     //   2774: aload_0
/*      */     //   2775: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   2778: fload #9
/*      */     //   2780: aload_0
/*      */     //   2781: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   2784: invokevirtual getHeight : ()F
/*      */     //   2787: ldc_w 30.0
/*      */     //   2790: fsub
/*      */     //   2791: fcmpg
/*      */     //   2792: ifge -> 2799
/*      */     //   2795: fconst_0
/*      */     //   2796: goto -> 2816
/*      */     //   2799: fload #9
/*      */     //   2801: fneg
/*      */     //   2802: ldc_w 280.0
/*      */     //   2805: fadd
/*      */     //   2806: aload_0
/*      */     //   2807: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   2810: invokevirtual getScroll : ()F
/*      */     //   2813: invokestatic max : (FF)F
/*      */     //   2816: invokevirtual setScroll : (F)V
/*      */     //   2819: aload_0
/*      */     //   2820: aload #7
/*      */     //   2822: invokevirtual get : (Lfun/rockstarity/api/modules/Category;)Lfun/rockstarity/api/render/ui/clickgui/GlyphType;
/*      */     //   2825: invokevirtual entrySet : ()Ljava/util/Set;
/*      */     //   2828: invokeinterface isEmpty : ()Z
/*      */     //   2833: ifeq -> 2899
/*      */     //   2836: aload_0
/*      */     //   2837: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   2840: invokevirtual isSearching : ()Z
/*      */     //   2843: ifeq -> 2899
/*      */     //   2846: aload #7
/*      */     //   2848: getstatic fun/rockstarity/api/modules/Category.SCRIPTS : Lfun/rockstarity/api/modules/Category;
/*      */     //   2851: if_acmpeq -> 2899
/*      */     //   2854: getstatic fun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer.semibold : Lfun/rockstarity/api/render/ui/fonts/CustomFont;
/*      */     //   2857: bipush #16
/*      */     //   2859: invokevirtual get : (I)Lfun/rockstarity/api/render/ui/fonts/FontSize;
/*      */     //   2862: aload_1
/*      */     //   2863: ldc_w 'Ничего не найдено..'
/*      */     //   2866: aload_0
/*      */     //   2867: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   2870: invokevirtual getX : ()F
/*      */     //   2873: ldc_w 48.0
/*      */     //   2876: fadd
/*      */     //   2877: aload_0
/*      */     //   2878: getfield window : Lfun/rockstarity/api/render/ui/clickgui/ClickGuiWindow;
/*      */     //   2881: invokevirtual getY : ()F
/*      */     //   2884: ldc_w 30.0
/*      */     //   2887: fadd
/*      */     //   2888: fload #9
/*      */     //   2890: fadd
/*      */     //   2891: aload_0
/*      */     //   2892: getfield moduleColor : Lfun/rockstarity/api/render/color/FixColor;
/*      */     //   2895: invokevirtual draw : (Lcom/mojang/blaze3d/matrix/MatrixStack;Ljava/lang/String;FFLfun/rockstarity/api/render/color/FixColor;)Lfun/rockstarity/api/render/ui/rect/Rect;
/*      */     //   2898: pop
/*      */     //   2899: invokestatic end : ()V
/*      */     //   2902: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #464	-> 0
/*      */     //   #465	-> 12
/*      */     //   #467	-> 22
/*      */     //   #468	-> 42
/*      */     //   #469	-> 53
/*      */     //   #470	-> 71
/*      */     //   #471	-> 103
/*      */     //   #472	-> 123
/*      */     //   #473	-> 145
/*      */     //   #474	-> 155
/*      */     //   #476	-> 164
/*      */     //   #477	-> 167
/*      */     //   #480	-> 206
/*      */     //   #481	-> 215
/*      */     //   #482	-> 218
/*      */     //   #483	-> 258
/*      */     //   #482	-> 288
/*      */     //   #484	-> 291
/*      */     //   #485	-> 295
/*      */     //   #486	-> 339
/*      */     //   #488	-> 345
/*      */     //   #489	-> 356
/*      */     //   #490	-> 374
/*      */     //   #491	-> 415
/*      */     //   #489	-> 423
/*      */     //   #492	-> 427
/*      */     //   #493	-> 471
/*      */     //   #492	-> 494
/*      */     //   #494	-> 498
/*      */     //   #497	-> 509
/*      */     //   #498	-> 554
/*      */     //   #499	-> 561
/*      */     //   #500	-> 567
/*      */     //   #502	-> 597
/*      */     //   #503	-> 600
/*      */     //   #504	-> 611
/*      */     //   #507	-> 615
/*      */     //   #508	-> 627
/*      */     //   #509	-> 635
/*      */     //   #510	-> 652
/*      */     //   #512	-> 663
/*      */     //   #513	-> 671
/*      */     //   #514	-> 698
/*      */     //   #513	-> 712
/*      */     //   #515	-> 716
/*      */     //   #516	-> 724
/*      */     //   #518	-> 769
/*      */     //   #519	-> 777
/*      */     //   #521	-> 822
/*      */     //   #523	-> 830
/*      */     //   #525	-> 875
/*      */     //   #526	-> 883
/*      */     //   #527	-> 910
/*      */     //   #526	-> 924
/*      */     //   #529	-> 928
/*      */     //   #532	-> 939
/*      */     //   #534	-> 943
/*      */     //   #535	-> 981
/*      */     //   #537	-> 988
/*      */     //   #538	-> 999
/*      */     //   #541	-> 1002
/*      */     //   #543	-> 1047
/*      */     //   #544	-> 1095
/*      */     //   #545	-> 1104
/*      */     //   #546	-> 1133
/*      */     //   #544	-> 1173
/*      */     //   #549	-> 1176
/*      */     //   #551	-> 1184
/*      */     //   #552	-> 1216
/*      */     //   #553	-> 1224
/*      */     //   #554	-> 1227
/*      */     //   #556	-> 1230
/*      */     //   #558	-> 1234
/*      */     //   #560	-> 1245
/*      */     //   #561	-> 1283
/*      */     //   #563	-> 1290
/*      */     //   #564	-> 1301
/*      */     //   #566	-> 1304
/*      */     //   #569	-> 1312
/*      */     //   #570	-> 1344
/*      */     //   #571	-> 1373
/*      */     //   #570	-> 1384
/*      */     //   #572	-> 1390
/*      */     //   #573	-> 1433
/*      */     //   #576	-> 1441
/*      */     //   #577	-> 1467
/*      */     //   #579	-> 1516
/*      */     //   #581	-> 1530
/*      */     //   #582	-> 1551
/*      */     //   #583	-> 1602
/*      */     //   #581	-> 1605
/*      */     //   #585	-> 1609
/*      */     //   #586	-> 1630
/*      */     //   #587	-> 1681
/*      */     //   #588	-> 1696
/*      */     //   #587	-> 1702
/*      */     //   #585	-> 1705
/*      */     //   #590	-> 1709
/*      */     //   #591	-> 1717
/*      */     //   #592	-> 1720
/*      */     //   #593	-> 1723
/*      */     //   #594	-> 1734
/*      */     //   #595	-> 1737
/*      */     //   #597	-> 1748
/*      */     //   #598	-> 1752
/*      */     //   #599	-> 1783
/*      */     //   #602	-> 1798
/*      */     //   #604	-> 1843
/*      */     //   #605	-> 1891
/*      */     //   #606	-> 1900
/*      */     //   #607	-> 1929
/*      */     //   #605	-> 1969
/*      */     //   #610	-> 1972
/*      */     //   #612	-> 1980
/*      */     //   #613	-> 2019
/*      */     //   #614	-> 2027
/*      */     //   #616	-> 2030
/*      */     //   #618	-> 2033
/*      */     //   #620	-> 2037
/*      */     //   #621	-> 2048
/*      */     //   #622	-> 2079
/*      */     //   #624	-> 2094
/*      */     //   #627	-> 2102
/*      */     //   #628	-> 2141
/*      */     //   #629	-> 2170
/*      */     //   #628	-> 2181
/*      */     //   #630	-> 2187
/*      */     //   #631	-> 2230
/*      */     //   #634	-> 2238
/*      */     //   #635	-> 2264
/*      */     //   #636	-> 2313
/*      */     //   #638	-> 2327
/*      */     //   #639	-> 2348
/*      */     //   #640	-> 2399
/*      */     //   #641	-> 2414
/*      */     //   #640	-> 2420
/*      */     //   #638	-> 2423
/*      */     //   #644	-> 2427
/*      */     //   #646	-> 2430
/*      */     //   #647	-> 2471
/*      */     //   #648	-> 2520
/*      */     //   #649	-> 2544
/*      */     //   #647	-> 2547
/*      */     //   #654	-> 2553
/*      */     //   #656	-> 2562
/*      */     //   #657	-> 2570
/*      */     //   #659	-> 2573
/*      */     //   #660	-> 2576
/*      */     //   #663	-> 2587
/*      */     //   #664	-> 2596
/*      */     //   #665	-> 2646
/*      */     //   #664	-> 2657
/*      */     //   #667	-> 2660
/*      */     //   #668	-> 2669
/*      */     //   #669	-> 2718
/*      */     //   #667	-> 2737
/*      */     //   #672	-> 2740
/*      */     //   #673	-> 2747
/*      */     //   #675	-> 2756
/*      */     //   #678	-> 2759
/*      */     //   #680	-> 2774
/*      */     //   #682	-> 2819
/*      */     //   #683	-> 2854
/*      */     //   #687	-> 2899
/*      */     //   #688	-> 2902
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   1216	8	15	module	Lfun/rockstarity/api/modules/Module;
/*      */     //   988	239	13	name	Ljava/lang/String;
/*      */     //   981	246	12	script	Lfun/rockstarity/api/scripts/Script;
/*      */     //   1344	373	15	module	Lfun/rockstarity/api/modules/Module;
/*      */     //   1290	430	13	name	Ljava/lang/String;
/*      */     //   1283	437	12	script	Lfun/rockstarity/api/scripts/Script;
/*      */     //   943	791	10	startOff	F
/*      */     //   2019	8	16	module	Lfun/rockstarity/api/modules/Module;
/*      */     //   1798	232	14	name	Ljava/lang/String;
/*      */     //   1783	247	13	entry	Ljava/util/Map$Entry;
/*      */     //   2520	27	21	sin	Ljava/lang/String;
/*      */     //   2430	140	17	displayTooltip	Z
/*      */     //   2141	429	16	module	Lfun/rockstarity/api/modules/Module;
/*      */     //   2094	479	14	name	Ljava/lang/String;
/*      */     //   2079	494	13	entry	Ljava/util/Map$Entry;
/*      */     //   1748	839	10	mods	Ljava/util/Set;
/*      */     //   1752	835	11	startOff	F
/*      */     //   0	2903	0	this	Lfun/rockstarity/api/render/ui/clickgui/ClickGuiRenderer;
/*      */     //   0	2903	1	matrixStack	Lcom/mojang/blaze3d/matrix/MatrixStack;
/*      */     //   0	2903	2	mouseX	I
/*      */     //   0	2903	3	mouseY	I
/*      */     //   0	2903	4	partialTicks	F
/*      */     //   71	2832	5	forwardsValue	Z
/*      */     //   123	2780	6	animValue	F
/*      */     //   164	2739	7	current	Lfun/rockstarity/api/modules/Category;
/*      */     //   554	2349	8	modulesArea	Lfun/rockstarity/api/render/ui/rect/Rect;
/*      */     //   627	2276	9	yOff	F
/*      */     // Local variable type table:
/*      */     //   start	length	slot	name	signature
/*      */     //   1783	247	13	entry	Ljava/util/Map$Entry<Ljava/lang/Character;Ljava/util/List<Lfun/rockstarity/api/modules/Module;>;>;
/*      */     //   2079	494	13	entry	Ljava/util/Map$Entry<Ljava/lang/Character;Ljava/util/List<Lfun/rockstarity/api/modules/Module;>;>;
/*      */     //   1748	839	10	mods	Ljava/util/Set<Ljava/util/Map$Entry<Ljava/lang/Character;Ljava/util/List<Lfun/rockstarity/api/modules/Module;>;>;>;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void renderOpened(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/*  691 */     if (this.window.getQueue() != null) {
/*  692 */       openedAnim.setForward(false);
/*  693 */       if (openedAnim.finished(false)) {
/*  694 */         this.window.setOpened(this.window.getQueue());
/*  695 */         this.window.setQueue((Module)null);
/*      */       } 
/*      */     } else {
/*  698 */       openedAnim.setForward((this.window.getOpened() != null));
/*      */     } 
/*  700 */     if (this.window.getOpened() != null) {
/*  701 */       this.window.setPrevOpened(this.window.getOpened());
/*      */     }
/*  703 */     if (!openedAnim.finished()) {
/*      */       
/*  705 */       this; themesAnim.setForward(isFullScreenCategory(this.window.getCurrent()));
/*      */       
/*  707 */       if (!this.stencil) {
/*  708 */         Stencil.init();
/*  709 */         Round.draw(matrixStack, this.window, 8.0F, this.settingsBg);
/*  710 */         Stencil.read(1);
/*      */       } 
/*      */       
/*  713 */       this;
/*      */ 
/*      */       
/*  716 */       this; Round.draw(matrixStack, new Rect(this.loadedAnimX + 156.0F - 118.0F * themesAnim.get(), this.window.getY() + 29.0F * upSideAnim.get(), this.window.getWidth() - 156.0F + 118.0F * themesAnim.get(), this.window
/*  717 */             .getHeight() - 29.0F * upSideAnim.get()), 0.0F, 12.0F - 12.0F * upSideAnim
/*  718 */           .get(), 0.0F, 8.0F, this.settingsBg);
/*      */       
/*  720 */       float anim = 10.0F * upSideAnim.get();
/*      */       
/*  722 */       GL11.glPushMatrix();
/*  723 */       this; GL11.glTranslatef(this.window.getWidth() * themesAnim.get(), 0.0F, 0.0F);
/*      */       
/*  725 */       if (!rock.isNewYear() || this.stencil) {
/*  726 */         this; Gifs.idontknow.draw(matrixStack, this.loadedAnimX + 272.0F, this.window.getY() + 79.0F + 5.0F + anim, 100.0F, 100.0F, opening
/*  727 */             .get(), 20.0D);
/*      */       } 
/*  729 */       String nothing = "Ничего не открыто";
/*  730 */       String desc1 = "После того как вы откроете модуль здесь";
/*  731 */       String desc2 = "будут отображаться настройки";
/*      */       
/*  733 */       bold.get(24).draw(matrixStack, nothing, this.loadedAnimX + 155.0F + (this.window
/*  734 */           .getWidth() - 155.0F) / 2.0F - bold.get(24).getWidth(nothing) / 2.0F, this.window
/*  735 */           .getY() + 184.0F + anim, this.text);
/*      */       
/*  737 */       bold.get(16).start();
/*  738 */       bold.get(16).draw(matrixStack, desc1, this.loadedAnimX + 155.0F + (this.window
/*  739 */           .getWidth() - 155.0F) / 2.0F - bold.get(16).getWidth(desc1) / 2.0F, this.window
/*  740 */           .getY() + 201.0F + anim, this.moduleColor);
/*  741 */       bold.get(16).draw(matrixStack, desc2, this.loadedAnimX + 155.0F + (this.window
/*  742 */           .getWidth() - 155.0F) / 2.0F - bold.get(16).getWidth(desc2) / 2.0F, this.window
/*  743 */           .getY() + 210.0F + anim, this.moduleColor);
/*  744 */       bold.get(16).end();
/*      */       
/*  746 */       Render.end();
/*      */       
/*  748 */       if (rock.isNewYear()) {
/*  749 */         Render.image("events/snow.png", this.window.getX() + this.window.getWidth() + 20.0F - 47.0F, this.window
/*  750 */             .getY() + this.window.getHeight() + 15.0F - 47.0F, 47.0F, 47.0F, (Color)this.bgColor.move((Color)this.text, 0.05F));
/*  751 */         Render.image("events/snow.png", this.window.getX() + this.window.getWidth() - 23.0F - 32.0F, this.window
/*  752 */             .getY() + this.window.getHeight() + 13.0F - 32.0F, 32.0F, 32.0F, (Color)this.bgColor.move((Color)this.text, 0.05F));
/*      */       } 
/*      */       
/*  755 */       if (!this.stencil) {
/*  756 */         Stencil.finish();
/*      */       }
/*  758 */       if (rock.isNewYear() && !isFullScreenCategory(this.window.getCurrent()) && !this.stencil) {
/*  759 */         Stencil.init();
/*  760 */         Round.draw(matrixStack, new Rect(this.loadedAnimX + 272.0F, this.window.getY() + 79.0F + 5.0F + anim, 100.0F, 100.0F), 11.0F, FixColor.WHITE);
/*      */         
/*  762 */         Stencil.read(1);
/*  763 */         this; Gifs.idontknow.draw(matrixStack, this.loadedAnimX + 272.0F, this.window.getY() + 79.0F + 5.0F + anim, 100.0F, 100.0F, opening
/*  764 */             .get(), 20.0D);
/*  765 */         Stencil.finish();
/*      */       } 
/*      */       
/*  768 */       if (this.window.getCurrent() == Category.THEMES || this.window.getPrevCurrent() == Category.THEMES) {
/*  769 */         renderThemes(matrixStack, mouseX, mouseY, partialTicks);
/*      */       }
/*      */     } 
/*  772 */     if (this.window.getPrevOpened() != null && !openedAnim.finished(false)) {
/*  773 */       float anim = this.window.getWidth() - this.window.getWidth() * openedAnim.get();
/*      */       
/*  775 */       if (!this.stencil) {
/*  776 */         Stencil.init();
/*  777 */         Round.draw(matrixStack, new Rect(this.loadedAnimX + 156.0F, this.window
/*  778 */               .getY() + 29.0F * upSideAnim.get(), this.window
/*  779 */               .getWidth() - 156.0F, this.window.getHeight() - 29.0F * upSideAnim.get()), 0.0F, 12.0F - 12.0F * upSideAnim
/*  780 */             .get(), 0.0F, 8.0F, this.settingsBg);
/*  781 */         Stencil.read(1);
/*  782 */         Round.draw(matrixStack, new Rect(this.loadedAnimX + 156.0F + anim, this.window
/*  783 */               .getY() + 29.0F * upSideAnim.get(), this.window
/*  784 */               .getWidth() - 156.0F, this.window.getHeight() - 29.0F * upSideAnim.get()), 0.0F, 12.0F - 12.0F * upSideAnim
/*  785 */             .get(), 0.0F, 8.0F, this.settingsBg);
/*  786 */         Stencil.finish();
/*      */       } else {
/*  788 */         Round.draw(matrixStack, new Rect(this.loadedAnimX + 156.0F + anim, this.window
/*  789 */               .getY() + 29.0F * upSideAnim.get(), this.window
/*  790 */               .getWidth() - 156.0F, this.window.getHeight() - 29.0F * upSideAnim.get()), 0.0F, 12.0F - 12.0F * upSideAnim
/*  791 */             .get(), 0.0F, 8.0F, this.settingsBg);
/*      */       } 
/*      */       
/*  794 */       String openedMod = "Настройки " + this.window.getPrevOpened().getInfo().name();
/*  795 */       bold.get(24).draw(matrixStack, openedMod, this.loadedAnimX + 166.0F + anim, this.window.getY() + 39.0F, this.text);
/*  796 */       bold.get(16).draw(matrixStack, this.window.getPrevOpened().getInfo().desc(), this.loadedAnimX + 166.0F + anim, this.window
/*  797 */           .getY() + 53.5F, this.moduleColor);
/*      */       
/*  799 */       if (Hover.isHovered((this.loadedAnimX + anim + 171.0F + bold.get(24).getWidth(openedMod)), (this.window.getY() + 43.5F), 9.0D, 9.0D, mouseX, mouseY) || 
/*      */         
/*  801 */         Hover.isHovered((this.loadedAnimX + this.window.getWidth() - 21.0F + anim), (this.window.getY() + 43.0F), 9.0D, 9.0D, mouseX, mouseY))
/*      */       {
/*  803 */         this.window.setCanDrag(false);
/*      */       }
/*      */       
/*  806 */       this; hoverBindAnim.setForward(Hover.isHovered((this.loadedAnimX + anim + 171.0F + bold.get(24).getWidth(openedMod)), (this.window
/*  807 */             .getY() + 43.5F), 9.0D, 9.0D, mouseX, mouseY));
/*      */       
/*  809 */       this; Render.image("icons/bind.png", this.loadedAnimX + anim + 171.0F + bold.get(24).getWidth(openedMod), this.window.getY() + 43.5F, 9.0F, 9.0F, (Color)this.text.alpha((1.0F - hoverBindAnim.get() * 0.3F)));
/*      */       
/*  811 */       this; hoverCloseAnim.setForward(Hover.isHovered((this.loadedAnimX + this.window.getWidth() - 21.0F + anim), (this.window
/*  812 */             .getY() + 43.0F), 9.0D, 9.0D, mouseX, mouseY));
/*  813 */       this; Render.image("icons/close.png", this.loadedAnimX + this.window.getWidth() - 21.0F + anim, this.window.getY() + 43.0F, 9.0F, 9.0F, (Color)this.text
/*  814 */           .alpha((1.0F - hoverCloseAnim.get() * 0.3F)));
/*      */       
/*  816 */       if (!this.stencil) {
/*  817 */         Stencil.init();
/*  818 */         Round.draw(matrixStack, new Rect(this.loadedAnimX + 156.0F, this.window
/*  819 */               .getY() + 29.0F * upSideAnim.get() + 40.0F, this.window
/*  820 */               .getWidth() - 156.0F, this.window.getHeight() - 40.0F - 29.0F * upSideAnim.get()), 0.0F, 12.0F - 12.0F * upSideAnim
/*  821 */             .get(), 0.0F, 8.0F, this.settingsBg);
/*  822 */         Stencil.read(1);
/*      */       } 
/*      */       
/*  825 */       if (this.window.getPrevOpened() instanceof fun.rockstarity.client.modules.render.ESP && mc.currentScreen instanceof ClickGuiScreen) {
/*  826 */         this.window.getEspSettings().renderPage(matrixStack, mouseX, mouseY, partialTicks);
/*      */       }
/*  828 */       else if (get(this.window.getPrevOpened()).isEmpty()) {
/*  829 */         float space = 20.0F;
/*      */         
/*  831 */         this; Gifs.sleep.draw(matrixStack, this.loadedAnimX + 272.0F + anim, this.window.getY() + 79.0F + 5.0F + space, 100.0F, 100.0F, opening
/*  832 */             .get(), 20.0D);
/*      */         
/*  834 */         String nothing = "Настроек нет";
/*  835 */         String desc1 = "У этого модуля ещё нет настроек";
/*  836 */         String desc2 = "Может быть когда-нибудь появятся...";
/*      */         
/*  838 */         bold.get(24).draw(matrixStack, nothing, this.loadedAnimX + 155.0F + anim + (this.window.getWidth() - 155.0F) / 2.0F - bold
/*  839 */             .get(24).getWidth(nothing) / 2.0F, this.window.getY() + 184.0F + space, this.text);
/*      */         
/*  841 */         bold.get(16).start();
/*  842 */         bold.get(16).draw(matrixStack, desc1, this.loadedAnimX + 155.0F + anim + (this.window
/*  843 */             .getWidth() - 155.0F) / 2.0F - bold.get(16).getWidth(desc1) / 2.0F, this.window
/*  844 */             .getY() + 201.0F + space, this.moduleColor);
/*  845 */         bold.get(16).draw(matrixStack, desc2, this.loadedAnimX + 155.0F + anim + (this.window
/*  846 */             .getWidth() - 155.0F) / 2.0F - bold.get(16).getWidth(desc2) / 2.0F, this.window
/*  847 */             .getY() + 210.0F + space, this.moduleColor);
/*  848 */         bold.get(16).end();
/*      */       } else {
/*  850 */         int leftY = 0, rightY = 0, column = 0;
/*      */         
/*  852 */         for (SettingRect setting : get(this.window.getPrevOpened())) {
/*  853 */           setting.getHide().setForward(setting.getParent().isHide());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  859 */           if (!setting.getHide().finished()) {
/*  860 */             setting.set(this.loadedAnimX + 166.0F + (160 * column) + anim, this.window
/*  861 */                 .getY() + 74.0F + ((column == 0) ? leftY : rightY) - 8.0F * setting.getHide().get() + this.window
/*  862 */                 .getSettingsScrollValue().get(), 152.0F, setting
/*  863 */                 .getHeight());
/*  864 */             setting.render(matrixStack, mouseX, mouseY, partialTicks, opening
/*  865 */                 .get() * (1.0F - setting.getHide().get()));
/*      */             
/*  867 */             if (setting.getParent().getDesc() != null && 
/*  868 */               Hover.isHovered(this.window.getX(), (this.window.getY() + 30.0F), this.window.getWidth(), (this.window
/*  869 */                 .getHeight() - 30.0F), mouseX, mouseY) && 
/*  870 */               Hover.isHovered(setting, mouseX, mouseY)) {
/*  871 */               boolean canHover = true;
/*      */               
/*  873 */               for (Window window : this.window.getWindows()) {
/*  874 */                 if (!window.canClick(mouseX, mouseY)) canHover = false;
/*      */               
/*      */               } 
/*  877 */               if (canHover) {
/*  878 */                 this.hovered = setting;
/*      */               }
/*      */             } 
/*      */           } 
/*  882 */           if (column == 0) {
/*  883 */             leftY = (int)(leftY + (setting.getHeight() + 9.0F) * (1.0F - setting.getHide().get()));
/*      */           } else {
/*  885 */             rightY = (int)(rightY + (setting.getHeight() + 9.0F) * (1.0F - setting.getHide().get()));
/*      */           } 
/*  887 */           column++;
/*  888 */           if (column > 1) {
/*  889 */             column = 0;
/*      */           }
/*      */         } 
/*  892 */         float yOff = Math.max(leftY, rightY) + this.window.getSettingsScrollValue().get();
/*      */         
/*  894 */         float scroll = Math.max(this.window.getSettingsScroll(), this.window
/*  895 */             .getHeight() - Math.max(leftY, rightY) - 80.0F);
/*      */         
/*  897 */         this.window.setSettingsScroll((Math.max(leftY, rightY) < this.window.getHeight() - 100.0F) ? 0.0F : scroll);
/*      */       } 
/*      */ 
/*      */       
/*  901 */       if (!this.stencil) {
/*  902 */         Stencil.finish();
/*      */       }
/*  904 */       this; shadowAnim.setForward((this.window.getSettingsScroll() != 0.0F));
/*      */ 
/*      */ 
/*      */       
/*  908 */       this;
/*  909 */       this; Round.draw(matrixStack, new Rect(this.loadedAnimX + 156.0F, this.window.getY() + 29.0F * upSideAnim.get() + 40.0F, this.window.getWidth() - 156.0F, (this.window.getHeight() - 40.0F - 29.0F * upSideAnim.get()) / 7.0F), 1.0F, this.settingsBg.alpha(shadowAnim.get()), this.settingsBg.alpha(shadowAnim.get()), this.settingsBg
/*  910 */           .alpha(0.0D), this.settingsBg.alpha(0.0D));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  916 */       this; this; Round.draw(matrixStack, new Rect(this.loadedAnimX + 156.0F, this.window.getY() + 29.0F * upSideAnim.get() + 40.0F + this.window.getHeight() - 40.0F - 29.0F * upSideAnim.get() - (this.window.getHeight() - 40.0F - 29.0F * upSideAnim.get()) / 15.0F, this.window.getWidth() - 156.0F, (this.window.getHeight() - 40.0F - 29.0F * upSideAnim.get()) / 15.0F), 12.0F, this.settingsBg.alpha(0.0D), this.settingsBg.alpha(0.0D), this.settingsBg.alpha(shadowAnim.get()), this.settingsBg
/*  917 */           .alpha(shadowAnim.get()));
/*      */     } 
/*      */   }
/*      */   
/*      */   private void renderTab(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/*  922 */     this; float anim = searchAnim.get();
/*      */ 
/*      */     
/*  925 */     this;
/*      */     
/*  927 */     this; Round.draw(matrixStack, new Rect(this.window.getX() + 156.0F - 118.0F * themesAnim.get(), this.window.getY() + 29.0F - 29.0F - 29.0F * upSideAnim.get(), this.window.getWidth() - 156.0F + 118.0F * themesAnim.get(), 1.0F), 0.0F, this.separatorColor);
/*      */ 
/*      */     
/*  930 */     this; hoverOpenFolderAnim.setForward(Hover.isHovered((this.window.getX() + 449.0F), (this.window
/*  931 */           .getY() + 8.0F - 29.0F - 29.0F * upSideAnim.get()), 13.0D, 13.0D, mouseX, mouseY));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  936 */     this; hoverSearchAnim.setForward(Hover.isHovered((this.window.getX() + 468.0F), (this.window
/*  937 */           .getY() + 9.0F - 29.0F - 29.0F * upSideAnim.get()), 11.0D, 11.0D, mouseX, mouseY));
/*  938 */     if (Hover.isHovered((this.window.getX() + 468.0F), (this.window.getY() + 9.0F - 29.0F - 29.0F * upSideAnim.get()), 11.0D, 11.0D, mouseX, mouseY))
/*      */     {
/*  940 */       this.window.setCanDrag(false);
/*      */     }
/*      */ 
/*      */     
/*  944 */     this; Render.image("category/search.png", this.window.getX() + 468.0F, this.window.getY() + 9.0F - 29.0F - 29.0F * upSideAnim.get(), 11.0F, 11.0F, (Color)this.text
/*  945 */         .alpha(((1.0F - hoverSearchAnim.get() * 0.3F) * (1.0F - anim))));
/*  946 */     this; Render.image("icons/close.png", this.window.getX() + 468.0F, this.window.getY() + 9.0F - 29.0F - 29.0F * upSideAnim.get(), 11.0F, 11.0F, (Color)this.text
/*  947 */         .alpha(((1.0F - hoverSearchAnim.get() * 0.3F) * anim)));
/*      */     
/*  949 */     String buttonTitle = "Сохранить конфиг";
/*      */     
/*  951 */     Rect rect = new Rect(this.window.getX() + 166.0F, this.window.getY() + 7.0F - 29.0F - 29.0F * upSideAnim.get(), MathUtility.interpolate((bold.get(16).getWidth(buttonTitle) + 9.0F), 150.0D, anim), 15.0F);
/*  952 */     this; hoverSaveConfigAnim.setForward(Hover.isHovered(rect, mouseX, mouseY));
/*      */     
/*  954 */     if (Hover.isHovered(rect, mouseX, mouseY)) {
/*  955 */       this.window.setCanDrag(false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  961 */     this; Round.draw(matrixStack, rect, 3.0F, this.separatorColor.move((Color)this.separatorColor.darker(0.1F), hoverSaveConfigAnim.get()));
/*      */     
/*  963 */     this; searchAnim.setForward(this.window.isSearching());
/*      */     
/*  965 */     this; if (!searchAnim.finished()) {
/*  966 */       bold.get(16).draw(matrixStack, buttonTitle, this.window.getX() + 170.0F, this.window
/*  967 */           .getY() + 9.0F - 29.0F - 29.0F * upSideAnim.get() - 5.0F * anim, this.text.alpha((1.0F - anim)));
/*      */       
/*  969 */       this; if (!hoverSaveConfigAnim.finished(false)) {
/*  970 */         String tooltipTitle = "Кнопка сохранит конфиг \"" + rock.getConfigHandler().getCurrent() + "\"";
/*      */ 
/*      */         
/*  973 */         this; Round.draw(matrixStack, new Rect(this.window.getX() + 181.0F + bold.get(16).getWidth(buttonTitle), this.window.getY() + 7.0F - 29.0F - 29.0F * upSideAnim.get(), bold.get(16).getWidth(tooltipTitle) + 9.0F, 15.0F), 3.0F, this.separatorColor
/*  974 */             .alpha((0.7F * hoverSaveConfigAnim.get() * (1.0F - anim))));
/*      */         
/*  976 */         this; bold.get(16).draw(matrixStack, tooltipTitle, this.window.getX() + 185.0F + bold.get(16).getWidth(buttonTitle), this.window.getY() + 9.0F - 29.0F - 29.0F * upSideAnim.get(), this.text
/*  977 */             .alpha((hoverSaveConfigAnim.get() * (1.0F - anim))));
/*      */       } 
/*      */     } 
/*      */     
/*  981 */     this; if (!searchAnim.finished(false)) {
/*      */       
/*  983 */       this; this;
/*      */       
/*  985 */       this; bold.get(16).draw(matrixStack, "Поиск..", this.window.getX() + 170.0F, this.window.getY() + 9.0F - 29.0F - 29.0F * upSideAnim.get() + 5.0F - 5.0F * anim - 5.0F * searchFocusedAnim.get(), this.text.alpha((anim * (1.0F - hoverSaveConfigAnim.get() * 0.5F) * (1.0F - searchFocusedAnim.get()))));
/*      */       
/*  987 */       if (this.window.getInput() == null) {
/*  988 */         this.window.setInput(new InputWidget(bold.get(16), (int)(this.window.getX() + 166.0F), 
/*  989 */               (int)(this.window.getY() + 7.0F - 29.0F - 29.0F * upSideAnim.get()), 150, 15, (ITextComponent)new TranslationTextComponent(""), false));
/*      */       }
/*      */ 
/*      */       
/*  993 */       this; searchFocusedAnim.setForward((this.window.isSearching() && (this.window
/*  994 */           .getInput().isFocused() || !this.window.getInput().getText().isEmpty())));
/*      */       
/*  996 */       (this.window.getInput()).x = (int)(this.window.getX() + 165.0F);
/*  997 */       this; (this.window.getInput())
/*  998 */         .y = (int)(this.window.getY() + 5.0F - 5.0F * searchFocusedAnim.get() + 8.0F - 29.0F - 29.0F * upSideAnim.get());
/*      */       
/* 1000 */       this;
/* 1001 */       this; this.window.getInput().renderButton(matrixStack, mouseX, mouseY, partialTicks, opening.get() * anim * searchFocusedAnim.get());
/*      */     } 
/*      */   }
/*      */   
/*      */   private void renderThemes(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/* 1006 */     Stencil.init();
/* 1007 */     Round.draw(matrixStack, this.window.x(this.window.getX() + 38.0F).width(this.window.getWidth() - 38.0F), 12.0F, this.separatorColor);
/* 1008 */     Stencil.read(1);
/* 1009 */     GL11.glPushMatrix();
/* 1010 */     this; GL11.glTranslatef(this.window.getWidth() * themesAnim.get(), 0.0F, 0.0F);
/*      */     
/* 1012 */     float xOff = 0.0F;
/* 1013 */     for (Theme theme : rock.getThemes()) {
/* 1014 */       theme.getSelectAnimation().setForward((rock.getThemes().getCurrent() == theme));
/*      */       
/* 1016 */       float width = bold.get(18).getWidth(theme.getName()) + 65.0F;
/* 1017 */       float off = theme.getSelectAnimation().get();
/* 1018 */       Round.draw(matrixStack, new Rect(this.window
/* 1019 */             .getX() - this.window.getWidth() + 45.0F + xOff, this.window.getY() + 37.0F, width, 25.0F), 3.0F, this.separatorColor);
/*      */       
/* 1021 */       Round.draw(matrixStack, new Rect(this.window.getX() - this.window.getWidth() + 45.0F + xOff + off, this.window
/* 1022 */             .getY() + 37.0F + off, width - off * 2.0F, 25.0F - off * 2.0F), 3.0F - off, this.bgColor);
/* 1023 */       bold.get(18).draw(matrixStack, theme.getName(), this.window.getX() - this.window.getWidth() + 53.0F + xOff, this.window
/* 1024 */           .getY() + 43.0F, this.text);
/*      */       
/* 1026 */       Round.draw(matrixStack, new Rect(this.window
/* 1027 */             .getX() - this.window.getWidth() + 47.0F + width + xOff - 19.0F, this.window.getY() + 45.0F, 9.0F, 9.0F), 4.5F, this.separatorColor);
/*      */ 
/*      */ 
/*      */       
/* 1031 */       this; Round.draw(matrixStack, new Rect(this.window.getX() - this.window.getWidth() + 47.0F + width + xOff - 19.0F + 1.0F, this.window.getY() + 46.0F, 7.0F, 7.0F), 3.5F, theme.getFirstColor().alpha(opening.get()));
/*      */       
/* 1033 */       Round.draw(matrixStack, new Rect(this.window
/* 1034 */             .getX() - this.window.getWidth() + 47.0F + width + xOff - 30.0F, this.window.getY() + 45.0F, 9.0F, 9.0F), 4.5F, this.separatorColor);
/*      */ 
/*      */ 
/*      */       
/* 1038 */       this; Round.draw(matrixStack, new Rect(this.window.getX() - this.window.getWidth() + 47.0F + width + xOff - 30.0F + 1.0F, this.window.getY() + 46.0F, 7.0F, 7.0F), 3.5F, theme.getSecondColor().alpha(opening.get()));
/*      */       
/* 1040 */       xOff += width + 5.0F;
/*      */     } 
/*      */     
/* 1043 */     xOff = 0.0F;
/* 1044 */     float yOff = 33.0F;
/* 1045 */     for (Style style : Style.values()) {
/* 1046 */       style.getSelectAnimation().setForward((Style.getCurrent() == style));
/*      */       
/* 1048 */       float width = 105.0F;
/* 1049 */       float off = style.getSelectAnimation().get();
/* 1050 */       Round.draw(matrixStack, new Rect(this.window
/* 1051 */             .getX() - this.window.getWidth() + 45.0F + xOff, this.window.getY() + 37.0F + yOff, width, 33.0F), 3.0F, this.separatorColor);
/*      */       
/* 1053 */       Round.draw(matrixStack, new Rect(this.window.getX() - this.window.getWidth() + 45.0F + xOff + off, this.window
/* 1054 */             .getY() + 37.0F + yOff + off, width - off * 2.0F, 33.0F - off * 2.0F), 3.0F - off, this.bgColor);
/* 1055 */       bold.get(16).draw(matrixStack, style.getName(), this.window.getX() - this.window.getWidth() + 53.0F + xOff, this.window
/* 1056 */           .getY() + 43.0F + yOff, this.text);
/*      */       
/* 1058 */       float xOffColors = 0.0F;
/* 1059 */       for (FixColor color : style.getColors()) {
/* 1060 */         Round.draw(matrixStack, new Rect(this.window.getX() - this.window.getWidth() + 52.0F + xOff + xOffColors, this.window
/* 1061 */               .getY() + 55.0F + yOff, 8.0F, 8.0F), 4.0F, this.separatorColor);
/*      */         
/* 1063 */         this; Round.draw(matrixStack, new Rect(this.window.getX() - this.window.getWidth() + 53.0F + xOff + xOffColors, this.window.getY() + 56.0F + yOff, 6.0F, 6.0F), 3.0F, color.alpha(opening.get()));
/*      */         
/* 1065 */         xOffColors += 10.0F;
/*      */       } 
/*      */       
/* 1068 */       xOff += width + 5.0F;
/* 1069 */       if (xOff + width + 5.0F > this.window.getWidth()) {
/* 1070 */         yOff += 38.0F;
/* 1071 */         xOff = 0.0F;
/*      */       } 
/*      */     } 
/*      */     
/* 1075 */     Render.end();
/* 1076 */     Stencil.finish();
/*      */   }
/*      */   
/*      */   private boolean isFullScreenCategory(Category cat) {
/* 1080 */     return (cat == Category.THEMES);
/*      */   }
/*      */   
/*      */   private GlyphType get(Category type) {
/* 1084 */     return this.window.get(type);
/*      */   }
/*      */   
/*      */   private List<SettingRect> get(Module module) {
/* 1088 */     return this.window.get(module);
/*      */   }
/*      */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\clickgui\ClickGuiRenderer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */