/*    */ package fun.rockstarity.api.render.ui.clickgui.esp.elmts;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.binds.Bindable;
/*    */ import fun.rockstarity.api.helpers.game.Server;
/*    */ import fun.rockstarity.api.modules.settings.list.CheckBox;
/*    */ import fun.rockstarity.api.render.ui.clickgui.esp.ESPTextElement;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ import net.minecraft.item.Items;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ESPLeftItem
/*    */   extends ESPTextElement
/*    */ {
/* 18 */   private final CheckBox hideIfEmpty = new CheckBox((Bindable)this, "Не отображать если пусто");
/*    */   
/*    */   public ESPLeftItem() {
/* 21 */     super("Левая рука");
/*    */   }
/*    */ 
/*    */   
/*    */   public void drawOnEntity(MatrixStack matrixStack, LivingEntity entity, float x, float y, float width, float height, float anim) {
/* 26 */     String name = entity.getName().getString();
/* 27 */     String item = (entity.getHeldItemOffhand().getItem() != Items.AIR) ? (Server.isHW() ? entity.getHeldItemOffhand().getItem().getName().getString() : entity.getHeldItemOffhand().getDisplayName().getString()) : "Пусто";
/*    */     
/* 29 */     if (this.hideIfEmpty.get() && (entity.getHeldItemOffhand().isEmpty() || entity.getHeldItemOffhand().getItem() == Items.AIR)) {
/*    */       return;
/*    */     }
/*    */     
/* 33 */     setText(item);
/*    */     
/* 35 */     super.drawOnEntity(matrixStack, entity, x, y, width, height, anim);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\clickgui\esp\elmts\ESPLeftItem.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */