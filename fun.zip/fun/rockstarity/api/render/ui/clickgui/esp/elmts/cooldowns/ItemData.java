/*    */ package fun.rockstarity.api.render.ui.clickgui.esp.elmts.cooldowns;
/*    */ 
/*    */ import fun.rockstarity.api.helpers.math.TimerUtility;
/*    */ import net.minecraft.item.Item;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemData
/*    */ {
/*    */   private final TimerUtility creation;
/*    */   private final long cooldown;
/*    */   private final Item item;
/*    */   
/*    */   public ItemData(long cooldown, Item item) {
/* 17 */     this.creation = new TimerUtility(); this.cooldown = cooldown; this.item = item; } public TimerUtility getCreation() { return this.creation; }
/* 18 */   public long getCooldown() { return this.cooldown; } public Item getItem() {
/* 19 */     return this.item;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\clickgui\esp\elmts\cooldowns\ItemData.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */