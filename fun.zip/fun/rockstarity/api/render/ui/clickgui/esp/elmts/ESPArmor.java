/*     */ package fun.rockstarity.api.render.ui.clickgui.esp.elmts;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import fun.rockstarity.api.binds.Bindable;
/*     */ import fun.rockstarity.api.helpers.game.Server;
/*     */ import fun.rockstarity.api.helpers.render.Render;
/*     */ import fun.rockstarity.api.helpers.render.Stencil;
/*     */ import fun.rockstarity.api.modules.settings.list.CheckBox;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.shaders.list.Round;
/*     */ import fun.rockstarity.api.render.ui.clickgui.esp.ESPElement;
/*     */ import fun.rockstarity.api.render.ui.clickgui.esp.ESPSettings;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.enchantment.Enchantment;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.enchantment.Enchantments;
/*     */ import net.minecraft.entity.LivingEntity;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.Items;
/*     */ import net.minecraft.util.IItemProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ESPArmor
/*     */   extends ESPElement
/*     */ {
/*  33 */   private CheckBox enchants = new CheckBox((Bindable)this, "Зачарования");
/*     */   
/*     */   public ESPArmor() {
/*  36 */     super("Броня");
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawPreview(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks, float anim) {
/*  41 */     super.drawPreview(matrixStack, mouseX, mouseY, partialTicks, anim);
/*     */     
/*  43 */     if (this.activeAnim.finished(false))
/*     */       return; 
/*  45 */     anim *= this.activeAnim.get();
/*     */     
/*  47 */     ESPSettings settings = rock.getClickGui().getWindow().getEspSettings();
/*  48 */     Rect previewRect = settings.getPreviewRect();
/*     */     
/*  50 */     float x = previewRect.getX() + previewRect.getWidth() / 2.0F - 25.0F;
/*  51 */     float y = previewRect.getY() + previewRect.getHeight() / 2.0F - 60.0F;
/*     */     
/*  53 */     if (!this.dragging) {
/*  54 */       switch (this.direction) {
/*     */         case 0:
/*  56 */           this.targetX = x;
/*  57 */           this.targetY = y - 13.2F;
/*     */           break;
/*     */         case 1:
/*  60 */           this.targetX = x;
/*  61 */           this.targetY = y + 122.0F;
/*     */           break;
/*     */         case 2:
/*  64 */           this.targetX = x - 13.2F;
/*  65 */           this.targetY = y;
/*     */           break;
/*     */         case 3:
/*  68 */           this.targetX = x + 52.0F;
/*  69 */           this.targetY = y;
/*     */           break;
/*     */       } 
/*     */     
/*     */     }
/*  74 */     if (!this.dragging) {
/*  75 */       this.targetY += this.yOffset;
/*  76 */       this.targetX += this.xOffset;
/*     */     } 
/*     */     
/*  79 */     if (this.direction < 2) {
/*  80 */       this.rect.setWidth(44.8F);
/*  81 */       this.rect.setHeight(11.2F);
/*     */     } else {
/*  83 */       this.rect.setWidth(11.2F);
/*  84 */       this.rect.setHeight(44.8F);
/*     */     } 
/*     */     
/*  87 */     Stencil.init();
/*  88 */     Round.draw(matrixStack, settings.getPreviewRect(), 7.0F, FixColor.WHITE);
/*  89 */     Stencil.read(1);
/*     */ 
/*     */ 
/*     */     
/*  93 */     ArrayList<ItemStack> stacks = new ArrayList<>();
/*  94 */     stacks.add(new ItemStack((IItemProvider)Items.NETHERITE_BOOTS));
/*  95 */     stacks.add(new ItemStack((IItemProvider)Items.NETHERITE_LEGGINGS));
/*  96 */     stacks.add(new ItemStack((IItemProvider)Items.NETHERITE_CHESTPLATE));
/*  97 */     stacks.add(new ItemStack((IItemProvider)Items.NETHERITE_HELMET));
/*     */     
/*  99 */     float off = 0.0F;
/* 100 */     for (ItemStack stack : stacks) {
/* 101 */       drawIcon(matrixStack, stack, this.targetX, this.targetY, this.direction, off, stacks.size(), 50.0F);
/*     */       
/* 103 */       off += 11.2F;
/*     */     } 
/*     */ 
/*     */     
/* 107 */     Stencil.finish();
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawOnEntity(MatrixStack matrixStack, LivingEntity entity, float x, float y, float width, float height, float anim) {
/* 112 */     anim *= this.activeAnim.get();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     float posX = 0.0F;
/* 121 */     float posY = 0.0F;
/*     */     
/* 123 */     y += this.yOffset;
/* 124 */     x += this.xOffset;
/*     */     
/* 126 */     switch (this.direction) {
/*     */       case 0:
/* 128 */         posX = x;
/* 129 */         posY = y - 13.2F;
/*     */         break;
/*     */       case 1:
/* 132 */         posX = x;
/* 133 */         posY = y + height + 2.0F;
/*     */         break;
/*     */       case 2:
/* 136 */         posX = x - 13.2F;
/* 137 */         posY = y;
/*     */         break;
/*     */       case 3:
/* 140 */         posX = x + width + 2.0F;
/* 141 */         posY = y;
/*     */         break;
/*     */     } 
/*     */     
/* 145 */     ArrayList<ItemStack> stacks = new ArrayList<>();
/* 146 */     entity.getArmorInventoryList().forEach(stack -> {
/*     */           if (!stack.isEmpty()) {
/*     */             stacks.add(stack);
/*     */           }
/*     */         });
/*     */     
/* 152 */     float off = 0.0F;
/* 153 */     for (ItemStack stack : stacks) {
/* 154 */       drawIcon(matrixStack, stack, posX, posY, this.direction, off, stacks.size(), width);
/*     */       
/* 156 */       off += 11.2F;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void drawIcon(MatrixStack matrixStack, ItemStack stack, float x, float y, int direction, float off, int size, float width) {
/* 161 */     size--;
/* 162 */     y += (direction == 2 || direction == 3) ? (size * 11.2F - off) : 0.0F;
/* 163 */     x += (direction == 0 || direction == 1) ? (width / 2.0F - (size + 1) * 11.2F / 2.0F + off) : 0.0F;
/*     */     
/* 165 */     if (Server.isHW()) {
/* 166 */       stack.setCount(1);
/* 167 */       stack.setDamage(0);
/*     */     } 
/*     */     
/* 170 */     Render.drawStackOld(stack, x, y, 0.7F);
/*     */     
/* 172 */     float xOff = 0.0F;
/* 173 */     float yOff = 0.0F;
/*     */     
/* 175 */     if (!Server.isFT() && this.enchants.get()) {
/* 176 */       for (Enchantment ench : EnchantmentHelper.getEnchantments(stack).keySet()) {
/* 177 */         if (ench != Enchantments.PROTECTION && ench != Enchantments.PROTECTION && ench != Enchantments.SHARPNESS && ench != Enchantments.MENDING && ench != Enchantments.FIRE_ASPECT && ench != Enchantments.THORNS && ench != Enchantments.KNOCKBACK && ench != Enchantments.SILK_TOUCH) {
/*     */           continue;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 186 */         String display = ench.getDisplayName(((Integer)EnchantmentHelper.getEnchantments(stack).get(ench)).intValue()).getString().toLowerCase();
/* 187 */         String name = display.contains("защита") ? "з" : (display.contains("§") ? display.trim().substring(0, 4) : display.trim().substring(0, 2));
/*     */         
/* 189 */         String[] splitName = ench.getDisplayName(((Integer)EnchantmentHelper.getEnchantments(stack).get(ench)).intValue()).getString().split(" ");
/* 190 */         name = name + name;
/*     */ 
/*     */         
/* 193 */         Rect rect = bold.get(10).draw(matrixStack, name, x + ((direction == 3) ? 11.2F : ((direction == 2) ? -bold.get(10).getWidth(name) : 0.0F)) + xOff, y + ((direction == 0) ? -6.0F : ((direction == 1) ? 11.2F : 0.0F)) + yOff, FixColor.WHITE);
/*     */         
/* 195 */         if (direction == 0) {
/* 196 */           yOff -= 6.0F; continue;
/* 197 */         }  if (direction == 1) {
/* 198 */           yOff += 6.0F; continue;
/* 199 */         }  if (direction == 2) {
/* 200 */           xOff -= rect.getWidth() + 2.0F; continue;
/* 201 */         }  if (direction == 3) {
/* 202 */           xOff += rect.getWidth() + 2.0F;
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean clicked(double mouseX, double mouseY, int button) {
/* 210 */     if (this.direction < 2) {
/* 211 */       this.rect.setWidth(44.8F);
/* 212 */       this.rect.setHeight(11.2F);
/*     */     } else {
/* 214 */       this.rect.setWidth(11.2F);
/* 215 */       this.rect.setHeight(44.8F);
/*     */     } 
/* 217 */     return super.clicked(mouseX, mouseY, button);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\clickgui\esp\elmts\ESPArmor.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */