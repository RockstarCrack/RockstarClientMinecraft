/*     */ package fun.rockstarity.api.render.ui.clickgui.esp;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.Reacher;
/*     */ import fun.rockstarity.api.helpers.math.Hover;
/*     */ import fun.rockstarity.api.render.animation.Animation;
/*     */ import fun.rockstarity.api.render.animation.Easing;
/*     */ import fun.rockstarity.api.render.animation.infinity.InfinityAnimation;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.shaders.list.Round;
/*     */ import fun.rockstarity.api.render.ui.clickgui.ClickGuiRenderer;
/*     */ import fun.rockstarity.api.render.ui.clickgui.ClickGuiWindow;
/*     */ import fun.rockstarity.api.render.ui.clickgui.windows.SettingsWindow;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.gui.screen.inventory.InventoryScreen;
/*     */ import net.minecraft.entity.LivingEntity;
/*     */ import net.minecraft.util.math.vector.Vector2f;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ESPSettings
/*     */   implements IAccess
/*     */ {
/*     */   FixColor bgColor;
/*     */   FixColor settingsBg;
/*     */   FixColor separatorColor;
/*     */   FixColor moduleColor;
/*     */   FixColor black;
/*     */   FixColor white;
/*     */   FixColor text;
/*  40 */   private final Animation hoverLeft = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(200);
/*  41 */   private final Animation hoverRight = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(200);
/*     */   
/*  43 */   final InfinityAnimation heightAnim = new InfinityAnimation(); private float rotate;
/*     */   private boolean dragESP;
/*     */   private float dragX;
/*  46 */   final InfinityAnimation rotating = new InfinityAnimation(); private Rect elementsRect; public boolean isDragESP() {
/*  47 */     return this.dragESP;
/*     */   } private Rect previewRect;
/*     */   public Rect getElementsRect() {
/*  50 */     return this.elementsRect; } public Rect getPreviewRect() { return this.previewRect; }
/*  51 */    private float leftHeight = 100.0F, rightHeight = 200.0F;
/*     */   
/*     */   public void renderPage(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/*  54 */     float anim1 = ClickGuiRenderer.opening.get();
/*  55 */     this.bgColor = rock.getThemes().getFirstColor().alpha(anim1);
/*  56 */     this.settingsBg = rock.getThemes().getSecondColor().alpha(anim1);
/*  57 */     this.separatorColor = rock.getThemes().getThirdColor().alpha(anim1);
/*  58 */     this.moduleColor = rock.getThemes().getTextSecondColor().alpha(anim1);
/*  59 */     this.text = rock.getThemes().getTextFirstColor().alpha(anim1);
/*  60 */     this.black = FixColor.BLACK.alpha(anim1);
/*  61 */     this.white = FixColor.WHITE.alpha(anim1);
/*     */     
/*  63 */     int leftY = 0, rightY = 0, column = 1;
/*     */     
/*  65 */     ClickGuiWindow window = rock.getClickGui().getWindow();
/*     */     
/*  67 */     float anim = window.getWidth() - window.getWidth() * ClickGuiRenderer.openedAnim.get();
/*     */     
/*  69 */     renderPreview(matrixStack, mouseX, mouseY, partialTicks, this
/*     */         
/*  71 */         .previewRect = new Rect(window.getRenderer().getLoadedAnimX() + 166.0F + (160 * column) + anim, window.getY() + 74.0F + ((column == 0) ? leftY : rightY), 152.0F, this.rightHeight), anim1);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     column = 0;
/*     */     
/*  78 */     renderElements(matrixStack, mouseX, mouseY, partialTicks, this
/*     */         
/*  80 */         .elementsRect = new Rect(window.getRenderer().getLoadedAnimX() + 166.0F + (160 * column) + anim, window.getY() + 74.0F + ((column == 0) ? leftY : rightY), 152.0F, this.leftHeight), anim1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void renderElements(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks, Rect rect, float anim) {
/*  87 */     this.hoverLeft.setForward(Hover.isHovered(rect, mouseX, mouseY));
/*     */     
/*  89 */     Round.draw(matrixStack, rect, 7.0F, this.separatorColor.darker(this.hoverLeft.get() * 0.05F));
/*  90 */     Round.draw(matrixStack, rect.x(rect.getX() + 1.0F).y(rect.getY() + 1.0F).width(rect.getWidth() - 2.0F).height(rect.getHeight() - 2.0F), 6.5F, this.bgColor);
/*     */     
/*  92 */     float offX = 0.0F, offY = 0.0F;
/*     */     
/*  94 */     ArrayList<ESPElement> elements = rock.getEspSettingsHandler().getEspElements();
/*     */     
/*  96 */     bold.get(16).draw(matrixStack, "Перетаскиваемые элементы", rect.getX() + 8.5F, rect.getY() + 8.5F, this.moduleColor);
/*     */     
/*  98 */     float[] xOffsets = { 0.0F, 0.0F, 0.0F, 0.0F };
/*  99 */     float[] yOffsets = { 0.0F, 0.0F, 0.0F, 0.0F };
/*     */     
/* 101 */     for (ESPElement elmt : elements) {
/* 102 */       boolean drag = elmt.isDragging();
/* 103 */       int speed = drag ? 1 : 50;
/*     */       
/* 105 */       if (!drag) {
/* 106 */         if (elmt.isActive()) {
/* 107 */           if (elmt instanceof fun.rockstarity.api.render.ui.clickgui.esp.elmts.ESPBoxes) {
/* 108 */             elmt.setTargetX(this.previewRect.getX() + this.previewRect.getWidth() / 2.0F - 25.0F);
/* 109 */             elmt.setTargetY(this.previewRect.getY() + this.previewRect.getHeight() / 2.0F - 60.0F);
/*     */           }
/* 111 */           else if (elmt instanceof ESPBar) {
/* 112 */             if (elmt.getDirection() < 2) {
/* 113 */               yOffsets[elmt.getDirection()] = yOffsets[elmt.getDirection()] + 4.0F;
/*     */             } else {
/* 115 */               xOffsets[elmt.getDirection()] = xOffsets[elmt.getDirection()] + 4.0F;
/*     */             } 
/* 117 */           } else if (elmt instanceof fun.rockstarity.api.render.ui.clickgui.esp.elmts.ESPArmor) {
/* 118 */             switch (elmt.getDirection()) {
/*     */               case 0:
/* 120 */                 elmt.setYOffset(-yOffsets[elmt.getDirection()]);
/* 121 */                 elmt.setXOffset(0.0F);
/*     */                 break;
/*     */               case 1:
/* 124 */                 elmt.setYOffset(yOffsets[elmt.getDirection()]);
/* 125 */                 elmt.setXOffset(0.0F);
/*     */                 break;
/*     */               case 2:
/* 128 */                 elmt.setXOffset(-xOffsets[elmt.getDirection()]);
/* 129 */                 elmt.setYOffset(yOffsets[elmt.getDirection()]);
/*     */                 break;
/*     */               case 3:
/* 132 */                 elmt.setXOffset(xOffsets[elmt.getDirection()]);
/* 133 */                 elmt.setYOffset(yOffsets[elmt.getDirection()]);
/*     */                 break;
/*     */             } 
/*     */             
/* 137 */             if (elmt.getDirection() < 2) {
/* 138 */               yOffsets[elmt.getDirection()] = yOffsets[elmt.getDirection()] + 14.8F;
/*     */             } else {
/* 140 */               xOffsets[elmt.getDirection()] = xOffsets[elmt.getDirection()] + 14.8F;
/*     */             } 
/* 142 */           } else if (elmt instanceof fun.rockstarity.api.render.ui.clickgui.esp.elmts.ESPCooldowns) {
/* 143 */             switch (elmt.getDirection()) {
/*     */               case 0:
/* 145 */                 elmt.setYOffset(-yOffsets[elmt.getDirection()]);
/* 146 */                 elmt.setXOffset(0.0F);
/*     */                 break;
/*     */               case 1:
/* 149 */                 elmt.setYOffset(yOffsets[elmt.getDirection()]);
/* 150 */                 elmt.setXOffset(0.0F);
/*     */                 break;
/*     */               case 2:
/* 153 */                 elmt.setXOffset(-xOffsets[elmt.getDirection()]);
/* 154 */                 elmt.setYOffset(yOffsets[elmt.getDirection()]);
/*     */                 break;
/*     */               case 3:
/* 157 */                 elmt.setXOffset(xOffsets[elmt.getDirection()]);
/* 158 */                 elmt.setYOffset(yOffsets[elmt.getDirection()]);
/*     */                 break;
/*     */             } 
/*     */             
/* 162 */             if (elmt.getDirection() < 2) {
/* 163 */               yOffsets[elmt.getDirection()] = yOffsets[elmt.getDirection()] + 14.8F;
/*     */             } else {
/* 165 */               xOffsets[elmt.getDirection()] = xOffsets[elmt.getDirection()] + 14.8F;
/*     */             } 
/*     */           } else {
/* 168 */             switch (elmt.getDirection()) {
/*     */               case 0:
/* 170 */                 elmt.setYOffset(-yOffsets[elmt.getDirection()]);
/* 171 */                 elmt.setXOffset(0.0F);
/*     */                 break;
/*     */               case 1:
/* 174 */                 elmt.setYOffset(yOffsets[elmt.getDirection()]);
/* 175 */                 elmt.setXOffset(0.0F);
/*     */                 break;
/*     */               case 2:
/* 178 */                 elmt.setXOffset(-xOffsets[elmt.getDirection()]);
/* 179 */                 elmt.setYOffset(yOffsets[elmt.getDirection()]);
/*     */                 break;
/*     */               case 3:
/* 182 */                 elmt.setXOffset(xOffsets[elmt.getDirection()]);
/* 183 */                 elmt.setYOffset(yOffsets[elmt.getDirection()]);
/*     */                 break;
/*     */             } 
/*     */             
/* 187 */             yOffsets[elmt.getDirection()] = yOffsets[elmt.getDirection()] + 8.0F;
/*     */           } 
/*     */         } else {
/*     */           
/* 191 */           elmt.setTargetX(rect.getX() + offX + 8.0F);
/* 192 */           elmt.setTargetY(rect.getY() + offY + 25.0F);
/*     */         }
/*     */       
/* 195 */       } else if (elmt.isActive()) {
/* 196 */         List<Vector2f> points = new ArrayList<>();
/* 197 */         points.add(new Vector2f(this.previewRect.getWidth() / 2.0F, this.previewRect.getHeight() / 2.0F - 66.0F));
/* 198 */         points.add(new Vector2f(this.previewRect.getWidth() / 2.0F, this.previewRect.getHeight() / 2.0F + 65.0F));
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 203 */         points.add(new Vector2f(this.previewRect.getWidth() / 2.0F - 25.0F, this.previewRect.getHeight() / 2.0F - 60.0F));
/* 204 */         points.add(new Vector2f(this.previewRect.getWidth() / 2.0F + 25.0F, this.previewRect.getHeight() / 2.0F - 60.0F));
/*     */ 
/*     */ 
/*     */         
/* 208 */         if ((rock.getEspSettingsHandler()).armor.active && !(elmt instanceof ESPBar) && !(elmt instanceof fun.rockstarity.api.render.ui.clickgui.esp.elmts.ESPArmor) && !(elmt instanceof fun.rockstarity.api.render.ui.clickgui.esp.elmts.ESPCooldowns)) {
/* 209 */           ((Vector2f)points.get((rock.getEspSettingsHandler()).armor.direction)).x += 1000.0F;
/*     */         }
/*     */         
/* 212 */         List<Vector2f> cache = new ArrayList<>(points);
/*     */         
/* 214 */         Vector2f closest = findClosestPoint(cache, elmt.getTargetX() - this.previewRect.getX(), elmt.getTargetY() - this.previewRect.getY());
/*     */         
/* 216 */         elmt.setDirection(points.indexOf(closest));
/*     */         
/* 218 */         if (elmt instanceof fun.rockstarity.api.render.ui.clickgui.esp.elmts.ESPArmor) {
/* 219 */           for (ESPElement elmt1 : elements) {
/* 220 */             if (elmt1 instanceof fun.rockstarity.api.render.ui.clickgui.esp.elmts.ESPArmor || elmt1 instanceof ESPBar)
/*     */               continue; 
/* 222 */             if (elmt1.direction == elmt.getDirection()) {
/* 223 */               elmt1.direction++;
/* 224 */               if (elmt1.direction > 3) elmt1.direction = 0;
/*     */             
/*     */             } 
/*     */           } 
/*     */         }
/* 229 */         if (elmt instanceof fun.rockstarity.api.render.ui.clickgui.esp.elmts.ESPCooldowns) {
/* 230 */           for (ESPElement elmt1 : elements) {
/* 231 */             if (elmt1 instanceof fun.rockstarity.api.render.ui.clickgui.esp.elmts.ESPArmor || elmt1 instanceof ESPBar || elmt1 instanceof fun.rockstarity.api.render.ui.clickgui.esp.elmts.ESPCooldowns)
/*     */               continue; 
/* 233 */             if (elmt1.direction == elmt.getDirection()) {
/* 234 */               elmt1.direction++;
/* 235 */               if (elmt1.direction > 3) elmt1.direction = 0;
/*     */             
/*     */             } 
/*     */           } 
/*     */         }
/*     */       } 
/*     */       
/* 242 */       elmt.getXAnim().animate(elmt.getTargetX() - rect.getX(), speed);
/* 243 */       elmt.getYAnim().animate(elmt.getTargetY() - rect.getY(), speed);
/*     */       
/* 245 */       elmt.getRect().setX(elmt.getXAnim().get() + rect.getX());
/* 246 */       elmt.getRect().setY(elmt.getYAnim().get() + rect.getY());
/*     */       
/* 248 */       if (elmt.isDragging()) {
/* 249 */         elmt.setActive(Hover.isHovered(this.previewRect, elmt.getRect().getX(), elmt.getRect().getY()));
/*     */       }
/* 251 */       elmt.drawPreview(matrixStack, mouseX, mouseY, partialTicks, anim);
/*     */       
/* 253 */       if (elmt.isActive())
/* 254 */         continue;  offX += bold.get(14).getWidth(elmt.getName()) + 8.0F;
/* 255 */       if (elements.indexOf(elmt) + 1 != elements.size() && offX + bold
/* 256 */         .get(14).getWidth(((ESPElement)elements.get(elements.indexOf(elmt) + 1)).getName()) + 8.0F > rect.getWidth() - 8.0F) {
/* 257 */         offX = 0.0F;
/* 258 */         offY += 13.0F;
/*     */       } 
/*     */     } 
/*     */     
/* 262 */     Collections.sort(rock.getEspSettingsHandler().getEspElements(), (a, b) -> Float.compare(
/* 263 */           (a instanceof ESPBar || a instanceof fun.rockstarity.api.render.ui.clickgui.esp.elmts.ESPArmor || a instanceof fun.rockstarity.api.render.ui.clickgui.esp.elmts.ESPCooldowns) ? -50.0F : (a.isDragging() ? (mouseY + a.getDragY()) : a.getRect().getY()), (b instanceof ESPBar || b instanceof fun.rockstarity.api.render.ui.clickgui.esp.elmts.ESPArmor || a instanceof fun.rockstarity.api.render.ui.clickgui.esp.elmts.ESPCooldowns) ? -50.0F : (b.isDragging() ? (mouseY + b.getDragY()) : b.getRect().getY())));
/*     */ 
/*     */     
/* 266 */     if (offX == 0.0F) offY -= 13.0F;
/*     */     
/* 268 */     this.leftHeight = this.heightAnim.animate(44.0F + offY, 25);
/*     */     
/* 270 */     if (this.dragESP) {
/* 271 */       this.rotate = mouseX + this.dragX;
/*     */     }
/*     */   }
/*     */   
/*     */   private void renderPreview(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks, Rect rect, float anim) {
/* 276 */     this.hoverRight.setForward(Hover.isHovered(rect, mouseX, mouseY));
/* 277 */     this.rotating.animate(this.rotate, 150);
/*     */     
/* 279 */     Round.draw(matrixStack, rect, 7.0F, this.separatorColor.darker(this.hoverRight.get() * 0.05F));
/* 280 */     Round.draw(matrixStack, rect.x(rect.getX() + 1.0F).y(rect.getY() + 1.0F).width(rect.getWidth() - 2.0F).height(rect.getHeight() - 2.0F), 6.5F, this.bgColor);
/*     */     
/* 282 */     bold.get(16).draw(matrixStack, "Предпросмотр", rect.getX() + 8.5F, rect.getY() + 8.5F, this.moduleColor);
/*     */     
/* 284 */     Reacher.ENTITY_ALPHA = anim;
/* 285 */     Reacher.SILENT = true;
/* 286 */     GL11.glPushMatrix();
/* 287 */     GL11.glTranslated((int)(rect.getX() + rect.getWidth() / 2.0F), (int)(rect.getY() + rect.getHeight() / 2.0F + 60.0F), 100.0D);
/* 288 */     GL11.glRotated((this.rotating.get() - 180.0F + ClickGuiRenderer.rotationESP.get() * 3.0F * 180.0F), 0.0D, 1.0D, 0.0D);
/* 289 */     GL11.glTranslated(0.0D, 0.0D, -50.0D);
/*     */     
/* 291 */     InventoryScreen.drawEntityOnScreen(0.0F, 0.0F, 60.0F, 0.0F, 0.0F, (LivingEntity)mc.player);
/*     */     
/* 293 */     GL11.glPopMatrix();
/* 294 */     Reacher.ENTITY_ALPHA = 1.0F;
/* 295 */     Reacher.SILENT = false;
/*     */   }
/*     */   
/*     */   public void clicked(double mouseX, double mouseY, int button) {
/* 299 */     boolean cancel = false;
/*     */     
/* 301 */     if (cancel)
/*     */       return; 
/* 303 */     for (ESPElement elmt : rock.getEspSettingsHandler().getEspElements()) {
/* 304 */       elmt.getRect().setX(elmt.getXAnim().get() + this.elementsRect.getX());
/* 305 */       elmt.getRect().setY(elmt.getYAnim().get() + this.elementsRect.getY());
/* 306 */       if (elmt.clicked(mouseX, mouseY, button))
/*     */         break; 
/* 308 */       if (button == 1 && Hover.isHovered(
/* 309 */           !elmt.isActive() ? 
/* 310 */           new Rect(elmt.getTargetX(), elmt.getTargetY(), bold.get(14).getWidth(elmt.getName()) + 5.0F, 10.0F) : 
/* 311 */           new Rect(elmt.getTargetX(), elmt.getTargetY(), elmt.getRect().getWidth(), elmt.getRect().getHeight()), mouseX, mouseY)) {
/*     */         
/* 313 */         if (!elmt.getSettings().isEmpty()) {
/* 314 */           ClickGuiWindow window = rock.getClickGui().getWindow();
/* 315 */           window.getWindows().add(new SettingsWindow(elmt, (float)mouseX, (float)mouseY));
/* 316 */           elmt.setDragging(false);
/*     */         } 
/*     */         
/*     */         break;
/*     */       } 
/* 321 */       if (Hover.isHovered(elmt.rect, mouseX, mouseY)) {
/* 322 */         cancel = true;
/*     */       }
/*     */     } 
/*     */     
/* 326 */     if (cancel)
/*     */       return; 
/* 328 */     if (Hover.isHovered(this.previewRect, mouseX, mouseY)) {
/* 329 */       this.dragESP = true;
/* 330 */       this.dragX = (float)(this.rotate - mouseX);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void released(double mouseX, double mouseY, int button) {
/* 335 */     for (ESPElement elmt : rock.getEspSettingsHandler().getEspElements()) {
/* 336 */       elmt.released(mouseX, mouseY, button);
/*     */     }
/* 338 */     this.dragESP = false;
/*     */   }
/*     */   
/*     */   protected Vector2f findClosestPoint(List<Vector2f> points, float x, float y) {
/* 342 */     points.sort(Comparator.comparing(new Vector2f(x, y)::distance));
/*     */     
/* 344 */     return points.get(0);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\clickgui\esp\ESPSettings.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */