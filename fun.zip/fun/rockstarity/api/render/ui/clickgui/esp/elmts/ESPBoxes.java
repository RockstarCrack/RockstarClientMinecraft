/*    */ package fun.rockstarity.api.render.ui.clickgui.esp.elmts;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.helpers.render.Stencil;
/*    */ import fun.rockstarity.api.render.color.FixColor;
/*    */ import fun.rockstarity.api.render.color.themes.Style;
/*    */ import fun.rockstarity.api.render.shaders.list.Outline;
/*    */ import fun.rockstarity.api.render.shaders.list.Round;
/*    */ import fun.rockstarity.api.render.ui.clickgui.esp.ESPElement;
/*    */ import fun.rockstarity.api.render.ui.clickgui.esp.ESPSettings;
/*    */ import fun.rockstarity.api.render.ui.rect.Rect;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ESPBoxes
/*    */   extends ESPElement
/*    */ {
/*    */   public ESPBoxes() {
/* 24 */     super("Боксы");
/*    */   }
/*    */ 
/*    */   
/*    */   public void drawPreview(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks, float anim) {
/* 29 */     super.drawPreview(matrixStack, mouseX, mouseY, partialTicks, anim);
/*    */     
/* 31 */     this.rect.setWidth(50.0F);
/* 32 */     this.rect.setHeight(120.0F);
/*    */     
/* 34 */     if (this.activeAnim.finished(false))
/*    */       return; 
/* 36 */     ESPSettings settings = rock.getClickGui().getWindow().getEspSettings();
/*    */     
/* 38 */     Stencil.init();
/* 39 */     Round.draw(matrixStack, settings.getPreviewRect(), 7.0F, FixColor.WHITE);
/* 40 */     Stencil.read(1);
/*    */     
/* 42 */     drawOnEntity(matrixStack, (LivingEntity)mc.player, this.rect.getX(), this.rect.getY(), this.rect.getWidth(), this.rect.getHeight(), anim);
/*    */     
/* 44 */     Stencil.finish();
/*    */   }
/*    */ 
/*    */   
/*    */   public void drawOnEntity(MatrixStack matrixStack, LivingEntity entity, float x, float y, float width, float height, float anim) {
/* 49 */     anim *= this.activeAnim.get();
/*    */     
/* 51 */     FixColor color1 = Style.getPoint(0).alpha(anim);
/* 52 */     FixColor color2 = Style.getPoint(90).alpha(anim);
/* 53 */     FixColor color3 = Style.getPoint(180).alpha(anim);
/* 54 */     FixColor color4 = Style.getPoint(230).alpha(anim);
/*    */     
/* 56 */     if (rock.getFriendsHandler().isFriend((Entity)entity)) {
/* 57 */       Outline.draw(matrixStack, new Rect(x, y, width, height), 2.0F, 1.0F, FixColor.GREEN);
/*    */     } else {
/* 59 */       Outline.draw(matrixStack, new Rect(x, y, width, height), 2.0F, 1.0F, color1, color2, color3, color4);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean clicked(double mouseX, double mouseY, int button) {
/* 65 */     this.rect.setWidth(50.0F);
/* 66 */     this.rect.setHeight(120.0F);
/* 67 */     return super.clicked(mouseX, mouseY, button);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\clickgui\esp\elmts\ESPBoxes.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */