/*    */ package fun.rockstarity.api.render.ui.clickgui.esp.elmts;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.helpers.game.Server;
/*    */ import fun.rockstarity.api.render.color.FixColor;
/*    */ import fun.rockstarity.api.render.ui.clickgui.esp.ESPBar;
/*    */ import java.awt.Color;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ESPHealth
/*    */   extends ESPBar
/*    */ {
/*    */   public ESPHealth() {
/* 19 */     super("Здоровье");
/*    */   }
/*    */ 
/*    */   
/*    */   public void drawOnEntity(MatrixStack matrixStack, LivingEntity entity, float x, float y, float width, float height, float anim) {
/* 24 */     float noAnimHealth = Math.max(0.0F, Math.min(1.0F, Server.isServerForHPFix() ? (entity.getRealHealth() / 20.0F) : (entity.getHealth() / (entity.getMaxHealth() + entity.getAbsorptionAmount()))));
/* 25 */     this.percent = entity.getHealthAnim().animate(noAnimHealth, 300);
/* 26 */     this.color = (this.percent > 0.5F) ? FixColor.ORANGE.move((Color)FixColor.GREEN, (this.percent - 0.5F) * 2.0F) : FixColor.RED.move((Color)FixColor.ORANGE, this.percent * 2.0F);
/* 27 */     super.drawOnEntity(matrixStack, entity, x, y, width, height, anim);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\clickgui\esp\elmts\ESPHealth.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */