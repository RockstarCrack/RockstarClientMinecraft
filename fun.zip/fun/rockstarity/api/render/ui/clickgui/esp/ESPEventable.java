/*    */ package fun.rockstarity.api.render.ui.clickgui.esp;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ESPEventable
/*    */   extends ESPElement
/*    */ {
/*    */   public ESPEventable(String name) {
/* 16 */     super(name);
/*    */   }
/*    */   
/*    */   public void onEvent(Event event) {}
/*    */   
/*    */   public void drawOnEntity(MatrixStack matrixStack, LivingEntity entity, float x, float y, float width, float height, float anim) {}
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\clickgui\esp\ESPEventable.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */