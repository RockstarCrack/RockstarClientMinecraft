/*     */ package fun.rockstarity.api.render.ui.clickgui.esp;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import fun.rockstarity.api.helpers.render.Stencil;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.shaders.list.Round;
/*     */ import fun.rockstarity.api.render.ui.fonts.FontSize;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import net.minecraft.entity.LivingEntity;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ESPTextElement
/*     */   extends ESPElement
/*     */ {
/*     */   private String text;
/*     */   
/*     */   public void setText(String text) {
/*  19 */     this.text = text;
/*     */   }
/*     */   public String getText() {
/*  22 */     return this.text;
/*     */   }
/*     */   public ESPTextElement(String name) {
/*  25 */     super(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawPreview(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks, float anim) {
/*  30 */     super.drawPreview(matrixStack, mouseX, mouseY, partialTicks, anim);
/*     */     
/*  32 */     if (this.activeAnim.finished(false))
/*     */       return; 
/*  34 */     anim *= this.activeAnim.get();
/*     */     
/*  36 */     ESPSettings settings = rock.getClickGui().getWindow().getEspSettings();
/*  37 */     Rect previewRect = settings.getPreviewRect();
/*     */     
/*  39 */     FontSize font = bold.get(14);
/*  40 */     float textWidth = font.getWidth(this.name);
/*  41 */     float x = previewRect.getX() + previewRect.getWidth() / 2.0F - 25.0F;
/*  42 */     float y = previewRect.getY() + previewRect.getHeight() / 2.0F - 60.0F;
/*     */     
/*  44 */     if (!this.dragging) {
/*  45 */       switch (this.direction) {
/*     */         case 0:
/*  47 */           this.targetX = x + 25.0F - textWidth / 2.0F;
/*  48 */           this.targetY = y - 11.0F;
/*     */           break;
/*     */         case 1:
/*  51 */           this.targetX = x + 25.0F - textWidth / 2.0F;
/*  52 */           this.targetY = y + 120.0F;
/*     */           break;
/*     */         case 2:
/*  55 */           this.targetX = x - 3.0F - textWidth;
/*  56 */           this.targetY = y;
/*     */           break;
/*     */         case 3:
/*  59 */           this.targetX = x + 53.0F;
/*  60 */           this.targetY = y;
/*     */           break;
/*     */       } 
/*     */     
/*     */     }
/*  65 */     if (!this.dragging) {
/*  66 */       this.targetY += this.yOffset;
/*  67 */       this.targetX += this.xOffset;
/*     */     } 
/*     */     
/*  70 */     this.rect.setWidth(font.getWidth(this.name));
/*     */     
/*  72 */     Stencil.init();
/*  73 */     Round.draw(matrixStack, settings.getPreviewRect(), 7.0F, FixColor.WHITE);
/*  74 */     Stencil.read(1);
/*     */     
/*  76 */     font.draw(matrixStack, this.name, this.rect.getX() + 0.5F, this.rect.getY() + 0.5F, FixColor.BLACK.alpha((0.5F * anim)));
/*  77 */     font.draw(matrixStack, this.name, this.rect.getX(), this.rect.getY(), rock.getThemes().getDarkTheme().getTextFirstColor().alpha(anim));
/*     */     
/*  79 */     Stencil.finish();
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawOnEntity(MatrixStack matrixStack, LivingEntity entity, float x, float y, float width, float height, float anim) {
/*  84 */     anim *= this.activeAnim.get();
/*     */     
/*  86 */     FontSize font = bold.get(14);
/*  87 */     float textWidth = font.getWidth(this.text);
/*     */     
/*  89 */     y += this.yOffset;
/*  90 */     x += this.xOffset;
/*     */     
/*  92 */     switch (this.direction) {
/*     */       case 0:
/*  94 */         font.draw(matrixStack, this.text, x + width / 2.0F - textWidth / 2.0F + 0.5F, y - 10.5F, FixColor.BLACK.alpha((0.5F * anim)));
/*  95 */         font.draw(matrixStack, this.text, x + width / 2.0F - textWidth / 2.0F, y - 11.0F, rock.getThemes().getDarkTheme().getTextFirstColor().alpha(anim));
/*     */         break;
/*     */       case 1:
/*  98 */         font.draw(matrixStack, this.text, x + width / 2.0F - textWidth / 2.0F + 0.5F, y + height + 0.5F, FixColor.BLACK.alpha((0.5F * anim)));
/*  99 */         font.draw(matrixStack, this.text, x + width / 2.0F - textWidth / 2.0F, y + height, rock.getThemes().getDarkTheme().getTextFirstColor().alpha(anim));
/*     */         break;
/*     */       case 2:
/* 102 */         font.draw(matrixStack, this.text, x - 4.0F - textWidth, y + 0.5F, FixColor.BLACK.alpha((0.5F * anim)));
/* 103 */         font.draw(matrixStack, this.text, x - 4.0F - textWidth, y, rock.getThemes().getDarkTheme().getTextFirstColor().alpha(anim));
/*     */         break;
/*     */       case 3:
/* 106 */         font.draw(matrixStack, this.text, x + 3.0F + width + 0.5F, y + 0.5F, FixColor.BLACK.alpha((0.5F * anim)));
/* 107 */         font.draw(matrixStack, this.text, x + 3.0F + width, y, rock.getThemes().getDarkTheme().getTextFirstColor().alpha(anim));
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean clicked(double mouseX, double mouseY, int button) {
/* 114 */     this.rect.setWidth(bold.get(14).getWidth(this.name));
/* 115 */     this.rect.setHeight(10.0F);
/* 116 */     return super.clicked(mouseX, mouseY, button);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\clickgui\esp\ESPTextElement.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */