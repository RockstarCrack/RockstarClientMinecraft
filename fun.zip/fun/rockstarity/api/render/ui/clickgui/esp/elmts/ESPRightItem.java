/*    */ package fun.rockstarity.api.render.ui.clickgui.esp.elmts;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.binds.Bindable;
/*    */ import fun.rockstarity.api.modules.settings.list.CheckBox;
/*    */ import fun.rockstarity.api.render.ui.clickgui.esp.ESPTextElement;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ import net.minecraft.item.Items;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ESPRightItem
/*    */   extends ESPTextElement
/*    */ {
/* 16 */   private final CheckBox hideIfEmpty = new CheckBox((Bindable)this, "Не отображать если пусто");
/*    */   
/*    */   public ESPRightItem() {
/* 19 */     super("Правая рука");
/*    */   }
/*    */ 
/*    */   
/*    */   public void drawOnEntity(MatrixStack matrixStack, LivingEntity entity, float x, float y, float width, float height, float anim) {
/* 24 */     String name = entity.getName().getString();
/* 25 */     String item = (entity.getHeldItemMainhand().getItem() != Items.AIR) ? entity.getHeldItemMainhand().getDisplayName().getString() : "Пусто";
/*    */     
/* 27 */     if (this.hideIfEmpty.get() && (entity.getHeldItemMainhand().isEmpty() || entity.getHeldItemMainhand().getItem() == Items.AIR))
/*    */       return; 
/* 29 */     setText(item);
/*    */     
/* 31 */     super.drawOnEntity(matrixStack, entity, x, y, width, height, anim);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\clickgui\esp\elmts\ESPRightItem.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */