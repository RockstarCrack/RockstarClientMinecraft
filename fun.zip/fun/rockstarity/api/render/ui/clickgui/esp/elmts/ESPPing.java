/*    */ package fun.rockstarity.api.render.ui.clickgui.esp.elmts;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.render.ui.clickgui.esp.ESPTextElement;
/*    */ import java.util.Map;
/*    */ import net.minecraft.client.gui.overlay.PlayerTabOverlayGui;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ESPPing
/*    */   extends ESPTextElement
/*    */ {
/*    */   public ESPPing() {
/* 19 */     super("Пинг");
/*    */   }
/*    */ 
/*    */   
/*    */   public void drawOnEntity(MatrixStack matrixStack, LivingEntity entity, float x, float y, float width, float height, float anim) {
/* 24 */     Map<String, Integer> pings = PlayerTabOverlayGui.getPlayerPings();
/* 25 */     String name = entity.getName().getString();
/* 26 */     int ping = pings.containsKey(name) ? ((Integer)pings.get(name)).intValue() : 0;
/*    */     
/* 28 */     setText("" + ping + " ms");
/*    */     
/* 30 */     super.drawOnEntity(matrixStack, entity, x, y, width, height, anim);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\clickgui\esp\elmts\ESPPing.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */