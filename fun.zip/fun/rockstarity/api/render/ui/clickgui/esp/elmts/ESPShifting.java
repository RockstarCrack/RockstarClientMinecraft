/*    */ package fun.rockstarity.api.render.ui.clickgui.esp.elmts;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.render.ui.clickgui.esp.ESPTextElement;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ESPShifting
/*    */   extends ESPTextElement
/*    */ {
/*    */   public ESPShifting() {
/* 16 */     super("Шифт");
/*    */   }
/*    */ 
/*    */   
/*    */   public void drawOnEntity(MatrixStack matrixStack, LivingEntity entity, float x, float y, float width, float height, float anim) {
/* 21 */     String name = entity.getName().getString();
/* 22 */     String item = entity.isSneaking() ? "С шифтом" : "Без шифта";
/*    */     
/* 24 */     setText(item);
/*    */     
/* 26 */     super.drawOnEntity(matrixStack, entity, x, y, width, height, anim);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\clickgui\esp\elmts\ESPShifting.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */