/*    */ package fun.rockstarity.api.render.ui.clickgui.esp;
/*    */ 
/*    */ import fun.rockstarity.api.render.ui.clickgui.esp.elmts.ESPArmor;
/*    */ import fun.rockstarity.api.render.ui.clickgui.esp.elmts.ESPBoxes;
/*    */ import fun.rockstarity.api.render.ui.clickgui.esp.elmts.ESPCooldowns;
/*    */ import fun.rockstarity.api.render.ui.clickgui.esp.elmts.ESPHealth;
/*    */ import fun.rockstarity.api.render.ui.clickgui.esp.elmts.ESPLeftItem;
/*    */ import fun.rockstarity.api.render.ui.clickgui.esp.elmts.ESPPing;
/*    */ import fun.rockstarity.api.render.ui.clickgui.esp.elmts.ESPRightItem;
/*    */ import fun.rockstarity.api.render.ui.clickgui.esp.elmts.ESPShifting;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ESPSettingsHandler
/*    */ {
/*    */   protected final ESPBoxes boxes;
/*    */   protected final ESPPing ping;
/*    */   protected final ESPRightItem rightItem;
/*    */   protected final ESPLeftItem leftItem;
/*    */   protected final ESPHealth health;
/*    */   protected final ESPShifting shift;
/*    */   protected final ESPArmor armor;
/*    */   protected final ESPCooldowns cooldowns;
/* 27 */   protected final ArrayList<ESPElement> espElements = new ArrayList<>(); public ArrayList<ESPElement> getEspElements() { return this.espElements; }
/*    */    public ESPBoxes getBoxes() {
/* 29 */     return this.boxes;
/*    */   }
/* 31 */   public ESPPing getPing() { return this.ping; }
/* 32 */   public ESPRightItem getRightItem() { return this.rightItem; }
/* 33 */   public ESPLeftItem getLeftItem() { return this.leftItem; }
/* 34 */   public ESPHealth getHealth() { return this.health; }
/* 35 */   public ESPShifting getShift() { return this.shift; }
/* 36 */   public ESPArmor getArmor() { return this.armor; } public ESPCooldowns getCooldowns() {
/* 37 */     return this.cooldowns;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ESPSettingsHandler() {
/* 63 */     Objects.requireNonNull(this.espElements); Arrays.<ESPElement>stream(new ESPElement[] { (ESPElement)(this.boxes = new ESPBoxes()), (ESPElement)(this.health = new ESPHealth()), (ESPElement)(this.armor = new ESPArmor()), (ESPElement)(this.rightItem = new ESPRightItem()), (ESPElement)(this.leftItem = new ESPLeftItem()), (ESPElement)(this.ping = new ESPPing()), (ESPElement)(this.shift = new ESPShifting()), (ESPElement)(this.cooldowns = new ESPCooldowns()) }).forEach(this.espElements::add);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\clickgui\esp\ESPSettingsHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */