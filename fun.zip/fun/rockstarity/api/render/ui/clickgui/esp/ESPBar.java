/*     */ package fun.rockstarity.api.render.ui.clickgui.esp;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import fun.rockstarity.api.helpers.render.Stencil;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.shaders.list.Round;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import net.minecraft.entity.LivingEntity;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ESPBar
/*     */   extends ESPElement
/*     */ {
/*     */   protected float percent;
/*     */   protected FixColor color;
/*     */   
/*     */   public ESPBar(String name) {
/*  23 */     super(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawPreview(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks, float anim) {
/*  28 */     super.drawPreview(matrixStack, mouseX, mouseY, partialTicks, anim);
/*     */     
/*  30 */     if (this.activeAnim.finished(false))
/*     */       return; 
/*  32 */     anim *= this.activeAnim.get();
/*     */     
/*  34 */     ESPSettings settings = rock.getClickGui().getWindow().getEspSettings();
/*  35 */     Rect previewRect = settings.getPreviewRect();
/*     */     
/*  37 */     float x = previewRect.getX() + previewRect.getWidth() / 2.0F - 25.0F;
/*  38 */     float y = previewRect.getY() + previewRect.getHeight() / 2.0F - 60.0F;
/*     */     
/*  40 */     if (!this.dragging) {
/*  41 */       switch (this.direction) {
/*     */         case 0:
/*  43 */           this.targetX = x;
/*  44 */           this.targetY = y - 6.0F;
/*     */           break;
/*     */         case 1:
/*  47 */           this.targetX = x;
/*  48 */           this.targetY = y + 122.0F;
/*     */           break;
/*     */         case 2:
/*  51 */           this.targetX = x - 6.0F;
/*  52 */           this.targetY = y;
/*     */           break;
/*     */         case 3:
/*  55 */           this.targetX = x + 52.0F;
/*  56 */           this.targetY = y;
/*     */           break;
/*     */       } 
/*     */     
/*     */     }
/*  61 */     if (this.direction < 2) {
/*  62 */       this.rect.setWidth(50.0F);
/*  63 */       this.rect.setHeight(6.0F);
/*     */     } else {
/*  65 */       this.rect.setWidth(6.0F);
/*  66 */       this.rect.setHeight(120.0F);
/*     */     } 
/*     */     
/*  69 */     Stencil.init();
/*  70 */     Round.draw(matrixStack, settings.getPreviewRect(), 7.0F, FixColor.WHITE);
/*  71 */     Stencil.read(1);
/*     */     
/*  73 */     FixColor first = FixColor.GREEN.alpha(anim);
/*  74 */     FixColor second = first.darker(0.5F);
/*     */     
/*  76 */     Round.draw(matrixStack, new Rect(this.rect
/*  77 */           .getX() + ((this.direction == 2) ? 2 : false), this.rect
/*  78 */           .getY() + ((this.direction == 0) ? 2 : false), this.rect
/*  79 */           .getWidth() - ((this.direction < 2) ? false : 4), this.rect
/*  80 */           .getHeight() - ((this.direction < 2) ? 4 : false)), 1.0F, first, 
/*     */ 
/*     */         
/*  83 */         (this.direction < 2) ? second : first, 
/*  84 */         (this.direction < 2) ? first : second, second);
/*     */ 
/*     */     
/*  87 */     Stencil.finish();
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawOnEntity(MatrixStack matrixStack, LivingEntity entity, float x, float y, float width, float height, float anim) {
/*  92 */     anim *= this.activeAnim.get();
/*     */     
/*  94 */     FixColor up = this.color.alpha(anim);
/*  95 */     FixColor down = up.darker(0.5F);
/*     */     
/*  97 */     switch (this.direction) {
/*     */       case 0:
/*  99 */         Round.draw(matrixStack, new Rect(x, y - 4.0F, width, 2.0F), 1.0F, rock.getThemes().getFoursColor().alpha(anim));
/* 100 */         Round.draw(matrixStack, new Rect(x + width / 2.0F - width / 2.0F * this.percent, y - 4.0F, width * this.percent, 2.0F), 1.0F, up, down, up, down);
/*     */         break;
/*     */       case 1:
/* 103 */         Round.draw(matrixStack, new Rect(x, y + height + 2.0F, width, 2.0F), 1.0F, rock.getThemes().getFoursColor().alpha(anim));
/* 104 */         Round.draw(matrixStack, new Rect(x + width / 2.0F - width / 2.0F * this.percent, y + height + 2.0F, width * this.percent, 2.0F), 1.0F, up, down, up, down);
/*     */         break;
/*     */       case 2:
/* 107 */         Round.draw(matrixStack, new Rect(x - 4.0F, y, 2.0F, height), 1.0F, rock.getThemes().getFoursColor().alpha(anim));
/* 108 */         Round.draw(matrixStack, new Rect(x - 4.0F, y + height - height * this.percent, 2.0F, height * this.percent), 1.0F, up, up, down, down);
/*     */         break;
/*     */       case 3:
/* 111 */         Round.draw(matrixStack, new Rect(x + width + 2.0F, y, 2.0F, height), 1.0F, rock.getThemes().getFoursColor().alpha(anim));
/* 112 */         Round.draw(matrixStack, new Rect(x + width + 2.0F, y + height - height * this.percent, 2.0F, height * this.percent), 1.0F, up, up, down, down);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean clicked(double mouseX, double mouseY, int button) {
/* 119 */     if (this.direction < 2) {
/* 120 */       this.rect.setWidth(50.0F);
/* 121 */       this.rect.setHeight(4.0F);
/*     */     } else {
/* 123 */       this.rect.setWidth(4.0F);
/* 124 */       this.rect.setHeight(120.0F);
/*     */     } 
/* 126 */     return super.clicked(mouseX, mouseY, button);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\clickgui\esp\ESPBar.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */