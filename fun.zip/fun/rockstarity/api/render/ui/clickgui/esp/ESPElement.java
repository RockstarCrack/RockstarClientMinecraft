/*    */ package fun.rockstarity.api.render.ui.clickgui.esp;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.binds.Bindable;
/*    */ import fun.rockstarity.api.helpers.math.Hover;
/*    */ import fun.rockstarity.api.modules.settings.Setting;
/*    */ import fun.rockstarity.api.render.animation.Animation;
/*    */ import fun.rockstarity.api.render.animation.Easing;
/*    */ import fun.rockstarity.api.render.animation.infinity.InfinityAnimation;
/*    */ import fun.rockstarity.api.render.shaders.list.Round;
/*    */ import fun.rockstarity.api.render.ui.rect.Rect;
/*    */ import java.util.ArrayList;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ESPElement
/*    */   extends Bindable
/*    */   implements IAccess
/*    */ {
/*    */   public void setSettings(ArrayList<Setting> settings) {
/* 30 */     this.settings = settings; } public void setActive(boolean active) { this.active = active; } public void setXOffset(float xOffset) { this.xOffset = xOffset; } public void setYOffset(float yOffset) { this.yOffset = yOffset; } public void setRect(Rect rect) { this.rect = rect; } public void setTargetX(float targetX) { this.targetX = targetX; } public void setTargetY(float targetY) { this.targetY = targetY; } public void setDragging(boolean dragging) { this.dragging = dragging; } public void setDragX(float dragX) { this.dragX = dragX; } public void setDragY(float dragY) { this.dragY = dragY; } public ESPElement(String name) {
/* 31 */     this.name = name;
/*    */   }
/*    */   protected boolean active; protected int direction;
/*    */   protected float xOffset;
/* 35 */   private ArrayList<Setting> settings = new ArrayList<>(); protected float yOffset; protected final String name; public ArrayList<Setting> getSettings() { return this.settings; }
/*    */   
/* 37 */   public boolean isActive() { return this.active; }
/* 38 */   public int getDirection() { return this.direction; } public void setDirection(int direction) { this.direction = direction; }
/* 39 */   public float getXOffset() { return this.xOffset; } public float getYOffset() { return this.yOffset; } public String getName() {
/* 40 */     return this.name;
/* 41 */   } protected Rect rect = Rect.EMPTY; public Rect getRect() { return this.rect; }
/*    */ 
/*    */ 
/*    */   
/* 45 */   protected final Animation activeAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public Animation getActiveAnim() { return this.activeAnim; }
/* 46 */    protected final InfinityAnimation xAnim = new InfinityAnimation(); public InfinityAnimation getXAnim() { return this.xAnim; }
/* 47 */    protected float targetX; protected float targetY; protected boolean dragging; protected final InfinityAnimation yAnim = new InfinityAnimation(); protected float dragX; protected float dragY; public InfinityAnimation getYAnim() { return this.yAnim; }
/* 48 */   public float getTargetX() { return this.targetX; } public float getTargetY() { return this.targetY; }
/*    */ 
/*    */   
/* 51 */   public boolean isDragging() { return this.dragging; }
/* 52 */   public float getDragX() { return this.dragX; } public float getDragY() { return this.dragY; }
/*    */   
/*    */   public void drawPreview(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks, float anim) {
/* 55 */     this.activeAnim.setForward(this.active);
/*    */     
/* 57 */     if (this.dragging) {
/* 58 */       this.targetX = mouseX + this.dragX;
/* 59 */       this.targetY = mouseY + this.dragY;
/*    */     } 
/*    */     
/* 62 */     Round.draw(matrixStack, this.rect.width(bold.get(14).getWidth(this.name) + 5.0F).height(10.0F), 2.0F, rock.getThemes().getThirdColor().alpha(anim).alpha((1.0F - this.activeAnim.get())));
/*    */     
/* 64 */     bold.get(14).draw(matrixStack, this.name, this.rect.getX() + 2.0F, this.rect.getY() + 0.5F, rock.getThemes().getTextSecondColor().alpha(anim).darker(0.1F).alpha((1.0F - this.activeAnim.get())));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean clicked(double mouseX, double mouseY, int button) {
/* 70 */     if (Hover.isHovered(this.active ? this.rect : this.rect.width(bold.get(14).getWidth(this.name) + 5.0F).height(10.0F), mouseX, mouseY)) {
/* 71 */       this.dragging = true;
/* 72 */       this.dragX = (int)(this.rect.getX() - mouseX);
/* 73 */       this.dragY = (int)(this.rect.getY() - mouseY);
/* 74 */       return false;
/*    */     } 
/* 76 */     return false;
/*    */   }
/*    */   
/*    */   public void released(double mouseX, double mouseY, int button) {
/* 80 */     this.dragging = false;
/*    */   }
/*    */   
/*    */   public abstract void drawOnEntity(MatrixStack paramMatrixStack, LivingEntity paramLivingEntity, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5);
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\clickgui\esp\ESPElement.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */