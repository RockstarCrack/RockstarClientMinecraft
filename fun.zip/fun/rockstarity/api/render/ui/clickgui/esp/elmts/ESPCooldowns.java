/*     */ package fun.rockstarity.api.render.ui.clickgui.esp.elmts;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import fun.rockstarity.api.events.Event;
/*     */ import fun.rockstarity.api.events.list.game.EventTotemBreak;
/*     */ import fun.rockstarity.api.events.list.game.EventUsePearl;
/*     */ import fun.rockstarity.api.events.list.player.EventFinishEat;
/*     */ import fun.rockstarity.api.helpers.game.Server;
/*     */ import fun.rockstarity.api.helpers.render.Render;
/*     */ import fun.rockstarity.api.helpers.system.TextUtility;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.shaders.list.Round;
/*     */ import fun.rockstarity.api.render.ui.clickgui.esp.ESPEventable;
/*     */ import fun.rockstarity.api.render.ui.clickgui.esp.ESPSettings;
/*     */ import fun.rockstarity.api.render.ui.clickgui.esp.elmts.cooldowns.ItemData;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import net.minecraft.entity.LivingEntity;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.Items;
/*     */ import net.minecraft.util.IItemProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ESPCooldowns
/*     */   extends ESPEventable
/*     */ {
/*     */   public ESPCooldowns() {
/*  34 */     super("Задержки");
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawPreview(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks, float anim) {
/*  39 */     super.drawPreview(matrixStack, mouseX, mouseY, partialTicks, anim);
/*     */     
/*  41 */     if (this.activeAnim.finished(false))
/*     */       return; 
/*  43 */     anim *= this.activeAnim.get();
/*     */     
/*  45 */     ESPSettings settings = rock.getClickGui().getWindow().getEspSettings();
/*  46 */     Rect previewRect = settings.getPreviewRect();
/*     */     
/*  48 */     float x = previewRect.getX() + previewRect.getWidth() / 2.0F - 25.0F;
/*  49 */     float y = previewRect.getY() + previewRect.getHeight() / 2.0F - 60.0F;
/*     */     
/*  51 */     String text = "13.1 сек";
/*  52 */     float width = semibold.get(14).getWidth(text) + 19.0F;
/*     */     
/*  54 */     if (!this.dragging) {
/*  55 */       switch (this.direction) {
/*     */         case 0:
/*  57 */           this.targetX = x;
/*  58 */           this.targetY = y - 15.0F;
/*     */           break;
/*     */         case 1:
/*  61 */           this.targetX = x;
/*  62 */           this.targetY = y + 122.0F;
/*     */           break;
/*     */         case 2:
/*  65 */           this.targetX = x - width;
/*  66 */           this.targetY = y;
/*     */           break;
/*     */         case 3:
/*  69 */           this.targetX = x + 52.0F;
/*  70 */           this.targetY = y;
/*     */           break;
/*     */       } 
/*     */     
/*     */     }
/*  75 */     if (!this.dragging) {
/*  76 */       this.targetY += this.yOffset;
/*  77 */       this.targetX += this.xOffset;
/*     */     } 
/*     */     
/*  80 */     this.rect.setWidth(width);
/*  81 */     this.rect.setHeight(13.0F);
/*     */     
/*  83 */     Round.draw(matrixStack, new Rect(this.targetX, this.targetY, width, 13.0F), 3.0F, rock.getThemes().getDarkTheme().getThirdColor().alpha(anim));
/*  84 */     Render.drawStackOld(new ItemStack((IItemProvider)Items.ENCHANTED_GOLDEN_APPLE), this.targetX + 2.0F, this.targetY, 0.7F * anim);
/*  85 */     semibold.get(14).draw(matrixStack, text, this.targetX + 14.0F, this.targetY + 1.0F, FixColor.WHITE.alpha(anim));
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawOnEntity(MatrixStack matrixStack, LivingEntity entity, float x, float y, float width, float height, float anim) {
/*  90 */     anim *= this.activeAnim.get();
/*     */     
/*  92 */     float posX = 0.0F;
/*  93 */     float posY = 0.0F;
/*     */     
/*  95 */     y += this.yOffset;
/*  96 */     x += this.xOffset;
/*     */     
/*  98 */     switch (this.direction) {
/*     */       case 0:
/* 100 */         posX = x + width / 2.0F;
/* 101 */         posY = y - 15.0F;
/*     */         break;
/*     */       case 1:
/* 104 */         posX = x + width / 2.0F;
/* 105 */         posY = y + height;
/*     */         break;
/*     */       case 2:
/* 108 */         posX = x;
/* 109 */         posY = y;
/*     */         break;
/*     */       case 3:
/* 112 */         posX = x + width;
/* 113 */         posY = y;
/*     */         break;
/*     */     } 
/*     */     
/* 117 */     entity.getDatas().removeIf(data -> data.getCreation().passed(data.getCooldown()));
/*     */     
/* 119 */     float off = 0.0F;
/* 120 */     for (ItemData stack : entity.getDatas()) {
/* 121 */       drawData(matrixStack, stack, posX, posY, this.direction, off, anim);
/*     */       
/* 123 */       off += 14.0F;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void drawData(MatrixStack matrixStack, ItemData data, float x, float y, int direction, float off, float anim) {
/* 128 */     String text = TextUtility.formatNumberOld(((float)(data.getCooldown() - data.getCreation().getElapsed()) / 1000.0F)) + " сек";
/* 129 */     float width = semibold.get(14).getWidth(text) + 19.0F;
/*     */     
/* 131 */     x += (direction == 2) ? -width : 0.0F;
/* 132 */     x -= (direction == 0 || direction == 1) ? (width / 2.0F) : 0.0F;
/* 133 */     y += (direction == 0) ? -off : off;
/*     */     
/* 135 */     Round.draw(matrixStack, new Rect(x, y, width, 13.0F), 3.0F, rock.getThemes().getDarkTheme().getThirdColor().alpha(anim));
/* 136 */     Render.drawStackOld(new ItemStack((IItemProvider)data.getItem()), x + 2.0F, y, 0.7F * anim);
/* 137 */     semibold.get(14).draw(matrixStack, text, x + 14.0F, y + 1.0F, FixColor.WHITE.alpha(anim));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean clicked(double mouseX, double mouseY, int button) {
/* 142 */     String text = "13.1 сек";
/* 143 */     float width = semibold.get(14).getWidth(text) + 19.0F;
/*     */     
/* 145 */     this.rect.setWidth(width);
/* 146 */     this.rect.setHeight(13.0F);
/*     */     
/* 148 */     return super.clicked(mouseX, mouseY, button);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEvent(Event event) {
/* 153 */     if (event instanceof EventTotemBreak) { EventTotemBreak e = (EventTotemBreak)event;
/* 154 */       e.getEntity().getDatas().removeIf(item -> (item.getItem() == Items.TOTEM_OF_UNDYING));
/* 155 */       e.getEntity().getDatas().add(new ItemData(Server.is("spooky") ? 15000L : 120000L, Items.TOTEM_OF_UNDYING)); }
/*     */ 
/*     */     
/* 158 */     if (event instanceof EventFinishEat) { EventFinishEat e = (EventFinishEat)event;
/* 159 */       if (e.getItem() == Items.ENCHANTED_GOLDEN_APPLE) {
/* 160 */         e.getEntity().getDatas().removeIf(item -> (item.getItem() == Items.ENCHANTED_GOLDEN_APPLE));
/* 161 */         e.getEntity().getDatas().add(new ItemData(150000L, Items.ENCHANTED_GOLDEN_APPLE));
/*     */       } 
/*     */       
/* 164 */       if (e.getItem() == Items.GOLDEN_APPLE) {
/* 165 */         e.getEntity().getDatas().removeIf(item -> (item.getItem() == Items.GOLDEN_APPLE));
/* 166 */         e.getEntity().getDatas().add(new ItemData(30000L, Items.GOLDEN_APPLE));
/*     */       } 
/*     */       
/* 169 */       if (e.getItem() == Items.CHORUS_FRUIT) {
/* 170 */         e.getEntity().getDatas().removeIf(item -> (item.getItem() == Items.CHORUS_FRUIT));
/* 171 */         e.getEntity().getDatas().add(new ItemData(25000L, Items.CHORUS_FRUIT));
/*     */       }  }
/*     */ 
/*     */     
/* 175 */     if (event instanceof EventUsePearl) { EventUsePearl e = (EventUsePearl)event;
/* 176 */       e.getThrower().getDatas().removeIf(item -> (item.getItem() == Items.ENDER_PEARL));
/* 177 */       e.getThrower().getDatas().add(new ItemData(60000L, Items.ENDER_PEARL)); }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\clickgui\esp\elmts\ESPCooldowns.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */