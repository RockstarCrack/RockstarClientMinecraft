/*     */ package fun.rockstarity.api.render.ui.clickgui.windows;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import fun.rockstarity.api.binds.Bind;
/*     */ import fun.rockstarity.api.binds.BindType;
/*     */ import fun.rockstarity.api.binds.Bindable;
/*     */ import fun.rockstarity.api.helpers.game.Binds;
/*     */ import fun.rockstarity.api.helpers.math.Hover;
/*     */ import fun.rockstarity.api.helpers.render.Stencil;
/*     */ import fun.rockstarity.api.modules.settings.Setting;
/*     */ import fun.rockstarity.api.render.animation.Animation;
/*     */ import fun.rockstarity.api.render.animation.Easing;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.color.themes.Style;
/*     */ import fun.rockstarity.api.render.shaders.list.Round;
/*     */ import fun.rockstarity.api.render.ui.clickgui.SettingRect;
/*     */ import fun.rockstarity.api.render.ui.fonts.FontSize;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import fun.rockstarity.api.render.ui.widgets.Window;
/*     */ import java.awt.Color;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BindWindow
/*     */   extends Window
/*     */ {
/*     */   private boolean binding;
/*     */   private final Bind bind;
/*     */   private final BindListWindow parent;
/*  38 */   protected final Animation deleting = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300).setSize(1.0F);
/*     */   private SettingRect settingRect;
/*     */   
/*     */   public BindWindow(BindListWindow parent, Bind bind, float x, float y, float width, float height) {
/*  42 */     super(x, y, width, height);
/*  43 */     this.bind = bind;
/*  44 */     this.parent = parent;
/*  45 */     Bindable bindable = this.parent.getBindable(); if (bindable instanceof Setting) { Setting setting = (Setting)bindable; if (!(setting instanceof fun.rockstarity.api.modules.settings.list.Clickable) && !(setting instanceof fun.rockstarity.api.modules.settings.list.Binding) && !(setting instanceof fun.rockstarity.api.modules.settings.list.Select) && !(setting instanceof fun.rockstarity.api.modules.settings.list.Input) && !(setting instanceof fun.rockstarity.api.modules.settings.list.ColorPicker)) {
/*  46 */         this.settingRect = new SettingRect(setting);
/*     */       } }
/*     */   
/*     */   }
/*     */   
/*     */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/*  52 */     super.render(matrixStack, mouseX, mouseY, partialTicks);
/*  53 */     Round.draw(matrixStack, width(this.width * this.opening.get()), 4.0F, this.bgColor);
/*     */ 
/*     */ 
/*     */     
/*  57 */     Stencil.init();
/*  58 */     Round.draw(matrixStack, width(this.width * this.opening.get()), 4.0F, this.bgColor);
/*     */     
/*  60 */     Stencil.read(1);
/*     */     
/*  62 */     float yOff = -1.0F;
/*     */     
/*  64 */     FontSize font = bold.get(14);
/*  65 */     float inc = 12.0F;
/*     */ 
/*     */     
/*  68 */     font.draw(matrixStack, "Клавиша", this.x + 5.0F, this.y + 5.0F + yOff, this.text);
/*  69 */     String bind = this.binding ? "..." : Binds.getName(this.bind.getKey(), this.bind.getScancode()).toUpperCase();
/*  70 */     float bindWidth = font.getWidth(bind) + 4.0F;
/*  71 */     Round.draw(matrixStack, new Rect(this.x + this.width - 5.0F - bindWidth, this.y + 5.0F + yOff, bindWidth, 10.0F), 2.0F, this.bgColor.darker(0.05F));
/*  72 */     font.draw(matrixStack, bind, this.x + this.width - 5.0F - bindWidth + 1.7F, this.y + 5.5F + yOff, this.text);
/*  73 */     yOff += inc;
/*  74 */     font.draw(matrixStack, "Тип", this.x + 5.0F, this.y + 5.0F + yOff, this.text);
/*  75 */     float globalWidth = font.getWidth("ToggleHold") + 8.0F;
/*  76 */     Round.draw(matrixStack, new Rect(this.x + this.width - 5.0F - globalWidth, this.y + 5.0F + yOff, globalWidth, 10.0F), 2.0F, this.bgColor.darker(0.05F));
/*  77 */     float xOff = 0.0F;
/*  78 */     for (BindType type : BindType.values()) {
/*  79 */       float nameWidth = font.getWidth(type.getName());
/*  80 */       if (this.bind.getType() == type) {
/*  81 */         if (type == BindType.HOLD) {
/*  82 */           Round.draw(matrixStack, new Rect(this.x + this.width - 5.0F - globalWidth + xOff, this.y + 5.0F + yOff, nameWidth + 4.5F, 10.0F), 2.0F, 0.0F, 2.0F, 0.0F, Style.getMain().alpha(this.opening.get()));
/*     */         } else {
/*  84 */           Round.draw(matrixStack, new Rect(this.x + this.width - 5.0F - globalWidth + xOff, this.y + 5.0F + yOff, nameWidth + 4.5F, 10.0F), 0.0F, 2.0F, 0.0F, 2.0F, Style.getMain().alpha(this.opening.get()));
/*     */         } 
/*     */       }
/*  87 */       font.draw(matrixStack, type.getName(), this.x + this.width - 5.0F - globalWidth + xOff + 2.0F, this.y + 5.0F + yOff, (this.bind.getType() == type) ? FixColor.WHITE.alpha(this.opening.get()) : this.text);
/*  88 */       xOff += nameWidth + 4.0F;
/*     */     } 
/*  90 */     yOff += inc;
/*     */     
/*  92 */     font.draw(matrixStack, "Управление", this.x + 5.0F, this.y + 5.0F + yOff, this.text);
/*  93 */     String del = "Удалить";
/*  94 */     this.deleting.setForward(Hover.isHovered((this.x + 5.0F), (this.y + 5.0F + yOff), (this.width - 10.0F), inc, mouseX, mouseY));
/*  95 */     font.draw(matrixStack, del, this.x + this.width - 6.0F - font.getWidth(del), this.y + 5.0F + yOff, this.text.move((Color)FixColor.RED, this.deleting.get()));
/*  96 */     yOff += inc;
/*     */     
/*  98 */     if (this.settingRect != null) {
/*  99 */       font.draw(matrixStack, "Значение", this.x + 5.0F, this.y + 5.5F + yOff, this.text);
/* 100 */       this.settingRect.set(this.x - 3.0F, this.y + yOff - 4.0F, this.width + 6.0F, this.settingRect.getHeight());
/* 101 */       this.settingRect.render(matrixStack, mouseX, mouseY, 0.0F, this.opening.get(), true, false);
/* 102 */       yOff += this.settingRect.getParent().getBindHeight() - 12.0F;
/*     */     } 
/*     */     
/* 105 */     setHeight(yOff + 6.0F);
/*     */     
/* 107 */     Stencil.finish();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean clicked(double mouseX, double mouseY, int button) {
/* 112 */     if (this.binding) {
/* 113 */       this.bind.setKey(-1);
/* 114 */       this.bind.setScancode(button);
/* 115 */       this.binding = false;
/* 116 */       return false;
/*     */     } 
/*     */     
/* 119 */     float yOff = 0.0F;
/*     */     
/* 121 */     FontSize font = bold.get(14);
/* 122 */     float inc = 11.0F;
/*     */     
/* 124 */     String bind = Binds.getName(this.bind.getKey(), this.bind.getScancode()).toUpperCase();
/* 125 */     float bindWidth = font.getWidth(bind) + 4.0F;
/* 126 */     if (Hover.isHovered((this.x + this.width - 5.0F - bindWidth), (this.y + 5.0F + yOff), bindWidth, 10.0D, mouseX, mouseY)) {
/* 127 */       this.binding = true;
/*     */     }
/* 129 */     yOff += inc;
/*     */     
/* 131 */     float globalWidth = font.getWidth("ToggleHold") + 8.0F;
/* 132 */     float xOff = 0.0F;
/* 133 */     for (BindType type : BindType.values()) {
/* 134 */       float nameWidth = font.getWidth(type.getName());
/* 135 */       if (Hover.isHovered((this.x + this.width - 5.0F - globalWidth + xOff), (this.y + 5.0F + yOff), (nameWidth + 4.5F), 10.0D, mouseX, mouseY)) {
/* 136 */         this.bind.setType(type);
/*     */       }
/* 138 */       xOff += nameWidth + 4.0F;
/*     */     } 
/* 140 */     yOff += inc;
/*     */     
/* 142 */     if (Hover.isHovered((this.x + 5.0F), (this.y + 5.0F + yOff), (this.width - 10.0F), inc, mouseX, mouseY)) {
/* 143 */       this.parent.getBindable().getBinds().remove(this.bind);
/* 144 */       this.opening.setForward(false);
/*     */     } 
/* 146 */     yOff += inc;
/*     */     
/* 148 */     if (!super.clicked(mouseX, mouseY, button)) {
/* 149 */       this.parent.setActive(null);
/* 150 */       return true;
/*     */     } 
/*     */     
/* 153 */     if (this.settingRect != null) {
/* 154 */       this.settingRect.clicked(mouseX, mouseY, button, false, true);
/*     */     }
/*     */     
/* 157 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean released(double mouseX, double mouseY, int button) {
/* 162 */     if (this.settingRect != null) {
/* 163 */       this.settingRect.clicked(mouseX, mouseY, button, true, true);
/*     */     }
/* 165 */     return super.released(mouseX, mouseY, button);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean dragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
/* 170 */     FontSize font = bold.get(14);
/* 171 */     float inc = 11.0F;
/* 172 */     float yOff = 0.0F;
/* 173 */     yOff += inc * 3.0F;
/*     */     
/* 175 */     if (this.settingRect != null) {
/* 176 */       this.settingRect.dragged(mouseX, mouseY, button, dragX, dragY, true);
/*     */     }
/*     */     
/* 179 */     return super.dragged(mouseX, mouseY, button, dragX, dragY);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean pressed(int keyCode, int scanCode, int modifiers) {
/* 184 */     if (this.binding) {
/* 185 */       this.bind.setKey(keyCode);
/* 186 */       this.bind.setScancode(scanCode);
/* 187 */       this.binding = false;
/*     */     } 
/*     */     
/* 190 */     if (this.settingRect != null) {
/* 191 */       this.parent.pressed(keyCode, scanCode, modifiers);
/*     */     }
/*     */     
/* 194 */     return super.pressed(keyCode, scanCode, modifiers);
/*     */   }
/*     */ 
/*     */   
/*     */   public void charTyped(char codePoint, int modifiers) {
/* 199 */     if (this.settingRect != null) {
/* 200 */       this.settingRect.charTyped(codePoint, modifiers);
/*     */     }
/*     */     
/* 203 */     super.charTyped(codePoint, modifiers);
/*     */   }
/*     */ 
/*     */   
/*     */   public void tick() {
/* 208 */     if (this.settingRect != null) {
/* 209 */       this.settingRect.tick();
/*     */     }
/*     */     
/* 212 */     super.tick();
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\clickgui\windows\BindWindow.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */