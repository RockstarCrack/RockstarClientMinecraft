/*     */ package fun.rockstarity.api.render.ui.clickgui.windows;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import fun.rockstarity.api.binds.Bindable;
/*     */ import fun.rockstarity.api.helpers.math.Hover;
/*     */ import fun.rockstarity.api.helpers.render.Stencil;
/*     */ import fun.rockstarity.api.modules.settings.Setting;
/*     */ import fun.rockstarity.api.modules.settings.list.Mode;
/*     */ import fun.rockstarity.api.modules.settings.list.Select;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.shaders.list.Outline;
/*     */ import fun.rockstarity.api.render.shaders.list.Round;
/*     */ import fun.rockstarity.api.render.ui.clickgui.SettingRect;
/*     */ import fun.rockstarity.api.render.ui.clickgui.esp.ESPElement;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import fun.rockstarity.api.render.ui.widgets.Window;
/*     */ import fun.rockstarity.client.modules.render.Interface;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SettingsWindow
/*     */   extends Window
/*     */ {
/*     */   private final Bindable element;
/*  31 */   private final ArrayList<SettingRect> settings = new ArrayList<>();
/*     */   
/*     */   public SettingsWindow(Bindable parent, float x, float y) {
/*  34 */     super(x, y, 145.0F, 10.0F);
/*  35 */     this.element = parent;
/*     */ 
/*     */     
/*  38 */     if (parent instanceof ESPElement) { ESPElement ui = (ESPElement)parent;
/*  39 */       for (Setting setting : ui.getSettings()) {
/*  40 */         this.settings.add(new SettingRect(setting));
/*     */       }
/*     */       
/*     */       return; }
/*     */     
/*  45 */     if (parent instanceof Setting) { Setting ui = (Setting)parent;
/*  46 */       for (Setting setting : ui.getSettings()) {
/*  47 */         this.settings.add(new SettingRect(setting));
/*     */       }
/*     */       
/*     */       return; }
/*     */     
/*  52 */     if (parent instanceof Interface.UIElement) { Interface.UIElement ui = (Interface.UIElement)parent;
/*  53 */       for (Setting setting : ui.getSettings()) {
/*  54 */         this.settings.add(new SettingRect(setting));
/*     */       }
/*     */       
/*     */       return; }
/*     */     
/*  59 */     if (parent instanceof Select.Element) { Select.Element ui = (Select.Element)parent;
/*  60 */       for (Setting setting : ui.getSettings()) {
/*  61 */         this.settings.add(new SettingRect(setting));
/*     */       }
/*     */       
/*     */       return; }
/*     */     
/*  66 */     if (parent instanceof Mode.Element) { Mode.Element ui = (Mode.Element)parent;
/*  67 */       for (Setting setting : ui.getSettings()) {
/*  68 */         this.settings.add(new SettingRect(setting));
/*     */       }
/*     */       return; }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/*  76 */     int count = 0;
/*     */     
/*  78 */     this.x = Math.min(sr.getScaledWidth() - this.width, this.x);
/*  79 */     this.y = Math.min(sr.getScaledHeight() - this.height - 10.0F, this.y);
/*     */     
/*  81 */     Round.draw(matrixStack, (Rect)this, 8.0F, rock.getThemes().getFirstColor().alpha(this.opening.get()));
/*     */     
/*  83 */     Stencil.init();
/*  84 */     Round.draw(matrixStack, (Rect)this, 8.0F, rock.getThemes().getFirstColor().alpha(this.opening.get()));
/*  85 */     Stencil.read(1);
/*     */     
/*  87 */     float yOff = 0.0F;
/*  88 */     for (SettingRect setting : this.settings) {
/*  89 */       setting.getHide().setForward(setting.getParent().isHide());
/*     */       
/*  91 */       setting.set(this.x, this.y + yOff - 2.0F - 10.0F + 10.0F * this.opening.get() * (1.0F - setting.getHide().get()), 145.0F, setting.getHeight());
/*  92 */       setting.render(matrixStack, mouseX, mouseY, partialTicks, this.opening.get() * (1.0F - setting.getHide().get()), false, false);
/*     */       
/*  94 */       if (Hover.isHovered((Rect)setting, mouseX, mouseY)) {
/*  95 */         rock.getClickGui().getWindow().getRenderer().setHovered(setting);
/*     */       }
/*     */       
/*  98 */       if (!setting.getParent().isHide()) {
/*  99 */         count++;
/*     */       }
/* 101 */       yOff += (setting.getHeight() - 13.0F) * (1.0F - setting.getHide().get());
/*     */     } 
/* 103 */     Stencil.finish();
/*     */     
/* 105 */     Interface ui = (Interface)rock.getModules().get(Interface.class);
/*     */     
/* 107 */     FixColor[] circle = Interface.getCircle(this.opening.get());
/*     */     
/* 109 */     Outline.draw(matrixStack, y(getY()).size(-0.25F), 8.0F, ui.getOutlineWidth().get() / 4.0F, rock.getThemes().getFoursColor().alpha(this.opening.get()));
/*     */     
/* 111 */     this.height = yOff + 10.0F;
/*     */     
/* 113 */     if (count == 0) {
/* 114 */       this.opening.setForward(false);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean clicked(double mouseX, double mouseY, int button) {
/* 120 */     if (button != 0) return super.clicked(mouseX, mouseY, button);
/*     */     
/* 122 */     float yOff = 0.0F;
/* 123 */     for (SettingRect setting : this.settings) {
/* 124 */       if (setting.getParent().isHide()) {
/*     */         continue;
/*     */       }
/* 127 */       if (Hover.isHovered(setting.y(this.y + yOff - 2.0F - 10.0F + 10.0F * this.opening.get() + 3.0F).height(setting.getHeight() - 14.0F), mouseX, mouseY)) {
/* 128 */         setting.clicked(mouseX, mouseY, button, false);
/*     */       }
/* 130 */       yOff += setting.getHeight() - 13.0F;
/*     */     } 
/*     */     
/* 133 */     return super.clicked(mouseX, mouseY, button);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean released(double mouseX, double mouseY, int button) {
/* 138 */     if (button != 0) return super.clicked(mouseX, mouseY, button);
/*     */     
/* 140 */     for (SettingRect setting : this.settings) {
/* 141 */       if (setting.getParent().isHide()) {
/*     */         continue;
/*     */       }
/* 144 */       setting.clicked(mouseX, mouseY, button, true);
/*     */     } 
/*     */     
/* 147 */     return super.released(mouseX, mouseY, button);
/*     */   }
/*     */ 
/*     */   
/*     */   public void charTyped(char codePoint, int modifiers) {
/* 152 */     for (SettingRect setting : this.settings) {
/* 153 */       if (setting.getParent().isHide()) {
/*     */         continue;
/*     */       }
/* 156 */       setting.charTyped(codePoint, modifiers);
/*     */     } 
/* 158 */     super.charTyped(codePoint, modifiers);
/*     */   }
/*     */ 
/*     */   
/*     */   public void tick() {
/* 163 */     for (SettingRect setting : this.settings) {
/* 164 */       if (setting.getParent().isHide()) {
/*     */         continue;
/*     */       }
/* 167 */       setting.tick();
/*     */     } 
/* 169 */     super.tick();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean pressed(int keyCode, int scanCode, int modifiers) {
/* 174 */     for (SettingRect setting : this.settings) {
/* 175 */       if (setting.getParent().isHide()) {
/*     */         continue;
/*     */       }
/* 178 */       setting.pressed(keyCode, scanCode, modifiers);
/*     */     } 
/* 180 */     return super.pressed(keyCode, scanCode, modifiers);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\clickgui\windows\SettingsWindow.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */