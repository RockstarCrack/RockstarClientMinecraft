/*     */ package fun.rockstarity.api.render.ui.clickgui.windows;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import fun.rockstarity.api.helpers.math.Hover;
/*     */ import fun.rockstarity.api.helpers.render.Render;
/*     */ import fun.rockstarity.api.helpers.render.Stencil;
/*     */ import fun.rockstarity.api.modules.Category;
/*     */ import fun.rockstarity.api.modules.settings.list.ColorPicker;
/*     */ import fun.rockstarity.api.render.animation.Animation;
/*     */ import fun.rockstarity.api.render.animation.Easing;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.color.themes.Style;
/*     */ import fun.rockstarity.api.render.shaders.list.Outline;
/*     */ import fun.rockstarity.api.render.shaders.list.Round;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import fun.rockstarity.api.render.ui.widgets.Window;
/*     */ import fun.rockstarity.api.secure.Debugger;
/*     */ import java.awt.Color;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.DoubleBuffer;
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import org.lwjgl.glfw.GLFW;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import org.lwjgl.system.MemoryStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PickerWindow
/*     */   extends Window
/*     */ {
/*     */   private final ColorPicker parent;
/*  38 */   protected final Animation clientColorAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); private boolean dragPicker; private boolean dragHue; private boolean pick; private int current;
/*     */   private float hue;
/*     */   private float brightness;
/*     */   private float saturation;
/*  42 */   protected final Animation pickAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300);
/*     */   
/*     */   public PickerWindow(ColorPicker parent, float x, float y, float width, float height) {
/*  45 */     super(x, y, width, height);
/*  46 */     this.parent = parent;
/*     */     
/*  48 */     if (parent.getColors().isEmpty()) {
/*  49 */       parent.add(new FixColor[] { FixColor.RED });
/*     */     }
/*  51 */     updateColor();
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/*  56 */     super.render(matrixStack, mouseX, mouseY, partialTicks);
/*     */     
/*  58 */     this.clientColorAnim.setForward(this.parent.isClient());
/*     */     
/*  60 */     Round.draw(matrixStack, height(this.height * this.opening.get()), 7.0F, this.bgColor);
/*     */     
/*  62 */     Stencil.init();
/*  63 */     Round.draw(matrixStack, width(this.width * this.opening.get()), 7.0F, this.bgColor);
/*  64 */     Stencil.read(1);
/*     */     
/*  66 */     float animX = this.width * this.clientColorAnim.get() - this.width;
/*     */     
/*  68 */     Round.draw(matrixStack, new Rect(this.x + 5.0F, this.y + 5.0F, 9.0F, 9.0F), 2.0F, this.actionsColor.move((Color)Style.getMain(), this.clientColorAnim.get()).alpha(this.opening.get()));
/*     */     
/*  70 */     Render.image("icons/checkmark.png", this.x + 6.0F, this.y + 6.0F, 7.0F, 7.0F, (Color)FixColor.WHITE.alpha((this.opening.get() * this.clientColorAnim.get())));
/*     */     
/*  72 */     bold.get(12).draw(matrixStack, "Брать цвет из стиля", this.x + 17.0F, this.y + 5.0F, rock.getThemes().getTextFirstColor().alpha(this.opening.get()));
/*     */     
/*  74 */     semibold.get(12).draw(matrixStack, "На данный момент выбран цвет", this.x + 5.0F - animX, this.y + 17.0F, rock.getThemes().getTextFirstColor().alpha(this.opening.get()));
/*  75 */     semibold.get(12).draw(matrixStack, "стиля клиента. Стиль клиента", this.x + 5.0F - animX, this.y + 25.0F, rock.getThemes().getTextFirstColor().alpha(this.opening.get()));
/*  76 */     semibold.get(12).draw(matrixStack, "можно поменять на ", this.x + 5.0F - animX, this.y + 33.0F, rock.getThemes().getTextFirstColor().alpha(this.opening.get()));
/*     */     
/*  78 */     bold.get(12).draw(matrixStack, "этой странице", this.x + 6.0F - animX + semibold.get(12).getWidth("можно поменять на "), this.y + 33.25F, (new FixColor(0.0D, 0.0D, 0.0D, 100.0D)).alpha(this.opening.get()));
/*  79 */     bold.get(12).draw(matrixStack, "этой странице", this.x + 5.5F - animX + semibold.get(12).getWidth("можно поменять на "), this.y + 32.75F, Style.getMain().alpha(this.opening.get()));
/*     */     
/*  81 */     if (!this.parent.isClient() || this.opening.finished()) {
/*  82 */       FixColor clor = this.parent.getColors().get(this.current);
/*  83 */       float[] hsb = Color.RGBtoHSB(clor.getRed(), clor.getGreen(), clor.getBlue(), null);
/*  84 */       float ht = 108.0F;
/*     */       
/*  86 */       Round.draw(matrixStack, new Rect(this.x + 5.0F - animX - this.width, this.y + 33.0F, 108.0F, 108.0F), 5.0F, FixColor.WHITE
/*  87 */           .alpha((this.opening.get() * (1.0F - this.clientColorAnim.get()))), (new FixColor(
/*  88 */             FixColor.getHSBColor(this.hue, 1.0F, 1.0F))).alpha((this.opening.get() * (1.0F - this.clientColorAnim.get()))), FixColor.BLACK
/*  89 */           .alpha((this.opening.get() * (1.0F - this.clientColorAnim.get()))), FixColor.BLACK
/*  90 */           .alpha((this.opening.get() * (1.0F - this.clientColorAnim.get()))));
/*     */       
/*  92 */       float xOff = 0.0F, i = 0.0F;
/*  93 */       for (FixColor color : this.parent.getColors()) {
/*  94 */         color.getSelectAnim().setForward((this.current == i++));
/*     */         
/*  96 */         float off = 1.0F + color.getSelectAnim().get();
/*  97 */         Round.draw(matrixStack, new Rect(this.x + 5.0F - animX - this.width + xOff, this.y + 18.0F, 10.0F, 10.0F), 5.0F, this.actionsColor);
/*  98 */         Round.draw(matrixStack, new Rect(this.x + 5.0F - animX - this.width + xOff + off, this.y + 18.0F + off, 10.0F - off * 2.0F, 10.0F - off * 2.0F), 5.0F - off, color);
/*     */         
/* 100 */         xOff += 12.0F;
/*     */       } 
/*     */       
/* 103 */       if (this.parent.getColors().size() < 9) {
/* 104 */         Round.draw(matrixStack, new Rect(this.x + 5.0F - animX - this.width + xOff, this.y + 18.0F, 10.0F, 10.0F), 5.0F, this.actionsColor);
/* 105 */         Round.draw(matrixStack, new Rect(this.x + 5.0F - animX - this.width + xOff + 4.5F, this.y + 20.0F, 1.0F, 6.0F), 0.0F, rock.getThemes().getTextFirstColor().alpha((this.opening.get() * (1.0F - this.clientColorAnim.get()))));
/* 106 */         Round.draw(matrixStack, new Rect(this.x + 5.0F - animX - this.width + xOff + 2.0F, this.y + 18.0F + 4.5F, 6.0F, 1.0F), 0.0F, rock.getThemes().getTextFirstColor().alpha((this.opening.get() * (1.0F - this.clientColorAnim.get()))));
/*     */       } 
/*     */       
/* 109 */       Render.image("icons/pick.png", this.x + this.width - 5.0F - 8.0F, this.y + 5.0F, 8.0F, 8.0F, (Color)rock.getThemes().getTextFirstColor().alpha((this.opening.get() * (1.0F - this.clientColorAnim.get()))));
/*     */       
/* 111 */       float size = 10.0F;
/* 112 */       for (int i1 = 0; i1 < size; i1++) {
/* 113 */         FixColor color = new FixColor(FixColor.getHSBColor(1.0F / size * i1, 1.0F, 1.0F));
/* 114 */         FixColor next = new FixColor(FixColor.getHSBColor(1.0F / size * (i1 + 1.0F), 1.0F, 1.0F));
/*     */         
/* 116 */         Round.draw(matrixStack, new Rect(this.x - animX - 18.0F, this.y + 33.0F + i1 * ht / size, 13.0F, ht / size + ((i1 != size - 1.0F) ? 0.3F : 0.0F)), 
/* 117 */             (i1 == 0) ? 5.0F : 0.1F, (i1 == 0) ? 5.0F : 0.1F, (i1 == size - 1.0F) ? 5.0F : 0.1F, (i1 == size - 1.0F) ? 5.0F : 0.1F, color
/* 118 */             .alpha((this.opening.get() * (1.0F - this.clientColorAnim.get()))), color
/* 119 */             .alpha((this.opening.get() * (1.0F - this.clientColorAnim.get()))), next
/* 120 */             .alpha((this.opening.get() * (1.0F - this.clientColorAnim.get()))), next
/* 121 */             .alpha((this.opening.get() * (1.0F - this.clientColorAnim.get()))));
/*     */       } 
/*     */ 
/*     */       
/* 125 */       Round.draw(matrixStack, new Rect(this.x - animX - 14.6F, this.y + 35.0F + ht * this.hue, 6.0F, 6.0F), 3.0F, FixColor.WHITE.alpha((this.opening.get() * (1.0F - this.clientColorAnim.get()))));
/*     */       
/* 127 */       Outline.draw(matrixStack, new Rect(this.x + 5.0F - animX - this.width + 108.0F * this.saturation + 0.5F, this.y + 33.0F + 108.0F * this.brightness + 0.5F, 6.0F, 6.0F), 3.0F, 0.5F, FixColor.WHITE.alpha((this.opening.get() * (1.0F - this.clientColorAnim.get()))));
/*     */       
/* 129 */       if (this.dragPicker) {
/* 130 */         this.saturation = Hover.getSliderValue(0.0F, 0.95F, this.x + 5.0F - animX - this.width, ht * 0.95F, mouseX);
/* 131 */         this.brightness = Hover.getSliderValue(0.0F, 0.95F, this.y + 33.0F, ht * 0.95F, mouseY);
/* 132 */         this.parent.getColors().set(this.current, new FixColor(FixColor.getHSBColor(this.hue, this.saturation, 1.0F - this.brightness)));
/*     */       } 
/*     */       
/* 135 */       if (this.dragHue) {
/* 136 */         this.hue = Hover.getSliderValue(0.0F, 0.92F, this.y + 36.0F, ht * 0.92F, mouseY);
/* 137 */         this.parent.getColors().set(this.current, new FixColor(FixColor.getHSBColor(this.hue, hsb[1], hsb[2])));
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 142 */     setHeight(46.0F + 100.0F * (1.0F - this.clientColorAnim.get()));
/*     */     
/* 144 */     Stencil.finish();
/*     */     
/* 146 */     if (this.pick || (!this.pickAnim.finished(false) && this.opening.finished())) {
/* 147 */       FixColor color = FixColor.WHITE;
/*     */       try {
/* 149 */         double mouseX1 = 0.0D, mouseY1 = 0.0D;
/* 150 */         MemoryStack stack = MemoryStack.stackPush(); 
/* 151 */         try { DoubleBuffer xBuffer = stack.mallocDouble(1);
/* 152 */           DoubleBuffer yBuffer = stack.mallocDouble(1);
/* 153 */           GLFW.glfwGetCursorPos(Minecraft.getInstance().getMainWindow().getHandle(), xBuffer, yBuffer);
/* 154 */           mouseX1 = xBuffer.get(0);
/* 155 */           mouseY1 = Minecraft.getInstance().getMainWindow().getHeight() - yBuffer.get(0);
/* 156 */           if (stack != null) stack.close();  } catch (Throwable throwable) { if (stack != null)
/*     */             try { stack.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */               throw throwable; }
/* 159 */          ByteBuffer pixelBuffer = ByteBuffer.allocateDirect(4);
/* 160 */         GL11.glReadPixels((int)mouseX1, (int)mouseY1, 1, 1, 6408, 5121, pixelBuffer);
/*     */         
/* 162 */         int red = pixelBuffer.get() & 0xFF;
/* 163 */         int green = pixelBuffer.get() & 0xFF;
/* 164 */         int blue = pixelBuffer.get() & 0xFF;
/* 165 */         int alpha = pixelBuffer.get() & 0xFF;
/* 166 */         color = new FixColor(red, green, blue);
/* 167 */         Round.draw(matrixStack, new Rect((mouseX - 9), (mouseY - 27), 20.0F, 20.0F), 10.0F, FixColor.WHITE.alpha(this.pickAnim.get()));
/* 168 */         Round.draw(matrixStack, new Rect((mouseX - 7), (mouseY - 25), 16.0F, 16.0F), 8.0F, color.alpha(this.pickAnim.get()));
/* 169 */       } catch (Exception e) {
/* 170 */         Debugger.print(e);
/*     */       } 
/*     */     } 
/* 173 */     this.pickAnim.setForward(this.pick);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean clicked(double mouseX, double mouseY, int button) {
/* 178 */     float animX = this.width * this.clientColorAnim.get() - this.width;
/*     */     
/* 180 */     if (this.pick) {
/* 181 */       if (button == 0) {
/*     */         try {
/* 183 */           double mouseX1 = 0.0D, mouseY1 = 0.0D;
/* 184 */           MemoryStack stack = MemoryStack.stackPush(); 
/* 185 */           try { DoubleBuffer xBuffer = stack.mallocDouble(1);
/* 186 */             DoubleBuffer yBuffer = stack.mallocDouble(1);
/* 187 */             GLFW.glfwGetCursorPos(Minecraft.getInstance().getMainWindow().getHandle(), xBuffer, yBuffer);
/* 188 */             mouseX1 = xBuffer.get(0);
/* 189 */             mouseY1 = Minecraft.getInstance().getMainWindow().getHeight() - yBuffer.get(0);
/* 190 */             if (stack != null) stack.close();  } catch (Throwable throwable) { if (stack != null)
/*     */               try { stack.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }
/* 192 */            ByteBuffer pixelBuffer = ByteBuffer.allocateDirect(4);
/* 193 */           GL11.glReadPixels((int)mouseX1, (int)mouseY1, 1, 1, 6408, 5121, pixelBuffer);
/*     */           
/* 195 */           int red = pixelBuffer.get() & 0xFF;
/* 196 */           int green = pixelBuffer.get() & 0xFF;
/* 197 */           int blue = pixelBuffer.get() & 0xFF;
/* 198 */           int alpha = pixelBuffer.get() & 0xFF;
/*     */           
/* 200 */           FixColor color = new FixColor(red, green, blue);
/* 201 */           this.parent.getColors().set(this.current, color);
/* 202 */           float[] hsb = Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null);
/* 203 */           this.hue = hsb[0];
/* 204 */           this.brightness = hsb[1];
/* 205 */           this.saturation = hsb[2];
/* 206 */         } catch (Exception e) {
/* 207 */           e.printStackTrace();
/*     */         } 
/*     */       }
/* 210 */       this.pick = false;
/* 211 */       return false;
/*     */     } 
/* 213 */     if (!this.parent.isClient() && Hover.isHovered((this.x + this.width - 5.0F - 8.0F), (this.y + 5.0F), 8.0D, 8.0D, mouseX, mouseY)) {
/* 214 */       this.pick = true;
/*     */     }
/*     */     
/* 217 */     if (Hover.isHovered((this.x + 5.0F), (this.y + 5.0F), 80.0D, 9.0D, mouseX, mouseY)) {
/* 218 */       this.parent.set(!this.parent.isClient());
/*     */     }
/*     */     
/* 221 */     if (Hover.isHovered((this.x + 5.5F - animX + semibold.get(12).getWidth("можно поменять на ")), (this.y + 32.75F), bold.get(12).getWidth("этой странице"), 12.0D, mouseX, mouseY)) {
/* 222 */       rock.getClickGui().getWindow().changeCategory(Category.THEMES);
/* 223 */       this.opening.setForward(false);
/*     */     } 
/*     */     
/* 226 */     if (Hover.isHovered((Rect)this, mouseX, mouseY)) {
/* 227 */       if (Hover.isHovered((this.x + 5.0F - animX - this.width), (this.y + 28.0F), 113.0D, 108.0D, mouseX, mouseY)) {
/* 228 */         this.dragPicker = true;
/*     */       }
/*     */       
/* 231 */       if (Hover.isHovered((this.x - animX - 18.0F), (this.y + 34.0F), 13.0D, 108.0D, mouseX, mouseY)) {
/* 232 */         this.dragHue = true;
/*     */       }
/*     */       
/* 235 */       int i = 0;
/* 236 */       float xOff = 0.0F;
/* 237 */       for (FixColor color : new ArrayList(this.parent.getColors())) {
/* 238 */         float off = 1.0F + color.getSelectAnim().get();
/* 239 */         if (Hover.isHovered((this.x + 5.0F - animX - this.width + xOff), (this.y + 18.0F), 10.0D, 10.0D, mouseX, mouseY)) {
/* 240 */           if (button == 0) {
/* 241 */             this.current = i;
/* 242 */             updateColor();
/*     */           }
/* 244 */           else if (this.parent.getColors().size() > 1) {
/* 245 */             this.parent.getColors().remove(color);
/* 246 */             this.current = Math.max(0, i - 1);
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/* 251 */         i++;
/* 252 */         xOff += 12.0F;
/*     */       } 
/*     */       
/* 255 */       if (Hover.isHovered((this.x + 5.0F - animX - this.width + xOff), (this.y + 18.0F), 10.0D, 10.0D, mouseX, mouseY) && this.parent.getColors().size() < 9) {
/* 256 */         FixColor[] rainbow = { FixColor.RED, FixColor.ORANGE, FixColor.YELLOW, FixColor.GREEN, new FixColor(66.0D, 170.0D, 255.0D), FixColor.BLUE, new FixColor(139.0D, 0.0D, 255.0D) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 265 */         for (FixColor color : rainbow) {
/* 266 */           if (!this.parent.getColors().contains(color)) {
/* 267 */             this.parent.add(new FixColor[] { color });
/* 268 */             this.current = this.parent.getColors().size() - 1;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 276 */     return super.clicked(mouseX, mouseY, button);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean released(double mouseX, double mouseY, int button) {
/* 281 */     this.dragPicker = false;
/* 282 */     this.dragHue = false;
/* 283 */     return super.released(mouseX, mouseY, button);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean dragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
/* 288 */     if (this.dragPicker || this.dragHue) return super.dragged(mouseX, mouseY, button, dragX, dragY); 
/* 289 */     this.x = (float)(this.x + dragX);
/* 290 */     this.y = (float)(this.y + dragY);
/* 291 */     return super.dragged(mouseX, mouseY, button, dragX, dragY);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean pressed(int keyCode, int scanCode, int modifiers) {
/* 296 */     return super.pressed(keyCode, scanCode, modifiers);
/*     */   }
/*     */   
/*     */   private void updateColor() {
/* 300 */     FixColor clor = this.parent.getColors().get(this.current);
/* 301 */     float[] hsb = Color.RGBtoHSB(clor.getRed(), clor.getGreen(), clor.getBlue(), null);
/* 302 */     this.hue = hsb[0];
/* 303 */     this.saturation = hsb[1];
/* 304 */     this.brightness = 1.0F - hsb[2];
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\clickgui\windows\PickerWindow.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */