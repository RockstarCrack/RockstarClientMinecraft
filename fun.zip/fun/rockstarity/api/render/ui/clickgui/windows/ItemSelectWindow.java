/*     */ package fun.rockstarity.api.render.ui.clickgui.windows;
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import fun.rockstarity.api.autobuy.logic.items.MinecraftItem;
/*     */ import fun.rockstarity.api.helpers.math.Hover;
/*     */ import fun.rockstarity.api.helpers.render.Render;
/*     */ import fun.rockstarity.api.helpers.render.Stencil;
/*     */ import fun.rockstarity.api.modules.settings.list.ItemSelect;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.color.themes.Style;
/*     */ import fun.rockstarity.api.render.shaders.list.Round;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import fun.rockstarity.api.render.ui.widgets.InputWidget;
/*     */ import fun.rockstarity.api.render.ui.widgets.Window;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.Items;
/*     */ import net.minecraft.util.IItemProvider;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TranslationTextComponent;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class ItemSelectWindow extends Window {
/*     */   private float x;
/*     */   private float y;
/*     */   private float width;
/*  29 */   private float height = 50.0F;
/*     */   private float scroll;
/*     */   private float dragX;
/*     */   private float dragY;
/*     */   
/*     */   public ItemSelectWindow(ItemSelect parent, float x, float y, float width, float height) {
/*  35 */     super(x, y, width, height);
/*  36 */     this.x = x;
/*  37 */     this.y = y;
/*  38 */     this.width = width;
/*  39 */     this.parent = parent;
/*  40 */     this.height = 150.0F;
/*  41 */     this.input = new InputWidget(bold.get(15), 0, 0, 56, 15, (ITextComponent)new TranslationTextComponent(""), false);
/*     */   }
/*     */   private boolean dragWin; private boolean dragSize; private final ItemSelect parent; private InputWidget input;
/*     */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/*  45 */     FixColor mainColor = rock.getThemes().getFirstColor().alpha(this.opening.get());
/*  46 */     FixColor textColor = rock.getThemes().getTextFirstColor().alpha(this.opening.get());
/*  47 */     float y = this.y - this.height + 25.0F + (this.height + 25.0F) * this.opening.get();
/*  48 */     float offset = y + 18.0F;
/*     */     
/*  50 */     if (this.dragWin) {
/*  51 */       this.x = mouseX + this.dragX;
/*  52 */       this.y = mouseY + this.dragY;
/*     */     } 
/*     */     
/*  55 */     if (this.dragSize) {
/*  56 */       this.width = MathHelper.clamp(mouseX - this.x, 127.0F, 530.0F);
/*  57 */       this.height = MathHelper.clamp(mouseY - y, 107.0F, 430.0F);
/*     */     } 
/*     */     
/*  60 */     GL11.glPushMatrix();
/*  61 */     GL11.glEnable(3089);
/*  62 */     Render.scissor((this.x - 2.0F), this.y, (this.width + 4.0F), (this.height + 1.0F));
/*  63 */     Round.draw(matrixStack, new Rect(this.x, y, this.width, this.height), 5.0F, mainColor);
/*  64 */     bold.get(15).draw(matrixStack, "Выбор предмета", this.x + 4.0F, y + 3.0F, textColor);
/*  65 */     String hover = null;
/*  66 */     Stencil.init();
/*  67 */     Round.draw(matrixStack, new Rect(this.x, y + 18.0F, this.width, this.height - 18.0F), 5.0F, mainColor);
/*  68 */     Stencil.read(1);
/*  69 */     float scrollOff = 0.0F;
/*  70 */     float xOff = 7.0F, yOff = 22.0F + this.scroll;
/*     */     
/*  72 */     for (MinecraftItem set : Items.getMinecraftItems()) {
/*  73 */       Item item = set.getItem().asItem();
/*  74 */       if ((!(item instanceof net.minecraft.item.BlockItem) && this.parent.isOnlyBlocks()) || 
/*  75 */         item instanceof net.minecraft.item.AirItem)
/*     */         continue; 
/*  77 */       if (xOff > this.width || yOff > this.height)
/*  78 */         break;  if (!set.getName().toLowerCase().contains(this.input.getText().toLowerCase()))
/*  79 */         continue;  Round.draw(matrixStack, new Rect(this.x + xOff, y + yOff, 15.0F, 15.0F), 2.0F, textColor.alpha(0.10000000149011612D).move((Color)Style.getMain(), this.parent.getItems().contains(set) ? 1.0F : 0.0F));
/*  80 */       GL11.glPushMatrix();
/*  81 */       GlStateManager.translated((this.x + xOff), (y + yOff), 0.0D);
/*  82 */       GlStateManager.scaled(1.55D, 1.55D, 1.55D);
/*  83 */       (mc.getItemRenderer()).zLevel = -900.0F;
/*  84 */       Render.drawStack(new ItemStack((IItemProvider)item), 0.0F, 0.0F);
/*  85 */       GL11.glPopMatrix();
/*     */       
/*  87 */       if (Hover.isHovered((this.x + xOff), (y + yOff), 20.0D, 20.0D, mouseX, mouseY)) {
/*  88 */         hover = set.getName();
/*     */       }
/*     */       
/*  91 */       xOff += 20.0F;
/*  92 */       if (xOff + 20.0F > this.width) {
/*  93 */         yOff += 20.0F;
/*  94 */         scrollOff += 20.0F;
/*  95 */         xOff = 7.0F;
/*     */       } 
/*     */     } 
/*     */     
/*  99 */     if (-scrollOff > this.scroll) {
/* 100 */       this.scroll = -scrollOff;
/*     */     }
/*     */     
/* 103 */     Stencil.finish();
/* 104 */     Round.draw(matrixStack, new Rect(this.x + this.width - 52.5F, y + 2.5F, 50.0F, 10.0F), 2.0F, textColor.alpha(0.1D));
/* 105 */     this.input.x = (int)(this.x + this.width - 56.0F);
/* 106 */     this.input.y = (int)y + 2;
/* 107 */     this.input.renderButton(matrixStack, mouseX, mouseY, partialTicks, 1.0F);
/* 108 */     GL11.glDisable(3089);
/* 109 */     GL11.glPopMatrix();
/*     */     
/* 111 */     if (hover != null) {
/* 112 */       Round.draw(matrixStack, new Rect((mouseX + 10), mouseY, bold.get(15).getWidth(hover) + 5.0F, 11.0F), 2.0F, mainColor.alpha(0.5D));
/* 113 */       bold.get(15).draw(matrixStack, hover, (mouseX + 12), mouseY + 1.5F, textColor);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean clicked(double mouseX, double mouseY, int button) {
/* 118 */     float y = this.y - 25.0F + 25.0F * this.opening.get();
/* 119 */     float addOff = 12.5F;
/* 120 */     float offset = y + 18.0F;
/* 121 */     float scrollOff = 0.0F;
/* 122 */     float xOff = 7.0F, yOff = 22.0F + this.scroll;
/*     */     
/* 124 */     for (MinecraftItem set : Items.getMinecraftItems()) {
/*     */       
/* 126 */       if (xOff > this.width || yOff > this.height)
/* 127 */         break;  if (!set.getName().toLowerCase().contains(this.input.getText().toLowerCase()) || 
/* 128 */         set.getItem() instanceof net.minecraft.item.AirItem)
/*     */         continue; 
/* 130 */       if (Hover.isHovered((this.x + xOff), (y + yOff), 15.0D, 15.0D, mouseX, mouseY)) {
/* 131 */         if (this.parent.getItems().contains(set)) {
/* 132 */           this.parent.getItems().remove(set);
/*     */         } else {
/* 134 */           this.parent.getItems().add(set);
/*     */         } 
/* 136 */         return true;
/*     */       } 
/*     */       
/* 139 */       xOff += 20.0F;
/* 140 */       if (xOff + 20.0F > this.width) {
/* 141 */         yOff += 20.0F;
/* 142 */         scrollOff += 20.0F;
/* 143 */         xOff = 7.0F;
/*     */       } 
/*     */     } 
/*     */     
/* 147 */     if (Hover.isHovered((this.x + this.width - 7.0F), (this.y + this.height - 7.0F), 7.0D, 7.0D, mouseX, mouseY)) {
/* 148 */       this.dragSize = true;
/* 149 */     } else if (Hover.isHovered(this.x, this.y, this.width, this.height, mouseX, mouseY)) {
/* 150 */       this.dragX = (float)(this.x - mouseX);
/* 151 */       this.dragY = (float)(this.y - mouseY);
/* 152 */       this.dragWin = true;
/*     */     } 
/*     */     
/* 155 */     this.input.mouseClicked(mouseX, mouseY, button);
/* 156 */     if (!Hover.isHovered(this.x, this.y, this.width, this.height, mouseX, mouseY)) {
/* 157 */       if (this.opening.finished())
/* 158 */         this.opening.setForward(false); 
/* 159 */       return false;
/*     */     } 
/* 161 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean released(double mouseX, double mouseY, int button) {
/* 166 */     this.dragWin = false;
/* 167 */     this.dragSize = false;
/* 168 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean dragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
/* 173 */     if (Hover.isHovered((Rect)this, mouseX, mouseY))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 179 */       return true;
/*     */     }
/* 181 */     return super.dragged(mouseX, mouseY, button, dragX, dragY);
/*     */   }
/*     */   
/*     */   public void scrolled(double mouseX, double mouseY, double delta) {
/* 185 */     this.scroll += Hover.isHovered(new Rect(this.x, this.y, this.width, this.height), mouseX, mouseY) ? (float)(delta * 15.0D) : 0.0F;
/* 186 */     if (this.scroll > 0.0F) this.scroll = 0.0F; 
/*     */   }
/*     */   
/*     */   public boolean pressed(int keyCode, int scanCode, int modifiers) {
/* 190 */     this.input.keyPressed(keyCode, scanCode, modifiers);
/* 191 */     return false;
/*     */   }
/*     */   
/*     */   public void charTyped(char typedChar, int keyCode) {
/* 195 */     this.input.charTyped(typedChar, keyCode);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\clickgui\windows\ItemSelectWindow.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */