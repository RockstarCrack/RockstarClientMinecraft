/*     */ package fun.rockstarity.api.render.ui.clickgui.windows;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import fun.rockstarity.api.binds.Bind;
/*     */ import fun.rockstarity.api.binds.BindType;
/*     */ import fun.rockstarity.api.binds.Bindable;
/*     */ import fun.rockstarity.api.helpers.game.Binds;
/*     */ import fun.rockstarity.api.helpers.math.Hover;
/*     */ import fun.rockstarity.api.helpers.render.Stencil;
/*     */ import fun.rockstarity.api.render.shaders.list.Round;
/*     */ import fun.rockstarity.api.render.ui.alerts.AlertType;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import fun.rockstarity.api.render.ui.widgets.Window;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import net.minecraft.client.settings.KeyBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BindListWindow
/*     */   extends Window
/*     */ {
/*     */   private Bind active;
/*     */   private BindWindow child;
/*     */   private final Bindable bindable;
/*     */   
/*     */   public Bind getActive() {
/*  37 */     return this.active; } public void setActive(Bind active) { this.active = active; }
/*     */   
/*     */   public Bindable getBindable() {
/*  40 */     return this.bindable;
/*     */   }
/*     */   
/*  43 */   private final LinkedHashMap<String, Runnable> actions = new LinkedHashMap<>();
/*     */   
/*     */   public BindListWindow(Bindable bindable, float x, float y, float width, float height) {
/*  46 */     super(x, y, width, height);
/*  47 */     this.bindable = bindable;
/*     */     
/*  49 */     update();
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/*  54 */     update();
/*     */     
/*  56 */     super.render(matrixStack, mouseX, mouseY, partialTicks);
/*  57 */     Round.draw(matrixStack, height(this.height * this.opening.get()), 4.0F, this.bgColor);
/*     */     
/*  59 */     Stencil.init();
/*  60 */     Round.draw(matrixStack, height(this.height * this.opening.get()), 4.0F, this.bgColor);
/*     */     
/*  62 */     Stencil.read(1);
/*     */     
/*  64 */     float yOff = 0.0F;
/*  65 */     for (Map.Entry<String, Runnable> action : this.actions.entrySet()) {
/*  66 */       Rect rect = new Rect(this.x + 2.0F, this.y + 2.0F + yOff, this.width - 4.0F, 15.0F);
/*  67 */       if (Hover.isHovered(rect, mouseX, mouseY) || (this.active != null && ((String)action.getKey()).contains(Binds.getName(this.active.getKey(), this.active.getScancode()))))
/*  68 */         Round.draw(matrixStack, rect, 2.0F, (this.active != null && ((String)action.getKey()).contains(Binds.getName(this.active.getKey(), this.active.getScancode()))) ? this.bgColor.darker(0.02F) : this.bgColor.darker(0.05F)); 
/*  69 */       bold.get(14).draw(matrixStack, action.getKey(), this.x + 6.0F, this.y + 4.5F + yOff, this.text);
/*  70 */       if (bold.get(14).getWidth(action.getKey()) + 12.0F > this.width) this.width = bold.get(14).getWidth(action.getKey()) + 12.0F;
/*     */       
/*  72 */       yOff += 17.0F;
/*     */     } 
/*     */     
/*  75 */     this.height = yOff + 2.0F;
/*     */     
/*  77 */     Stencil.finish();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean clicked(double mouseX, double mouseY, int button) {
/*  82 */     float yOff = 0.0F;
/*  83 */     for (Map.Entry<String, Runnable> action : this.actions.entrySet()) {
/*  84 */       Rect rect = new Rect(this.x + 2.0F, this.y + 2.0F + yOff, this.width - 4.0F, 15.0F);
/*  85 */       if (Hover.isHovered(rect, mouseX, mouseY)) {
/*  86 */         if (this.child != null) this.child.getOpening().setForward(false); 
/*  87 */         ((Runnable)action.getValue()).run();
/*     */       } 
/*     */       
/*  90 */       yOff += 17.0F;
/*     */     } 
/*     */     
/*  93 */     if (this.child != null && Hover.isHovered((Rect)this.child, mouseX, mouseY)) {
/*  94 */       return false;
/*     */     }
/*     */     
/*  97 */     return super.clicked(mouseX, mouseY, button);
/*     */   }
/*     */ 
/*     */   
/*     */   public void update() {
/* 102 */     this.actions.clear();
/* 103 */     this.actions.put("Добавить", () -> {
/*     */           Bind bind = new Bind(-1);
/*     */           
/*     */           this.bindable.getBinds().add(bind);
/*     */           showBind(bind);
/*     */         });
/* 109 */     for (Iterator<Bind> iterator = this.bindable.getBinds().iterator(); iterator.hasNext(); ) { Bind bind = iterator.next();
/* 110 */       this.actions.put(String.format("%s '%s'", new Object[] { bind.getType().getName(), Binds.getName(bind.getKey(), bind.getScancode()) }), () -> showBind(bind)); }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     this.actions.put("Очистить", () -> this.bindable.getBinds().clear());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean pressed(int keyCode, int scanCode, int modifiers) {
/* 122 */     if (keyCode != 256 && keyCode != scanCode && this.child == null && this.bindable.getBinds().size() < 5) {
/* 123 */       if (Arrays.<KeyBinding>stream(new KeyBinding[] {
/* 124 */             (mc.getGameSettings()).keyBindSneak, 
/* 125 */             (mc.getGameSettings()).keyBindSprint, 
/* 126 */             (mc.getGameSettings()).keyBindForward, 
/* 127 */             (mc.getGameSettings()).keyBindBack, 
/* 128 */             (mc.getGameSettings()).keyBindLeft, 
/* 129 */             (mc.getGameSettings()).keyBindRight, 
/* 130 */             (mc.getGameSettings()).keyBindJump
/* 131 */           }).anyMatch(key -> (key.getKeyCode().getKeyCode() == keyCode)))
/*     */       {
/*     */         
/* 134 */         return super.pressed(keyCode, scanCode, modifiers);
/*     */       }
/* 136 */       this.bindable.getBinds().add(new Bind(keyCode, scanCode, BindType.TOGGLE));
/* 137 */       rock.getAlertHandler().alert("Бинд добавлен!", AlertType.INFO);
/* 138 */       update();
/*     */     } 
/*     */     
/* 141 */     return super.pressed(keyCode, scanCode, modifiers);
/*     */   }
/*     */   
/*     */   private void showBind(Bind bind) {
/* 145 */     float height1 = 42.0F;
/* 146 */     float width1 = (this.bindable instanceof fun.rockstarity.api.modules.settings.list.Select || this.bindable instanceof fun.rockstarity.api.modules.settings.list.Mode) ? 140.0F : 120.0F;
/* 147 */     rock.getClickGui().getWindow().getWindows().add(this.child = new BindWindow(this, bind, this.x + this.width + 5.0F, this.y + (this.bindable.getBinds().indexOf(bind) * 17) + 17.0F + 9.5F - height1 / 2.0F, width1, height1));
/* 148 */     this.active = bind;
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\clickgui\windows\BindListWindow.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */