/*     */ package fun.rockstarity.api.render.ui.draggables;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.binds.Bindable;
/*     */ import fun.rockstarity.api.helpers.math.Hover;
/*     */ import fun.rockstarity.api.helpers.math.TimerUtility;
/*     */ import fun.rockstarity.api.helpers.render.Render;
/*     */ import fun.rockstarity.api.modules.settings.list.Select;
/*     */ import fun.rockstarity.api.render.animation.Animation;
/*     */ import fun.rockstarity.api.render.animation.Easing;
/*     */ import fun.rockstarity.api.render.animation.infinity.InfinityAnimation;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.shaders.list.Outline;
/*     */ import fun.rockstarity.api.render.shaders.list.Round;
/*     */ import fun.rockstarity.api.render.ui.clickgui.windows.SettingsWindow;
/*     */ import fun.rockstarity.api.render.ui.draggables.grid.Grid;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import fun.rockstarity.client.modules.render.Interface;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DraggableHandler
/*     */   implements IAccess
/*     */ {
/*  35 */   private final ArrayList<Draggable> draggables = new ArrayList<>(); public ArrayList<Draggable> getDraggables() { return this.draggables; }
/*     */   
/*  37 */   private ArrayList<SettingsWindow> windows = new ArrayList<>();
/*  38 */   private final Animation leftClick = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(500);
/*  39 */   private final Grid grid = new Grid();
/*     */   
/*     */   private boolean clicked;
/*     */   private boolean moveBack;
/*  43 */   private final InfinityAnimation animX = new InfinityAnimation();
/*  44 */   private final InfinityAnimation animY = new InfinityAnimation();
/*  45 */   private final Animation mouseMove = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(500);
/*  46 */   private final TimerUtility clickTimer = new TimerUtility();
/*  47 */   private final Animation mouseClick = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(200);
/*  48 */   private final TimerUtility waitTimer = new TimerUtility();
/*     */   
/*     */   private Draggable lastDrag;
/*     */   private int lastMouseX;
/*     */   private int lastMouseY;
/*  53 */   private final Animation selAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); private boolean selection;
/*     */   private float startX;
/*     */   private float startY;
/*     */   
/*     */   public void init() {
/*  58 */     this.grid.updateLineList();
/*     */   }
/*     */   
/*     */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/*  62 */     this.grid.render(matrixStack, mouseX, mouseY, partialTicks);
/*     */     
/*  64 */     SettingsWindow toRemove = null;
/*  65 */     this.lastMouseX = mouseX;
/*  66 */     this.lastMouseY = mouseY;
/*  67 */     for (SettingsWindow window : this.windows) {
/*  68 */       window.render(matrixStack, mouseX, mouseY, partialTicks);
/*     */       
/*  70 */       if (window.getOpening().finished(false)) toRemove = window;
/*     */     
/*     */     } 
/*  73 */     if (toRemove != null) {
/*  74 */       this.windows.remove(toRemove);
/*     */     }
/*     */     
/*  77 */     boolean cursorRendered = false;
/*  78 */     Draggable draggable = null;
/*     */     
/*  80 */     this.selAnim.setSpeed(200);
/*  81 */     float startX = this.startX;
/*  82 */     float startY = this.startY;
/*  83 */     float x = mouseX;
/*  84 */     float y = mouseY;
/*     */     
/*  86 */     if (x < startX) {
/*  87 */       x = startX;
/*  88 */       startX = mouseX;
/*     */     } 
/*     */     
/*  91 */     if (y < startY) {
/*  92 */       y = startY;
/*  93 */       startY = mouseY;
/*     */     } 
/*     */     
/*  96 */     Rect sel = new Rect(startX, startY, x - startX, y - startY);
/*     */     
/*  98 */     if (this.selection) {
/*  99 */       this.selAnim.setForward((Math.abs(x - startX) > 30.0F || Math.abs(y - startY) > 30.0F));
/*     */     } else {
/* 101 */       this.selAnim.setForward(false);
/*     */     } 
/*     */     
/* 104 */     for (Draggable draggable1 : this.draggables) {
/* 105 */       if (draggable1.isDragging()) {
/* 106 */         boolean canDrag = true;
/*     */         
/* 108 */         if (canDrag) {
/* 109 */           draggable1.setX(mouseX + draggable1.getDragX());
/* 110 */           draggable1.setY(mouseY + draggable1.getDragY());
/*     */         } 
/*     */       } 
/* 113 */       if (draggable1.getX() < 0.0F) draggable1.setX(0.0F); 
/* 114 */       if (draggable1.getY() < 0.0F) draggable1.setY(0.0F); 
/* 115 */       if (draggable1.getX() + draggable1.getWidth() > sr.getScaledWidth()) draggable1.setX(sr.getScaledWidth() - draggable1.getWidth()); 
/* 116 */       if (draggable1.getY() + draggable1.getHeight() > sr.getScaledHeight()) draggable1.setY(sr.getScaledHeight() - draggable1.getHeight());
/*     */       
/* 118 */       if (draggable1.isDragging());
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 123 */       if (Hover.isHovered(draggable1, mouseX, mouseY)) {
/* 124 */         draggable = draggable1;
/*     */       }
/*     */       
/* 127 */       if (this.selection && draggable1.contains(sel)) {
/* 128 */         draggable1.setSelected(true);
/*     */       }
/*     */     } 
/*     */     
/* 132 */     Draggable drag = draggable;
/* 133 */     if (drag != null || this.lastDrag != null) {
/* 134 */       if (drag == null) drag = this.lastDrag;
/*     */       
/* 136 */       boolean dragging = (drag.isDragging() && this.waitTimer.passed(500L));
/*     */       
/* 138 */       if (!drag.isDragging()) {
/* 139 */         this.waitTimer.reset();
/*     */       }
/*     */       
/* 142 */       this.mouseMove.setForward((Hover.isHovered(drag, mouseX, mouseY) && !cursorRendered && !this.moveBack && this.windows.isEmpty() && !dragging));
/* 143 */       this.mouseClick.setForward((this.mouseMove.finished() && !this.clicked && this.leftClick.finished(false)));
/* 144 */       if (!this.mouseMove.finished(false) && !rock.isPanic()) {
/* 145 */         this.animX.animate(drag.getX() + drag.getWidth() / 2.0F - mouseX - 10.0F, 150);
/* 146 */         this.animY.animate(drag.getY() + drag.getHeight() / 2.0F - mouseY, 150);
/*     */         
/* 148 */         float size = 20.0F;
/*     */         
/* 150 */         GL11.glPushMatrix();
/* 151 */         GL11.glTranslated((drag.getX() - 60.0F + drag.getWidth() / 1.5F - this.animX.get()), (drag.getY() + 40.0F + drag.getHeight() / 2.0F - this.animY.get()), 0.0D);
/* 152 */         GL11.glRotated((-10.0F - 30.0F * this.mouseMove.get()), 0.0D, 0.0D, 1.0D);
/* 153 */         Render.image("icons/hud/mouse/center.png", 50.0F, 0.0F, size, size, (Color)rock.getThemes().getTextFirstColor().alpha(this.mouseMove.get()));
/* 154 */         Render.image("icons/hud/mouse/tail.png", 50.0F, -size / 2.0F + 6.0F, size, size, (Color)rock.getThemes().getTextFirstColor().alpha(this.mouseMove.get()));
/*     */         
/* 156 */         Render.scale(50.0F + size / 2.0F, size / 2.0F, 1.0F - 0.15F * this.leftClick.get());
/* 157 */         Render.image("icons/hud/mouse/left.png", 50.0F, 0.0F, size, size, (Color)rock.getThemes().getTextFirstColor().alpha((this.mouseMove.get() - 0.4F * this.leftClick.get())));
/* 158 */         Render.end();
/*     */         
/* 160 */         Render.scale(50.0F + size / 2.0F, size / 2.0F, 1.0F - 0.15F * this.mouseClick.get());
/* 161 */         Render.image("icons/hud/mouse/right.png", 50.0F, 0.0F, size, size, (Color)rock.getThemes().getTextFirstColor().alpha((this.mouseMove.get() - 0.4F * this.mouseClick.get())));
/* 162 */         Render.end();
/* 163 */         GL11.glPopMatrix();
/*     */         
/* 165 */         bold.get(16).draw(matrixStack, "", -10.0F, -10.0F, FixColor.WHITE);
/*     */         
/* 167 */         if (this.mouseClick.finished() && !this.clicked) {
/* 168 */           this.clicked = true;
/* 169 */           this.clickTimer.reset();
/*     */         } 
/*     */         
/* 172 */         if (this.mouseClick.finished(false) && this.clicked && this.clickTimer.passed(500L))
/*     */         {
/* 174 */           this.clicked = false;
/*     */         }
/* 176 */         cursorRendered = true;
/*     */       } else {
/* 178 */         this.moveBack = false;
/* 179 */         this.clicked = false;
/*     */       } 
/*     */       
/* 182 */       this.lastDrag = drag;
/*     */     } 
/*     */     
/* 185 */     this.grid.handleDragPositions();
/*     */     
/* 187 */     if (!this.selAnim.finished(false)) {
/* 188 */       Outline.draw(matrixStack, sel, 4.0F, 0.5F, FixColor.WHITE.alpha((0.5F * this.selAnim.get())));
/* 189 */       Round.draw(matrixStack, sel, 4.0F, FixColor.WHITE.alpha((0.5F * this.selAnim.get())));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void keyPressed(int keyCode, int scanCode, int modifiers) {
/* 194 */     if (this.lastDrag != null && Hover.isHovered(this.lastDrag, this.lastMouseX, this.lastMouseY)) {
/* 195 */       switch (keyCode) { case 265:
/* 196 */           this.lastDrag.setY(this.lastDrag.getY() - 1.0F); break;
/* 197 */         case 264: this.lastDrag.setY(this.lastDrag.getY() + 1.0F); break;
/* 198 */         case 263: this.lastDrag.setX(this.lastDrag.getX() - 1.0F); break;
/* 199 */         case 262: this.lastDrag.setX(this.lastDrag.getX() + 1.0F);
/*     */           break; }
/*     */     
/*     */     }
/* 203 */     for (SettingsWindow window : this.windows) {
/* 204 */       window.pressed(keyCode, scanCode, modifiers);
/*     */     }
/*     */   }
/*     */   
/*     */   public void mouseClicked(double mouseX, double mouseY, int button) {
/* 209 */     boolean noDragAny = true;
/* 210 */     boolean dragging = false;
/*     */     
/* 212 */     for (SettingsWindow window : this.windows) {
/* 213 */       window.clicked(mouseX, mouseY, button);
/* 214 */       if (!window.canClick(mouseX, mouseY))
/*     */         return; 
/*     */     } 
/* 217 */     for (Draggable drag : this.draggables) {
/* 218 */       if (Hover.isHovered(drag.getX(), drag.getY(), drag.getWidth(), drag.getHeight(), mouseX, mouseY) && this.windows.isEmpty() && noDragAny) {
/* 219 */         noDragAny = false;
/*     */         
/* 221 */         if (button == 0) {
/* 222 */           for (Draggable d : this.draggables) {
/* 223 */             d.setDragging(false);
/*     */           }
/* 225 */           drag.setDragX((float)(drag.getX() - mouseX));
/* 226 */           drag.setDragY((float)(drag.getY() - mouseY));
/* 227 */           drag.setDragging(true);
/* 228 */           this.leftClick.setForward(true);
/* 229 */           dragging = true; continue;
/* 230 */         }  if (button == 1) {
/*     */           
/* 232 */           Interface.UIElement elmt = null;
/*     */           
/* 234 */           for (Select.Element element : ((Interface)rock.getModules().get(Interface.class)).getElements().getElements()) {
/* 235 */             Interface.UIElement ui = (Interface.UIElement)element;
/* 236 */             if (ui.getName().equals(drag.getName())) elmt = ui;
/*     */           
/*     */           } 
/* 239 */           float x = (float)mouseX;
/* 240 */           float y = (float)mouseY;
/*     */           
/* 242 */           while (y < drag.getY() + drag.getHeight()) {
/* 243 */             y += 10.0F;
/*     */           }
/* 245 */           if (elmt != null && !elmt.getSettings().isEmpty())
/* 246 */             this.windows.add(new SettingsWindow((Bindable)elmt, x - 2.0F, y - 2.0F)); 
/* 247 */           this.clicked = true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 252 */     if (dragging) {
/* 253 */       for (Draggable drag : this.draggables) {
/* 254 */         if (drag.isSelected()) {
/* 255 */           drag.setDragX((float)(drag.getX() - mouseX));
/* 256 */           drag.setDragY((float)(drag.getY() - mouseY));
/* 257 */           drag.setDragging(true);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 262 */     if (noDragAny) {
/* 263 */       for (Draggable drag : this.draggables) {
/* 264 */         drag.setSelected(false);
/*     */       }
/*     */       
/* 267 */       this.startX = (float)mouseX;
/* 268 */       this.startY = (float)mouseY;
/* 269 */       this.selection = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void mouseReleased(double mouseX, double mouseY, int button) {
/* 274 */     this.selection = false;
/*     */     
/* 276 */     for (Draggable drag : this.draggables) {
/* 277 */       if (drag.isDragging()) {
/* 278 */         drag.setDragging(false);
/*     */       }
/*     */     } 
/*     */     
/* 282 */     if (button == 0) {
/* 283 */       this.leftClick.setForward(false);
/*     */     }
/*     */     
/* 286 */     for (SettingsWindow window : this.windows) {
/* 287 */       window.released(mouseX, mouseY, button);
/*     */     }
/*     */   }
/*     */   
/*     */   public void charTyped(char codePoint, int modifiers) {
/* 292 */     for (SettingsWindow window : this.windows) {
/* 293 */       window.charTyped(codePoint, modifiers);
/*     */     }
/*     */   }
/*     */   
/*     */   public void tick() {
/* 298 */     for (SettingsWindow window : this.windows) {
/* 299 */       window.tick();
/*     */     }
/*     */   }
/*     */   
/*     */   public void closeChat() {
/* 304 */     this.windows.clear();
/*     */     
/* 306 */     for (Draggable drag : rock.getDraggableHandler().getDraggables()) {
/* 307 */       drag.setDragging(false);
/* 308 */       drag.setSelected(false);
/*     */     } 
/*     */     
/* 311 */     this.selection = false;
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\draggables\DraggableHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */