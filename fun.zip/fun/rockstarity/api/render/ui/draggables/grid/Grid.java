/*     */ package fun.rockstarity.api.render.ui.draggables.grid;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.helpers.math.TimerUtility;
/*     */ import fun.rockstarity.api.render.ui.draggables.Draggable;
/*     */ import fun.rockstarity.api.render.ui.draggables.grid.line.GridLine;
/*     */ import fun.rockstarity.api.render.ui.draggables.grid.line.GridRotationType;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Grid
/*     */   implements IAccess
/*     */ {
/*  21 */   private final ArrayList<GridLine> lines = new ArrayList<>();
/*  22 */   private TimerUtility updateTimer = new TimerUtility();
/*     */   private GridLine activeVerticalLine;
/*     */   
/*     */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/*  26 */     this.activeHorizontalLine = null;
/*  27 */     this.activeVerticalLine = null;
/*     */     
/*  29 */     float closestXDistance = Float.MAX_VALUE;
/*  30 */     float closestYDistance = Float.MAX_VALUE;
/*     */     
/*  32 */     for (GridLine line : this.lines) {
/*  33 */       boolean hovered = false;
/*  34 */       for (Draggable drag : rock.getDraggableHandler().getDraggables()) {
/*  35 */         if (!drag.isCanDrag() || !drag.isDragging())
/*     */           continue; 
/*  37 */         float[] data = calcDist(drag, line);
/*  38 */         float dist = data[0];
/*     */         
/*  40 */         if (line.getRotationType() == GridRotationType.HORIZONTAL) {
/*  41 */           if (dist < 15.0F) hovered = true; 
/*  42 */           if (dist < 5.0F && dist < closestYDistance) {
/*  43 */             closestYDistance = dist;
/*  44 */             this.activeHorizontalLine = line;
/*     */           }  continue;
/*     */         } 
/*  47 */         if (dist < 15.0F) hovered = true; 
/*  48 */         if (dist < 5.0F && dist < closestXDistance) {
/*  49 */           closestXDistance = dist;
/*  50 */           this.activeVerticalLine = line;
/*     */         } 
/*     */       } 
/*     */       
/*  54 */       line.getHoveredAnim().setForward(hovered);
/*     */     } 
/*     */     
/*  57 */     if (!this.updateTimer.passed(300L))
/*     */       return; 
/*  59 */     for (GridLine line : this.lines) {
/*  60 */       line.getActiveAnim().setForward((this.activeHorizontalLine == line || this.activeVerticalLine == line));
/*  61 */       line.render(matrixStack, mouseX, mouseY, partialTicks);
/*     */     } 
/*     */   }
/*     */   private GridLine activeHorizontalLine;
/*     */   public void handleDragPositions() {
/*  66 */     for (Draggable drag : rock.getDraggableHandler().getDraggables()) {
/*  67 */       if (!drag.isCanDrag() || !drag.isDragging())
/*     */         continue; 
/*  69 */       if (this.activeHorizontalLine != null) {
/*  70 */         float[] data = calcDist(drag, this.activeHorizontalLine);
/*  71 */         float distY = data[0];
/*  72 */         if (distY < 5.0F) {
/*  73 */           drag.setY(this.activeHorizontalLine.getCoord() - data[1]);
/*     */         }
/*     */       } 
/*     */       
/*  77 */       if (this.activeVerticalLine != null) {
/*  78 */         float[] data = calcDist(drag, this.activeVerticalLine);
/*  79 */         float distX = data[0];
/*  80 */         if (distX < 5.0F) {
/*  81 */           drag.setX(this.activeVerticalLine.getCoord() - data[1]);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private float[] calcDist(Draggable drag, GridLine line) {
/*  88 */     boolean horizontal = (line.getRotationType() == GridRotationType.HORIZONTAL);
/*  89 */     float coord = horizontal ? drag.getY() : drag.getX();
/*  90 */     float size = horizontal ? drag.getHeight() : drag.getWidth();
/*  91 */     float modif = 0.0F;
/*     */     
/*  93 */     float dist = Math.abs(coord - line.getCoord());
/*  94 */     float distHalfSize = Math.abs(coord + size / 2.0F - line.getCoord());
/*  95 */     float distSize = Math.abs(coord + size - line.getCoord());
/*     */     
/*  97 */     float minDist = Math.min(dist, Math.min(distHalfSize, distSize));
/*     */     
/*  99 */     if (minDist == distHalfSize) {
/* 100 */       modif = size / 2.0F;
/* 101 */     } else if (minDist == distSize) {
/* 102 */       modif = size;
/*     */     } 
/*     */     
/* 105 */     return new float[] { minDist, modif };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addHorizontalLine(float y) {
/* 112 */     this.lines.add(new GridLine(y, GridRotationType.HORIZONTAL));
/*     */   }
/*     */   
/*     */   public void addVerticalLine(float x) {
/* 116 */     this.lines.add(new GridLine(x, GridRotationType.VERTICAL));
/*     */   }
/*     */   
/*     */   public void updateLineList() {
/* 120 */     this.updateTimer.reset();
/* 121 */     this.lines.clear();
/*     */ 
/*     */     
/* 124 */     addHorizontalLine((sr.getScaledHeight() / 2) - 0.5F);
/* 125 */     addVerticalLine((sr.getScaledWidth() / 2) - 0.5F);
/*     */ 
/*     */     
/* 128 */     addHorizontalLine(6.0F);
/* 129 */     addHorizontalLine((sr.getScaledHeight() - 7));
/* 130 */     addVerticalLine(6.0F);
/* 131 */     addVerticalLine((sr.getScaledWidth() - 7));
/*     */ 
/*     */     
/* 134 */     addHorizontalLine((sr.getScaledHeight() / 4) - 0.5F);
/* 135 */     addHorizontalLine((3 * sr.getScaledHeight() / 4) - 0.5F);
/* 136 */     addVerticalLine((sr.getScaledWidth() / 4) - 0.5F);
/* 137 */     addVerticalLine((3 * sr.getScaledWidth() / 4) - 0.5F);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\draggables\grid\Grid.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */