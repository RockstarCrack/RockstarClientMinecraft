/*    */ package fun.rockstarity.api.render.ui.draggables.grid.line;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.render.animation.Animation;
/*    */ import fun.rockstarity.api.render.animation.Easing;
/*    */ import fun.rockstarity.api.render.color.FixColor;
/*    */ import fun.rockstarity.api.render.shaders.list.Round;
/*    */ import fun.rockstarity.api.render.ui.rect.Rect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GridLine
/*    */   implements IAccess
/*    */ {
/* 24 */   private final Animation hoveredAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public Animation getHoveredAnim() { return this.hoveredAnim; }
/* 25 */    private final GridRotationType rotationType; private final Animation activeAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); private final float coord; public Animation getActiveAnim() { return this.activeAnim; }
/* 26 */   public GridRotationType getRotationType() { return this.rotationType; } public float getCoord() {
/* 27 */     return this.coord;
/*    */   }
/*    */   public GridLine(float coord, GridRotationType rotationType) {
/* 30 */     this.rotationType = rotationType;
/* 31 */     this.coord = coord;
/*    */   }
/*    */   
/*    */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/* 35 */     if (this.hoveredAnim.finished(false) || rock.isPanic())
/*    */       return; 
/* 37 */     Round.draw(matrixStack, getLineRect(), 0.0F, FixColor.WHITE.alpha((0.4F * this.hoveredAnim.get() + 0.3F * this.activeAnim.get())));
/*    */   }
/*    */   
/*    */   public Rect getLineRect() {
/* 41 */     return (this.rotationType == GridRotationType.HORIZONTAL) ? new Rect(0.0F, this.coord, sr.getScaledWidth(), 1.0F) : new Rect(this.coord, 0.0F, 1.0F, sr.getScaledHeight());
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\draggables\grid\line\GridLine.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */