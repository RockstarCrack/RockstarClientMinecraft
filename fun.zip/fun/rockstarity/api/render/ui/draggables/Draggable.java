/*    */ package fun.rockstarity.api.render.ui.draggables;
/*    */ 
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.interfaces.Jsonable;
/*    */ import fun.rockstarity.api.render.ui.rect.Rect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Draggable
/*    */   extends Rect
/*    */   implements IAccess, Jsonable
/*    */ {
/*    */   private boolean canDrag = true;
/*    */   private final String name;
/*    */   private boolean dragging;
/*    */   private boolean selected;
/*    */   private float dragX;
/*    */   private float dragY;
/*    */   
/*    */   public boolean isCanDrag() {
/* 24 */     return this.canDrag; } public void setCanDrag(boolean canDrag) { this.canDrag = canDrag; }
/*    */   
/* 26 */   public String getName() { return this.name; }
/* 27 */   public boolean isDragging() { return this.dragging; } public void setDragging(boolean dragging) { this.dragging = dragging; }
/* 28 */   public boolean isSelected() { return this.selected; } public void setSelected(boolean selected) { this.selected = selected; }
/* 29 */   public float getDragX() { return this.dragX; } public float getDragY() { return this.dragY; } public void setDragX(float dragX) { this.dragX = dragX; } public void setDragY(float dragY) { this.dragY = dragY; }
/*    */   
/*    */   public Draggable(String name, float x, float y, float width, float height) {
/* 32 */     super(x, y, width, height);
/* 33 */     this.name = name;
/* 34 */     rock.getDraggableHandler().getDraggables().add(this);
/*    */   }
/*    */   
/*    */   public Draggable(String name, Rect rect) {
/* 38 */     this(name, rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void load(JsonElement element) {
/* 48 */     JsonObject dragData = element.getAsJsonObject();
/* 49 */     setX(dragData.get("x").getAsFloat());
/* 50 */     setY(dragData.get("y").getAsFloat());
/* 51 */     setWidth(dragData.get("width").getAsFloat());
/* 52 */     setHeight(dragData.get("height").getAsFloat());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JsonElement save() {
/* 62 */     JsonObject jsonObject = new JsonObject();
/* 63 */     jsonObject.addProperty("x", Float.valueOf(getX()));
/* 64 */     jsonObject.addProperty("y", Float.valueOf(getY()));
/*    */     
/* 66 */     jsonObject.addProperty("width", Float.valueOf(getWidth()));
/* 67 */     jsonObject.addProperty("height", Float.valueOf(getHeight()));
/* 68 */     return (JsonElement)jsonObject;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\draggables\Draggable.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */