/*     */ package fun.rockstarity.api.render.ui.fonts;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.helpers.render.Render;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.font.FontRenderContext;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import net.minecraft.util.math.vector.Matrix4f;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CharSet
/*     */   implements IAccess
/*     */ {
/*  30 */   private Map<Character, Rect> rectsCache = new HashMap<>();
/*  31 */   protected final Map<Character, Rect> rects = new HashMap<>();
/*     */   protected int texId;
/*     */   protected int imgWidth;
/*  34 */   float spacing = 2.0F; protected int imgHeight; protected float fontHeight;
/*     */   
/*     */   public CharSet(Font font, char[] chars) {
/*  37 */     FontRenderContext fontRenderContext = new FontRenderContext(font.getTransform(), true, true);
/*  38 */     double maxWidth = 0.0D;
/*  39 */     double maxHeight = 0.0D;
/*     */     
/*  41 */     for (char c : chars) {
/*  42 */       Rectangle2D bound = font.getStringBounds(Character.toString(c), fontRenderContext);
/*  43 */       maxWidth = Math.max(maxWidth, bound.getWidth());
/*  44 */       maxHeight = Math.max(maxHeight, bound.getHeight());
/*     */     } 
/*     */     
/*  47 */     int d = (int)Math.ceil(Math.sqrt((maxHeight + 2.0D) * (maxWidth + 2.0D) * chars.length));
/*     */     
/*  49 */     this.fontHeight = (float)(maxHeight / 2.0D);
/*  50 */     this.imgHeight = d;
/*  51 */     this.imgWidth = d;
/*     */     
/*  53 */     BufferedImage image = new BufferedImage(this.imgWidth, this.imgHeight, 2);
/*  54 */     Graphics2D graphics = image.createGraphics();
/*     */     
/*  56 */     graphics.setFont(font);
/*  57 */     graphics.setColor(new Color(255, 255, 255, 0));
/*  58 */     graphics.fillRect(0, 0, this.imgWidth, this.imgHeight);
/*  59 */     graphics.setColor(Color.WHITE);
/*  60 */     graphics.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
/*  61 */     graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*  62 */     graphics.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/*     */ 
/*     */     
/*  65 */     FontMetrics fontMetrics = graphics.getFontMetrics();
/*  66 */     int posX = 1;
/*  67 */     int posY = 2;
/*     */     
/*  69 */     for (char c : chars) {
/*  70 */       Rect rect = new Rect();
/*  71 */       Rectangle2D bounds = fontMetrics.getStringBounds(Character.toString(c), graphics);
/*  72 */       rect.setWidth((float)(bounds.getWidth() + 1.0D));
/*  73 */       rect.setHeight((float)(bounds.getHeight() + 2.0D));
/*     */       
/*  75 */       if (posX + rect.getWidth() >= this.imgWidth) {
/*  76 */         posX = 1;
/*  77 */         posY = (int)(posY + maxHeight + fontMetrics.getDescent() + 2.0D);
/*     */       } 
/*     */       
/*  80 */       rect.setX(posX);
/*  81 */       rect.setY(posY);
/*     */       
/*  83 */       graphics.drawString(Character.toString(c), posX, posY + fontMetrics.getAscent());
/*     */       
/*  85 */       posX = (int)(posX + rect.getWidth() + 4.0F);
/*  86 */       this.rects.put(Character.valueOf(c), rect);
/*     */     } 
/*     */     
/*  89 */     RenderSystem.recordRenderCall(() -> this.texId = Render.loadTexture(image));
/*     */   }
/*     */   
/*     */   public float renderGlyph(Matrix4f matrix, char c, float x, float y, float red, float green, float blue, float alpha) {
/*  93 */     GlStateManager.bindTexture(this.texId);
/*     */     
/*  95 */     Rect rect = this.rectsCache.computeIfAbsent(Character.valueOf(c), this::getRect);
/*     */     
/*  97 */     if (rect == null) {
/*  98 */       return 0.0F;
/*     */     }
/* 100 */     float pageX = rect.getX() / this.imgWidth;
/* 101 */     float pageY = rect.getY() / this.imgHeight;
/* 102 */     float width = rect.getWidth();
/* 103 */     float height = rect.getHeight();
/* 104 */     float pageWidth = width / this.imgWidth;
/* 105 */     float pageHeight = height / this.imgHeight;
/*     */     
/* 107 */     BUILDER.pos(matrix, x, y + height, 0.0F).color(red, green, blue, alpha).tex(pageX, pageY + pageHeight).endVertex();
/* 108 */     BUILDER.pos(matrix, x + width, y + height, 0.0F).color(red, green, blue, alpha).tex(pageX + pageWidth, pageY + pageHeight).endVertex();
/* 109 */     BUILDER.pos(matrix, x + width, y, 0.0F).color(red, green, blue, alpha).tex(pageX + pageWidth, pageY).endVertex();
/* 110 */     BUILDER.pos(matrix, x, y, 0.0F).color(red, green, blue, alpha).tex(pageX, pageY).endVertex();
/*     */ 
/*     */     
/* 113 */     return width + this.spacing;
/*     */   }
/*     */   
/*     */   private Rect getRect(char c) {
/* 117 */     Rect rect = this.rects.get(Character.valueOf(c));
/* 118 */     return (rect != null) ? rect : null;
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\fonts\CharSet.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */