/*    */ package fun.rockstarity.api.render.ui.fonts;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ 
/*    */ public class CustomFont
/*    */   extends HashMap<Integer, FontSize>
/*    */ {
/*    */   private final String name;
/*    */   
/*    */   public CustomFont(String name) {
/* 12 */     this.name = name;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public FontSize get(int size) {
/* 18 */     if (containsKey(Integer.valueOf(size))) {
/* 19 */       return (FontSize)get(Integer.valueOf(size));
/*    */     }
/* 21 */     FontSize font = new FontSize(this.name, size);
/* 22 */     put(Integer.valueOf(size), font);
/* 23 */     return new FontSize(this.name, size);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean loaded(int size) {
/* 28 */     return containsKey(Integer.valueOf(size));
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\fonts\CustomFont.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */