/*     */ package fun.rockstarity.api.render.ui.fonts;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.helpers.game.Server;
/*     */ import fun.rockstarity.api.helpers.render.Converter;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import java.awt.Font;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.util.math.vector.Matrix4f;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FontSize
/*     */   implements IAccess
/*     */ {
/*     */   private static boolean FLAT_RENDERER;
/*     */   private final CharSet charSet;
/*     */   private final int size;
/*     */   public static final String STYLE_CODES = "0123456789abcdefklmnor";
/*  31 */   private static final HashMap<String, Float> widthMap = new HashMap<>();
/*     */   
/*     */   public int getSize() {
/*  34 */     return this.size;
/*     */   }
/*     */   public FontSize(String fontName, int size) {
/*  37 */     int[] codes = { 31, 127, 1024, 1106 };
/*  38 */     char[] chars = new char[codes[1] - codes[0] + codes[3] - codes[2]];
/*     */     
/*  40 */     int c = 0;
/*  41 */     for (int d = 0; d <= 2; d += 2) {
/*  42 */       for (int i = codes[d]; i <= codes[d + 1] - 1; i++) {
/*  43 */         chars[c] = (char)i;
/*  44 */         c++;
/*     */       } 
/*     */     } 
/*  47 */     this.size = size;
/*  48 */     Font font = Converter.getFont(fontName, 0, size);
/*  49 */     if (font == null) {
/*  50 */       font = new Font("Arial", 0, size);
/*     */     }
/*  52 */     this.charSet = new CharSet(font, chars);
/*     */   }
/*     */ 
/*     */   
/*     */   public FontSize(Font font, int size) {
/*  57 */     int[] codes = { 31, 127, 1024, 1106 };
/*  58 */     char[] chars = new char[codes[1] - codes[0] + codes[3] - codes[2]];
/*     */     
/*  60 */     int c = 0;
/*  61 */     for (int d = 0; d <= 2; d += 2) {
/*  62 */       for (int i = codes[d]; i <= codes[d + 1] - 1; i++) {
/*  63 */         chars[c] = (char)i;
/*  64 */         c++;
/*     */       } 
/*     */     } 
/*  67 */     this.size = size;
/*  68 */     this.charSet = new CharSet(font, chars);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  73 */   public static final int[] COLOR_CODES = new int[32];
/*     */   
/*     */   static {
/*  76 */     for (int i = 0; i < 32; i++) {
/*  77 */       int j = (i >> 3 & 0x1) * 85;
/*  78 */       int k = (i >> 2 & 0x1) * 170 + j;
/*  79 */       int l = (i >> 1 & 0x1) * 170 + j;
/*  80 */       int i1 = (i & 0x1) * 170 + j;
/*     */       
/*  82 */       if (i == 6) {
/*  83 */         k += 85;
/*     */       }
/*     */       
/*  86 */       if (i >= 16) {
/*  87 */         k /= 4;
/*  88 */         l /= 4;
/*  89 */         i1 /= 4;
/*     */       } 
/*     */       
/*  92 */       COLOR_CODES[i] = (k & 0xFF) << 16 | (l & 0xFF) << 8 | i1 & 0xFF;
/*     */     } 
/*     */   }
/*     */   
/*     */   public Rect draw(MatrixStack matrices, String text, float x, float y, FixColor color) {
/*  97 */     return renderString(matrices, text, x, y, color);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/* 109 */     GlStateManager.enableBlend();
/* 110 */     BUILDER.begin(7, DefaultVertexFormats.POSITION_COLOR_TEX);
/* 111 */     FLAT_RENDERER = true;
/*     */   }
/*     */   
/*     */   public void end() {
/* 115 */     TESSELLATOR.draw();
/* 116 */     GlStateManager.disableBlend();
/* 117 */     FLAT_RENDERER = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public float draw(MatrixStack matrices, ITextComponent text, float x, float y, FixColor color) {
/* 122 */     return drawStringMajestic(matrices, text, x, y, color, false);
/*     */   }
/*     */   
/*     */   public float drawStringMajestic(MatrixStack stack, ITextComponent text, double x, double y, FixColor color, boolean shadow) {
/* 126 */     float offset = 0.0F;
/* 127 */     int i = 0;
/* 128 */     int removals = Server.isRW() ? 3 : 0;
/* 129 */     for (ITextComponent it : text.getSiblings()) {
/* 130 */       for (ITextComponent it1 : it.getSiblings()) {
/* 131 */         String draw = it1.getString();
/*     */         
/* 133 */         if (it1.getStyle().getColor() != null) { renderString(stack, draw, (float)(x + offset), (float)y, new FixColor(it1.getStyle().getColor().getColor())); }
/* 134 */         else { renderString(stack, draw, (float)(x + offset), (float)y, color); }
/*     */         
/* 136 */         offset += getWidth(draw) + 1.0F;
/* 137 */         i++;
/*     */       } 
/*     */       
/* 140 */       if (it.getSiblings().size() <= 1) {
/* 141 */         String draw = it.getString();
/*     */         
/* 143 */         renderString(stack, draw, (float)(x + offset), (float)y, (it.getStyle().getColor() == null) ? color : new FixColor(it.getStyle().getColor().getColor()));
/* 144 */         offset += getWidth(draw) + 1.0F;
/* 145 */         i++;
/*     */       } 
/*     */     } 
/*     */     
/* 149 */     if (text.getSiblings().isEmpty()) {
/* 150 */       String draw = text.getString();
/*     */       
/* 152 */       renderString(stack, draw, (float)(x + offset), (float)y, (text.getStyle().getColor() == null) ? color : new FixColor(text.getStyle().getColor().getColor()));
/* 153 */       if (draw != null) offset += getWidth(draw) + 1.0F;
/*     */     
/*     */     } 
/* 156 */     return 0.0F;
/*     */   }
/*     */   
/*     */   private Rect renderString(MatrixStack matrices, String text, float x, float y, FixColor color) {
/* 160 */     if (text == null) return new Rect(0.0F, 0.0F, 0.0F, 0.0F);
/*     */     
/* 162 */     float startPos = x * 2.0F;
/* 163 */     float posX = startPos;
/* 164 */     float posY = y * 2.0F;
/* 165 */     float[] colors = { color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F };
/*     */ 
/*     */     
/* 168 */     matrices.push();
/* 169 */     matrices.scale(0.5F, 0.5F, 1.0F);
/*     */     
/* 171 */     if (!FLAT_RENDERER) {
/* 172 */       GlStateManager.enableBlend();
/*     */       
/* 174 */       BUILDER.begin(7, DefaultVertexFormats.POSITION_COLOR_TEX);
/*     */     } 
/*     */     
/* 177 */     Matrix4f matrix = matrices.getLast().getMatrix();
/*     */     
/* 179 */     for (int i = 0; i < text.length(); i++) {
/* 180 */       char c0 = text.charAt(i);
/*     */       
/* 182 */       if (c0 == '§' && i + 1 < text.length() && "0123456789abcdefklmnor"
/* 183 */         .indexOf(text.toLowerCase(Locale.ENGLISH).charAt(i + 1)) != -1) {
/* 184 */         int i1 = "0123456789abcdefklmnor".indexOf(text.toLowerCase(Locale.ENGLISH).charAt(i + 1));
/*     */         
/* 186 */         if (i1 < 16) {
/* 187 */           int j1 = COLOR_CODES[i1];
/*     */           
/* 189 */           colors = new float[] { (j1 >> 16 & 0xFF) / 255.0F, (j1 >> 8 & 0xFF) / 255.0F, (j1 & 0xFF) / 255.0F, colors[3] };
/*     */         } 
/*     */         
/* 192 */         i++;
/*     */       } else {
/* 194 */         float f = this.charSet.renderGlyph(matrix, c0, posX, posY, colors[0], colors[1], colors[2], colors[3]);
/* 195 */         posX += f * 0.82F;
/*     */       } 
/*     */     } 
/*     */     
/* 199 */     if (!FLAT_RENDERER) {
/* 200 */       TESSELLATOR.draw();
/*     */       
/* 202 */       GlStateManager.disableBlend();
/*     */     } 
/*     */     
/* 205 */     matrices.pop();
/*     */     
/* 207 */     return new Rect(x, y, (posX - startPos) / 2.0F, this.size);
/*     */   }
/*     */   
/*     */   public float getWidth(ITextComponent text) {
/* 211 */     float offset = 0.0F;
/* 212 */     int i = 0;
/* 213 */     int removals = Server.isRW() ? 3 : 0;
/* 214 */     for (ITextComponent it : text.getSiblings()) {
/* 215 */       for (ITextComponent it1 : it.getSiblings()) {
/* 216 */         String draw = it1.getString();
/* 217 */         offset += getWidth(draw) + 1.0F;
/* 218 */         i++;
/*     */       } 
/*     */       
/* 221 */       if (it.getSiblings().size() <= 1) {
/* 222 */         String draw = it.getString();
/* 223 */         offset += getWidth(draw) + 1.0F;
/* 224 */         i++;
/*     */       } 
/*     */     } 
/*     */     
/* 228 */     if (text.getSiblings().isEmpty()) {
/* 229 */       String draw = text.getString();
/* 230 */       if (draw != null) offset += getWidth(draw) + 1.0F;
/*     */     
/*     */     } 
/* 233 */     return offset;
/*     */   }
/*     */   
/*     */   public float getWidth(String text) {
/* 237 */     if (text == null) return 0.0F;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 242 */     boolean bold = false;
/* 243 */     boolean italic = false;
/* 244 */     float width = 0.0F;
/*     */     
/* 246 */     for (int i = 0; i < text.length(); i++) {
/* 247 */       char c0 = text.charAt(i);
/*     */       
/* 249 */       if (c0 == '§' && i + 1 < text.length() && "0123456789abcdefklmnor"
/* 250 */         .indexOf(text.toLowerCase(Locale.ENGLISH).charAt(i + 1)) != -1) {
/* 251 */         int i1 = "0123456789abcdefklmnor".indexOf(text.toLowerCase(Locale.ENGLISH).charAt(i + 1));
/*     */         
/* 253 */         if (i1 < 16) {
/* 254 */           bold = false;
/* 255 */           italic = false;
/* 256 */         } else if (i1 == 17) {
/* 257 */           bold = true;
/* 258 */         } else if (i1 == 20) {
/* 259 */           italic = true;
/* 260 */         } else if (i1 == 21) {
/* 261 */           bold = false;
/* 262 */           italic = false;
/*     */         } 
/*     */         
/* 265 */         i++;
/*     */       } else {
/* 267 */         width += (this.charSet.rects.get(Character.valueOf(c0)) == null) ? 0.0F : ((((Rect)this.charSet.rects.get(Character.valueOf(c0))).getWidth() + this.charSet.spacing) * 0.82F);
/*     */       } 
/*     */     } 
/*     */     
/* 271 */     widthMap.put("" + this.size + this.size, Float.valueOf((width - this.charSet.spacing) / 2.0F));
/*     */     
/* 273 */     return (width - this.charSet.spacing) / 2.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getHeight() {
/* 278 */     return this.size / 2.0F;
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\fonts\FontSize.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */