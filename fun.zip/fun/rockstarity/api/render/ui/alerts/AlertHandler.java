/*    */ package fun.rockstarity.api.render.ui.alerts;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.events.list.game.client.EventAlert;
/*    */ import fun.rockstarity.api.helpers.math.TimerUtility;
/*    */ import fun.rockstarity.api.secure.Debugger;
/*    */ import fun.rockstarity.api.sounds.Sound;
/*    */ import fun.rockstarity.client.modules.other.Sounds;
/*    */ import fun.rockstarity.client.modules.render.Interface;
/*    */ import java.util.ArrayList;
/*    */ import java.util.ConcurrentModificationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AlertHandler
/*    */   implements IAccess
/*    */ {
/* 24 */   private final ArrayList<Alert> alerts = new ArrayList<>(); public ArrayList<Alert> getAlerts() { return this.alerts; }
/*    */   
/* 26 */   private static final TimerUtility timer = new TimerUtility();
/*    */   
/*    */   public void render(MatrixStack matrixStack) {
/*    */     try {
/* 30 */       this.alerts.stream().forEach(alert -> alert.render(matrixStack));
/*    */ 
/*    */ 
/*    */       
/* 34 */       this.alerts.removeIf(alert -> alert.getShow().finished(false));
/* 35 */     } catch (ConcurrentModificationException e) {
/* 36 */       Debugger.print(e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void renderBackground(MatrixStack matrixStack) {
/*    */     try {
/* 42 */       this.alerts.stream().forEach(alert -> alert.renderBackground(matrixStack));
/*    */ 
/*    */ 
/*    */       
/* 46 */       this.alerts.removeIf(alert -> alert.getShow().finished(false));
/* 47 */     } catch (ConcurrentModificationException e) {
/* 48 */       Debugger.print(e);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Alert alert(String text, AlertType type) {
/* 59 */     if (text != null && text.isEmpty()) return null;
/*    */     
/* 61 */     (new EventAlert(text, type.getName())).hook();
/*    */     
/* 63 */     float height = 25.0F;
/* 64 */     Alert alert = new Alert(text, type, 0.0F, 0.0F, 25.0F, height);
/* 65 */     if (((Interface)rock.getModules().get(Interface.class)).getAlerts().get()) {
/* 66 */       this.alerts.add(alert);
/*    */     }
/* 68 */     Sounds sounds = (Sounds)rock.getModules().get(Sounds.class);
/*    */     
/* 70 */     if (sounds.get() && sounds.getModule().get() && timer.passed(50L)) {
/* 71 */       switch (type) {
/*    */         case SUCCESS:
/* 73 */           if (sounds.get()) (new Sound("on" + sounds.getModifier())).play(); 
/*    */           break;
/*    */         case ERROR:
/* 76 */           if (sounds.get()) (new Sound("off" + sounds.getModifier())).play(); 
/*    */           break;
/*    */         case INFO:
/* 79 */           if (sounds.get()) (new Sound("info" + sounds.getModifier())).play();
/*    */           
/*    */           break;
/*    */       } 
/*    */       
/* 84 */       timer.reset();
/*    */     } 
/*    */     
/* 87 */     return alert;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\alerts\AlertHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */