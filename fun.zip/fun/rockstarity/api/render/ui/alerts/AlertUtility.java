/*     */ package fun.rockstarity.api.render.ui.alerts;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.helpers.math.TimerUtility;
/*     */ import fun.rockstarity.api.helpers.render.Render;
/*     */ import fun.rockstarity.api.helpers.render.Stencil;
/*     */ import fun.rockstarity.api.modules.Modules;
/*     */ import fun.rockstarity.api.render.animation.infinity.InfinityAnimation;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.shaders.list.Outline;
/*     */ import fun.rockstarity.api.render.shaders.list.Round;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import fun.rockstarity.client.modules.render.Interface;
/*     */ import fun.rockstarity.client.modules.render.ui.Alerts;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AlertUtility
/*     */   implements IAccess
/*     */ {
/*     */   private AlertUtility() {
/*  30 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*     */   }
/*  32 */   private static final TimerUtility timer = new TimerUtility();
/*  33 */   private static final InfinityAnimation slotAnim = new InfinityAnimation();
/*     */   private static int slot; private static boolean direction;
/*     */   private static float ticks;
/*     */   
/*  37 */   public static void setTicks(float ticks) { AlertUtility.ticks = ticks; } public static float getTicks() { return ticks; }
/*     */ 
/*     */   
/*     */   public static void previewSmall(MatrixStack ms, float x, float y, float width, float height, float anim) {
/*  41 */     Interface ui = (Interface)rock.getModules().get(Interface.class);
/*  42 */     Alerts alerts = ui.getAlerts();
/*     */     
/*  44 */     if (((Interface)rock.getModules().get(Interface.class)).getAlerts().getAdditions().get()) {
/*  45 */       Render.glow(ms, new Rect(x, y, width, height), anim);
/*     */     }
/*  47 */     Round.draw(ms, new Rect(x, y, width, height), 3.0F, rock.getThemes().getSecondColor().alpha((anim * (alerts.getTransparent().get() ? 0.5F : 1.0F))));
/*     */     
/*  49 */     slotAnim.animate(slot, 50);
/*     */     
/*  51 */     GL11.glEnable(3089);
/*  52 */     Render.scissor(x, y, width, height);
/*     */     
/*  54 */     for (AlertType type : AlertType.values()) {
/*  55 */       drawSmallIcon(ms, type, x, y + type.ordinal() * height - slotAnim.get() * height, anim);
/*     */     }
/*     */     
/*  58 */     GL11.glDisable(3089);
/*     */     
/*  60 */     if (timer.passed(2000L)) {
/*  61 */       if ((slot == (AlertType.values()).length - 1 && direction) || (slot == 0 && !direction)) direction = !direction; 
/*  62 */       slot += direction ? 1 : -1;
/*  63 */       timer.reset();
/*     */     } 
/*     */     
/*  66 */     Stencil.init();
/*  67 */     Round.draw(ms, new Rect(x, y, width, height), 4.0F, FixColor.WHITE.alpha(anim));
/*  68 */     Stencil.read(1);
/*  69 */     semibold.get(13).draw(ms, ((Interface)rock.getModules().get(Interface.class)).getEnglish().get() ? "Alert example" : "Пример уведомления", x + 16.0F, y + 3.0F, rock.getThemes().getTextFirstColor().alpha(anim));
/*  70 */     Stencil.finish();
/*     */     
/*  72 */     if (((Interface)rock.getModules().get(Interface.class)).getAlerts().getAdditions().get()) {
/*  73 */       Render.outline(ms, new Rect(x, y, width, height), anim);
/*     */     }
/*     */     
/*  76 */     ticks += 1.0F / Math.max(Minecraft.debugFPS, 5.0F) * 75.0F;
/*     */   }
/*     */   
/*     */   public static void previewBig(MatrixStack ms, float x, float y, float width, float height, float anim) {
/*  80 */     Interface ui = (Interface)rock.getModules().get(Interface.class);
/*  81 */     Alerts alerts = ui.getAlerts();
/*     */     
/*  83 */     if (((Interface)rock.getModules().get(Interface.class)).getAlerts().getAdditions().get()) {
/*  84 */       Render.glow(ms, new Rect(x, y, width, height), anim);
/*     */     }
/*  86 */     Round.draw(ms, new Rect(x, y, width, height), 4.0F, rock.getThemes().getFirstColor().alpha((anim * (alerts.getTransparent().get() ? 0.5F : 1.0F))));
/*     */     
/*  88 */     slotAnim.animate(slot, 50);
/*     */     
/*  90 */     GL11.glEnable(3089);
/*  91 */     Render.scissor(x, y, width, height);
/*     */     
/*  93 */     for (AlertType type : AlertType.values()) {
/*  94 */       drawBigIcon(ms, type, x, y + type.ordinal() * height - slotAnim.get() * height, anim);
/*     */     }
/*     */     
/*  97 */     GL11.glDisable(3089);
/*     */     
/*  99 */     if (timer.passed(2000L)) {
/* 100 */       if ((slot == (AlertType.values()).length - 1 && direction) || (slot == 0 && !direction)) direction = !direction; 
/* 101 */       slot += direction ? 1 : -1;
/* 102 */       timer.reset();
/*     */     } 
/*     */     
/* 105 */     Stencil.init();
/* 106 */     Round.draw(ms, new Rect(x, y, width, height), 4.0F, FixColor.WHITE.alpha(anim));
/* 107 */     Stencil.read(1);
/* 108 */     semibold.get(16).draw(ms, ((Interface)rock.getModules().get(Interface.class)).getEnglish().get() ? "Alert example" : "Пример уведомления", x + 26.0F, y + 7.0F, rock.getThemes().getTextFirstColor().alpha(anim));
/* 109 */     Stencil.finish();
/*     */     
/* 111 */     if (((Interface)rock.getModules().get(Interface.class)).getAlerts().getAdditions().get()) {
/* 112 */       Render.outline(ms, new Rect(x, y, width, height), anim);
/*     */     }
/*     */     
/* 115 */     ticks += 1.0F / Math.max(Minecraft.debugFPS, 5.0F) * 75.0F;
/*     */   }
/*     */   
/*     */   public static void drawSmall(MatrixStack ms, AlertType type, String text, float x, float y, float width, float height, float anim) {
/* 119 */     Alerts alerts = ((Interface)rock.getModules().get(Interface.class)).getAlerts();
/*     */     
/* 121 */     if (((Interface)rock.getModules().get(Interface.class)).getAlerts().getAdditions().get()) {
/* 122 */       Render.glow(ms, new Rect(x, y, width, height), anim);
/*     */     }
/* 124 */     Round.draw(ms, new Rect(x, y, width, height), 3.0F, rock.getThemes().getSecondColor().alpha((anim * (alerts.getTransparent().get() ? 0.5F : 1.0F))));
/*     */     
/* 126 */     drawSmallIcon(ms, type, x, y, anim);
/*     */     
/* 128 */     Stencil.init();
/* 129 */     Round.draw(ms, new Rect(x, y, width, height), 4.0F, FixColor.WHITE.alpha(anim));
/* 130 */     Stencil.read(1);
/* 131 */     semibold.get(13).draw(ms, text, x + 16.0F, y + 3.0F, rock.getThemes().getTextFirstColor().alpha(anim));
/* 132 */     Stencil.finish();
/* 133 */     if (((Interface)rock.getModules().get(Interface.class)).getAlerts().getAdditions().get()) {
/* 134 */       Render.outline(ms, new Rect(x, y, width, height), anim);
/*     */     }
/* 136 */     ticks += 1.0F / Math.max(Minecraft.debugFPS, 5.0F) * 75.0F;
/*     */   }
/*     */   
/*     */   public static void drawBig(MatrixStack ms, AlertType type, String text, float x, float y, float width, float height, float anim) {
/* 140 */     Alerts alerts = ((Interface)rock.getModules().get(Interface.class)).getAlerts();
/*     */     
/* 142 */     if (((Interface)rock.getModules().get(Interface.class)).getAlerts().getAdditions().get()) {
/* 143 */       Render.glow(ms, new Rect(x, y, width, height), anim);
/*     */     }
/* 145 */     Round.draw(ms, new Rect(x, y, width, height), 4.0F, rock.getThemes().getFirstColor().alpha((anim * (alerts.getTransparent().get() ? 0.5F : 1.0F))));
/*     */     
/* 147 */     drawBigIcon(ms, type, x, y, anim);
/*     */     
/* 149 */     Stencil.init();
/* 150 */     Round.draw(ms, new Rect(x, y, width, height), 4.0F, FixColor.WHITE.alpha(anim));
/* 151 */     Stencil.read(1);
/* 152 */     semibold.get(16).draw(ms, text, x + 26.0F, y + 7.0F, rock.getThemes().getTextFirstColor().alpha(anim));
/* 153 */     Stencil.finish();
/*     */     
/* 155 */     if (((Interface)rock.getModules().get(Interface.class)).getAlerts().getAdditions().get()) {
/* 156 */       Render.outline(ms, new Rect(x, y, width, height), anim);
/*     */     }
/*     */     
/* 159 */     ticks += 1.0F / Math.max(Minecraft.debugFPS, 5.0F) * 75.0F;
/*     */   } public static void drawSmallIcon(MatrixStack ms, AlertType type, float x, float y, float anim) {
/*     */     float off;
/*     */     Rect rect1;
/* 163 */     Modules alerts = rock.getModules();
/* 164 */     float alpha = (alerts != null && ((Interface)alerts.get(Interface.class)).getAlerts().getTransparent().get()) ? 0.5F : 1.0F;
/*     */     
/* 166 */     switch (type) {
/*     */       case WAIT:
/* 168 */         off = 1.0F;
/* 169 */         rect1 = new Rect(x + 3.0F, y + 3.5F, 9.0F, 9.0F);
/* 170 */         rect1 = rect1.x(rect1.getX() + off).y(rect1.getY() + off).width(rect1.getWidth() - off * 2.0F).height(rect1.getHeight() - off * 2.0F);
/*     */         
/* 172 */         Outline.draw(ms, rect1, 3.0F, 1.2F, (new FixColor(220.0D, 220.0D, 220.0D)).alpha((anim * 0.3F)));
/*     */         
/* 174 */         Stencil.init();
/* 175 */         GL11.glPushMatrix();
/* 176 */         GL11.glTranslated((x + 3.0F + 4.5F), (y + 3.5F + 4.5F), 0.0D);
/* 177 */         GL11.glRotated((ticks * 2.0F), 0.0D, 0.0D, 1.0D);
/* 178 */         Round.draw(ms, new Rect(-1.5F, -1.5F, 9.0F, 9.0F), 0.0F, FixColor.WHITE);
/* 179 */         GL11.glPopMatrix();
/* 180 */         Stencil.read(0);
/* 181 */         Outline.draw(ms, rect1, 3.0F, 1.2F, FixColor.WHITE.alpha((anim * alpha)));
/* 182 */         Stencil.finish();
/*     */         break;
/*     */       case SUCCESS:
/* 185 */         Round.draw(ms, new Rect(x + 3.0F, y + 3.0F, 9.0F, 9.0F), 4.5F, FixColor.GREEN.alpha((anim * alpha)));
/* 186 */         Render.image("icons/yes.png", x + 4.5F, y + 5.0F, 6.0F, 6.0F, (Color)FixColor.WHITE.alpha((anim * alpha)));
/*     */         break;
/*     */       case ERROR:
/* 189 */         Round.draw(ms, new Rect(x + 3.0F, y + 3.0F, 9.0F, 9.0F), 4.5F, FixColor.RED.alpha((anim * alpha)));
/* 190 */         Render.image("icons/xmark.png", x + 5.3F, y + 5.5F, 4.0F, 4.0F, (Color)FixColor.WHITE.alpha((anim * alpha)));
/*     */         break;
/*     */       case INFO:
/* 193 */         Round.draw(ms, new Rect(x + 3.0F, y + 3.0F, 9.0F, 9.0F), 4.5F, FixColor.GREEN.alpha((anim * alpha)));
/* 194 */         Render.image("icons/info.png", x + 4.5F, y + 5.0F, 6.0F, 6.0F, (Color)FixColor.WHITE.alpha((anim * alpha)));
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void drawBigIcon(MatrixStack ms, AlertType type, float x, float y, float anim) {
/*     */     float off;
/*     */     Rect rect1;
/* 202 */     Alerts alerts = ((Interface)rock.getModules().get(Interface.class)).getAlerts();
/*     */     
/* 204 */     switch (type) {
/*     */       case WAIT:
/* 206 */         off = 1.0F;
/* 207 */         rect1 = new Rect(x + 5.0F, y + 5.5F, 15.0F, 15.0F);
/* 208 */         rect1 = rect1.x(rect1.getX() + off).y(rect1.getY() + off).width(rect1.getWidth() - off * 2.0F).height(rect1.getHeight() - off * 2.0F);
/*     */         
/* 210 */         Outline.draw(ms, rect1, 7.0F, 2.4F, (new FixColor(220.0D, 220.0D, 220.0D)).alpha((anim * 0.3F)));
/*     */         
/* 212 */         Stencil.init();
/* 213 */         GL11.glPushMatrix();
/* 214 */         GL11.glTranslated((x + 5.0F + 7.5F), (y + 5.5F + 7.5F), 0.0D);
/* 215 */         GL11.glRotated((ticks * 2.0F), 0.0D, 0.0D, 1.0D);
/* 216 */         Round.draw(ms, new Rect(-0.5F, -0.5F, 15.0F, 15.0F), 0.0F, FixColor.WHITE);
/* 217 */         GL11.glPopMatrix();
/* 218 */         Stencil.read(0);
/* 219 */         Outline.draw(ms, rect1, 7.0F, 2.4F, FixColor.WHITE.alpha((anim * (alerts.getTransparent().get() ? 0.5F : 1.0F))));
/* 220 */         Stencil.finish();
/*     */         break;
/*     */       case SUCCESS:
/* 223 */         Round.draw(ms, new Rect(x + 5.0F, y + 5.0F, 15.0F, 15.0F), 7.5F, FixColor.GREEN.alpha((anim * (alerts.getTransparent().get() ? 0.5F : 1.0F))));
/* 224 */         Render.image("icons/yes.png", x + 7.0F, y + 7.5F, 11.0F, 11.0F, (Color)FixColor.WHITE.alpha((anim * (alerts.getTransparent().get() ? 0.5F : 1.0F))));
/*     */         break;
/*     */       case ERROR:
/* 227 */         Round.draw(ms, new Rect(x + 5.0F, y + 5.0F, 15.0F, 15.0F), 7.5F, FixColor.RED.alpha((anim * (alerts.getTransparent().get() ? 0.5F : 1.0F))));
/* 228 */         Render.image("icons/xmark.png", x + 8.5F, y + 8.5F, 8.0F, 8.0F, (Color)FixColor.WHITE.alpha((anim * (alerts.getTransparent().get() ? 0.5F : 1.0F))));
/*     */         break;
/*     */       case INFO:
/* 231 */         Round.draw(ms, new Rect(x + 5.0F, y + 5.0F, 15.0F, 15.0F), 7.5F, FixColor.GREEN.alpha((anim * (alerts.getTransparent().get() ? 0.5F : 1.0F))));
/* 232 */         Render.image("icons/info.png", x + 7.0F, y + 7.5F, 11.0F, 11.0F, (Color)FixColor.WHITE.alpha((anim * (alerts.getTransparent().get() ? 0.5F : 1.0F))));
/*     */         break;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\alerts\AlertUtility.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */