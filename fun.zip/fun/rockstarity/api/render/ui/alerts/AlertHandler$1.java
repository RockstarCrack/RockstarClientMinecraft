/*    */ package fun.rockstarity.api.render.ui.alerts;


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\alerts\AlertHandler$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */