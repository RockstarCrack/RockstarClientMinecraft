/*    */ package fun.rockstarity.api.render.ui.alerts;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Tooltip
/*    */ {
/*    */   private Tooltip() {
/* 15 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*    */   }
/* 17 */   private static final HashSet<String> usedTooltips = new HashSet<>();
/*    */   
/*    */   public static String create(String text) {
/* 20 */     if (!usedTooltips.contains(text)) {
/* 21 */       usedTooltips.add(text);
/* 22 */       return text;
/*    */     } 
/*    */     
/* 25 */     return "";
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\alerts\Tooltip.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */