/*    */ package fun.rockstarity.api.render.ui.alerts;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.binds.Bind;
/*    */ import fun.rockstarity.api.binds.Bindable;
/*    */ import fun.rockstarity.api.render.animation.Animation;
/*    */ import fun.rockstarity.api.render.animation.Easing;
/*    */ import fun.rockstarity.api.render.shaders.list.Round;
/*    */ import fun.rockstarity.api.render.ui.rect.Rect;
/*    */ import fun.rockstarity.client.modules.render.Interface;
/*    */ import fun.rockstarity.client.modules.render.ui.Alerts;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import javafx.animation.Interpolator;
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ public class Alert
/*    */   extends Rect
/*    */   implements IAccess {
/*    */   private Bindable bindable;
/*    */   private Bind bind;
/*    */   private final String text;
/*    */   private final AlertType type;
/*    */   private float ticks;
/*    */   private boolean closing;
/*    */   private float yAnim;
/*    */   
/*    */   public Bindable getBindable() {
/* 30 */     return this.bindable; } public void setBindable(Bindable bindable) { this.bindable = bindable; }
/* 31 */   public Bind getBind() { return this.bind; } public void setBind(Bind bind) { this.bind = bind; }
/*    */    public AlertType getType() {
/* 33 */     return this.type;
/*    */   }
/*    */ 
/*    */   
/*    */   public Animation getShow() {
/* 38 */     return this.show; } public Animation getOpen() { return this.open; } private final Animation show = (new Animation())
/* 39 */     .setEasing(Easing.BOTH_SINE).setSpeed(300).setSize(1.0F);
/* 40 */   private final Animation open = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(200).setSize(1.0F);
/*    */   
/*    */   public Alert(String text, AlertType type, float x, float y, float width, float height) {
/* 43 */     super(x, y, width, height);
/* 44 */     this.type = type;
/* 45 */     this.text = text;
/* 46 */     this.show.setForward(true);
/*    */   }
/*    */   
/*    */   public void render(MatrixStack matrixStack) {
/* 50 */     float openValue = (this.open.isForward() || !this.show.isForward()) ? this.open.get() : 0.0F;
/* 51 */     Alerts alerts = ((Interface)rock.getModules().get(Interface.class)).getAlerts();
/* 52 */     boolean big = alerts.getMode().is(alerts.getBig());
/*    */     
/* 54 */     ArrayList<Alert> alertsList = new ArrayList<>(rock.getAlertHandler().getAlerts());
/*    */     
/* 56 */     if (!big) {
/* 57 */       Collections.reverse(alertsList);
/*    */     }
/* 59 */     this.yAnim = (float)Interpolator.LINEAR.interpolate(this.yAnim, (alertsList.indexOf(this) * (this.height + (big ? 5 : ((Interface.glow() || Interface.outline()) ? 4 : true)))), (0.3F / Math.max(Minecraft.debugFPS, 5.0F) * 75.0F));
/*    */     
/* 61 */     if (big) {
/* 62 */       this.width = 25.0F + (10.0F + semibold.get(16).getWidth(this.text)) * openValue;
/* 63 */       this.height = 25.0F;
/* 64 */       this.x = sr.getScaledWidth() - this.width - 10.0F;
/* 65 */       this.y = sr.getScaledHeight() - this.height - 10.0F - this.yAnim;
/* 66 */       AlertUtility.drawBig(matrixStack, this.type, this.text, this.x, this.y, this.width, this.height, this.show.get());
/*    */     } else {
/* 68 */       this.width = semibold.get(14).getWidth(this.text) + 18.0F;
/* 69 */       this.height = 15.0F;
/* 70 */       this.x = (sr.getScaledWidth() / 2) - this.width / 2.0F * ((Interface)rock.getModules().get(Interface.class)).getSize().get();
/* 71 */       if (alerts.getPosition().is(alerts.getTop())) {
/* 72 */         this.y = 10.0F + this.yAnim;
/* 73 */       } else if (alerts.getPosition().is(alerts.getCenter())) {
/* 74 */         this.y = (sr.getScaledHeight() / 2 + 10) + this.yAnim;
/* 75 */       } else if (alerts.getPosition().is(alerts.getBottom())) {
/* 76 */         this.y = (sr.getScaledHeight() - 90) - this.yAnim;
/*    */       } 
/* 78 */       AlertUtility.drawSmall(matrixStack, this.type, this.text, this.x, this.y, this.width, this.height, this.show.get());
/*    */     } 
/*    */     
/* 81 */     this.ticks += 1.0F / Math.max(Minecraft.debugFPS, 5.0F) * 75.0F;
/*    */     
/* 83 */     if (this.type != AlertType.WAIT && this.ticks > 130.0F) this.show.setForward(false);
/*    */     
/* 85 */     this.open.setForward(this.show.finished());
/*    */   }
/*    */   
/*    */   public void renderBackground(MatrixStack ms) {
/* 89 */     Round.draw(ms, new Rect(this.x, this.y, this.width, this.height), 3.0F, rock.getThemes().getFirstColor().alpha(this.show.get()));
/*    */   }
/*    */   
/*    */   public void hide() {
/* 93 */     this.closing = true;
/* 94 */     this.show.setForward(false);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\rende\\ui\alerts\Alert.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */