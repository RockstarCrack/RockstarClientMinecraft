/*    */ package fun.rockstarity.api.render.globals.marks;
/*    */ 
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.helpers.system.ThreadManager;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.OutputStream;
/*    */ import java.io.PrintWriter;
/*    */ import java.net.Socket;
/*    */ import net.minecraft.client.gui.overlay.PlayerTabOverlayGui;
/*    */ import net.minecraft.util.math.vector.Vector3d;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MarkServer
/*    */   implements IAccess
/*    */ {
/*    */   static Socket socket;
/*    */   static OutputStream output;
/*    */   static InputStream input;
/*    */   static PrintWriter writer;
/*    */   static BufferedReader reader;
/*    */   
/*    */   private MarkServer() {
/* 28 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void init() {
/*    */     try {
/* 38 */       socket = new Socket("85.192.24.174", 14253);
/* 39 */       OutputStream output = socket.getOutputStream();
/* 40 */       InputStream input = socket.getInputStream();
/*    */       
/* 42 */       writer = new PrintWriter(output, true);
/* 43 */       reader = new BufferedReader(new InputStreamReader(input));
/* 44 */     } catch (Exception exception) {}
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void finish() {
/*    */     try {
/* 51 */       if (output != null)
/* 52 */         output.close(); 
/* 53 */       if (input != null)
/* 54 */         input.close(); 
/* 55 */       if (writer != null)
/* 56 */         writer.close(); 
/* 57 */       if (reader != null)
/* 58 */         reader.close(); 
/* 59 */       if (socket != null)
/* 60 */         socket.close(); 
/* 61 */     } catch (IOException iOException) {}
/*    */   }
/*    */ 
/*    */   
/*    */   public static void updateSchedules() {
/* 66 */     if (writer != null) {
/* 67 */       writer.println("/update");
/*    */     }
/*    */   }
/*    */   
/*    */   public static void send(Mark mark) {
/* 72 */     if (writer != null)
/* 73 */       writer.println(mc.player.getNameClear() + "/" + mc.player.getNameClear() + "/" + mark.getUser() + "/" + (mark.getPosition()).x + "/" + (mark.getPosition()).y); 
/*    */   }
/*    */   
/*    */   public static void update() {
/* 77 */     ThreadManager.run(() -> {
/*    */           if (reader == null) {
/*    */             init();
/*    */             
/*    */             return;
/*    */           } 
/*    */           
/*    */           try {
/*    */             try {
/*    */               String message = null;
/*    */               
/*    */               while ((message = reader.readLine()) != null) {
/*    */                 if (message.contains("/")) {
/*    */                   String[] splitted = message.split("/");
/*    */                   
/*    */                   synchronized (MarkManager.getMarks()) {
/*    */                     for (String player : PlayerTabOverlayGui.getPlayersNames()) {
/*    */                       if (player.contains(splitted[0])) {
/*    */                         Mark mark = new Mark(splitted[0], new Vector3d(Double.parseDouble(splitted[2]), Double.parseDouble(splitted[3]), Double.parseDouble(splitted[4])));
/*    */                         
/*    */                         mark.getShowing().finish();
/*    */                         
/*    */                         MarkManager.getMarks().add(mark);
/*    */                       } 
/*    */                     } 
/*    */                   } 
/*    */                 } 
/*    */               } 
/* :5 */             } catch (Exception e) {
/*    */               e.printStackTrace();
/*    */               
/*    */               init();
/*    */             } 
/* ;0 */           } catch (Exception e) {
/*    */             e.printStackTrace();
/*    */           } 
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\globals\marks\MarkServer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */