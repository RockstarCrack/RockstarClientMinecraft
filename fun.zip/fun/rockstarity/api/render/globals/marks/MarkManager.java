/*    */ package fun.rockstarity.api.render.globals.marks;
/*    */ 
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.events.list.game.inputs.EventKey;
/*    */ import fun.rockstarity.api.helpers.math.MathUtility;
/*    */ import fun.rockstarity.client.modules.other.Globals;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.Entity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MarkManager
/*    */   implements IAccess
/*    */ {
/*    */   private MarkManager() {
/* 22 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*    */   } public static List<Mark> getMarks() {
/* 24 */     return marks;
/* 25 */   } private static final List<Mark> marks = new ArrayList<>();
/*    */   
/*    */   public static void onEvent(Event event) {
/* 28 */     if (event instanceof EventKey) { EventKey e = (EventKey)event; if (mc.currentScreen == null || e.isReleased()) handleKeys(e);  }
/*    */     
/* 30 */     Iterator<Mark> iterator = marks.iterator();
/*    */     
/*    */     try {
/* 33 */       synchronized (marks) {
/* 34 */         while (iterator.hasNext()) {
/* 35 */           Mark mark = iterator.next();
/* 36 */           mark.onEvent(event);
/*    */           
/* 38 */           if (event instanceof fun.rockstarity.api.events.list.render.EventRender2D && 
/* 39 */             mark.getShowing().finished(false)) {
/* 40 */             marks.remove(mark);
/*    */           }
/*    */         }
/*    */       
/*    */       } 
/* 45 */     } catch (Exception exception) {}
/*    */   }
/*    */ 
/*    */   
/*    */   private static void handleKeys(EventKey e) {
/* 50 */     if (((Globals)rock.getModules().get(Globals.class)).getMarkBind().getBindByKey(e).isPresent() && !e.isReleased()) {
/* 51 */       Mark mark = new Mark(mc.player.getNameClear(), MathUtility.rayTrace(150.0D, mc.player.rotationYaw, mc.player.rotationPitch, (Entity)mc.player).getHitVec());
/* 52 */       mark.getShowing().finish();
/* 53 */       marks.add(mark);
/* 54 */       MarkServer.send(mark);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\globals\marks\MarkManager.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */