/*    */ package fun.rockstarity.api.render.globals.marks;
/*    */ 
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.events.list.render.EventRender2D;
/*    */ import fun.rockstarity.api.helpers.math.TimerUtility;
/*    */ import fun.rockstarity.api.helpers.render.PositionTracker;
/*    */ import fun.rockstarity.api.helpers.render.Render;
/*    */ import fun.rockstarity.api.render.animation.Animation;
/*    */ import fun.rockstarity.api.render.animation.Easing;
/*    */ import fun.rockstarity.api.render.color.FixColor;
/*    */ import fun.rockstarity.api.render.color.themes.Style;
/*    */ import java.awt.Color;
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ import net.minecraft.util.math.vector.Vector2f;
/*    */ import net.minecraft.util.math.vector.Vector3d;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Mark
/*    */   implements IAccess
/*    */ {
/*    */   private Vector3d position;
/*    */   private Vector2f wts;
/*    */   
/*    */   public Vector3d getPosition() {
/* 27 */     return this.position; } public Vector2f getWts() {
/* 28 */     return this.wts;
/* 29 */   } private String user; private TimerUtility timer = new TimerUtility(); public TimerUtility getTimer() { return this.timer; } public String getUser() {
/* 30 */     return this.user;
/*    */   }
/*    */   
/* 33 */   public Animation getShowing() { return this.showing; } private Animation showing = (new Animation())
/* 34 */     .setEasing(Easing.BOTH_SINE).setSpeed(300);
/* 35 */   private Animation blinking = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public Animation getBlinking() { return this.blinking; }
/*    */   
/*    */   public Mark(String user, Vector3d position) {
/* 38 */     this.position = position;
/* 39 */     this.user = user;
/*    */   }
/*    */   
/*    */   public void onEvent(Event event) {
/* 43 */     if (event instanceof EventRender2D) { EventRender2D e = (EventRender2D)event;
/* 44 */       this.wts = null;
/*    */       
/* 46 */       double[] pos = Render.worldToScreen(this.position.x, this.position.y, this.position.z);
/*    */       
/* 48 */       if (PositionTracker.isInView(this.position) && pos != null) {
/* 49 */         this.wts = new Vector2f((float)pos[0], (float)pos[1]);
/*    */       }
/* 51 */       if (this.wts == null)
/*    */         return; 
/* 53 */       float size = 20.0F;
/* 54 */       Render.image("icons/gps/point.png", this.wts.x - size / 2.0F, this.wts.y - size / 2.0F, size, size, (Color)Style.getMain().alpha(((0.3F + this.blinking.get() * 0.7F) * this.showing.get())));
/*    */       
/* 56 */       String who = "От " + (this.user.equals(mc.player.getName().getString()) ? "Вас" : this.user);
/* 57 */       bold.get(14).draw(e.getMatrixStack(), who, this.wts.x - bold.get(14).getWidth(who) / 2.0F, this.wts.y + 12.0F, FixColor.WHITE.alpha(((0.3F + this.blinking.get() * 0.7F) * this.showing.get())));
/*    */       
/* 59 */       if (this.blinking.finished()) {
/* 60 */         this.blinking.setForward(false);
/* 61 */       } else if (this.blinking.finished(false)) {
/* 62 */         this.blinking.setForward(true);
/*    */       } 
/* 64 */       this.blinking.setSpeed(MathHelper.clamp((int)(1000L - this.timer.getElapsed() / 4L), 100, 1000));
/* 65 */       this.showing.setForward(!this.timer.passed(4000L)); }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\globals\marks\Mark.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */