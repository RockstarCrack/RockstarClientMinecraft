/*     */ package fun.rockstarity.api.render.globals.emotions.shared;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.events.Event;
/*     */ import fun.rockstarity.api.events.list.game.inputs.EventKey;
/*     */ import fun.rockstarity.api.events.list.game.inputs.EventMouseMove;
/*     */ import fun.rockstarity.api.events.list.render.EventRender2D;
/*     */ import fun.rockstarity.api.helpers.render.Render;
/*     */ import fun.rockstarity.api.helpers.render.Stencil;
/*     */ import fun.rockstarity.api.render.animation.Animation;
/*     */ import fun.rockstarity.api.render.animation.Easing;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.globals.emotions.Emotions;
/*     */ import fun.rockstarity.api.render.globals.emotions.instance.EmotionType;
/*     */ import fun.rockstarity.api.render.shaders.fog.Vector2d;
/*     */ import fun.rockstarity.api.render.shaders.list.Round;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import fun.rockstarity.client.modules.other.Globals;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.entity.LivingEntity;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EmotionsWheel
/*     */   implements IAccess
/*     */ {
/*     */   private final Emotions emotions;
/*  33 */   private final Animation wheelAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300);
/*  34 */   private final Animation[] elementAnims = new Animation[8];
/*     */   
/*     */   private double mouseX;
/*     */   
/*     */   public EmotionsWheel(Emotions emotions) {
/*  39 */     this.emotions = emotions;
/*  40 */     for (int i = 0; i < 8; i++)
/*  41 */       this.elementAnims[i] = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); 
/*     */   }
/*     */   private double mouseY; private EmotionType emotion;
/*     */   
/*     */   public void onEvent(Event event) {
/*  46 */     if (mc.currentScreen == null)
/*  47 */     { if (event instanceof EventKey) { EventKey e = (EventKey)event;
/*  48 */         if (((Globals)rock.getModules().get(Globals.class)).getWheelBind().getBindByKey(e).isPresent()) {
/*  49 */           this.wheelAnim.setForward(!e.isReleased());
/*     */ 
/*     */           
/*  52 */           this.mouseX = this.mouseY = 0.0D;
/*  53 */           this.emotion = null;
/*     */           
/*  55 */           if (this.emotion != null) {
/*  56 */             rock.getEmotions().playEmotion((LivingEntity)mc.player, this.emotion);
/*     */           }
/*     */         }  }
/*     */ 
/*     */       
/*  61 */       if (event instanceof EventMouseMove) { EventMouseMove e = (EventMouseMove)event;
/*  62 */         if (this.wheelAnim.isForward()) {
/*  63 */           this.mouseX += e.getXVelocity();
/*  64 */           this.mouseY += e.getYVelocity();
/*  65 */           e.cancel();
/*     */         }  }
/*     */ 
/*     */       
/*  69 */       if (event instanceof EventRender2D) { EventRender2D e = (EventRender2D)event;
/*  70 */         drawWheel(e); }
/*     */        }
/*  72 */     else { this.wheelAnim.setForward(false);
/*  73 */       this.emotion = null; }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   private void drawWheel(EventRender2D event) {
/*  79 */     MatrixStack ms = event.getMatrixStack();
/*     */     
/*  81 */     if (this.wheelAnim.finished(false))
/*     */       return; 
/*  83 */     Round.draw(ms, new Rect(0.0F, 0.0F, sr.getScaledWidth(), sr.getScaledHeight()), 0.0F, FixColor.BLACK.alpha((0.4F * this.wheelAnim.get())));
/*     */     
/*  85 */     float x = sr.getScaledWidth() / 2.0F;
/*  86 */     float y = sr.getScaledHeight() / 2.0F;
/*     */     
/*  88 */     GL11.glPushMatrix();
/*     */     
/*  90 */     GL11.glTranslated(x, y, 0.0D);
/*     */ 
/*     */     
/*  93 */     double distance = Double.MAX_VALUE;
/*  94 */     int closest = 0;
/*     */     int i;
/*  96 */     for (i = 0; i < 8; i++) {
/*  97 */       float width = 95.0F * (1.5F - 0.5F * this.wheelAnim.get());
/*  98 */       float height = 58.0F * (1.5F - 0.5F * this.wheelAnim.get());
/*  99 */       float radius = 150.0F - 50.0F * this.wheelAnim.get();
/*     */       
/* 101 */       double xPos = Math.cos(Math.toRadians((45.0F * i + 90.0F))) * -radius;
/* 102 */       double yPos = Math.sin(Math.toRadians((45.0F * i + 90.0F))) * -radius;
/*     */ 
/*     */ 
/*     */       
/* 106 */       double dist = (new Vector2d(this.mouseX, this.mouseY)).distance(new Vector2d(xPos, yPos));
/*     */       
/* 108 */       if (dist < distance) {
/* 109 */         closest = i;
/* 110 */         distance = dist;
/*     */       } 
/*     */     } 
/*     */     
/* 114 */     GL11.glRotated(-45.0D, 0.0D, 0.0D, 1.0D);
/*     */     
/* 116 */     for (i = 0; i < 8; i++) {
/* 117 */       float width = 95.0F * (1.5F - 0.5F * this.wheelAnim.get());
/* 118 */       float height = 58.0F * (1.5F - 0.5F * this.wheelAnim.get());
/* 119 */       float radius = 150.0F - 50.0F * this.wheelAnim.get();
/*     */       
/* 121 */       this.elementAnims[i].setEasing(Easing.TARGETESP_EASE_OUT_BACK);
/* 122 */       this.elementAnims[i].setForward((i == closest));
/*     */       
/* 124 */       radius += this.elementAnims[i].get() * 5.0F;
/* 125 */       width *= 1.0F + this.elementAnims[i].get() * 0.1F;
/* 126 */       height *= 1.0F + this.elementAnims[i].get() * 0.1F;
/*     */ 
/*     */       
/* 129 */       GL11.glRotated(45.0D, 0.0D, 0.0D, 1.0D);
/* 130 */       Render.image("masks/wheel_element.png", -width / 2.0F, -radius - height / 2.0F, width, height, (Color)rock
/* 131 */           .getThemes().getFirstColor().move((i > (EmotionType.values()).length - 1) ? 
/* 132 */             (Color)rock.getThemes().getSecondColor().move((Color)FixColor.RED, 0.03F) : 
/* 133 */             (Color)rock.getThemes().getThirdColor(), this.elementAnims[i].get()).alpha((this.wheelAnim.get() * ((rock.getThemes().getCurrent() instanceof fun.rockstarity.api.render.color.themes.list.LightTheme) ? 0.7F : 1.0F))));
/*     */       
/* 135 */       if (i == closest) {
/* 136 */         this.emotion = (i > (EmotionType.values()).length - 1) ? null : EmotionType.values()[i];
/*     */       }
/* 138 */       Stencil.init();
/* 139 */       Render.image("masks/wheel_element.png", -width / 2.0F, -radius - height / 2.0F + 0.5F, width, height - 1.5F, (Color)rock.getThemes().getFirstColor().alpha(this.wheelAnim.get()));
/* 140 */       Stencil.read(1);
/*     */       
/* 142 */       GL11.glPushMatrix();
/* 143 */       GL11.glRotated((-45.0F * i), 0.0D, 0.0D, 1.0D);
/* 144 */       double xPos = Math.cos(Math.toRadians((45.0F * i + 90.0F))) * -radius;
/* 145 */       double yPos = Math.sin(Math.toRadians((45.0F * i + 90.0F))) * -radius;
/* 146 */       float emoteSize = height + 20.0F * this.elementAnims[i].get();
/* 147 */       float bgSize = height + 120.0F * this.elementAnims[i].get();
/* 148 */       float noChosedSize = height + 50.0F + 70.0F * this.elementAnims[i].get();
/*     */       
/* 150 */       if (i > (EmotionType.values()).length - 1) {
/* 151 */         Render.image("masks/emotions/floss.png", (float)xPos - noChosedSize / 2.0F, (float)yPos - noChosedSize / 2.0F, noChosedSize, noChosedSize, (Color)FixColor.WHITE.alpha((0.05F * this.wheelAnim.get() + 0.05F * this.elementAnims[i].get())));
/*     */       } else {
/* 153 */         if (i == closest) {
/* 154 */           Render.image("masks/emotions/" + EmotionType.values()[i].getName() + ".png", (float)xPos - bgSize / 2.0F, (float)yPos - bgSize / 2.0F, bgSize, bgSize, (Color)FixColor.WHITE.alpha((0.1F * this.wheelAnim.get())));
/*     */         }
/* 156 */         Render.image("masks/emotions/" + EmotionType.values()[i].getName() + ".png", (float)xPos - emoteSize / 2.0F, (float)yPos - emoteSize / 2.0F, emoteSize, emoteSize, (Color)FixColor.WHITE.alpha(this.wheelAnim.get()));
/*     */       } 
/* 158 */       GL11.glPopMatrix();
/*     */       
/* 160 */       Stencil.finish();
/*     */     } 
/*     */     
/* 163 */     GL11.glPopMatrix();
/*     */     
/* 165 */     String title = "Выбери нужную эмоцию";
/* 166 */     String subTitle = "Выбери эмоцию из списка и отпусти клавишу";
/* 167 */     bold.get(24).draw(ms, title, x - bold.get(24).getWidth(title) / 2.0F, y - 50.0F * (1.0F - this.wheelAnim.get()) - 200.0F, FixColor.WHITE.alpha(this.wheelAnim.get()));
/* 168 */     bold.get(17).draw(ms, subTitle, x - bold.get(17).getWidth(subTitle) / 2.0F, y - 50.0F * (1.0F - this.wheelAnim.get()) - 185.0F, rock.getThemes().getDarkTheme().getTextFirstColor().alpha(this.wheelAnim.get()));
/*     */     
/* 170 */     String current = (this.emotion == null) ? "Эмоция не выбрана" : this.emotion.getLocalized();
/* 171 */     bold.get(24).draw(ms, current, x - bold.get(24).getWidth(current) / 2.0F, y + 50.0F * (1.0F - this.wheelAnim.get()) + 150.0F, FixColor.WHITE.alpha((this.wheelAnim.get() * this.elementAnims[closest].get())));
/*     */     
/* 173 */     Round.draw(ms, new Rect(-100.0F, -100.0F, 10.0F, 10.0F), 1.0F, FixColor.WHITE);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\globals\emotions\shared\EmotionsWheel.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */