/*    */ package fun.rockstarity.api.render.globals.emotions;
/*    */ 
/*    */ import fun.rockstarity.api.render.globals.emotions.instance.EmotionType;
/*    */ 


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\globals\emotions\Emotions$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */