/*    */ package fun.rockstarity.api.render.globals.emotions;
/*    */ 
/*    */ import fun.rockstarity.api.connection.globals.SyncServer;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.render.globals.emotions.instance.Emotion;
/*    */ import fun.rockstarity.api.render.globals.emotions.instance.EmotionType;
/*    */ import fun.rockstarity.api.render.globals.emotions.instance.list.DebEmotion;
/*    */ import fun.rockstarity.api.render.globals.emotions.instance.list.FlossEmotion;
/*    */ import fun.rockstarity.api.render.globals.emotions.instance.list.GetGriddyEmotion;
/*    */ import fun.rockstarity.api.render.globals.emotions.instance.list.HappyEmotion;
/*    */ import fun.rockstarity.api.render.globals.emotions.instance.list.HelloEmotion;
/*    */ import fun.rockstarity.api.render.globals.emotions.instance.list.MasturbateEmotion;
/*    */ import fun.rockstarity.api.render.globals.emotions.shared.EmotionsWheel;
/*    */ import java.util.ArrayList;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Emotions
/*    */ {
/* 28 */   private final ArrayList<Emotion> activeEmotions = new ArrayList<>(); private final EmotionsWheel wheel; private final EmotionsPlayer emotionsPlayer; public ArrayList<Emotion> getActiveEmotions() { return this.activeEmotions; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Emotions() {
/* 34 */     this.emotionsPlayer = new EmotionsPlayer(this);
/* 35 */     this.wheel = new EmotionsWheel(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEvent(Event event) {
/* 40 */     this.emotionsPlayer.onEvent(event);
/*    */     
/* 42 */     this.wheel.onEvent(event); } public void playEmotion(LivingEntity player, EmotionType emotionType) { DebEmotion debEmotion; FlossEmotion flossEmotion; GetGriddyEmotion getGriddyEmotion;
/*    */     MasturbateEmotion masturbateEmotion;
/*    */     HelloEmotion helloEmotion;
/*    */     HappyEmotion happyEmotion;
/* 46 */     Emotion emotion = null;
/*    */     
/* 48 */     if (player instanceof net.minecraft.client.entity.player.ClientPlayerEntity) {
/* 49 */       SyncServer.send(emotionType);
/*    */     }
/*    */     
/* 52 */     switch (emotionType) {
/*    */       case DEB:
/* 54 */         debEmotion = new DebEmotion(player);
/*    */         break;
/*    */       case FLOSS:
/* 57 */         flossEmotion = new FlossEmotion(player);
/*    */         break;
/*    */       case GET_GRIDDY:
/* 60 */         getGriddyEmotion = new GetGriddyEmotion(player);
/*    */         break;
/*    */       case MASTURBATE:
/* 63 */         masturbateEmotion = new MasturbateEmotion(player);
/*    */         break;
/*    */       case HELLO:
/* 66 */         helloEmotion = new HelloEmotion(player);
/*    */         break;
/*    */       case HAPPY:
/* 69 */         happyEmotion = new HappyEmotion(player);
/*    */         break;
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 89 */     this.activeEmotions.add(happyEmotion); }
/*    */ 
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\globals\emotions\Emotions.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */