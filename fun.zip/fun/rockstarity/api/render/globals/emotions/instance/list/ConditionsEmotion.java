/*    */ package fun.rockstarity.api.render.globals.emotions.instance.list;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.events.list.render.player.EventModels;
/*    */ import fun.rockstarity.api.render.animation.Animation;
/*    */ import fun.rockstarity.api.render.animation.Easing;
/*    */ import fun.rockstarity.api.render.globals.emotions.instance.Emotion;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConditionsEmotion
/*    */   extends Emotion
/*    */ {
/* 17 */   protected final Animation itemDropAnim = (new Animation()).setEasing(Easing.EASE_OUT_BOUNCE);
/*    */   
/*    */   public ConditionsEmotion(LivingEntity player) {
/* 20 */     super(player, 3500L);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEvent(Event event) {
/* 25 */     if (event instanceof EventModels) { EventModels model = (EventModels)event;
/*    */       
/* 27 */       model.bipedRightLeg.rotateAngleX = moveProp(model.bipedRightLeg.rotateAngleZ, -1.3F * this.itemDropAnim.get());
/* 28 */       this.itemDropAnim.setEasing(Easing.EASE_OUT_BOUNCE);
/* 29 */       this.itemDropAnim.setForward(true); }
/*    */ 
/*    */     
/* 32 */     super.onEvent(event);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\globals\emotions\instance\list\ConditionsEmotion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */