/*    */ package fun.rockstarity.api.render.globals.emotions.instance.list;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.events.list.render.player.EventModels;
/*    */ import fun.rockstarity.api.render.globals.emotions.instance.ActionEmotion;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ import net.minecraft.entity.player.PlayerEntity;
/*    */ import net.minecraft.entity.projectile.LlamaSpitEntity;
/*    */ import net.minecraft.util.SoundEvents;
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MasturbateEmotion
/*    */   extends ActionEmotion
/*    */ {
/*    */   private boolean spit;
/*    */   
/*    */   public MasturbateEmotion(LivingEntity player) {
/* 25 */     super(player, 3500L);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEvent(Event event) {
/* 30 */     if (event instanceof EventModels) { EventModels model = (EventModels)event;
/* 31 */       this.actionAnim.setSpeed(100);
/*    */       
/* 33 */       if (this.actionAnim.finished()) {
/* 34 */         this.actionAnim.setForward(false);
/* 35 */       } else if (this.actionAnim.finished(false)) {
/* 36 */         this.actionAnim.setForward(true);
/*    */       } 
/* 38 */       if (!this.player.isSneaking()) {
/* 39 */         if (canAnimateHands()) {
/*    */           
/* 41 */           model.bipedRightArm.rotateAngleX = moveProp(model.bipedRightArm.rotateAngleX, -0.3F - 0.7F * this.actionAnim.get());
/* 42 */           model.bipedRightArm.rotateAngleZ = moveProp(model.bipedRightArm.rotateAngleZ, -0.55F);
/*    */ 
/*    */           
/* 45 */           model.bipedLeftArm.rotateAngleX = moveProp(model.bipedLeftArm.rotateAngleX, 0.3F);
/* 46 */           model.bipedLeftArm.rotateAngleZ = moveProp(model.bipedLeftArm.rotateAngleZ, 1.0F);
/*    */         } 
/*    */ 
/*    */         
/* 50 */         model.bipedBody.rotateAngleX = moveProp(model.bipedBody.rotateAngleX, -0.1F);
/*    */ 
/*    */         
/* 53 */         model.bipedRightLeg.rotationPointZ = moveProp(0.0F, -1.0F);
/*    */ 
/*    */         
/* 56 */         model.bipedLeftLeg.rotationPointZ = moveProp(0.0F, -1.0F);
/*    */       }
/* 58 */       else if (canAnimateHands()) {
/*    */         
/* 60 */         model.bipedRightArm.rotateAngleX = moveProp(model.bipedRightArm.rotateAngleX, 0.7F - 0.7F * this.actionAnim.get());
/* 61 */         model.bipedRightArm.rotateAngleZ = moveProp(model.bipedRightArm.rotateAngleZ, -0.55F);
/*    */       }  }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 71 */     super.onEvent(event);
/*    */   }
/*    */   
/*    */   private void spit() {
/* 75 */     LlamaSpitEntity llamaspitentity = new LlamaSpitEntity((World)mc.world, (LivingEntity)mc.player);
/*    */     
/* 77 */     double speed = 12.0D;
/* 78 */     double x = -Math.sin(Math.toRadians(mc.player.rotationYaw)) * speed;
/* 79 */     double z = Math.cos(Math.toRadians(mc.player.rotationYaw)) * speed;
/*    */     
/* 81 */     double d0 = x - mc.player.getPosX();
/* 82 */     double d1 = 0.0D;
/* 83 */     double d2 = z - mc.player.getPosZ();
/* 84 */     float f = MathHelper.sqrt(d0 * d0 + d2 * d2) * 0.2F;
/* 85 */     llamaspitentity.shoot(d0, d1 + f, d2, 1.5F, 10.0F);
/*    */     
/* 87 */     mc.world.playSound((PlayerEntity)mc.player, mc.player.getPosX(), mc.player.getPosYEye(), mc.player.getPosZ(), SoundEvents.ENTITY_LLAMA_SPIT, mc.player.getSoundCategory(), 1.0F, 1.0F);
/*    */     
/* 89 */     mc.world.addEntity((Entity)llamaspitentity);
/*    */     
/* 91 */     this.spit = true;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\globals\emotions\instance\list\MasturbateEmotion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */