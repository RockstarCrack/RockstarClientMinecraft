/*    */ package fun.rockstarity.api.render.globals.emotions.instance.list;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.events.list.render.player.EventModels;
/*    */ import fun.rockstarity.api.render.animation.Animation;
/*    */ import fun.rockstarity.api.render.animation.Easing;
/*    */ import fun.rockstarity.api.render.globals.emotions.instance.ActionEmotion;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ 
/*    */ public class CryEmotion
/*    */   extends ActionEmotion
/*    */ {
/* 13 */   private final Animation handToFaceAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(400);
/* 14 */   private final Animation headBobAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(250);
/*    */   
/*    */   public CryEmotion(LivingEntity player) {
/* 17 */     super(player, 2500L);
/* 18 */     this.handToFaceAnim.setForward(true);
/* 19 */     this.headBobAnim.setForward(true);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEvent(Event event) {
/* 24 */     if (event instanceof EventModels) { EventModels model = (EventModels)event;
/* 25 */       if (canAnimateHands()) {
/* 26 */         float t = this.handToFaceAnim.get();
/*    */         
/* 28 */         float xBend = moveProp(0.0F, -2.0F * t);
/* 29 */         float yInward = moveProp(0.0F, 0.5F * t);
/* 30 */         float zAcross = moveProp(0.0F, 1.2F * t);
/*    */ 
/*    */         
/* 33 */         model.bipedRightArm.rotateAngleX = xBend;
/* 34 */         model.bipedRightArm.rotateAngleY = -yInward;
/* 35 */         model.bipedRightArm.rotateAngleZ = zAcross;
/*    */ 
/*    */         
/* 38 */         model.bipedLeftArm.rotateAngleX = xBend;
/* 39 */         model.bipedLeftArm.rotateAngleY = yInward;
/* 40 */         model.bipedLeftArm.rotateAngleZ = -zAcross;
/*    */       } 
/*    */       
/* 43 */       float headNod = 0.5F + 0.2F * this.headBobAnim.get();
/* 44 */       model.bipedHead.rotateAngleX = moveProp(model.bipedHead.rotateAngleX, headNod);
/* 45 */       model.bipedHead.rotateAngleZ = moveProp(model.bipedHead.rotateAngleZ, 0.15F * this.headBobAnim.get());
/*    */       
/* 47 */       model.bipedHeadwear.rotateAngleX = model.bipedHead.rotateAngleX;
/* 48 */       model.bipedHeadwear.rotateAngleZ = model.bipedHead.rotateAngleZ; }
/*    */ 
/*    */     
/* 51 */     super.onEvent(event);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\globals\emotions\instance\list\CryEmotion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */