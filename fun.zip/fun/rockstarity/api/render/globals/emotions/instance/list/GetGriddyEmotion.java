/*    */ package fun.rockstarity.api.render.globals.emotions.instance.list;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.events.list.render.player.EventModels;
/*    */ import fun.rockstarity.api.helpers.math.TimerUtility;
/*    */ import fun.rockstarity.api.render.animation.Animation;
/*    */ import fun.rockstarity.api.render.animation.Easing;
/*    */ import fun.rockstarity.api.render.globals.emotions.instance.ActionEmotion;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GetGriddyEmotion
/*    */   extends ActionEmotion
/*    */ {
/* 18 */   final Animation legAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(200);
/* 19 */   final Animation toEyeAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(500);
/* 20 */   final TimerUtility eyeTimer = new TimerUtility();
/*    */   int armSwings;
/*    */   
/*    */   public GetGriddyEmotion(LivingEntity player) {
/* 24 */     super(player, 5500L);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEvent(Event event) {
/* 29 */     if (event instanceof EventModels) { EventModels model = (EventModels)event;
/* 30 */       this.actionAnim.setSpeed(350);
/*    */       
/* 32 */       if (this.toEyeAnim.finished(false)) {
/* 33 */         if (this.actionAnim.finished()) {
/* 34 */           this.actionAnim.setForward(false);
/* 35 */           this.armSwings++;
/* 36 */         } else if (this.actionAnim.finished(false)) {
/* 37 */           this.actionAnim.setForward(true);
/*    */         } 
/*    */       }
/*    */       
/* 41 */       this.legAnim.setSpeed(300);
/* 42 */       if (this.legAnim.finished()) {
/* 43 */         this.legAnim.setForward(false);
/* 44 */       } else if (this.legAnim.finished(false)) {
/* 45 */         this.legAnim.setForward(true);
/*    */       } 
/* 47 */       if (this.armSwings > 2) {
/* 48 */         this.toEyeAnim.setForward(true);
/* 49 */         this.eyeTimer.reset();
/* 50 */         this.armSwings = 0;
/*    */       } 
/*    */       
/* 53 */       if (this.eyeTimer.passed(1000L)) {
/* 54 */         this.toEyeAnim.setForward(false);
/*    */       }
/*    */       
/* 57 */       if (canAnimateHands()) {
/*    */         
/* 59 */         model.bipedRightArm.rotateAngleX = moveProp(model.bipedRightArm.rotateAngleX, 1.0F - 1.5F * this.actionAnim.get() - 3.5F * this.toEyeAnim.get());
/* 60 */         model.bipedRightArm.rotateAngleZ = moveProp(model.bipedRightArm.rotateAngleZ, 0.5F - 0.75F * this.actionAnim.get());
/*    */ 
/*    */         
/* 63 */         model.bipedLeftArm.rotateAngleX = moveProp(model.bipedRightArm.rotateAngleX, 1.0F - 1.5F * this.actionAnim.get() - 3.5F * this.toEyeAnim.get());
/* 64 */         model.bipedLeftArm.rotateAngleZ = moveProp(model.bipedRightArm.rotateAngleZ, -0.5F + 0.75F * this.actionAnim.get());
/*    */       } 
/*    */ 
/*    */       
/* 68 */       model.bipedBody.rotateAngleX = moveProp(model.bipedBody.rotateAngleX, 0.2F - 0.05F * this.actionAnim.get());
/*    */ 
/*    */       
/* 71 */       model.bipedRightLeg.rotationPointZ = moveProp(0.0F, 2.0F - 0.5F * this.actionAnim.get());
/* 72 */       model.bipedRightLeg.rotateAngleX = moveProp(model.bipedRightLeg.rotateAngleZ, 0.3F * this.legAnim.get() - 0.3F);
/*    */ 
/*    */       
/* 75 */       model.bipedLeftLeg.rotationPointZ = moveProp(0.0F, 2.0F - 0.5F * this.actionAnim.get());
/* 76 */       model.bipedLeftLeg.rotateAngleX = moveProp(model.bipedLeftLeg.rotateAngleZ, -0.3F * this.legAnim.get() - 0.1F);
/*    */ 
/*    */       
/* 79 */       model.bipedHead.rotateAngleY = moveProp(model.bipedHead.rotateAngleZ, -0.4F + 0.4F * this.toEyeAnim.get());
/* 80 */       model.bipedHead.rotateAngleX = moveProp(model.bipedHead.rotateAngleX, -0.3F * this.toEyeAnim.get());
/* 81 */       model.bipedHead.rotateAngleZ = moveProp(model.bipedHead.rotateAngleZ, 0.0F);
/*    */       
/* 83 */       model.bipedHeadwear.rotateAngleY = moveProp(model.bipedHead.rotateAngleZ, -0.4F + 0.4F * this.toEyeAnim.get());
/* 84 */       model.bipedHeadwear.rotateAngleX = moveProp(model.bipedHead.rotateAngleX, -0.3F * this.toEyeAnim.get());
/* 85 */       model.bipedHeadwear.rotateAngleZ = moveProp(model.bipedHead.rotateAngleZ, 0.0F); }
/*    */ 
/*    */     
/* 88 */     super.onEvent(event);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\globals\emotions\instance\list\GetGriddyEmotion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */