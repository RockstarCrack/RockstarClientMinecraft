/*    */ package fun.rockstarity.api.render.globals.emotions.instance.list;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.events.list.render.player.EventModels;
/*    */ import fun.rockstarity.api.render.globals.emotions.instance.ActionEmotion;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HelloEmotion
/*    */   extends ActionEmotion
/*    */ {
/*    */   public HelloEmotion(LivingEntity player) {
/* 16 */     super(player, 2500L);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEvent(Event event) {
/* 21 */     if (event instanceof EventModels) { EventModels model = (EventModels)event;
/* 22 */       this.actionAnim.setSpeed(250);
/*    */       
/* 24 */       if (this.actionAnim.finished()) {
/* 25 */         this.actionAnim.setForward(false);
/* 26 */       } else if (this.actionAnim.finished(false)) {
/* 27 */         this.actionAnim.setForward(true);
/*    */       } 
/* 29 */       if (canAnimateHands()) {
/*    */         
/* 31 */         model.bipedRightArm.rotateAngleX = moveProp(model.bipedRightArm.rotateAngleX, -0.2F);
/* 32 */         model.bipedRightArm.rotateAngleZ = moveProp(model.bipedRightArm.rotateAngleZ, 2.75F - 0.25F * this.actionAnim.get());
/*    */       }  }
/*    */ 
/*    */     
/* 36 */     super.onEvent(event);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\globals\emotions\instance\list\HelloEmotion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */