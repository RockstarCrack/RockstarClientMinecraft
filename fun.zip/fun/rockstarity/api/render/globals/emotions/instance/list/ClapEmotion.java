/*    */ package fun.rockstarity.api.render.globals.emotions.instance.list;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.events.list.render.player.EventModels;
/*    */ import fun.rockstarity.api.render.animation.Animation;
/*    */ import fun.rockstarity.api.render.animation.Easing;
/*    */ import fun.rockstarity.api.render.globals.emotions.instance.ActionEmotion;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ 
/*    */ public class ClapEmotion
/*    */   extends ActionEmotion {
/* 12 */   private final Animation clapAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300);
/*    */   
/*    */   public ClapEmotion(LivingEntity player) {
/* 15 */     super(player, 2500L);
/* 16 */     this.clapAnim.setForward(true);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEvent(Event event) {
/* 21 */     if (event instanceof EventModels) { EventModels model = (EventModels)event;
/*    */ 
/*    */       
/* 24 */       if (this.clapAnim.finished()) {
/* 25 */         this.clapAnim.setForward(false);
/* 26 */       } else if (this.clapAnim.finished(false)) {
/* 27 */         this.clapAnim.setForward(true);
/*    */       } 
/*    */       
/* 30 */       if (canAnimateHands()) {
/* 31 */         float t = this.clapAnim.get();
/*    */         
/* 33 */         float xBend = moveProp(0.0F, -0.8F * t);
/* 34 */         float yInward = moveProp(0.0F, 0.8F * t);
/* 35 */         float zFlat = moveProp(0.0F, 0.4F * t);
/*    */ 
/*    */         
/* 38 */         model.bipedRightArm.rotateAngleX = xBend;
/* 39 */         model.bipedRightArm.rotateAngleY = -yInward;
/* 40 */         model.bipedRightArm.rotateAngleZ = zFlat;
/*    */ 
/*    */         
/* 43 */         model.bipedLeftArm.rotateAngleX = xBend;
/* 44 */         model.bipedLeftArm.rotateAngleY = yInward;
/* 45 */         model.bipedLeftArm.rotateAngleZ = -zFlat;
/*    */       }  }
/*    */     
/* 48 */     super.onEvent(event);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\globals\emotions\instance\list\ClapEmotion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */