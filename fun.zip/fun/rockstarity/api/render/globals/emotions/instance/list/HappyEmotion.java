/*    */ package fun.rockstarity.api.render.globals.emotions.instance.list;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.events.list.render.player.EventModels;
/*    */ import fun.rockstarity.api.render.globals.emotions.instance.Emotion;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ 
/*    */ public class HappyEmotion
/*    */   extends Emotion
/*    */ {
/*    */   public HappyEmotion(LivingEntity player) {
/* 12 */     super(player, 2500L);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEvent(Event event) {
/* 17 */     if (event instanceof EventModels) { EventModels model = (EventModels)event;
/* 18 */       if (canAnimateHands()) {
/*    */         
/* 20 */         model.bipedRightArm.rotateAngleX = moveProp(model.bipedRightArm.rotateAngleX, 0.0F);
/* 21 */         model.bipedRightArm.rotateAngleZ = moveProp(model.bipedRightArm.rotateAngleZ, 2.75F);
/*    */         
/* 23 */         model.bipedLeftArm.rotateAngleX = moveProp(model.bipedLeftArm.rotateAngleX, 0.0F);
/* 24 */         model.bipedLeftArm.rotateAngleZ = moveProp(model.bipedLeftArm.rotateAngleZ, -2.75F);
/*    */       }  }
/*    */ 
/*    */     
/* 28 */     super.onEvent(event);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\globals\emotions\instance\list\HappyEmotion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */