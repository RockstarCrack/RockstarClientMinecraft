/*    */ package fun.rockstarity.api.render.globals.emotions.instance;
/*    */ 
/*    */ import fun.rockstarity.api.render.animation.Animation;
/*    */ import fun.rockstarity.api.render.animation.Easing;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActionEmotion
/*    */   extends Emotion
/*    */ {
/* 15 */   protected final Animation actionAnim = (new Animation()).setEasing(Easing.BOTH_SINE);
/*    */   
/*    */   public ActionEmotion(LivingEntity player, long time) {
/* 18 */     super(player, time);
/*    */   }
/*    */   
/*    */   public ActionEmotion(LivingEntity player) {
/* 22 */     super(player);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\globals\emotions\instance\ActionEmotion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */