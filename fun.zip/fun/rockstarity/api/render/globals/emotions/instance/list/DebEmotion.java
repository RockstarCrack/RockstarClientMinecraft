/*    */ package fun.rockstarity.api.render.globals.emotions.instance.list;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.events.list.render.player.EventModels;
/*    */ import fun.rockstarity.api.render.globals.emotions.instance.Emotion;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DebEmotion
/*    */   extends Emotion
/*    */ {
/*    */   public DebEmotion(LivingEntity player) {
/* 16 */     super(player);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEvent(Event event) {
/* 21 */     if (event instanceof EventModels) { EventModels model = (EventModels)event;
/* 22 */       if (canAnimateHands()) {
/*    */         
/* 24 */         model.bipedRightArm.rotateAngleX = moveProp(model.bipedRightArm.rotateAngleX, -0.7F);
/* 25 */         model.bipedRightArm.rotateAngleZ = moveProp(model.bipedRightArm.rotateAngleZ, -2.0F);
/*    */ 
/*    */         
/* 28 */         model.bipedLeftArm.rotateAngleX = moveProp(model.bipedLeftArm.rotateAngleX, -0.7F);
/* 29 */         model.bipedLeftArm.rotateAngleZ = moveProp(model.bipedLeftArm.rotateAngleZ, -2.0F);
/*    */       } 
/*    */ 
/*    */       
/* 33 */       model.bipedHead.rotateAngleX = moveProp(model.bipedHead.rotateAngleX, 0.7F);
/* 34 */       model.bipedHead.rotateAngleY = moveProp(model.bipedHead.rotateAngleY, 0.5F);
/*    */       
/* 36 */       model.bipedHeadwear.rotateAngleX = moveProp(model.bipedHeadwear.rotateAngleX, 0.7F);
/* 37 */       model.bipedHeadwear.rotateAngleY = moveProp(model.bipedHeadwear.rotateAngleY, 0.5F); }
/*    */ 
/*    */     
/* 40 */     super.onEvent(event);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\globals\emotions\instance\list\DebEmotion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */