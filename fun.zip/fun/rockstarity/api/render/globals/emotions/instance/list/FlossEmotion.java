/*    */ package fun.rockstarity.api.render.globals.emotions.instance.list;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.events.list.render.player.EventModels;
/*    */ import fun.rockstarity.api.render.animation.Animation;
/*    */ import fun.rockstarity.api.render.animation.Easing;
/*    */ import fun.rockstarity.api.render.globals.emotions.instance.ActionEmotion;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlossEmotion
/*    */   extends ActionEmotion
/*    */ {
/* 19 */   private final Animation rightChangeSideAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(250);
/* 20 */   private final Animation leftChangeSideAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(250);
/*    */   private int leftSwings;
/*    */   
/*    */   public FlossEmotion(LivingEntity player) {
/* 24 */     super(player, 4500L);
/* 25 */     this.leftSwings = 1;
/* 26 */     this.rightSwings = 1;
/* 27 */     this.rightChangeSideAnim.setForward(true);
/* 28 */     this.leftChangeSideAnim.setForward(true);
/*    */   }
/*    */   private int rightSwings;
/*    */   
/*    */   public void onEvent(Event event) {
/* 33 */     if (event instanceof EventModels) { EventModels model = (EventModels)event;
/*    */       
/* 35 */       this.actionAnim.setSpeed(250);
/*    */       
/* 37 */       if (this.actionAnim.finished()) {
/* 38 */         if (this.leftSwings == 2) {
/* 39 */           this.leftChangeSideAnim.setForward(false);
/*    */         }
/* 41 */         if (this.leftSwings == 3) {
/* 42 */           this.leftChangeSideAnim.setForward(true);
/*    */         }
/*    */         
/* 45 */         if (this.leftSwings > 2) {
/* 46 */           this.leftSwings = 0;
/*    */         }
/*    */         
/* 49 */         this.leftSwings++;
/* 50 */         this.actionAnim.setForward(false);
/* 51 */       } else if (this.actionAnim.finished(false)) {
/* 52 */         if (this.rightSwings == 1) {
/* 53 */           this.rightChangeSideAnim.setForward(false);
/*    */         }
/* 55 */         if (this.rightSwings == 2) {
/* 56 */           this.rightChangeSideAnim.setForward(true);
/*    */         }
/* 58 */         if (this.rightSwings > 2) {
/* 59 */           this.rightSwings = 0;
/*    */         }
/*    */         
/* 62 */         this.rightSwings++;
/* 63 */         this.actionAnim.setForward(true);
/*    */       } 
/*    */       
/* 66 */       if (canAnimateHands()) {
/*    */         
/* 68 */         model.bipedRightArm.rotateAngleX = moveProp(model.bipedRightArm.rotateAngleX, 0.5F - 1.0F * this.rightChangeSideAnim.get());
/* 69 */         model.bipedRightArm.rotateAngleZ = moveProp(model.bipedRightArm.rotateAngleZ, 1.0F - 2.0F * this.actionAnim.get());
/*    */ 
/*    */         
/* 72 */         model.bipedLeftArm.rotateAngleX = moveProp(model.bipedRightArm.rotateAngleX, 0.5F - 1.0F * this.leftChangeSideAnim.get());
/* 73 */         model.bipedLeftArm.rotateAngleZ = moveProp(model.bipedRightArm.rotateAngleZ, 1.5F - 2.0F * this.actionAnim.get());
/*    */       } 
/*    */ 
/*    */       
/* 77 */       model.bipedBody.rotateAngleZ = moveProp(0.0F, 0.3F * this.actionAnim.get() - 0.15F);
/*    */ 
/*    */       
/* 80 */       model.bipedRightLeg.rotationPointX = moveProp(-2.0F, -0.5F - 3.0F * this.actionAnim.get());
/*    */ 
/*    */       
/* 83 */       model.bipedLeftLeg.rotationPointX = moveProp(2.0F, 3.0F - 2.5F * this.actionAnim.get()); }
/*    */ 
/*    */     
/* 86 */     super.onEvent(event);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\globals\emotions\instance\list\FlossEmotion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */