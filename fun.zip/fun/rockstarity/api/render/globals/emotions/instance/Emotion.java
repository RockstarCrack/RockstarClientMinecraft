/*    */ package fun.rockstarity.api.render.globals.emotions.instance;
/*    */ 
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.events.list.render.entity.EventRenderEntity;
/*    */ import fun.rockstarity.api.helpers.math.MathUtility;
/*    */ import fun.rockstarity.api.helpers.math.TimerUtility;
/*    */ import fun.rockstarity.api.render.animation.Animation;
/*    */ import fun.rockstarity.api.render.animation.Easing;
/*    */ import fun.rockstarity.client.modules.render.GlowESP;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.settings.PointOfView;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Emotion
/*    */   implements IAccess
/*    */ {
/*    */   protected final LivingEntity player;
/*    */   protected final long time;
/*    */   
/*    */   public LivingEntity getPlayer() {
/* 28 */     return this.player; } public long getTime() {
/* 29 */     return this.time;
/* 30 */   } protected final Animation emotionAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public Animation getEmotionAnim() { return this.emotionAnim; }
/*    */   
/* 32 */   protected boolean emotionPlaying; protected final TimerUtility emotionTimer = new TimerUtility();
/* 33 */   private final TimerUtility timerUtility = new TimerUtility();
/*    */   
/*    */   public Emotion(LivingEntity player, long time) {
/* 36 */     this.player = player;
/* 37 */     this.time = time;
/* 38 */     this.emotionTimer.reset();
/* 39 */     this.emotionPlaying = true;
/* 40 */     this.emotionAnim.setForward(true);
/*    */   }
/*    */   
/*    */   public Emotion(LivingEntity player) {
/* 44 */     this(player, 2500L);
/*    */   }
/*    */   
/*    */   public void onEvent(Event event) {
/* 48 */     if (event instanceof fun.rockstarity.api.events.list.player.EventUpdate && this.emotionPlaying) {
/*    */       
/* 50 */       if (this.emotionTimer.passed(500L)) this.emotionAnim.setForward(true);
/*    */       
/* 52 */       if (this.emotionTimer.passed(this.time)) {
/* 53 */         this.emotionAnim.setForward(false);
/*    */ 
/*    */ 
/*    */         
/* 57 */         this.emotionPlaying = false;
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 62 */     if (event instanceof EventRenderEntity) { EventRenderEntity e = (EventRenderEntity)event; if (e.getEntity() == this.player && (!this.emotionAnim.finished(false) || this.emotionPlaying) && !(this instanceof fun.rockstarity.api.render.globals.emotions.instance.list.ConditionsEmotion)) {
/* 63 */         GlowESP.SILENT_RENDERING = e.isPre();
/*    */       } }
/*    */   
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean canAnimateHands() {
/* 71 */     return (!(this.player instanceof net.minecraft.client.entity.player.ClientPlayerEntity) || Minecraft.getInstance().getGameSettings().getPointOfView() != PointOfView.FIRST_PERSON);
/*    */   }
/*    */ 
/*    */   
/*    */   protected float moveProp(float originalOffset, float newOffset) {
/* 76 */     return MathUtility.interpolate(originalOffset, newOffset, this.emotionAnim.get());
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\globals\emotions\instance\Emotion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */