/*    */ package fun.rockstarity.api.render.globals.emotions;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmotionsPlayer
/*    */ {
/*    */   private final Emotions emotions;
/*    */   
/*    */   public EmotionsPlayer(Emotions emotions) {
/* 25 */     this.emotions = emotions;
/*    */   }
/*    */   
/*    */   public void onEvent(Event event) {
/*    */     // Byte code:
/*    */     //   0: aconst_null
/*    */     //   1: astore_2
/*    */     //   2: aload_0
/*    */     //   3: getfield emotions : Lfun/rockstarity/api/render/globals/emotions/Emotions;
/*    */     //   6: invokevirtual getActiveEmotions : ()Ljava/util/ArrayList;
/*    */     //   9: invokevirtual iterator : ()Ljava/util/Iterator;
/*    */     //   12: astore_3
/*    */     //   13: aload_3
/*    */     //   14: invokeinterface hasNext : ()Z
/*    */     //   19: ifeq -> 105
/*    */     //   22: aload_3
/*    */     //   23: invokeinterface next : ()Ljava/lang/Object;
/*    */     //   28: checkcast fun/rockstarity/api/render/globals/emotions/instance/Emotion
/*    */     //   31: astore #4
/*    */     //   33: aload #4
/*    */     //   35: invokevirtual getPlayer : ()Lnet/minecraft/entity/LivingEntity;
/*    */     //   38: astore #5
/*    */     //   40: aload_1
/*    */     //   41: instanceof fun/rockstarity/api/events/list/render/player/EventModels
/*    */     //   44: ifeq -> 63
/*    */     //   47: aload_1
/*    */     //   48: checkcast fun/rockstarity/api/events/list/render/player/EventModels
/*    */     //   51: astore #6
/*    */     //   53: aload #6
/*    */     //   55: invokevirtual getOwner : ()Lnet/minecraft/entity/LivingEntity;
/*    */     //   58: aload #5
/*    */     //   60: if_acmpne -> 69
/*    */     //   63: aload #4
/*    */     //   65: aload_1
/*    */     //   66: invokevirtual onEvent : (Lfun/rockstarity/api/events/Event;)V
/*    */     //   69: aload_1
/*    */     //   70: instanceof fun/rockstarity/api/events/list/player/EventUpdate
/*    */     //   73: ifeq -> 102
/*    */     //   76: aload #4
/*    */     //   78: invokevirtual getEmotionAnim : ()Lfun/rockstarity/api/render/animation/Animation;
/*    */     //   81: iconst_0
/*    */     //   82: invokevirtual finished : (Z)Z
/*    */     //   85: ifeq -> 102
/*    */     //   88: aload #4
/*    */     //   90: invokevirtual getEmotionAnim : ()Lfun/rockstarity/api/render/animation/Animation;
/*    */     //   93: invokevirtual isForward : ()Z
/*    */     //   96: ifne -> 102
/*    */     //   99: aload #4
/*    */     //   101: astore_2
/*    */     //   102: goto -> 13
/*    */     //   105: goto -> 109
/*    */     //   108: astore_3
/*    */     //   109: aload_1
/*    */     //   110: instanceof fun/rockstarity/api/events/list/player/EventUpdate
/*    */     //   113: ifeq -> 132
/*    */     //   116: aload_2
/*    */     //   117: ifnull -> 132
/*    */     //   120: aload_0
/*    */     //   121: getfield emotions : Lfun/rockstarity/api/render/globals/emotions/Emotions;
/*    */     //   124: invokevirtual getActiveEmotions : ()Ljava/util/ArrayList;
/*    */     //   127: aload_2
/*    */     //   128: invokevirtual remove : (Ljava/lang/Object;)Z
/*    */     //   131: pop
/*    */     //   132: return
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #29	-> 0
/*    */     //   #32	-> 2
/*    */     //   #33	-> 33
/*    */     //   #35	-> 40
/*    */     //   #36	-> 63
/*    */     //   #39	-> 69
/*    */     //   #40	-> 76
/*    */     //   #41	-> 99
/*    */     //   #43	-> 102
/*    */     //   #46	-> 105
/*    */     //   #44	-> 108
/*    */     //   #48	-> 109
/*    */     //   #49	-> 120
/*    */     //   #51	-> 132
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   53	10	6	model	Lfun/rockstarity/api/events/list/render/player/EventModels;
/*    */     //   40	62	5	player	Lnet/minecraft/entity/LivingEntity;
/*    */     //   33	69	4	emotion	Lfun/rockstarity/api/render/globals/emotions/instance/Emotion;
/*    */     //   0	133	0	this	Lfun/rockstarity/api/render/globals/emotions/EmotionsPlayer;
/*    */     //   0	133	1	event	Lfun/rockstarity/api/events/Event;
/*    */     //   2	131	2	toRemove	Lfun/rockstarity/api/render/globals/emotions/instance/Emotion;
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   2	105	108	java/lang/Exception
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\globals\emotions\EmotionsPlayer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */