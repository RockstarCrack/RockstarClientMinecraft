/*    */ package fun.rockstarity.api.render.optimize.culling.util.cache;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ 
/*    */ public class ArrayOcclusionCache
/*    */   implements OcclusionCache {
/*    */   private final int reachX2;
/*    */   private final byte[] cache;
/*    */   private int positionKey;
/*    */   private int entry;
/*    */   private int offset;
/*    */   
/*    */   public ArrayOcclusionCache(int reach) {
/* 14 */     this.reachX2 = reach * 2;
/* 15 */     this.cache = new byte[this.reachX2 * this.reachX2 * this.reachX2 / 4];
/*    */   }
/*    */ 
/*    */   
/*    */   public void resetCache() {
/* 20 */     Arrays.fill(this.cache, (byte)0);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setVisible(int x, int y, int z) {
/* 25 */     this.positionKey = x + y * this.reachX2 + z * this.reachX2 * this.reachX2;
/* 26 */     this.entry = this.positionKey / 4;
/* 27 */     this.offset = this.positionKey % 4 * 2;
/* 28 */     this.cache[this.entry] = (byte)(this.cache[this.entry] | 1 << this.offset);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setHidden(int x, int y, int z) {
/* 33 */     this.positionKey = x + y * this.reachX2 + z * this.reachX2 * this.reachX2;
/* 34 */     this.entry = this.positionKey / 4;
/* 35 */     this.offset = this.positionKey % 4 * 2;
/* 36 */     this.cache[this.entry] = (byte)(this.cache[this.entry] | 1 << this.offset + 1);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getState(int x, int y, int z) {
/* 41 */     this.positionKey = x + y * this.reachX2 + z * this.reachX2 * this.reachX2;
/* 42 */     this.entry = this.positionKey / 4;
/* 43 */     this.offset = this.positionKey % 4 * 2;
/* 44 */     return this.cache[this.entry] >> this.offset & 0x3;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setLastVisible() {
/* 49 */     this.cache[this.entry] = (byte)(this.cache[this.entry] | 1 << this.offset);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setLastHidden() {
/* 54 */     this.cache[this.entry] = (byte)(this.cache[this.entry] | 1 << this.offset + 1);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\optimize\cullin\\util\cache\ArrayOcclusionCache.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */