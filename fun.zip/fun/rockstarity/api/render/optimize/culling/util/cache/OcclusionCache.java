package fun.rockstarity.api.render.optimize.culling.util.cache;

public interface OcclusionCache {
  void resetCache();
  
  void setVisible(int paramInt1, int paramInt2, int paramInt3);
  
  void setHidden(int paramInt1, int paramInt2, int paramInt3);
  
  int getState(int paramInt1, int paramInt2, int paramInt3);
  
  void setLastHidden();
  
  void setLastVisible();
}


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\optimize\cullin\\util\cache\OcclusionCache.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */