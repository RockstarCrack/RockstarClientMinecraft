package fun.rockstarity.api.render.optimize.culling.util;

import fun.rockstarity.api.render.optimize.culling.util.util.Vec3d;

public interface DataProvider {
  boolean prepareChunk(int paramInt1, int paramInt2);
  
  boolean isOpaqueFullCube(int paramInt1, int paramInt2, int paramInt3);
  
  default void cleanup() {}
  
  default void checkingPosition(Vec3d[] targetPoints, int size, Vec3d viewerPosition) {}
}


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\optimize\cullin\\util\DataProvider.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */