/*    */ package fun.rockstarity.api.render.optimize.culling.util.util;
/*    */ 
/*    */ public class Vec3d
/*    */ {
/*    */   public double x;
/*    */   public double y;
/*    */   public double z;
/*    */   
/*    */   public Vec3d(double x, double y, double z) {
/* 10 */     this.x = x;
/* 11 */     this.y = y;
/* 12 */     this.z = z;
/*    */   }
/*    */   
/*    */   public double getX() {
/* 16 */     return this.x;
/*    */   }
/*    */   
/*    */   public double getY() {
/* 20 */     return this.y;
/*    */   }
/*    */   
/*    */   public double getZ() {
/* 24 */     return this.z;
/*    */   }
/*    */   
/*    */   public void set(double x, double y, double z) {
/* 28 */     this.x = x;
/* 29 */     this.y = y;
/* 30 */     this.z = z;
/*    */   }
/*    */   
/*    */   public void setAdd(Vec3d vec, double x, double y, double z) {
/* 34 */     vec.x += x;
/* 35 */     vec.y += y;
/* 36 */     vec.z += z;
/*    */   }
/*    */   
/*    */   public Vec3d div(Vec3d rayDir) {
/* 40 */     this.x /= rayDir.x;
/* 41 */     this.z /= rayDir.z;
/* 42 */     this.y /= rayDir.y;
/* 43 */     return this;
/*    */   }
/*    */   
/*    */   public Vec3d normalize() {
/* 47 */     double mag = Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
/* 48 */     this.x /= mag;
/* 49 */     this.y /= mag;
/* 50 */     this.z /= mag;
/* 51 */     return this;
/*    */   }
/*    */   
/*    */   public boolean equals(Object other) {
/* 55 */     if (this == other) {
/* 56 */       return true;
/*    */     }
/* 58 */     if (!(other instanceof Vec3d)) {
/* 59 */       return false;
/*    */     }
/* 61 */     Vec3d vec3d = (Vec3d)other;
/* 62 */     if (Double.compare(vec3d.x, this.x) != 0) {
/* 63 */       return false;
/*    */     }
/* 65 */     if (Double.compare(vec3d.y, this.y) != 0) {
/* 66 */       return false;
/*    */     }
/* 68 */     return (Double.compare(vec3d.z, this.z) == 0);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 73 */     long l = Double.doubleToLongBits(this.x);
/* 74 */     int i = (int)(l ^ l >>> 32L);
/* 75 */     l = Double.doubleToLongBits(this.y);
/* 76 */     i = 31 * i + (int)(l ^ l >>> 32L);
/* 77 */     l = Double.doubleToLongBits(this.z);
/* 78 */     i = 31 * i + (int)(l ^ l >>> 32L);
/* 79 */     return i;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 84 */     return "(" + this.x + ", " + this.y + ", " + this.z + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\optimize\cullin\\uti\\util\Vec3d.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */