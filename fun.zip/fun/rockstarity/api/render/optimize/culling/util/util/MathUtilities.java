/*    */ package fun.rockstarity.api.render.optimize.culling.util.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MathUtilities
/*    */ {
/*    */   public static int floor(double d) {
/* 12 */     int i = (int)d;
/* 13 */     return (d < i) ? (i - 1) : i;
/*    */   }
/*    */   
/*    */   public static int fastFloor(double d) {
/* 17 */     return (int)(d + 1024.0D) - 1024;
/*    */   }
/*    */   
/*    */   public static int ceil(double d) {
/* 21 */     int i = (int)d;
/* 22 */     return (d > i) ? (i + 1) : i;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\optimize\cullin\\uti\\util\MathUtilities.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */