/*    */ package fun.rockstarity.api.render.optimize.culling.processor;
/*    */ 
/*    */ import fun.rockstarity.api.render.optimize.culling.util.DataProvider;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.world.ClientWorld;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ 
/*    */ public class Provider
/*    */   implements DataProvider {
/* 10 */   private final Minecraft client = Minecraft.getInstance();
/* 11 */   private ClientWorld world = null;
/*    */ 
/*    */   
/*    */   public boolean prepareChunk(int chunkX, int chunkZ) {
/* 15 */     this.world = this.client.world;
/* 16 */     return (this.world != null);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isOpaqueFullCube(int x, int y, int z) {
/* 21 */     BlockPos pos = new BlockPos(x, y, z);
/*    */ 
/*    */ 
/*    */     
/* 25 */     return this.world.getBlockState(pos).isSolid();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void cleanup() {
/* 31 */     this.world = null;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\optimize\culling\processor\Provider.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */