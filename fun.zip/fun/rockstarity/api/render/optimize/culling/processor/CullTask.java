/*     */ package fun.rockstarity.api.render.optimize.culling.processor;
/*     */ 
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.helpers.player.Player;
/*     */ import fun.rockstarity.api.helpers.render.PositionTracker;
/*     */ import fun.rockstarity.api.render.optimize.culling.util.OcclusionCullingInstance;
/*     */ import it.unimi.dsi.fastutil.objects.ObjectIterator;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Queue;
/*     */ import java.util.Set;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.particle.IParticleRenderType;
/*     */ import net.minecraft.client.particle.Particle;
/*     */ import net.minecraft.client.particle.ParticleManager;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityType;
/*     */ import net.minecraft.entity.item.ArmorStandEntity;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.tileentity.TileEntityType;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.vector.Vector3d;
/*     */ import net.minecraft.world.chunk.Chunk;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CullTask
/*     */   implements Runnable, IAccess
/*     */ {
/*     */   public boolean requestCull = false;
/*     */   public boolean disableEntityCulling = false;
/*     */   public boolean disableBlockEntityCulling = false;
/*     */   private final OcclusionCullingInstance culling;
/*  39 */   private final Minecraft client = Minecraft.getInstance();
/*  40 */   private final int sleepDelay = CullingConfig.sleepDelay;
/*  41 */   private final int hitboxLimit = CullingConfig.hitboxLimit;
/*     */   private final Set<TileEntityType<?>> blockEntityWhitelist;
/*     */   private final Set<EntityType<?>> entityWhistelist;
/*  44 */   public long lastTime = 0L;
/*     */ 
/*     */   
/*  47 */   private Vector3d lastPos = new Vector3d(0.0D, 0.0D, 0.0D);
/*  48 */   private Vector3d aabbMin = new Vector3d(0.0D, 0.0D, 0.0D);
/*  49 */   private Vector3d aabbMax = new Vector3d(0.0D, 0.0D, 0.0D);
/*     */ 
/*     */   
/*     */   public CullTask(OcclusionCullingInstance culling, Set<TileEntityType<?>> blockEntityWhitelist, Set<EntityType<?>> entityWhistelist) {
/*  53 */     this.culling = culling;
/*  54 */     this.blockEntityWhitelist = blockEntityWhitelist;
/*  55 */     this.entityWhistelist = entityWhistelist;
/*     */   }
/*     */ 
/*     */   
/*     */   public void run() {
/*  60 */     while (this.client.isRunning()) {
/*     */       try {
/*  62 */         Thread.sleep(this.sleepDelay);
/*     */         
/*  64 */         process();
/*  65 */       } catch (Exception e) {
/*  66 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*  69 */     System.out.println("Shutting down culling task!");
/*     */   }
/*     */   
/*     */   private void process() {
/*  73 */     if (Player.isInGame() && this.client.player.ticksExisted > 10) {
/*     */ 
/*     */       
/*  76 */       Vector3d cameraMC = this.client.gameRenderer.getActiveRenderInfo().getProjectedView();
/*     */       
/*  78 */       if (this.requestCull || cameraMC.x != this.lastPos.x || cameraMC.y != this.lastPos.y || cameraMC.z != this.lastPos.z) {
/*     */         
/*  80 */         long start = System.currentTimeMillis();
/*  81 */         this.requestCull = false;
/*  82 */         this.lastPos.set(cameraMC.x, cameraMC.y, cameraMC.z);
/*  83 */         Vector3d camera = this.lastPos;
/*  84 */         this.culling.resetCache();
/*  85 */         cullBlockEntities(cameraMC, camera);
/*  86 */         cullEntities(cameraMC, camera);
/*  87 */         cullParticles(cameraMC, camera);
/*     */         
/*  89 */         this.lastTime = System.currentTimeMillis() - start;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void cullParticles(Vector3d cameraMC, Vector3d camera) {
/*  96 */     Collection<IParticleRenderType> collection = ParticleManager.TYPES;
/*     */     
/*  98 */     for (IParticleRenderType iparticlerendertype : collection) {
/*     */       
/* 100 */       if (iparticlerendertype != IParticleRenderType.NO_RENDER) {
/*     */         
/* 102 */         if (mc.particles.byType.get(iparticlerendertype) == null)
/* 103 */           continue;  Iterator<Particle> iterable = ((Queue<Particle>)mc.particles.byType.get(iparticlerendertype)).iterator();
/*     */         
/* 105 */         if (iterable != null) {
/*     */           
/* 107 */           Particle cullable = null;
/* 108 */           while (iterable.hasNext()) {
/*     */             try {
/* 110 */               cullable = iterable.next();
/* 111 */             } catch (NullPointerException|java.util.ConcurrentModificationException|ArrayIndexOutOfBoundsException ex) {
/*     */               break;
/*     */             } 
/*     */ 
/*     */ 
/*     */             
/* 117 */             AxisAlignedBB boundingBox = cullable.getBoundingBox();
/* 118 */             if (boundingBox.getXSize() > this.hitboxLimit || boundingBox.getYSize() > this.hitboxLimit || boundingBox
/* 119 */               .getZSize() > this.hitboxLimit) {
/* 120 */               cullable.setCulled(false);
/*     */               
/*     */               continue;
/*     */             } 
/* 124 */             this.aabbMin.set(boundingBox.minX, boundingBox.minY, boundingBox.minZ);
/* 125 */             this.aabbMax.set(boundingBox.maxX, boundingBox.maxY, boundingBox.maxZ);
/* 126 */             boolean visible = this.culling.isAABBVisible(this.aabbMin, this.aabbMax, camera);
/* 127 */             cullable.setCulled(!visible);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void cullChunks(Vector3d cameraMC, Vector3d camera) {
/* 135 */     for (int x = -8; x <= 8; x++) {
/* 136 */       for (int z = -8; z <= 8; z++) {
/* 137 */         int chunkX = this.client.player.chunkCoordX + x;
/* 138 */         int chunkZ = this.client.player.chunkCoordZ + z;
/*     */         
/* 140 */         Chunk chunk = this.client.world.getChunk(chunkX, chunkZ);
/*     */         
/* 142 */         float height = chunk.getHeight();
/*     */         
/* 144 */         AxisAlignedBB boundingBox = new AxisAlignedBB((chunkX * 16), 0.0D, (chunkZ * 16), (chunkX * 16 + 16), height, (chunkZ * 16 + 16));
/*     */         
/* 146 */         if (!PositionTracker.isInView(boundingBox)) {
/* 147 */           chunk.setCulled(true);
/*     */         }
/*     */         
/* 150 */         this.aabbMin.set(boundingBox.minX, boundingBox.minY, boundingBox.minZ);
/* 151 */         this.aabbMax.set(boundingBox.maxX, boundingBox.maxY, boundingBox.maxZ);
/*     */         
/* 153 */         boolean visible = this.culling.isAABBVisible(this.aabbMin, this.aabbMax, camera);
/* 154 */         chunk.setCulled(!visible);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void cullEntities(Vector3d cameraMC, Vector3d camera) {
/* 160 */     if (this.disableEntityCulling) {
/*     */       return;
/*     */     }
/* 163 */     Entity entity = null;
/* 164 */     ObjectIterator<Entity> objectIterator = this.client.world.getAllEntities().iterator();
/* 165 */     while (objectIterator.hasNext()) {
/*     */       try {
/* 167 */         entity = objectIterator.next();
/* 168 */       } catch (NullPointerException|java.util.ConcurrentModificationException|ArrayIndexOutOfBoundsException ex) {
/*     */         break;
/*     */       } 
/*     */ 
/*     */       
/* 173 */       if (entity == null) {
/*     */         break;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 182 */       if (this.entityWhistelist.contains(entity.getType())) {
/*     */         continue;
/*     */       }
/* 185 */       Entity cullable = entity;
/* 186 */       if (mc.isEntityGlowing(entity) || isSkippableArmorstand(entity)) {
/* 187 */         cullable.setCulled(false);
/*     */         continue;
/*     */       } 
/* 190 */       if (entity.getPositionVec().distanceTo(cameraMC) > CullingConfig.tracingDistance) {
/* 191 */         cullable.setCulled(false);
/*     */         
/*     */         continue;
/*     */       } 
/* 195 */       AxisAlignedBB boundingBox = entity.getRenderBoundingBox();
/* 196 */       if (boundingBox.getXSize() > this.hitboxLimit || boundingBox.getYSize() > this.hitboxLimit || boundingBox
/* 197 */         .getZSize() > this.hitboxLimit) {
/* 198 */         cullable.setCulled(false);
/*     */         
/*     */         continue;
/*     */       } 
/* 202 */       this.aabbMin.set(boundingBox.minX, boundingBox.minY, boundingBox.minZ);
/* 203 */       this.aabbMax.set(boundingBox.maxX, boundingBox.maxY, boundingBox.maxZ);
/* 204 */       boolean visible = this.culling.isAABBVisible(this.aabbMin, this.aabbMax, camera);
/* 205 */       cullable.setCulled(!visible);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void cullBlockEntities(Vector3d cameraMC, Vector3d camera) {
/* 212 */     if (this.disableBlockEntityCulling || mc.world == null) {
/*     */       return;
/*     */     }
/* 215 */     for (int x = -8; x <= 8; x++) {
/* 216 */       for (int z = -8; z <= 8; z++) {
/* 217 */         Chunk chunk = this.client.world.getChunk(this.client.player.chunkCoordX + x, this.client.player.chunkCoordZ + z);
/*     */         
/* 219 */         Iterator<Map.Entry<BlockPos, TileEntity>> iterator = chunk.getTileEntityMap().entrySet().iterator();
/*     */         
/* 221 */         while (iterator.hasNext()) {
/*     */           Map.Entry<BlockPos, TileEntity> entry; try {
/* 223 */             entry = iterator.next();
/* 224 */           } catch (NullPointerException|java.util.ConcurrentModificationException ex) {
/*     */             break;
/*     */           } 
/*     */ 
/*     */           
/* 229 */           if (entry == null) {
/*     */             break;
/*     */           }
/*     */ 
/*     */           
/* 234 */           if (this.blockEntityWhitelist.contains(((TileEntity)entry.getValue()).getType())) {
/*     */             continue;
/*     */           }
/* 237 */           TileEntity cullable = entry.getValue();
/* 238 */           if (!cullable.isForcedVisible()) {
/* 239 */             BlockPos pos = entry.getKey();
/* 240 */             if (closerThan(pos, cameraMC, 64.0D)) {
/* 241 */               AxisAlignedBB boundingBox = new AxisAlignedBB(pos);
/* 242 */               if (boundingBox.getXSize() > this.hitboxLimit || boundingBox.getYSize() > this.hitboxLimit || boundingBox
/* 243 */                 .getZSize() > this.hitboxLimit) {
/* 244 */                 cullable.setCulled(false);
/*     */                 continue;
/*     */               } 
/* 247 */               this.aabbMin.set(boundingBox.minX, boundingBox.minY, boundingBox.minZ);
/* 248 */               this.aabbMax.set(boundingBox.maxX, boundingBox.maxY, boundingBox.maxZ);
/* 249 */               boolean visible = this.culling.isAABBVisible(this.aabbMin, this.aabbMax, camera);
/* 250 */               cullable.setCulled(!visible);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isSkippableArmorstand(Entity entity) {
/* 260 */     if (entity instanceof ArmorStandEntity) { ArmorStandEntity ent = (ArmorStandEntity)entity; if (ent.isInvisible()); }  return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean closerThan(BlockPos blockPos, Vector3d vector3d, double d) {
/* 265 */     return (distSqr(blockPos, vector3d.x, vector3d.y, vector3d.z, true) < d * d);
/*     */   }
/*     */   
/*     */   private static double distSqr(BlockPos blockPos, double d, double e, double f, boolean bl) {
/* 269 */     double g = bl ? 0.5D : 0.0D;
/* 270 */     double h = blockPos.getX() + g - d;
/* 271 */     double i = blockPos.getY() + g - e;
/* 272 */     double j = blockPos.getZ() + g - f;
/* 273 */     return h * h + i * i + j * j;
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\optimize\culling\processor\CullTask.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */