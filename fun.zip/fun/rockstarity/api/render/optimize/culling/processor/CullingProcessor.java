/*    */ package fun.rockstarity.api.render.optimize.culling.processor;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.render.optimize.culling.util.OcclusionCullingInstance;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import java.util.function.Function;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityType;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.tileentity.TileEntityType;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CullingProcessor
/*    */ {
/*    */   private CullingProcessor() {
/* 29 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*    */   }
/* 31 */   public static final Logger LOGGER = LogManager.getLogger("EntityCulling");
/*    */   protected static Thread cullThread;
/*    */   public static CullTask cullTask;
/*    */   public static OcclusionCullingInstance culling;
/* 35 */   private static Set<Function<TileEntity, Boolean>> dynamicBlockEntityWhitelist = new HashSet<>();
/* 36 */   private static Set<Function<Entity, Boolean>> dynamicEntityWhitelist = new HashSet<>();
/* 37 */   public static Set<TileEntityType<?>> blockEntityWhitelist = new HashSet<>();
/* 38 */   public static Set<EntityType<?>> entityWhistelist = new HashSet<>();
/* 39 */   public static Set<EntityType<?>> tickCullWhistelist = new HashSet<>();
/*    */   private static boolean lateInit;
/*    */   
/*    */   public static void init() {
/* 43 */     culling = new OcclusionCullingInstance(CullingConfig.tracingDistance, new Provider());
/* 44 */     cullTask = new CullTask(culling, blockEntityWhitelist, entityWhistelist);
/*    */     
/* 46 */     cullThread = new Thread(cullTask, "CullThread");
/* 47 */     cullThread.setUncaughtExceptionHandler((thread, ex) -> LOGGER.error("The CullingThread has crashed! Please report the following stacktrace!", ex));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void onEvent(Event event) {
/* 53 */     if (event instanceof fun.rockstarity.api.events.list.player.EventUpdate) {
/* 54 */       if (!lateInit) {
/* 55 */         cullThread.start();
/* 56 */         lateInit = true;
/*    */       } 
/*    */       
/* 59 */       cullTask.requestCull = true;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\optimize\culling\processor\CullingProcessor.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */