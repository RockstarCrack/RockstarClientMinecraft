/*    */ package fun.rockstarity.api.render.optimize.culling.processor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Culling
/*    */ {
/*    */   private boolean culled;
/*    */   private boolean prevCulled;
/* 12 */   private long lasttime = 0L; private boolean outOfCamera; public boolean isCulled() {
/* 13 */     return this.culled;
/*    */   }
/* 15 */   public boolean isPrevCulled() { return this.prevCulled; } public void setPrevCulled(boolean prevCulled) { this.prevCulled = prevCulled; }
/*    */   
/* 17 */   public boolean isOutOfCamera() { return this.outOfCamera; } public void setOutOfCamera(boolean outOfCamera) { this.outOfCamera = outOfCamera; }
/*    */ 
/*    */   
/*    */   public void setTimeout() {
/* 21 */     this.lasttime = System.currentTimeMillis() + 1000L;
/*    */   }
/*    */   
/*    */   public boolean isForcedVisible() {
/* 25 */     return (this.lasttime > System.currentTimeMillis());
/*    */   }
/*    */   
/*    */   public void setCulled(boolean value) {
/* 29 */     if (this.culled) {
/* 30 */       this.prevCulled = true;
/*    */     }
/* 32 */     this.culled = value;
/* 33 */     if (!value) {
/* 34 */       setTimeout();
/*    */     }
/*    */     
/* 37 */     if (!value)
/* 38 */       this.prevCulled = false; 
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\optimize\culling\processor\Culling.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */