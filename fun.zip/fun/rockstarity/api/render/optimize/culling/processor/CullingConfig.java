/*    */ package fun.rockstarity.api.render.optimize.culling.processor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CullingConfig
/*    */ {
/*    */   private CullingConfig() {
/* 11 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/* 12 */   } public static int tracingDistance = 128;
/*    */   public static boolean debugMode = false;
/* 14 */   public static int sleepDelay = 10;
/* 15 */   public static int hitboxLimit = 50;
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\optimize\culling\processor\CullingConfig.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */