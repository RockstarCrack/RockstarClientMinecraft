/*    */ package fun.rockstarity.api.render.shaders.blur;
/*    */ 
/*    */ public class GaussianKernel
/*    */ {
/*    */   private final int size;
/*    */   private final float[] kernel;
/*    */   
/*    */   public GaussianKernel(int size) {
/*  9 */     this.size = size;
/* 10 */     this.kernel = new float[size];
/*    */   }
/*    */   
/*    */   public void compute() {
/* 14 */     float sigma = this.size / 2.0F;
/* 15 */     float kernelSum = 0.0F; int i;
/* 16 */     for (i = 0; i < this.size; i++) {
/* 17 */       float multiplier = i / sigma;
/* 18 */       this.kernel[i] = 1.0F / Math.abs(sigma) * 2.5066283F * (float)Math.exp(-0.5D * multiplier * multiplier);
/* 19 */       kernelSum += (i > 0) ? (this.kernel[i] * 2.0F) : this.kernel[0];
/*    */     } 
/*    */     
/* 22 */     for (i = 0; i < this.size; i++) {
/* 23 */       this.kernel[i] = this.kernel[i] / kernelSum;
/*    */     }
/*    */   }
/*    */   
/*    */   public int getSize() {
/* 28 */     return this.size;
/*    */   }
/*    */   
/*    */   public float[] getKernel() {
/* 32 */     return this.kernel;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\blur\GaussianKernel.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */