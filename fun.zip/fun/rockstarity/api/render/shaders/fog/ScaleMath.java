/*    */ package fun.rockstarity.api.render.shaders.fog;
/*    */ 
/*    */ import fun.rockstarity.api.IAccess;
/*    */ 
/*    */ public final class ScaleMath implements IAccess {
/*    */   private ScaleMath() {
/*  7 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*    */   }
/*    */   private static final int SCALE = 2;
/*    */   public static void scalePre() {
/* 11 */     mc.gameRenderer.setupOverlayRendering(2);
/*    */   }
/*    */   
/*    */   public static void scalePost() {
/* 15 */     mc.gameRenderer.setupOverlayRendering();
/*    */   }
/*    */   
/*    */   public static Vector2d getMouse(double mouseX, double mouseY) {
/* 19 */     return new Vector2d(mouseX * mc.getMainWindow().getGuiScaleFactor() / 2.0D, mouseY * mc.getMainWindow().getGuiScaleFactor() / 2.0D);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\fog\ScaleMath.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */