/*    */ package fun.rockstarity.api.render.shaders.fog;
/*    */ 
/*    */ import fun.rockstarity.api.render.color.FixColor;
/*    */ import fun.rockstarity.api.render.color.themes.Style;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ColorWheel
/*    */ {
/*    */   public FixColor getColor4() {
/* 13 */     return this.color4; } public FixColor getColor3() { return this.color3; } public FixColor getColor2() { return this.color2; } public FixColor getColor1() { return this.color1; }
/*    */ 
/*    */   
/* 16 */   FixColor color1 = this.color2 = this.color3 = this.color4 = FixColor.BLACK; FixColor color2; FixColor color3;
/*    */   FixColor color4;
/*    */   
/*    */   public void update() {
/* 20 */     this.color1 = Style.getPoint(0);
/* 21 */     this.color2 = Style.getPoint(90);
/* 22 */     this.color3 = Style.getPoint(180);
/* 23 */     this.color4 = Style.getPoint(270);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\fog\ColorWheel.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */