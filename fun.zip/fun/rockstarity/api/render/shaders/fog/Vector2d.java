/*    */ package fun.rockstarity.api.render.shaders.fog;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Vector2d
/*    */ {
/*  7 */   public static final Vector2d ZERO = new Vector2d(0.0D, 0.0D);
/*  8 */   public static final Vector2d ONE = new Vector2d(1.0D, 1.0D);
/*  9 */   public static final Vector2d UNIT_X = new Vector2d(1.0D, 0.0D);
/* 10 */   public static final Vector2d NEGATIVE_UNIT_X = new Vector2d(-1.0D, 0.0D);
/* 11 */   public static final Vector2d UNIT_Y = new Vector2d(0.0D, 1.0D);
/* 12 */   public static final Vector2d NEGATIVE_UNIT_Y = new Vector2d(0.0D, -1.0D);
/* 13 */   public static final Vector2d MAX = new Vector2d(3.4028234663852886E38D, 3.4028234663852886E38D); public final double x;
/* 14 */   public static final Vector2d MIN = new Vector2d(1.401298464324817E-45D, 1.401298464324817E-45D); public final double y; public Vector2d withX(double x) {
/* 15 */     return (this.x == x) ? this : new Vector2d(x, this.y); } public Vector2d withY(double y) {
/* 16 */     return (this.y == y) ? this : new Vector2d(this.x, y);
/*    */   }
/*    */   
/*    */   public Vector2d(double xIn, double yIn) {
/* 20 */     this.x = xIn;
/* 21 */     this.y = yIn;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Vector2d other) {
/* 26 */     return (this.x == other.x && this.y == other.y);
/*    */   }
/*    */   
/*    */   public float distance(Vector2d other) {
/* 30 */     double dx = this.x - other.x;
/* 31 */     double dy = this.y - other.y;
/* 32 */     return (float)Math.sqrt(dx * dx + dy * dy);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\fog\Vector2d.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */