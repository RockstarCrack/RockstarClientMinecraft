/*     */ package fun.rockstarity.api.render.shaders.fog;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.client.shader.Framebuffer;
/*     */ import net.minecraft.util.math.vector.Matrix4f;
/*     */ 
/*     */ public class CustomFramebuffer
/*     */   extends Framebuffer
/*     */   implements IAccess
/*     */ {
/*     */   private boolean linear;
/*     */   
/*     */   public CustomFramebuffer(int width, int height, boolean useDepth) {
/*  17 */     super(width, height, useDepth, Minecraft.IS_RUNNING_ON_MAC);
/*     */   }
/*     */   
/*     */   public CustomFramebuffer(boolean useDepth) {
/*  21 */     super(1, 1, useDepth, Minecraft.IS_RUNNING_ON_MAC);
/*     */   }
/*     */   
/*     */   private static boolean resizeFramebuffer(CustomFramebuffer framebuffer) {
/*  25 */     if (needsNewFramebuffer(framebuffer)) {
/*  26 */       framebuffer.createBuffers(Math.max(mc.getMainWindow().getFramebufferWidth(), 1), Math.max(mc.getMainWindow().getFramebufferHeight(), 1), Minecraft.IS_RUNNING_ON_MAC);
/*  27 */       return true;
/*     */     } 
/*  29 */     return false;
/*     */   }
/*     */   
/*     */   public CustomFramebuffer setLinear() {
/*  33 */     this.linear = true;
/*  34 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFramebufferFilter(int framebufferFilterIn) {
/*  39 */     super.setFramebufferFilter(this.linear ? 9729 : framebufferFilterIn);
/*     */   }
/*     */   
/*     */   public void setup() {
/*  43 */     resizeFramebuffer(this);
/*  44 */     framebufferClear(Minecraft.IS_RUNNING_ON_MAC);
/*  45 */     bindFramebuffer(false);
/*     */   }
/*     */   
/*     */   public static void drawQuads(MatrixStack matrix, double x, double y, double width, double height) {
/*  49 */     Matrix4f matrix4f = matrix.getLast().getMatrix();
/*  50 */     BUILDER.begin(7, DefaultVertexFormats.POSITION_TEX);
/*  51 */     BUILDER.pos(matrix4f, (float)x, (float)y, 0.0F).tex(0.0F, 1.0F).endVertex();
/*  52 */     BUILDER.pos(matrix4f, (float)x, (float)(y + height), 0.0F).tex(0.0F, 0.0F).endVertex();
/*  53 */     BUILDER.pos(matrix4f, (float)(x + width), (float)(y + height), 0.0F).tex(1.0F, 0.0F).endVertex();
/*  54 */     BUILDER.pos(matrix4f, (float)(x + width), (float)y, 0.0F).tex(1.0F, 1.0F).endVertex();
/*  55 */     TESSELLATOR.draw();
/*     */   }
/*     */   
/*     */   public static void drawQuads(double x, double y, double width, double height) {
/*  59 */     BUILDER.begin(7, DefaultVertexFormats.POSITION_TEX);
/*  60 */     BUILDER.pos(x, y, 0.0D).tex(0.0F, 1.0F).endVertex();
/*  61 */     BUILDER.pos(x, y + height, 0.0D).tex(0.0F, 0.0F).endVertex();
/*  62 */     BUILDER.pos(x + width, y + height, 0.0D).tex(1.0F, 0.0F).endVertex();
/*  63 */     BUILDER.pos(x + width, y, 0.0D).tex(1.0F, 1.0F).endVertex();
/*  64 */     TESSELLATOR.draw();
/*     */   }
/*     */   
/*     */   public static void drawQuads(MatrixStack matrix) {
/*  68 */     Vector2d window = ScaleMath.getMouse(mc.getMainWindow().getScaledWidth(), mc.getMainWindow().getScaledHeight());
/*  69 */     double width = window.x;
/*  70 */     double height = window.y;
/*  71 */     drawQuads(matrix, 0.0D, 0.0D, width, height);
/*     */   }
/*     */   
/*     */   public static void drawQuads() {
/*  75 */     Vector2d window = ScaleMath.getMouse(mc.getMainWindow().getScaledWidth(), mc.getMainWindow().getScaledHeight());
/*  76 */     double width = window.x;
/*  77 */     double height = window.y;
/*  78 */     drawQuads(0.0D, 0.0D, width, height);
/*     */   }
/*     */   
/*     */   public static void drawQuads(MatrixStack matrix, double width, double height) {
/*  82 */     drawQuads(matrix, 0.0D, 0.0D, width, height);
/*     */   }
/*     */   
/*     */   public static void drawQuads(double width, double height) {
/*  86 */     drawQuads(0.0D, 0.0D, width, height);
/*     */   }
/*     */   
/*     */   public static void drawQuads(MatrixStack matrix, double x, double y, double width, double height, int color) {
/*  90 */     Matrix4f matrix4f = matrix.getLast().getMatrix();
/*  91 */     BUILDER.begin(7, DefaultVertexFormats.POSITION_COLOR_TEX);
/*  92 */     BUILDER.pos(matrix4f, (float)x, (float)y, 0.0F).color(color).tex(0.0F, 1.0F).endVertex();
/*  93 */     BUILDER.pos(matrix4f, (float)x, (float)(y + height), 0.0F).color(color).tex(0.0F, 0.0F).endVertex();
/*  94 */     BUILDER.pos(matrix4f, (float)(x + width), (float)(y + height), 0.0F).color(color).tex(1.0F, 0.0F).endVertex();
/*  95 */     BUILDER.pos(matrix4f, (float)(x + width), (float)y, 0.0F).color(color).tex(1.0F, 1.0F).endVertex();
/*  96 */     TESSELLATOR.draw();
/*     */   }
/*     */   
/*     */   public static void drawQuads(double x, double y, double width, double height, int color) {
/* 100 */     BUILDER.begin(7, DefaultVertexFormats.POSITION_COLOR_TEX);
/* 101 */     BUILDER.pos(x, y, 0.0D).color(color).tex(0.0F, 1.0F).endVertex();
/* 102 */     BUILDER.pos(x, y + height, 0.0D).color(color).tex(0.0F, 0.0F).endVertex();
/* 103 */     BUILDER.pos(x + width, y + height, 0.0D).color(color).tex(1.0F, 0.0F).endVertex();
/* 104 */     BUILDER.pos(x + width, y, 0.0D).color(color).tex(1.0F, 1.0F).endVertex();
/* 105 */     TESSELLATOR.draw();
/*     */   }
/*     */   
/*     */   public static void drawQuads(MatrixStack matrix, int color) {
/* 109 */     Vector2d window = ScaleMath.getMouse(mc.getMainWindow().getScaledWidth(), mc.getMainWindow().getScaledHeight());
/* 110 */     double width = window.x;
/* 111 */     double height = window.y;
/* 112 */     drawQuads(matrix, 0.0D, 0.0D, width, height, color);
/*     */   }
/*     */   
/*     */   public static void drawQuads(int color) {
/* 116 */     Vector2d window = ScaleMath.getMouse(mc.getMainWindow().getScaledWidth(), mc.getMainWindow().getScaledHeight());
/* 117 */     double width = window.x;
/* 118 */     double height = window.y;
/* 119 */     drawQuads(0.0D, 0.0D, width, height, color);
/*     */   }
/*     */   
/*     */   public static void drawQuads(MatrixStack matrix, double width, double height, int color) {
/* 123 */     drawQuads(matrix, 0.0D, 0.0D, width, height, color);
/*     */   }
/*     */   
/*     */   public static void drawQuads(double width, double height, int color) {
/* 127 */     drawQuads(0.0D, 0.0D, width, height, color);
/*     */   }
/*     */   
/*     */   public void draw() {
/* 131 */     bindFramebufferTexture();
/* 132 */     drawQuads();
/*     */   }
/*     */   
/*     */   public void draw(int color) {
/* 136 */     bindFramebufferTexture();
/* 137 */     drawQuads(color);
/*     */   }
/*     */   
/*     */   public void draw(Framebuffer framebuffer) {
/* 141 */     framebuffer.bindFramebufferTexture();
/* 142 */     drawQuads();
/*     */   }
/*     */   
/*     */   public void stop() {
/* 146 */     unbindFramebuffer();
/* 147 */     mc.getFramebuffer().bindFramebuffer(true);
/*     */   }
/*     */   
/*     */   public static CustomFramebuffer createFrameBuffer(CustomFramebuffer framebuffer) {
/* 151 */     return createFrameBuffer(framebuffer, false);
/*     */   }
/*     */   
/*     */   public static CustomFramebuffer createFrameBuffer(CustomFramebuffer framebuffer, boolean depth) {
/* 155 */     if (needsNewFramebuffer(framebuffer)) {
/* 156 */       if (framebuffer != null) {
/* 157 */         framebuffer.deleteFramebuffer();
/*     */       }
/* 159 */       return new CustomFramebuffer(mc.getMainWindow().getFramebufferWidth(), mc.getMainWindow().getFramebufferHeight(), depth);
/*     */     } 
/* 161 */     return framebuffer;
/*     */   }
/*     */   
/*     */   public static boolean needsNewFramebuffer(CustomFramebuffer framebuffer) {
/* 165 */     return (framebuffer == null || framebuffer.framebufferWidth != mc.getMainWindow().getFramebufferWidth() || framebuffer.framebufferHeight != mc.getMainWindow().getFramebufferHeight());
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\fog\CustomFramebuffer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */