/*    */ package fun.rockstarity.api.render.shaders.fog.depth;
/*    */ 
/*    */ import fun.rockstarity.api.helpers.render.ColorUtility;
/*    */ import fun.rockstarity.api.render.color.FixColor;
/*    */ import fun.rockstarity.api.render.shaders.fog.AbstractShader;
/*    */ import net.minecraft.client.shader.ShaderDefault;
/*    */ 
/*    */ public final class DepthShader
/*    */   extends AbstractShader {
/*    */   private ShaderDefault nearUniform;
/*    */   private ShaderDefault farUniform;
/*    */   private ShaderDefault distance;
/*    */   private ShaderDefault color1;
/*    */   private ShaderDefault color2;
/*    */   private ShaderDefault color3;
/*    */   private ShaderDefault color4;
/*    */   private ShaderDefault clientColor;
/*    */   private ShaderDefault saturation;
/*    */   
/*    */   public void saturation(float value) {
/* 21 */     this.saturation.set(value);
/*    */   }
/*    */   
/*    */   public void clientColor(boolean value) {
/* 25 */     this.clientColor.set(value ? 1.0F : 0.0F);
/*    */   }
/*    */   
/*    */   public void color1(FixColor color) {
/* 29 */     this.color1.set(ColorUtility.getRGBAFloat(color));
/*    */   }
/*    */   
/*    */   public void color2(FixColor color) {
/* 33 */     this.color2.set(ColorUtility.getRGBAFloat(color));
/*    */   }
/*    */   
/*    */   public void color3(FixColor color) {
/* 37 */     this.color3.set(ColorUtility.getRGBAFloat(color));
/*    */   }
/*    */   
/*    */   public void color4(FixColor color) {
/* 41 */     this.color4.set(ColorUtility.getRGBAFloat(color));
/*    */   }
/*    */   
/*    */   public void setNear(float value) {
/* 45 */     this.nearUniform.set(value);
/*    */   }
/*    */ 
/*    */   
/*    */   public void far(float value) {
/* 50 */     this.farUniform.set(value);
/*    */   }
/*    */   
/*    */   public void distance(float value) {
/* 54 */     this.distance.set(value);
/*    */   }
/*    */ 
/*    */   
/*    */   public void depthBuffer(int buffer) {
/* 59 */     this.shaderInstance.setSampler("depthTex", () -> buffer);
/*    */   }
/*    */   
/*    */   public void blurBuffer(int buffer) {
/* 63 */     this.shaderInstance.setSampler("blur", () -> buffer);
/*    */   }
/*    */   
/*    */   public void minecraftBuffer(int buffer) {
/* 67 */     this.shaderInstance.setSampler("minecraft", () -> buffer);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShaderName() {
/* 72 */     return "depth_shader";
/*    */   }
/*    */ 
/*    */   
/*    */   public AbstractShader.Shader shader() {
/* 77 */     return AbstractShader.Shader.DEPTH_SHADER;
/*    */   }
/*    */ 
/*    */   
/*    */   public void handleShaderLoad() {
/* 82 */     super.handleShaderLoad();
/* 83 */     this.nearUniform = this.shaderInstance.safeGetUniform("near");
/* 84 */     this.farUniform = this.shaderInstance.safeGetUniform("far");
/* 85 */     this.distance = this.shaderInstance.safeGetUniform("distance");
/* 86 */     this.color1 = this.shaderInstance.safeGetUniform("color1");
/* 87 */     this.color2 = this.shaderInstance.safeGetUniform("color2");
/* 88 */     this.color3 = this.shaderInstance.safeGetUniform("color3");
/* 89 */     this.color4 = this.shaderInstance.safeGetUniform("color4");
/* 90 */     this.clientColor = this.shaderInstance.safeGetUniform("clientColor");
/* 91 */     this.saturation = this.shaderInstance.safeGetUniform("saturation");
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\fog\depth\DepthShader.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */