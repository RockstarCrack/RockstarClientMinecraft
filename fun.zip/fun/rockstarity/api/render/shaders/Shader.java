/*     */ package fun.rockstarity.api.render.shaders;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.helpers.render.Render;
/*     */ import fun.rockstarity.api.helpers.system.FileUtility;
/*     */ import fun.rockstarity.api.secure.nativeapi.NativeHelper;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.nio.FloatBuffer;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.client.shader.Framebuffer;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import org.lwjgl.opengl.GL20;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Shader
/*     */   implements IAccess
/*     */ {
/*     */   public static boolean FLAT_RENDERER;
/*     */   private final int id;
/*     */   
/*     */   public int getId() {
/*  48 */     return this.id;
/*     */   }
/*     */   
/*     */   public Shader() {
/*  52 */     int program = GL20.glCreateProgram();
/*  53 */     GL20.glAttachShader(program, getShader());
/*  54 */     GL20.glAttachShader(program, getVertex());
/*  55 */     GL20.glLinkProgram(program);
/*  56 */     this.id = program;
/*     */   }
/*     */   
/*     */   public String getCode() {
/*  60 */     return "";
/*     */   }
/*     */   
/*     */   public void start() {
/*  64 */     GL20.glUseProgram(this.id);
/*     */   }
/*     */   
/*     */   public void finish() {
/*  68 */     GL20.glUseProgram(0);
/*     */   }
/*     */   
/*     */   public int getShader() {
/*  72 */     return compile(new ByteArrayInputStream(getCode().getBytes()), 35632);
/*     */   }
/*     */   
/*     */   private int compile(InputStream inputStream, int shaderType) {
/*  76 */     int shader = GL20.glCreateShader(shaderType);
/*  77 */     GL20.glShaderSource(shader, FileUtility.readInputStream(inputStream));
/*  78 */     GL20.glCompileShader(shader);
/*  79 */     return shader;
/*     */   }
/*     */   
/*     */   public int getVertex() {
/*  83 */     return compile(new ByteArrayInputStream((new String("#version 120\r\n\r\nvoid main() {\r\n    gl_TexCoord[0] = gl_MultiTexCoord0;\r\n    gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;\r\n}"))
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  90 */           .getBytes()), 35633);
/*     */   }
/*     */   
/*     */   public static void drawQuads(MatrixStack matrixStack, float width, float height) {
/*  94 */     drawQuads(matrixStack, 0.0F, 0.0F, width, height);
/*     */   }
/*     */   
/*     */   public static void drawQuads(MatrixStack matrixStack) {
/*  98 */     drawQuads(matrixStack, sr.getScaledWidth(), sr.getScaledHeight());
/*     */   }
/*     */   
/*     */   public static void drawQuads() {
/* 102 */     float width = sr.getScaledWidth();
/* 103 */     float height = sr.getScaledHeight();
/* 104 */     GL11.glBegin(7);
/* 105 */     GL11.glTexCoord2f(0.0F, 1.0F);
/* 106 */     GL11.glVertex2f(0.0F, 0.0F);
/* 107 */     GL11.glTexCoord2f(0.0F, 0.0F);
/* 108 */     GL11.glVertex2f(0.0F, height);
/* 109 */     GL11.glTexCoord2f(1.0F, 0.0F);
/* 110 */     GL11.glVertex2f(width, height);
/* 111 */     GL11.glTexCoord2f(1.0F, 1.0F);
/* 112 */     GL11.glVertex2f(width, 0.0F);
/* 113 */     GL11.glEnd();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void startFlat() {
/* 126 */     FLAT_RENDERER = true;
/*     */     
/* 128 */     GlStateManager.enableBlend();
/* 129 */     GL11.glBlendFunc(770, 771);
/* 130 */     Render.setAlphaLimit(0.0F);
/* 131 */     BUILDER.begin(7, DefaultVertexFormats.POSITION_TEX);
/*     */   }
/*     */   
/*     */   public static void drawQuads(MatrixStack matrixStack, float x, float y, float width, float height) {
/* 135 */     if (!FLAT_RENDERER) {
/* 136 */       BUILDER.begin(7, DefaultVertexFormats.POSITION_TEX);
/*     */     }
/*     */     
/* 139 */     BUILDER.pos(matrixStack.getLast().getMatrix(), x, y, 0.0F).tex(0.0F, 0.0F).endVertex();
/* 140 */     BUILDER.pos(matrixStack.getLast().getMatrix(), x, y + height, 0.0F).tex(0.0F, 1.0F).endVertex();
/* 141 */     BUILDER.pos(matrixStack.getLast().getMatrix(), x + width, y + height, 0.0F).tex(1.0F, 1.0F).endVertex();
/* 142 */     BUILDER.pos(matrixStack.getLast().getMatrix(), x + width, y, 0.0F).tex(1.0F, 0.0F).endVertex();
/*     */     
/* 144 */     if (!FLAT_RENDERER) {
/* 145 */       TESSELLATOR.draw();
/*     */     }
/*     */   }
/*     */   
/*     */   public static void endFlat() {
/* 150 */     if (!FLAT_RENDERER)
/*     */       return; 
/* 152 */     TESSELLATOR.draw();
/* 153 */     GlStateManager.disableBlend();
/*     */     
/* 155 */     FLAT_RENDERER = false;
/*     */   }
/*     */   
/*     */   public static void drawScaledQuads() {
/* 159 */     drawQuadsESP(0.0D, 0.0D, sr.getScaledWidth(), sr.getScaledHeight());
/*     */   }
/*     */   
/*     */   public static void drawQuadsESP(double x, double y, double width, double height) {
/* 163 */     GL11.glBegin(7);
/* 164 */     GL11.glTexCoord2f(0.0F, 0.0F);
/* 165 */     if ((mc.getGameSettings()).fullscreen || sr.getHeight() < 847) {
/* 166 */       GL11.glVertex2d(x, y + height);
/* 167 */       GL11.glTexCoord2f(1.0F, 0.0F);
/* 168 */       GL11.glVertex2d(x + width, y + height);
/*     */     } else {
/* 170 */       GL11.glVertex2d(x, y + height - 0.5D);
/* 171 */       GL11.glTexCoord2f(1.0F, 0.0F);
/* 172 */       GL11.glVertex2d(x + width, y + height - 0.5D);
/*     */     } 
/* 174 */     GL11.glTexCoord2f(1.0F, 1.0F);
/* 175 */     GL11.glVertex2d(x + width, y);
/* 176 */     GL11.glTexCoord2f(0.0F, 1.0F);
/* 177 */     GL11.glVertex2d(x, y);
/* 178 */     GL11.glEnd();
/*     */   }
/*     */   
/*     */   public void setFloatBuffer(String name, FloatBuffer floatBuffer) {
/* 182 */     int loc = GL20.glGetUniformLocation(this.id, name);
/* 183 */     GL20.glUniform1fv(loc, floatBuffer);
/*     */   }
/*     */   
/*     */   public void setInt(String name, int... args) {
/* 187 */     int loc = GL20.glGetUniformLocation(this.id, name);
/* 188 */     if (args.length > 1) { GL20.glUniform2i(loc, args[0], args[1]); }
/* 189 */     else { GL20.glUniform1i(loc, args[0]); }
/*     */   
/*     */   }
/*     */   public void setFloat(String name, float... args) {
/* 193 */     int loc = GL20.glGetUniformLocation(this.id, name);
/* 194 */     switch (args.length) {
/*     */       case 1:
/* 196 */         GL20.glUniform1f(loc, args[0]);
/*     */         break;
/*     */       case 2:
/* 199 */         GL20.glUniform2f(loc, args[0], args[1]);
/*     */         break;
/*     */       case 3:
/* 202 */         GL20.glUniform3f(loc, args[0], args[1], args[2]);
/*     */         break;
/*     */       case 4:
/* 205 */         GL20.glUniform4f(loc, args[0], args[1], args[2], args[3]);
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getInt(String name) {
/* 211 */     return GL20.glGetUniformLocation(this.id, name);
/*     */   }
/*     */   
/*     */   public int get(String name) {
/* 215 */     return GL20.glGetUniformLocation(this.id, name);
/*     */   }
/*     */   
/*     */   public String readShader(String name) {
/* 219 */     return NativeHelper.readShader(name);
/*     */   }
/*     */   
/*     */   public static Framebuffer createFrameBuffer(Framebuffer framebuffer) {
/* 223 */     return createFrameBuffer(framebuffer, false);
/*     */   }
/*     */   
/*     */   public static Framebuffer createFrameBuffer(Framebuffer framebuffer, boolean depth) {
/* 227 */     if (framebuffer == null) {
/* 228 */       return new Framebuffer(sr.getFramebufferWidth(), sr.getFramebufferHeight(), depth);
/*     */     }
/* 230 */     if (needsNewFramebuffer(framebuffer)) {
/* 231 */       framebuffer.resize(sr.getFramebufferWidth(), sr.getFramebufferHeight(), depth);
/*     */     }
/* 233 */     return framebuffer;
/*     */   }
/*     */   
/*     */   public static boolean needsNewFramebuffer(Framebuffer framebuffer) {
/* 237 */     return (framebuffer.framebufferWidth != sr.getFramebufferWidth() || framebuffer.framebufferHeight != sr.getFramebufferHeight());
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\Shader.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */