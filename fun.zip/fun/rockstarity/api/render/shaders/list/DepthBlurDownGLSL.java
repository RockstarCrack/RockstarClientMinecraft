/*    */ package fun.rockstarity.api.render.shaders.list;
/*    */ 
/*    */ import fun.rockstarity.api.render.shaders.Shader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DepthBlurDownGLSL
/*    */   extends Shader
/*    */ {
/* 25 */   public static final DepthBlurDownGLSL SHADER = new DepthBlurDownGLSL();
/*    */ 
/*    */   
/*    */   public String getCode() {
/* 29 */     return "#version 330 core\n\nin vec2 texCoord;\nout vec4 fragColor;\nuniform sampler2D inputTexture;\nuniform vec2 texelSize;\n\nvoid main() {\n    vec2 tc = texCoord;\n    vec2 dx = vec2(texelSize.x, 0.0);\n    vec2 dy = vec2(0.0, texelSize.y);\n\n\n    vec4 color = texture(inputTexture, tc) * 4.0 / 16.0;\n    color += texture(inputTexture, tc - dx) * 2.0 / 16.0;\n    color += texture(inputTexture, tc + dx) * 2.0 / 16.0;\n    color += texture(inputTexture, tc - dy) * 2.0 / 16.0;\n    color += texture(inputTexture, tc + dy) * 2.0 / 16.0;\n    color += texture(inputTexture, tc - dx - dy) * 1.0 / 16.0;\n    color += texture(inputTexture, tc - dx + dy) * 1.0 / 16.0;\n    color += texture(inputTexture, tc + dx - dy) * 1.0 / 16.0;\n    color += texture(inputTexture, tc + dx + dy) * 1.0 / 16.0;\n\n    fragColor = color;\n}\n";
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\list\DepthBlurDownGLSL.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */