/*    */ package fun.rockstarity.api.render.shaders.list;
/*    */ 
/*    */ import fun.rockstarity.api.render.shaders.Shader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DepthBlurUpGLSL
/*    */   extends Shader
/*    */ {
/* 25 */   public static final DepthBlurUpGLSL SHADER = new DepthBlurUpGLSL();
/*    */ 
/*    */   
/*    */   public String getCode() {
/* 29 */     return "#version 120\n\n// Uniforms\nuniform sampler2D colorTexture;  // The color texture of the scene\nuniform sampler2D depthTexture;  // The depth texture of the scene\nuniform vec2 texelSize;          // Size of a texel (1.0 / width, 1.0 / height)\nuniform float blurStrength;      // Strength of the blur effect\nuniform float focusDepth;        // Depth value where the scene is in focus\nuniform float blurDirection;     // Direction of the blur (e.g., 1.0 for up, -1.0 for down)\n\n// Varying variable for texture coordinates\nvarying vec2 uv;\n\nvoid main() {\n    // Sample the depth at the current pixel\n    float depth = texture2D(depthTexture, uv).r;\n\n    // Calculate the blur amount based on the difference from the focus depth\n    float blurAmount = abs(depth - focusDepth) * blurStrength;\n\n    // Clamp the blur amount to a reasonable range\n    blurAmount = clamp(blurAmount, 0.0, 1.0);\n\n    // Number of samples for the blur (e.g., 5 samples for a simple Gaussian blur)\n    const int sampleCount = 5;\n    float weights[sampleCount] = float[](0.0545, 0.2442, 0.4026, 0.2442, 0.0545);\n    float offsets[sampleCount] = float[](-2.0, -1.0, 0.0, 1.0, 2.0);\n\n    // Initialize the final color\n    vec4 finalColor = vec4(0.0);\n\n    // Perform the vertical blur\n    for (int i = 0; i < sampleCount; i++) {\n        // Calculate the offset in the vertical direction\n        vec2 offset = vec2(0.0, offsets[i] * blurAmount * blurDirection * texelSize.y);\n\n        // Sample the color texture at the offset position\n        vec4 sampleColor = texture2D(colorTexture, uv + offset);\n\n        // Accumulate the weighted sample\n        finalColor += sampleColor * weights[i];\n    }\n\n    // Output the final blurred color\n    gl_FragColor = finalColor;\n}\n";
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\list\DepthBlurUpGLSL.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */