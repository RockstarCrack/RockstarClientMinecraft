/*    */ package fun.rockstarity.api.render.shaders.list;
/*    */ 
/*    */ import fun.rockstarity.api.render.shaders.Shader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClientBloom
/*    */   extends Shader
/*    */ {
/*    */   public String getCode() {
/* 14 */     return readShader("clientbloom");
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\list\ClientBloom.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */