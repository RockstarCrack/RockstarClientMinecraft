/*     */ package fun.rockstarity.api.render.shaders.list;
/*     */ 
/*     */ import com.google.common.collect.Queues;
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import com.mojang.blaze3d.systems.IRenderCall;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.helpers.render.Stencil;
/*     */ import fun.rockstarity.api.render.shaders.Shader;
/*     */ import fun.rockstarity.api.render.shaders.blur.GaussianKernel;
/*     */ import java.nio.FloatBuffer;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.shader.Framebuffer;
/*     */ import org.lwjgl.BufferUtils;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlurNew
/*     */   extends Shader
/*     */   implements IAccess
/*     */ {
/*  36 */   private static final ConcurrentLinkedQueue<IRenderCall> renderQueue = Queues.newConcurrentLinkedQueue();
/*  37 */   private static final BlurNew blurShader = new BlurNew();
/*     */   
/*  39 */   private static Framebuffer framebuffer = new Framebuffer(1, 1, false, Minecraft.IS_RUNNING_ON_MAC);
/*     */   
/*     */   public static void setupUniforms(float dir1, float dir2, float radius) {
/*  42 */     blurShader.setInt("textureIn", new int[] { 0 });
/*  43 */     blurShader.setFloat("texelSize", new float[] { 1.0F / sr.getFramebufferWidth(), 1.0F / sr
/*  44 */           .getFramebufferHeight() });
/*  45 */     blurShader.setFloat("direction", new float[] { dir1, dir2 });
/*  46 */     blurShader.setFloat("radius", new float[] { radius });
/*     */     
/*  48 */     GaussianKernel gaussianKernel = new GaussianKernel((int)radius);
/*  49 */     gaussianKernel.compute();
/*     */     
/*  51 */     FloatBuffer buffer = BufferUtils.createFloatBuffer((int)radius);
/*  52 */     buffer.put(gaussianKernel.getKernel());
/*  53 */     buffer.flip();
/*  54 */     RenderSystem.glUniform1(blurShader.get("weights"), buffer);
/*     */   }
/*     */   
/*     */   public static void registerRenderCall(IRenderCall rc) {
/*  58 */     renderQueue.add(rc);
/*     */   }
/*     */   
/*     */   public static void draw(int radius) {
/*  62 */     if (renderQueue.isEmpty())
/*     */       return; 
/*  64 */     Stencil.init();
/*  65 */     while (!renderQueue.isEmpty()) {
/*  66 */       ((IRenderCall)renderQueue.poll()).execute();
/*     */     }
/*  68 */     Stencil.read(1);
/*  69 */     renderBlur(radius);
/*  70 */     Stencil.finish();
/*     */   }
/*     */   
/*     */   public static void renderBlur(float radius) {
/*  74 */     GlStateManager.enableBlend();
/*  75 */     GlStateManager.color4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  76 */     GlStateManager.blendFunc(770, 771);
/*     */     
/*  78 */     framebuffer = createFrameBuffer(framebuffer);
/*     */     
/*  80 */     if (framebuffer != null) {
/*  81 */       framebuffer.framebufferClear(Minecraft.IS_RUNNING_ON_MAC);
/*  82 */       framebuffer.bindFramebuffer(true);
/*  83 */       blurShader.start();
/*  84 */       setupUniforms(1.0F, 0.0F, radius);
/*     */       
/*  86 */       GL11.glBindTexture(3553, (mc.getFramebuffer()).framebufferTexture);
/*     */       
/*  88 */       Shader.drawQuads();
/*  89 */       framebuffer.unbindFramebuffer();
/*  90 */       blurShader.finish();
/*     */       
/*  92 */       mc.getFramebuffer().bindFramebuffer(true);
/*  93 */       blurShader.start();
/*  94 */       setupUniforms(0.0F, 1.0F, radius);
/*     */       
/*  96 */       GL11.glBindTexture(3553, framebuffer.framebufferTexture);
/*  97 */       Shader.drawQuads();
/*  98 */       blurShader.finish();
/*     */     } 
/*     */     
/* 101 */     GL11.glColor4d(1.0D, 1.0D, 1.0D, 1.0D);
/* 102 */     GlStateManager.bindTexture(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCode() {
/* 107 */     return "#version 120\n\nuniform sampler2D textureIn;\nuniform vec2 texelSize, direction;\nuniform float radius;\nuniform float weights[256];\n\n#define offset texelSize * direction\n\nvoid main() {\n    vec3 blr = texture2D(textureIn, gl_TexCoord[0].st).rgb * weights[0];\n\n    for (float f = 1.0; f <= radius; f++) {\n        blr += texture2D(textureIn, gl_TexCoord[0].st + f * offset).rgb * (weights[int(abs(f))]);\n        blr += texture2D(textureIn, gl_TexCoord[0].st - f * offset).rgb * (weights[int(abs(f))]);\n    }\n\n    gl_FragColor = vec4(blr, 1.0);\n}\n\n";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Framebuffer createFrameBuffer(Framebuffer framebuffer) {
/* 133 */     if (framebuffer == null || framebuffer.framebufferWidth != sr.getFramebufferWidth() || framebuffer.framebufferHeight != sr.getFramebufferHeight()) {
/* 134 */       if (framebuffer != null) {
/* 135 */         framebuffer.deleteFramebuffer();
/*     */       }
/*     */       try {
/* 138 */         return new Framebuffer(sr.getFramebufferWidth(), sr.getFramebufferHeight(), true, Minecraft.IS_RUNNING_ON_MAC);
/* 139 */       } catch (Exception ex) {
/* 140 */         return null;
/*     */       } 
/*     */     } 
/* 143 */     return framebuffer;
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\list\BlurNew.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */