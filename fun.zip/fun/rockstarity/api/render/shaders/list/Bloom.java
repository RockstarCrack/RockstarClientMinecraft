/*     */ package fun.rockstarity.api.render.shaders.list;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.helpers.render.Render;
/*     */ import fun.rockstarity.api.render.shaders.Shader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.shader.Framebuffer;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import org.lwjgl.opengl.GL13;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Bloom
/*     */   implements IAccess
/*     */ {
/*  20 */   public static Shader kawaseDown = new Shader() { public String getCode() {
/*  21 */         return readShader("kawaseDownBloom");
/*     */       } }
/*  23 */   ; public static Shader kawaseUp = new Shader() { public String getCode() {
/*  24 */         return readShader("kawaseUpBloom");
/*     */       } }
/*     */   ;
/*  27 */   public static Framebuffer framebuffer = new Framebuffer(1, 1, false);
/*     */   
/*     */   private static int currentIterations;
/*     */   
/*  31 */   private static final List<Framebuffer> framebufferList = new ArrayList<>();
/*     */   
/*     */   private static void initFramebuffers(float iterations) {
/*  34 */     for (Framebuffer framebuffer : framebufferList) {
/*  35 */       framebuffer.deleteFramebuffer();
/*     */     }
/*  37 */     framebufferList.clear();
/*     */     
/*  39 */     framebufferList.add(Bloom.framebuffer = Shader.createFrameBuffer(null, true));
/*     */     
/*  41 */     for (int i = 1; i <= iterations; i++) {
/*  42 */       Framebuffer currentBuffer = new Framebuffer((int)(sr.getScaledWidth() / Math.pow(2.0D, i)), (int)(sr.getScaledHeight() / Math.pow(2.0D, i)), true);
/*  43 */       currentBuffer.setFramebufferFilter(9729);
/*     */       
/*  45 */       GlStateManager.bindTexture(currentBuffer.framebufferTexture);
/*  46 */       GL11.glTexParameteri(3553, 10242, 33648);
/*  47 */       GL11.glTexParameteri(3553, 10243, 33648);
/*  48 */       GlStateManager.bindTexture(0);
/*     */       
/*  50 */       framebufferList.add(currentBuffer);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void render(MatrixStack ms, int framebufferTexture, int iterations, int offset) {
/*  56 */     float off = (offset * 1);
/*     */     
/*  58 */     boolean can = false;
/*     */     
/*  60 */     if (mc.player.ticksExisted % 50 == 0 && can) {
/*  61 */       kawaseDown = new Shader() {
/*  62 */           public String getCode() { return readShader("kawaseDownBloom"); }
/*     */         };
/*  64 */       kawaseUp = new Shader() { public String getCode() {
/*  65 */             return readShader("kawaseUpBloom");
/*     */           } }
/*     */         ;
/*     */     } 
/*  69 */     if (currentIterations != iterations || framebuffer.framebufferWidth != sr.getFramebufferWidth() || framebuffer.framebufferHeight != sr.getFramebufferHeight()) {
/*  70 */       initFramebuffers(iterations);
/*  71 */       currentIterations = iterations;
/*     */     } 
/*     */     
/*  74 */     renderFBO(ms, framebufferList.get(1), framebufferTexture, kawaseDown, 0.1F);
/*     */     
/*     */     int i;
/*  77 */     for (i = 1; i < iterations; i++) {
/*  78 */       renderFBO(ms, framebufferList.get(i + 1), ((Framebuffer)framebufferList.get(i)).framebufferTexture, kawaseDown, 0.5F);
/*     */     }
/*     */ 
/*     */     
/*  82 */     for (i = iterations; i > 1; i--) {
/*  83 */       renderFBO(ms, framebufferList.get(i - 1), ((Framebuffer)framebufferList.get(i)).framebufferTexture, kawaseUp, 0.5F);
/*     */     }
/*     */     
/*  86 */     Framebuffer lastBuffer = framebufferList.get(0);
/*  87 */     lastBuffer.framebufferClear();
/*  88 */     lastBuffer.bindFramebuffer(false);
/*  89 */     kawaseUp.start();
/*  90 */     kawaseUp.setFloat("offset", new float[] { 0.1F, 0.1F });
/*  91 */     kawaseUp.setInt("inTexture", new int[] { 0 });
/*  92 */     kawaseUp.setInt("check", new int[] { 1 });
/*  93 */     kawaseUp.setInt("textureToCheck", new int[] { 16 });
/*  94 */     kawaseUp.setFloat("halfpixel", new float[] { 1.0F / lastBuffer.framebufferWidth, 1.0F / lastBuffer.framebufferHeight });
/*  95 */     kawaseUp.setFloat("iResolution", new float[] { lastBuffer.framebufferWidth, lastBuffer.framebufferHeight });
/*  96 */     GL13.glActiveTexture(34000);
/*  97 */     Render.bindTexture(framebufferTexture);
/*  98 */     GL13.glActiveTexture(33984);
/*  99 */     Render.bindTexture(((Framebuffer)framebufferList.get(1)).framebufferTexture);
/* 100 */     Shader.drawQuads(ms);
/* 101 */     kawaseUp.finish();
/*     */     
/* 103 */     mc.getFramebuffer().bindFramebuffer(true);
/* 104 */     Render.bindTexture(((Framebuffer)framebufferList.get(0)).framebufferTexture);
/* 105 */     Render.setAlphaLimit(0.0F);
/* 106 */     GlStateManager.enableBlend();
/* 107 */     Shader.drawQuads(ms);
/* 108 */     GlStateManager.bindTexture(0);
/*     */   }
/*     */   
/*     */   private static void renderFBO(MatrixStack ms, Framebuffer framebuffer, int framebufferTexture, Shader shader, float offset) {
/* 112 */     framebuffer.framebufferClear();
/* 113 */     framebuffer.bindFramebuffer(false);
/* 114 */     shader.start();
/* 115 */     Render.bindTexture(framebufferTexture);
/* 116 */     shader.setFloat("offset", new float[] { offset, offset });
/* 117 */     shader.setInt("inTexture", new int[] { 0 });
/* 118 */     shader.setInt("check", new int[] { 0 });
/* 119 */     shader.setFloat("halfpixel", new float[] { 1.0F / framebuffer.framebufferWidth, 1.0F / framebuffer.framebufferHeight });
/* 120 */     shader.setFloat("iResolution", new float[] { framebuffer.framebufferWidth, framebuffer.framebufferHeight });
/* 121 */     Shader.drawQuads(ms);
/* 122 */     shader.finish();
/*     */   }
/*     */   
/* 125 */   private static Framebuffer stencilFramebuffer = new Framebuffer(1, 1, false);
/*     */   
/*     */   public static void init() {
/* 128 */     stencilFramebuffer = Shader.createFrameBuffer(stencilFramebuffer);
/* 129 */     stencilFramebuffer.framebufferClear(false);
/* 130 */     stencilFramebuffer.bindFramebuffer(false);
/*     */   }
/*     */   
/*     */   public static void finish(MatrixStack ms, int shadow, int offset) {
/* 134 */     stencilFramebuffer.unbindFramebuffer();
/*     */     
/* 136 */     render(ms, stencilFramebuffer.framebufferTexture, shadow, offset);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\list\Bloom.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */