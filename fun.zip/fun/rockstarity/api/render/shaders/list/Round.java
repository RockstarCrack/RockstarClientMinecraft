/*     */ package fun.rockstarity.api.render.shaders.list;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import fun.rockstarity.api.helpers.render.Render;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.shaders.Shader;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import fun.rockstarity.api.secure.nativeapi.FastNative;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Round
/*     */   extends Shader
/*     */ {
/*  25 */   private static final Round shader = new Round();
/*  26 */   private static final Shader textured = new Shader()
/*     */     {
/*     */       public String getCode() {
/*  29 */         return "#version 120\n\nuniform sampler2D inTexture;\nuniform vec2 rectSize;\nuniform float radius;\nuniform float alpha;\n\nfloat roundedBox(vec2 center, vec2 size, float radius) {\n    vec2 q = abs(center) - size + radius;\n    return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - radius;\n}\n\nvoid main() {\n    vec2 uv = gl_TexCoord[0].st;\n    vec2 texCoord = uv * rectSize;\n    vec2 center = texCoord - rectSize / 2.0;\n\n    float distance = roundedBox(center, rectSize / 2.0, radius);\n    float mask = 1.0 - smoothstep(0.0, 1.0, distance);\n\n    vec4 texColor = texture2D(inTexture, uv);\n\n    gl_FragColor = vec4(texColor.rgb, texColor.a * alpha * mask);\n}\n\n";
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   private static final Shader outlined = new Shader()
/*     */     {
/*     */       public String getCode() {
/*  61 */         return readShader("roundOutline");
/*     */       }
/*     */     };
/*     */   
/*     */   public static void draw(MatrixStack matrixStack, Rect rect, float round, FixColor color) {
/*  66 */     draw(matrixStack, rect, round, color, color, color, color);
/*     */   }
/*     */   
/*     */   public static void draw(MatrixStack matrixStack, Rect rect, float topLeft, float topRight, float bottomLeft, float bottomRight, FixColor color) {
/*  70 */     draw(matrixStack, rect, topLeft, topRight, bottomLeft, bottomRight, color, color, color, color);
/*     */   }
/*     */   
/*     */   public static void draw(MatrixStack matrixStack, Rect rect, float round, FixColor gradientColor1, FixColor gradientColor2, FixColor gradientColor3, FixColor gradientColor4) {
/*  74 */     draw(matrixStack, rect, round, round, round, round, gradientColor1, gradientColor2, gradientColor3, gradientColor4);
/*     */   }
/*     */   
/*     */   public static void draw(MatrixStack matrixStack, Rect rect, float topLeft, float topRight, float bottomLeft, float bottomRight, FixColor gradientColor1, FixColor gradientColor2, FixColor gradientColor3, FixColor gradientColor4) {
/*  78 */     if (!Shader.FLAT_RENDERER) {
/*  79 */       GlStateManager.enableBlend();
/*  80 */       GL11.glBlendFunc(770, 771);
/*  81 */       Render.setAlphaLimit(0.0F);
/*     */     } 
/*     */     
/*  84 */     shader.start();
/*  85 */     int err = GL11.glGetError();
/*  86 */     if (err != 0) System.out.println("Error after shader.start(): " + err);
/*     */     
/*  88 */     shader.setFloat("size", new float[] { (float)(rect.getWidth() * sr.getGuiScaleFactor()), (float)(rect.getHeight() * sr.getGuiScaleFactor()) });
/*  89 */     shader.setFloat("gradientColor1", new float[] { gradientColor1.getRed() / 255.0F, gradientColor1.getGreen() / 255.0F, gradientColor1.getBlue() / 255.0F, gradientColor1.getAlpha() / 255.0F });
/*  90 */     shader.setFloat("gradientColor2", new float[] { gradientColor2.getRed() / 255.0F, gradientColor2.getGreen() / 255.0F, gradientColor2.getBlue() / 255.0F, gradientColor2.getAlpha() / 255.0F });
/*  91 */     shader.setFloat("gradientColor3", new float[] { gradientColor3.getRed() / 255.0F, gradientColor3.getGreen() / 255.0F, gradientColor3.getBlue() / 255.0F, gradientColor3.getAlpha() / 255.0F });
/*  92 */     shader.setFloat("gradientColor4", new float[] { gradientColor4.getRed() / 255.0F, gradientColor4.getGreen() / 255.0F, gradientColor4.getBlue() / 255.0F, gradientColor4.getAlpha() / 255.0F });
/*  93 */     shader.setFloat("cornerRadius", new float[] { (float)(topLeft * sr.getGuiScaleFactor()), (float)(bottomLeft * sr.getGuiScaleFactor()), (float)(topRight * sr.getGuiScaleFactor()), (float)(bottomRight * sr.getGuiScaleFactor()) });
/*  94 */     drawQuads(matrixStack, rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight());
/*  95 */     shader.finish();
/*  96 */     err = GL11.glGetError();
/*  97 */     if (err != 0) System.out.println("Error after shader.finish(): " + err);
/*     */     
/*  99 */     if (!Shader.FLAT_RENDERER) {
/* 100 */       GlStateManager.disableBlend();
/*     */     }
/*     */   }
/*     */   
/*     */   public static void drawTextured(MatrixStack matrixStack, String texture, Rect rect, float round, float alpha) {
/* 105 */     mc.getTextureManager().bindTexture(FastNative.getImageResource(texture));
/*     */     
/* 107 */     GlStateManager.enableBlend();
/* 108 */     GL11.glBlendFunc(770, 771);
/* 109 */     Render.setAlphaLimit(0.0F);
/*     */     
/* 111 */     textured.start();
/* 112 */     textured.setFloat("rectSize", new float[] { (float)(rect.getWidth() * sr.getGuiScaleFactor()), (float)(rect.getHeight() * sr.getGuiScaleFactor()) });
/* 113 */     textured.setInt("inTexture", new int[] { 0 });
/* 114 */     textured.setFloat("alpha", new float[] { alpha });
/* 115 */     textured.setFloat("radius", new float[] { (float)(round * sr.getGuiScaleFactor()) });
/* 116 */     drawQuads(matrixStack, rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight());
/* 117 */     textured.finish();
/*     */     
/* 119 */     GlStateManager.disableBlend();
/*     */   }
/*     */   
/*     */   public static void drawTextured(MatrixStack matrixStack, Rect rect, float round, float alpha) {
/* 123 */     GlStateManager.enableBlend();
/* 124 */     GL11.glBlendFunc(770, 771);
/* 125 */     Render.setAlphaLimit(0.0F);
/*     */     
/* 127 */     textured.start();
/* 128 */     textured.setFloat("rectSize", new float[] { (float)(rect.getWidth() * sr.getGuiScaleFactor()), (float)(rect.getHeight() * sr.getGuiScaleFactor()) });
/* 129 */     textured.setInt("inTexture", new int[] { 0 });
/* 130 */     textured.setFloat("alpha", new float[] { alpha });
/* 131 */     textured.setFloat("radius", new float[] { (float)(round * sr.getGuiScaleFactor()) });
/* 132 */     drawQuads(matrixStack, rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight());
/* 133 */     textured.finish();
/*     */     
/* 135 */     GlStateManager.disableBlend();
/*     */   }
/*     */   
/*     */   public static void drawOutlined(MatrixStack matrixStack, Rect rect, float round, float outline, FixColor color, FixColor outlineColor) {
/* 139 */     drawOutlined(matrixStack, rect, round, outline, color, outlineColor, false);
/*     */   }
/*     */   
/*     */   public static void drawOutlined(MatrixStack matrixStack, Rect rect, float round, float outline, FixColor color, FixColor outlineColor, boolean inner) {
/* 143 */     GlStateManager.enableBlend();
/* 144 */     GL11.glBlendFunc(770, 771);
/* 145 */     Render.setAlphaLimit(0.0F);
/*     */     
/* 147 */     outlined.start();
/* 148 */     outlined.setFloat("rectSize", new float[] { (float)(rect.getWidth() * sr.getGuiScaleFactor()), (float)(rect.getHeight() * sr.getGuiScaleFactor()) });
/* 149 */     outlined.setFloat("color", new float[] { color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F });
/* 150 */     outlined.setFloat("outlineColor", new float[] { outlineColor.getRed() / 255.0F, outlineColor.getGreen() / 255.0F, outlineColor.getBlue() / 255.0F, outlineColor.getAlpha() / 255.0F });
/* 151 */     outlined.setFloat("radius", new float[] { (float)(round * sr.getGuiScaleFactor()) });
/* 152 */     if (inner) {
/* 153 */       drawQuads(matrixStack, rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight());
/*     */     } else {
/* 155 */       drawQuads(matrixStack, rect.getX() - outline, rect.getY() - outline, rect.getWidth() + outline * 2.0F, rect.getHeight() + outline * 2.0F);
/*     */     } 
/* 157 */     outlined.finish();
/*     */     
/* 159 */     GlStateManager.disableBlend();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCode() {
/* 165 */     return "#version 120\n\nuniform vec4 gradientColor1;\nuniform vec4 gradientColor2;\nuniform vec4 gradientColor3;\nuniform vec4 gradientColor4;\n\nuniform vec2 size;\nuniform vec4 cornerRadius;\n\nfloat roundedBox(vec2 center, vec2 size, vec4 radius) {\n    radius.xy = (center.x > 0.0) ? radius.xy : radius.zw;\n    radius.x  = (center.y > 0.0) ? radius.x : radius.y;\n\n    vec2 q = abs(center) - size + radius.x;\n    return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - radius.x;\n}\n\nvec4 createGradient(vec2 pos) {\n    return mix(mix(gradientColor1, gradientColor2, pos.y), mix(gradientColor3, gradientColor4, pos.y), pos.x);\n}\n\nvoid main() {\n    vec2 texCoord = gl_TexCoord[0].st * size;\n    vec2 halfSize = size / 2.0;\n\n    // Box with constant border (value = 0), no soft edges\n    float distance = roundedBox(texCoord - halfSize, halfSize, cornerRadius);\n\n    float edgeSmooth = 1.0 - smoothstep(0.0, 1.0, distance); // You can parametrize this later\n\n    vec4 gradient = createGradient(gl_TexCoord[0].st);\n\n    gl_FragColor = vec4(gradient.rgb, gradient.a * edgeSmooth);\n}\n\n";
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\list\Round.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */