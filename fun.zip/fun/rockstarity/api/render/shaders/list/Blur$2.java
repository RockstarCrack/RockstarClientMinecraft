/*    */ package fun.rockstarity.api.render.shaders.list;
/*    */ 
/*    */ import fun.rockstarity.api.render.shaders.Shader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends Shader
/*    */ {
/*    */   public String getCode() {
/* 60 */     return "#version 330 core\n\nin vec2 texCoord;\nout vec4 fragColor;\n\nuniform sampler2D inTexture;\nuniform vec2 halfpixel;\nuniform vec2 offset;\n\nvoid main() {\n    vec2 uv = texCoord;\n    vec4 sum = texture(inTexture, uv) * 4.0;\n    sum += texture(inTexture, uv - halfpixel * offset.x);\n    sum += texture(inTexture, uv + halfpixel * offset.x);\n    sum += texture(inTexture, uv + vec2(halfpixel.x, -halfpixel.y) * offset.x);\n    sum += texture(inTexture, uv - vec2(halfpixel.x, -halfpixel.y) * offset.x);\n    fragColor = sum / 8.0;\n}\n";
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\list\Blur$2.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */