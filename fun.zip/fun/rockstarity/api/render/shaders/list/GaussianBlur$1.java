/*    */ package fun.rockstarity.api.render.shaders.list;
/*    */ 
/*    */ import fun.rockstarity.api.render.shaders.Shader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends Shader
/*    */ {
/*    */   public String getCode() {
/* 31 */     return "#version 120\n\nuniform sampler2D u_diffuse_sampler;\nuniform sampler2D u_other_sampler;\nuniform vec2 u_texel_size;\nuniform vec2 u_direction;\nuniform float u_radius;\nuniform float u_kernel[128];\n\nvoid main()\n{\n    vec2 uv = gl_TexCoord[0].st;\n\n    float alpha = texture2D(u_other_sampler, uv).a;\n    if (u_direction.x == 0.0 && alpha == 0.0) {\n        discard;\n    }\n\n    float half_radius = u_radius / 2.0;\n    vec4 pixel_color = texture2D(u_diffuse_sampler, uv) * u_kernel[0];\n\n    for (float f = 1; f <= u_radius; f++) {\n        vec2 offset = f * u_texel_size * u_direction;\n        pixel_color += texture2D(u_diffuse_sampler, uv - offset) * u_kernel[int(f)];\n        pixel_color += texture2D(u_diffuse_sampler, uv + offset) * u_kernel[int(f)];\n    }\n\n    gl_FragColor = vec4(pixel_color.rgb, u_direction.x == 0.0 ? alpha : 1.0);\n}\n";
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\list\GaussianBlur$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */