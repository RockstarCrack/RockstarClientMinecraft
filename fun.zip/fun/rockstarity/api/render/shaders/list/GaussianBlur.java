/*     */ package fun.rockstarity.api.render.shaders.list;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.shaders.Shader;
/*     */ import fun.rockstarity.api.render.shaders.blur.GaussianKernel;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import java.nio.FloatBuffer;
/*     */ import net.minecraft.client.shader.Framebuffer;
/*     */ import org.lwjgl.BufferUtils;
/*     */ import org.lwjgl.opengl.GL13;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GaussianBlur
/*     */   implements IAccess
/*     */ {
/*     */   private GaussianBlur() {
/*  28 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*     */   }
/*  30 */   private static Shader blurProgram = new Shader() { public String getCode() {
/*  31 */         return "#version 120\n\nuniform sampler2D u_diffuse_sampler;\nuniform sampler2D u_other_sampler;\nuniform vec2 u_texel_size;\nuniform vec2 u_direction;\nuniform float u_radius;\nuniform float u_kernel[128];\n\nvoid main()\n{\n    vec2 uv = gl_TexCoord[0].st;\n\n    float alpha = texture2D(u_other_sampler, uv).a;\n    if (u_direction.x == 0.0 && alpha == 0.0) {\n        discard;\n    }\n\n    float half_radius = u_radius / 2.0;\n    vec4 pixel_color = texture2D(u_diffuse_sampler, uv) * u_kernel[0];\n\n    for (float f = 1; f <= u_radius; f++) {\n        vec2 offset = f * u_texel_size * u_direction;\n        pixel_color += texture2D(u_diffuse_sampler, uv - offset) * u_kernel[int(f)];\n        pixel_color += texture2D(u_diffuse_sampler, uv + offset) * u_kernel[int(f)];\n    }\n\n    gl_FragColor = vec4(pixel_color.rgb, u_direction.x == 0.0 ? alpha : 1.0);\n}\n";
/*     */       } }
/*     */   ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   private static Framebuffer inputFramebuffer = new Framebuffer(sr.getFramebufferWidth(), sr.getFramebufferHeight(), true);
/*  65 */   private static Framebuffer outputFramebuffer = new Framebuffer(sr.getFramebufferWidth(), sr.getFramebufferHeight(), true);
/*  66 */   private static GaussianKernel gaussianKernel = new GaussianKernel(0);
/*     */   
/*     */   public static void start() {
/*  69 */     inputFramebuffer.bindFramebuffer(true);
/*     */   }
/*     */   
/*     */   public static void end() {
/*  73 */     end(8, 2.0F);
/*     */   }
/*     */   
/*     */   public static void end(int radius, float compression) {
/*  77 */     int programId = blurProgram.getId();
/*     */     
/*  79 */     outputFramebuffer.bindFramebuffer(true);
/*  80 */     blurProgram.start();
/*     */     
/*  82 */     if (gaussianKernel.getSize() != radius) {
/*  83 */       gaussianKernel = new GaussianKernel(radius);
/*  84 */       gaussianKernel.compute();
/*     */       
/*  86 */       FloatBuffer buffer = BufferUtils.createFloatBuffer(radius);
/*  87 */       buffer.put(gaussianKernel.getKernel());
/*  88 */       buffer.flip();
/*     */       
/*  90 */       blurProgram.setFloat("u_radius", new float[] { radius });
/*  91 */       blurProgram.setFloatBuffer("u_kernel", buffer);
/*  92 */       blurProgram.setInt("u_diffuse_sampler", new int[] { 0 });
/*  93 */       blurProgram.setInt("u_other_sampler", new int[] { 20 });
/*     */     } 
/*     */     
/*  96 */     blurProgram.setFloat("u_texel_size", new float[] { 1.0F / sr.getFramebufferWidth(), 1.0F / sr.getFramebufferHeight() });
/*  97 */     blurProgram.setFloat("u_direction", new float[] { compression, 0.0F });
/*     */     
/*  99 */     GlStateManager.enableBlend();
/* 100 */     GlStateManager.blendFuncSeparate(770, 771, 1, 0);
/* 101 */     GlStateManager.alphaFunc(516, 0.0F);
/* 102 */     mc.getFramebuffer().bindFramebufferTexture();
/* 103 */     Shader.drawQuads();
/*     */     
/* 105 */     mc.getFramebuffer().bindFramebuffer(true);
/* 106 */     blurProgram.setFloat("u_direction", new float[] { 0.0F, compression });
/* 107 */     outputFramebuffer.bindFramebufferTexture();
/* 108 */     GL13.glActiveTexture(34004);
/* 109 */     inputFramebuffer.bindFramebufferTexture();
/* 110 */     GL13.glActiveTexture(33984);
/* 111 */     Shader.drawQuads();
/* 112 */     GlStateManager.disableBlend();
/*     */     
/* 114 */     blurProgram.finish();
/*     */   }
/*     */   
/*     */   public static void draw(MatrixStack ms, int radius, float compression) {
/* 118 */     start();
/* 119 */     Round.draw(ms, new Rect(0.0F, 0.0F, sr.getScaledWidth(), sr.getScaledHeight()), 0.0F, FixColor.WHITE);
/* 120 */     end(radius, compression);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\list\GaussianBlur.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */