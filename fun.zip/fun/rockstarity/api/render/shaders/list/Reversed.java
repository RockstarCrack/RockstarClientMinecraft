/*    */ package fun.rockstarity.api.render.shaders.list;
/*    */ 
/*    */ import com.mojang.blaze3d.platform.GlStateManager;
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.helpers.render.ColorUtility;
/*    */ import fun.rockstarity.api.helpers.render.Render;
/*    */ import fun.rockstarity.api.render.color.FixColor;
/*    */ import fun.rockstarity.api.render.shaders.Shader;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import org.lwjgl.opengl.GL13;
/*    */ 
/*    */ 
/*    */ public class Reversed
/*    */   extends Shader
/*    */   implements IAccess
/*    */ {
/* 17 */   private static Reversed shader = new Reversed();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void render(FixColor color) {
/* 26 */     Render.resetColor();
/* 27 */     GlStateManager.enableBlend();
/* 28 */     GL11.glBlendFunc(770, 771);
/* 29 */     Render.setAlphaLimit(0.0F);
/*    */     
/* 31 */     GL13.glBindTexture(3553, (mc.getFramebuffer()).framebufferTexture);
/* 32 */     shader.start();
/* 33 */     shader.setInt("textureIn", new int[] { 0 });
/* 34 */     shader.setFloat("color", ColorUtility.getRGBAFloat(color));
/* 35 */     shader.setFloat("texelSize", new float[] { 1.0F / sr.getScaledWidth(), 1.0F / sr.getScaledHeight() });
/* 36 */     shader.setFloat("blurRadius", new float[] { 1.0F });
/*    */     
/* 38 */     Shader.drawQuads();
/* 39 */     shader.finish();
/*    */     
/* 41 */     GlStateManager.disableBlend();
/* 42 */     GlStateManager.bindTexture(0);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getCode() {
/* 47 */     return "            #version 120\n\n\n            uniform sampler2D textureIn;\n            uniform vec4 color;\n            uniform vec2 texelSize;\n            uniform float blurRadius;\n\n\n            varying vec2 uv;\n\n            void main() {\n\n                vec4 texColor = texture2D(textureIn, uv);\n\n\n                vec3 reversedColor = 1.0 - texColor.rgb;\n\n\n                vec3 finalColor = reversedColor * color.rgb;\n\n\n                if (blurRadius > 0.0) {\n                    vec4 blurredColor = vec4(0.0);\n                    float radius = floor(blurRadius);\n                    float divisor = 0.0;\n\n\n                    for (float x = -radius; x <= radius; x++) {\n                        for (float y = -radius; y <= radius; y++) {\n                            vec2 offset = vec2(x, y) * texelSize;\n                            blurredColor += texture2D(textureIn, uv + offset);\n                            divisor += 1.0;\n                        }\n                    }\n\n\n                    blurredColor /= divisor;\n\n                    finalColor = reversedColor * color.rgb * blurredColor.rgb;\n                }\n\n\n                gl_FragColor = vec4(finalColor, texColor.a);\n            }\n";
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\list\Reversed.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */