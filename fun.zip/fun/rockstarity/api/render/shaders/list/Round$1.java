/*    */ package fun.rockstarity.api.render.shaders.list;
/*    */ 
/*    */ import fun.rockstarity.api.render.shaders.Shader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends Shader
/*    */ {
/*    */   public String getCode() {
/* 29 */     return "#version 120\n\nuniform sampler2D inTexture;\nuniform vec2 rectSize;\nuniform float radius;\nuniform float alpha;\n\nfloat roundedBox(vec2 center, vec2 size, float radius) {\n    vec2 q = abs(center) - size + radius;\n    return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - radius;\n}\n\nvoid main() {\n    vec2 uv = gl_TexCoord[0].st;\n    vec2 texCoord = uv * rectSize;\n    vec2 center = texCoord - rectSize / 2.0;\n\n    float distance = roundedBox(center, rectSize / 2.0, radius);\n    float mask = 1.0 - smoothstep(0.0, 1.0, distance);\n\n    vec4 texColor = texture2D(inTexture, uv);\n\n    gl_FragColor = vec4(texColor.rgb, texColor.a * alpha * mask);\n}\n\n";
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\list\Round$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */