/*    */ package fun.rockstarity.api.render.shaders.list;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import com.mojang.blaze3d.platform.GlStateManager;
/*    */ import com.mojang.blaze3d.systems.RenderSystem;
/*    */ import fun.rockstarity.api.helpers.render.ColorUtility;
/*    */ import fun.rockstarity.api.helpers.render.Render;
/*    */ import fun.rockstarity.api.render.color.FixColor;
/*    */ import fun.rockstarity.api.render.shaders.Shader;
/*    */ import fun.rockstarity.api.render.ui.rect.Rect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Glow
/*    */   extends Shader
/*    */ {
/* 22 */   private static final Glow shader = new Glow();
/*    */   
/*    */   public static void draw(MatrixStack matrixStack, Rect rect, float radius, float alpha, float round, FixColor color1, FixColor color2, FixColor color3, FixColor color4) {
/* 25 */     draw(matrixStack, rect.size(-radius), true, alpha, radius * sr.getGuiScaleFactorF(), -radius, radius * sr.getGuiScaleFactorF(), round, color1, color2, color3, color4);
/*    */   }
/*    */   
/*    */   public static void draw(MatrixStack matrixStack, Rect rect, boolean shadow, float shadowAlpha, float value, float smoothness1, float smoothness2, float round, FixColor color1, FixColor color2, FixColor color3, FixColor color4) {
/* 29 */     Render.resetColor();
/* 30 */     GlStateManager.enableBlend();
/* 31 */     RenderSystem.blendFunc(770, 771);
/* 32 */     Render.setAlphaLimit(0.0F);
/*    */     
/* 34 */     shader.start();
/*    */     
/* 36 */     shader.setFloat("size", new float[] { (float)(rect.getWidth() * sr.getGuiScaleFactor()), (float)(rect.getHeight() * sr.getGuiScaleFactor()) });
/* 37 */     shader.setFloat("round", new float[] { round, round, round, round });
/* 38 */     shader.setFloat("smoothness", new float[] { smoothness1, smoothness2 });
/* 39 */     shader.setFloat("value", new float[] { value });
/* 40 */     shader.setInt("shadow", new int[] { shadow ? 1 : 0 });
/* 41 */     shader.setFloat("shadowAlpha", new float[] { shadow ? shadowAlpha : 0.0F });
/* 42 */     shader.setFloat("color1", ColorUtility.getRGBAFloat(color1));
/* 43 */     shader.setFloat("color2", ColorUtility.getRGBAFloat(color2));
/* 44 */     shader.setFloat("color3", ColorUtility.getRGBAFloat(color3));
/* 45 */     shader.setFloat("color4", ColorUtility.getRGBAFloat(color4));
/*    */     
/* 47 */     Shader.drawQuads(matrixStack, rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight());
/* 48 */     shader.finish();
/*    */     
/* 50 */     GlStateManager.disableBlend();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getCode() {
/* 55 */     return "#version 120\n\n            uniform vec4 color1;\n            uniform vec4 color2;\n            uniform vec4 color3;\n            uniform vec4 color4;\n\n            uniform vec2 size;\n            uniform vec4 round;\n            uniform float value;\n            uniform vec2 smoothness;\n            uniform bool shadow;\n            uniform float shadowAlpha;\n\n            float roundedBox(vec2 center, vec2 size, vec4 radius) {\n                radius.xy = (center.x > 0.0) ? radius.xy : radius.zw;\n                radius.x  = (center.y > 0.0) ? radius.x : radius.y;\n\n                vec2 q = abs(center) - size + radius.x;\n                return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - radius.x;\n            }\n\n            vec4 createGradient(vec2 pos) {\n                return mix(mix(color1, color2, pos.y), mix(color3, color4, pos.y), pos.x);\n            }\n\n            void main() {\n                vec2 tex = gl_TexCoord[0].st * size;\n\n                float distance = roundedBox(tex - (size / 2.0), (size / 2.0) - value, round);\n\n                float smoothedAlpha = (1.0 - smoothstep(smoothness.x, smoothness.y, distance));\n\n                vec4 gradient = createGradient(gl_TexCoord[0].st);\n\n                if (shadow) {\n                    vec4 finalColor = mix(vec4(gradient.rgb, 0.0), vec4(gradient.rgb, gradient.a * smoothedAlpha), smoothedAlpha);\n                    gl_FragColor = vec4(finalColor.rgb, finalColor.a * shadowAlpha);\n                } else {\n                    gl_FragColor = vec4(gradient.rgb, gradient.a * smoothedAlpha);\n                }\n            }\n";
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\list\Glow.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */