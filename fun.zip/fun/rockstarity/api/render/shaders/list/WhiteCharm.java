/*    */ package fun.rockstarity.api.render.shaders.list;
/*    */ 
/*    */ import fun.rockstarity.api.render.shaders.Shader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WhiteCharm
/*    */   extends Shader
/*    */ {
/*    */   public String getCode() {
/* 14 */     return "#version 120\n\nuniform vec2 size;\nuniform vec4 cornerRadius;\n\nvarying vec2 uv;\n\nvoid main() {\n    vec2 pos = uv * size;\n\n    float d;\n\n\n    if (pos.x < cornerRadius.x && pos.y < cornerRadius.x) {\n        vec2 center = vec2(cornerRadius.x, cornerRadius.x);\n        d = length(pos - center) - cornerRadius.x;\n    }\n\n    else if (pos.x > size.x - cornerRadius.z && pos.y < cornerRadius.z) {\n        vec2 center = vec2(size.x - cornerRadius.z, cornerRadius.z);\n        d = length(pos - center) - cornerRadius.z;\n    }\n\n    else if (pos.x < cornerRadius.y && pos.y > size.y - cornerRadius.y) {\n        vec2 center = vec2(cornerRadius.y, size.y - cornerRadius.y);\n        d = length(pos - center) - cornerRadius.y;\n    }\n\n    else if (pos.x > size.x - cornerRadius.w && pos.y > size.y - cornerRadius.w) {\n        vec2 center = vec2(size.x - cornerRadius.w, size.y - cornerRadius.w);\n        d = length(pos - center) - cornerRadius.w;\n    }\n\n    else {\n        float d_left = -pos.x;\n        float d_right = pos.x - size.x;\n        float d_top = -pos.y;\n        float d_bottom = pos.y - size.y;\n        d = max(max(d_left, d_right), max(d_top, d_bottom));\n    }\n\n\n    float aa = 1.0;\n    float mask = smoothstep(-aa, aa, -d);\n\n\n    gl_FragColor = vec4(1.0, 1.0, 1.0, mask);\n}\n";
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\list\WhiteCharm.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */