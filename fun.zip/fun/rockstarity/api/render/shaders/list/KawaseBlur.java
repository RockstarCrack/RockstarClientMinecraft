/*     */ package fun.rockstarity.api.render.shaders.list;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.helpers.render.Render;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.shaders.Shader;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.shader.Framebuffer;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import org.lwjgl.opengl.GL13;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class KawaseBlur
/*     */   implements IAccess
/*     */ {
/*     */   private KawaseBlur() {
/*  33 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*     */   }
/*  35 */   public static Framebuffer stencilFramebuffer = new Framebuffer(1, 1, false);
/*     */   
/*  37 */   private static Shader kawaseDown = new Shader() { public String getCode() {
/*  38 */         return "#version 120\n\nuniform sampler2D inTexture;\nuniform vec2 offset, halfpixel, iResolution;\n\nvoid main() {\n    vec2 uv = vec2(gl_FragCoord.xy / iResolution);\n    vec4 sum = texture2D(inTexture, gl_TexCoord[0].st) * 4.0;\n    sum += texture2D(inTexture, uv - halfpixel.xy * offset);\n    sum += texture2D(inTexture, uv + halfpixel.xy * offset);\n    sum += texture2D(inTexture, uv + vec2(halfpixel.x, -halfpixel.y) * offset);\n    sum += texture2D(inTexture, uv - vec2(halfpixel.x, -halfpixel.y) * offset);\n    gl_FragColor = vec4(sum.rgb * .125, 1.0);\n}\n";
/*     */       } }
/*     */   ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   private static Shader kawaseUp = new Shader() { public String getCode() {
/*  54 */         return "#version 120\n\nuniform sampler2D inTexture, textureToCheck;\nuniform vec2 halfpixel, offset, iResolution;\nuniform int check;\n\nvoid main() {\n    vec2 uv = vec2(gl_FragCoord.xy / iResolution);\n    vec4 sum = texture2D(inTexture, uv + vec2(-halfpixel.x * 2.0, 0.0) * offset);\n    sum += texture2D(inTexture, uv + vec2(-halfpixel.x, halfpixel.y) * offset) * 2.0;\n    sum += texture2D(inTexture, uv + vec2(0.0, halfpixel.y * 2.0) * offset);\n    sum += texture2D(inTexture, uv + vec2(halfpixel.x, halfpixel.y) * offset) * 2.0;\n    sum += texture2D(inTexture, uv + vec2(halfpixel.x * 2.0, 0.0) * offset);\n    sum += texture2D(inTexture, uv + vec2(halfpixel.x, -halfpixel.y) * offset) * 2.0;\n    sum += texture2D(inTexture, uv + vec2(0.0, -halfpixel.y * 2.0) * offset);\n    sum += texture2D(inTexture, uv + vec2(-halfpixel.x, -halfpixel.y) * offset) * 2.0;\n\n    gl_FragColor = vec4(sum.rgb /12.0, mix(1.0, texture2D(textureToCheck, gl_TexCoord[0].st).a, check));\n}\n";
/*     */       } }
/*     */   ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   public static Framebuffer framebuffer = new Framebuffer(1, 1, false); private static int currentIterations;
/*     */   
/*     */   public static void setupUniforms(float offset) {
/*  78 */     kawaseDown.setFloat("offset", new float[] { offset, offset });
/*  79 */     kawaseUp.setFloat("offset", new float[] { offset, offset });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  84 */   private static final List<Framebuffer> framebufferList = new ArrayList<>();
/*     */   
/*     */   private static void startFramebuffers(float iterations) {
/*  87 */     for (Framebuffer framebuffer : framebufferList) {
/*  88 */       framebuffer.deleteFramebuffer();
/*     */     }
/*  90 */     framebufferList.clear();
/*     */ 
/*     */     
/*  93 */     framebufferList.add(KawaseBlur.framebuffer = Shader.createFrameBuffer(null));
/*     */ 
/*     */     
/*  96 */     for (int i = 1; i <= iterations; i++) {
/*  97 */       Framebuffer currentBuffer = new Framebuffer((int)(sr.getFramebufferWidth() / Math.pow(2.0D, i)), (int)(sr.getFramebufferHeight() / Math.pow(2.0D, i)), false);
/*  98 */       currentBuffer.setFramebufferFilter(9729);
/*  99 */       GlStateManager.bindTexture(currentBuffer.framebufferTexture);
/* 100 */       GL11.glTexParameteri(3553, 10242, 33648);
/* 101 */       GL11.glTexParameteri(3553, 10243, 33648);
/* 102 */       GlStateManager.bindTexture(0);
/*     */       
/* 104 */       framebufferList.add(currentBuffer);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void renderBlur(int stencilFrameBufferTexture, int iterations, int offset) {
/* 110 */     if (currentIterations != iterations || framebuffer.framebufferWidth != sr.getFramebufferWidth() || framebuffer.framebufferHeight != sr.getFramebufferHeight()) {
/* 111 */       startFramebuffers(iterations);
/* 112 */       currentIterations = iterations;
/*     */     } 
/*     */     
/* 115 */     renderFBO(framebufferList.get(1), (mc.getFramebuffer()).framebufferTexture, kawaseDown, offset);
/*     */     
/*     */     int i;
/* 118 */     for (i = 1; i < iterations; i++) {
/* 119 */       renderFBO(framebufferList.get(i + 1), ((Framebuffer)framebufferList.get(i)).framebufferTexture, kawaseDown, offset);
/*     */     }
/*     */ 
/*     */     
/* 123 */     for (i = iterations; i > 1; i--) {
/* 124 */       renderFBO(framebufferList.get(i - 1), ((Framebuffer)framebufferList.get(i)).framebufferTexture, kawaseUp, offset);
/*     */     }
/*     */ 
/*     */     
/* 128 */     Framebuffer lastBuffer = framebufferList.get(0);
/* 129 */     lastBuffer.framebufferClear();
/* 130 */     lastBuffer.bindFramebuffer(false);
/* 131 */     kawaseUp.start();
/* 132 */     kawaseUp.setFloat("offset", new float[] { offset, offset });
/* 133 */     kawaseUp.setInt("inTexture", new int[] { 0 });
/* 134 */     kawaseUp.setInt("check", new int[] { 1 });
/* 135 */     kawaseUp.setInt("textureToCheck", new int[] { 16 });
/* 136 */     kawaseUp.setFloat("halfpixel", new float[] { 1.0F / lastBuffer.framebufferWidth, 1.0F / lastBuffer.framebufferHeight });
/* 137 */     kawaseUp.setFloat("iResolution", new float[] { lastBuffer.framebufferWidth, lastBuffer.framebufferHeight });
/* 138 */     GL13.glActiveTexture(34000);
/* 139 */     Render.bindTexture(stencilFrameBufferTexture);
/* 140 */     GL13.glActiveTexture(33984);
/* 141 */     Render.bindTexture(((Framebuffer)framebufferList.get(1)).framebufferTexture);
/* 142 */     Shader.drawQuads();
/* 143 */     kawaseUp.finish();
/*     */ 
/*     */     
/* 146 */     mc.getFramebuffer().bindFramebuffer(true);
/* 147 */     Render.bindTexture(((Framebuffer)framebufferList.get(0)).framebufferTexture);
/* 148 */     Render.setAlphaLimit(0.0F);
/* 149 */     RenderSystem.enableBlend();
/* 150 */     Shader.drawQuads();
/* 151 */     GlStateManager.bindTexture(0);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void renderFBO(Framebuffer framebuffer, int framebufferTexture, Shader shader, float offset) {
/* 156 */     framebuffer.framebufferClear();
/* 157 */     framebuffer.bindFramebuffer(false);
/* 158 */     shader.start();
/* 159 */     Render.bindTexture(framebufferTexture);
/* 160 */     shader.setFloat("offset", new float[] { offset, offset });
/* 161 */     shader.setInt("inTexture", new int[] { 0 });
/* 162 */     shader.setInt("check", new int[] { 0 });
/* 163 */     shader.setFloat("halfpixel", new float[] { 1.0F / framebuffer.framebufferWidth, 1.0F / framebuffer.framebufferHeight });
/* 164 */     shader.setFloat("iResolution", new float[] { framebuffer.framebufferWidth, framebuffer.framebufferHeight });
/* 165 */     Shader.drawQuads();
/* 166 */     shader.finish();
/*     */   }
/*     */   
/*     */   public static void renderBlur(MatrixStack ms, int iterations, int offset) {
/* 170 */     stencilFramebuffer = Shader.createFrameBuffer(Blur.stencilFramebuffer);
/*     */     
/* 172 */     stencilFramebuffer.framebufferClear();
/* 173 */     stencilFramebuffer.bindFramebuffer(false);
/* 174 */     Round.draw(ms, new Rect(0.0F, 0.0F, sr.getScaledWidth(), sr.getScaledHeight()), 0.0F, FixColor.WHITE);
/* 175 */     Blur.stencilFramebuffer.unbindFramebuffer();
/* 176 */     renderBlur(Blur.stencilFramebuffer.framebufferTexture, iterations, offset);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\list\KawaseBlur.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */