/*    */ package fun.rockstarity.api.render.shaders.list;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import com.mojang.blaze3d.platform.GlStateManager;
/*    */ import fun.rockstarity.api.helpers.render.Render;
/*    */ import fun.rockstarity.api.render.shaders.Shader;
/*    */ import net.minecraft.client.shader.Framebuffer;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RotateHelper
/*    */   extends Shader
/*    */ {
/* 25 */   private static final RotateHelper shader = new RotateHelper();
/*    */   private static Framebuffer framebuffer;
/*    */   
/*    */   public static void init() {
/* 29 */     framebuffer = Shader.createFrameBuffer(framebuffer);
/* 30 */     framebuffer.framebufferClear();
/* 31 */     framebuffer.bindFramebuffer(true);
/*    */   }
/*    */   
/*    */   public static void end() {
/* 35 */     framebuffer.unbindFramebuffer();
/* 36 */     mc.getFramebuffer().bindFramebuffer(true);
/*    */   }
/*    */   
/*    */   public static void draw(MatrixStack ms) {
/* 40 */     if (framebuffer != null) {
/* 41 */       GlStateManager.enableBlend();
/* 42 */       GL11.glBlendFunc(770, 771);
/* 43 */       Render.setAlphaLimit(0.0F);
/*    */       
/* 45 */       Render.bindTexture(framebuffer.framebufferTexture);
/* 46 */       shader.start();
/* 47 */       shader.setFloat("alpha", new float[] { 1.0F });
/* 48 */       drawQuads();
/* 49 */       shader.finish();
/*    */       
/* 51 */       GlStateManager.disableBlend();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getCode() {
/* 58 */     return "            #version 120\n\n\n            uniform sampler2D texture;\n            uniform float alpha;\n\n\n            varying vec2 uv;\n\n            void main() {\n\n                vec4 color = texture2D(texture, uv);\n\n\n                color.a *= alpha;\n\n\n                gl_FragColor = color;\n            }\n";
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\list\RotateHelper.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */