/*    */ package fun.rockstarity.api.render.shaders.list;
/*    */ 
/*    */ import com.mojang.blaze3d.platform.GlStateManager;
/*    */ import fun.rockstarity.api.helpers.render.ColorUtility;
/*    */ import fun.rockstarity.api.helpers.render.Render;
/*    */ import fun.rockstarity.api.render.color.FixColor;
/*    */ import fun.rockstarity.api.render.shaders.Shader;
/*    */ import net.minecraft.client.shader.Framebuffer;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import org.lwjgl.opengl.GL13;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Glass
/*    */   extends Shader
/*    */ {
/* 27 */   static Glass shader = new Glass();
/* 28 */   static Framebuffer framebuffer = new Framebuffer(1, 1, false);
/*    */ 
/*    */ 
/*    */   
/*    */   public static void draw(FixColor color, float noise, float reflected, float blur) {
/* 33 */     Render.resetColor();
/* 34 */     GlStateManager.enableBlend();
/* 35 */     GL11.glBlendFunc(770, 771);
/* 36 */     Render.setAlphaLimit(0.0F);
/*    */     
/* 38 */     GL13.glBindTexture(3553, (mc.getFramebuffer()).framebufferTexture);
/* 39 */     shader.start();
/* 40 */     shader.setInt("inputSampler", new int[] { 0 });
/* 41 */     shader.setFloat("inputResolution", new float[] { (mc.getFramebuffer()).framebufferTextureWidth, (mc.getFramebuffer()).framebufferTextureHeight });
/* 42 */     shader.setFloat("blurAmount", new float[] { blur });
/* 43 */     shader.setFloat("reflect", new float[] { reflected });
/* 44 */     shader.setFloat("noiseValue", new float[] { noise * 0.01F });
/* 45 */     shader.setFloat("vertexColor", ColorUtility.getRGBAFloat(color));
/*    */   }
/*    */   
/*    */   public static void end() {
/* 49 */     shader.finish();
/*    */     
/* 51 */     GlStateManager.disableBlend();
/* 52 */     GlStateManager.bindTexture(0);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getCode() {
/* 57 */     return "#version 150\n\nuniform sampler2D inputSampler;\nuniform vec2 inputResolution;\nuniform float blurAmount;\nuniform float reflect;\nuniform float noiseValue;\n\nin vec2 vertexPos;\nuniform vec4 vertexColor;\n\nout vec4 fragColor;\n\n#define TAU 6.28318530718\n\n//\tSimplex 3D Noise\n//\tby Ian McEwan, Stefan Gustavson (https://github.com/stegu/webgl-noise)\n//\nvec4 permute(vec4 x){ return mod(((x*34.0)+1.0)*x, 289.0); }\nvec4 taylorInvSqrt(vec4 r){ return 1.79284291400159 - 0.85373472095314 * r; }\n\nfloat snoise(vec3 v){\n    const vec2  C = vec2(1.0/6.0, 1.0/3.0);\n    const vec4  D = vec4(0.0, 0.5, 1.0, 2.0);\n\n    // First corner\n    vec3 i  = floor(v + dot(v, C.yyy));\n    vec3 x0 =   v - i + dot(i, C.xxx);\n\n    // Other corners\n    vec3 g = step(x0.yzx, x0.xyz);\n    vec3 l = 1.0 - g;\n    vec3 i1 = min(g.xyz, l.zxy);\n    vec3 i2 = max(g.xyz, l.zxy);\n\n    //  x0 = x0 - 0. + 0.0 * C\n    vec3 x1 = x0 - i1 + 1.0 * C.xxx;\n    vec3 x2 = x0 - i2 + 2.0 * C.xxx;\n    vec3 x3 = x0 - 1. + 3.0 * C.xxx;\n\n    // Permutations\n    i = mod(i, 289.0);\n    vec4 p = permute(permute(permute(\n    i.z + vec4(0.0, i1.z, i2.z, 1.0))\n    + i.y + vec4(0.0, i1.y, i2.y, 1.0))\n    + i.x + vec4(0.0, i1.x, i2.x, 1.0));\n\n    // Gradients\n    // ( N*N points uniformly over a square, mapped onto an octahedron.)\n    float n_ = 1.0/7.0;// N=7\n    vec3  ns = n_ * D.wyz - D.xzx;\n\n    vec4 j = p - 49.0 * floor(p * ns.z *ns.z);//  mod(p,N*N)\n\n    vec4 x_ = floor(j * ns.z);\n    vec4 y_ = floor(j - 7.0 * x_);// mod(j,N)\n\n    vec4 x = x_ *ns.x + ns.yyyy;\n    vec4 y = y_ *ns.x + ns.yyyy;\n    vec4 h = 1.0 - abs(x) - abs(y);\n\n    vec4 b0 = vec4(x.xy, y.xy);\n    vec4 b1 = vec4(x.zw, y.zw);\n\n    vec4 s0 = floor(b0)*2.0 + 1.0;\n    vec4 s1 = floor(b1)*2.0 + 1.0;\n    vec4 sh = -step(h, vec4(0.0));\n\n    vec4 a0 = b0.xzyw + s0.xzyw*sh.xxyy;\n    vec4 a1 = b1.xzyw + s1.xzyw*sh.zzww;\n\n    vec3 p0 = vec3(a0.xy, h.x);\n    vec3 p1 = vec3(a0.zw, h.y);\n    vec3 p2 = vec3(a1.xy, h.z);\n    vec3 p3 = vec3(a1.zw, h.w);\n\n    //Normalise gradients\n    vec4 norm = taylorInvSqrt(vec4(dot(p0, p0), dot(p1, p1), dot(p2, p2), dot(p3, p3)));\n    p0 *= norm.x;\n    p1 *= norm.y;\n    p2 *= norm.z;\n    p3 *= norm.w;\n\n    // Mix final noise value\n    vec4 m = max(0.6 - vec4(dot(x0, x0), dot(x1, x1), dot(x2, x2), dot(x3, x3)), 0.0);\n    m = m * m;\n    return 42.0 * dot(m*m, vec4(dot(p0, x0), dot(p1, x1),\n    dot(p2, x2), dot(p3, x3)));\n}\n\n// Blur Function\nvec4 blur(vec2 uv) {\n    vec4 pixelColor = texture(inputSampler, uv);\n\n    vec2 radius = vec2(blurAmount) / inputResolution;\n\n    float blurQuality = 4.0;\n    float blurDirections = 16.0;\n\n    for (float d = 0.0; d < TAU; d += TAU / blurDirections) {\n        for (float i = 1.0 / 4.0; i <= 1.0; i += 1.0 / blurQuality) {\n            pixelColor += texture(inputSampler, uv + vec2(cos(d), sin(d)) * radius * i);\n        }\n    }\n\n    // Normalize\n    pixelColor /= blurQuality * blurDirections;\n    return pixelColor;\n}\n\nvoid main() {\n    vec2 uv = gl_FragCoord.xy / inputResolution.xy;\n    vec2 reflectedUV = vec2(uv.x, 1.0 - uv.y);\n\n    float time = mod(gl_FragCoord.x + gl_FragCoord.y, 1000.0) * 0.001;\n    float noise = snoise(vec3(reflectedUV * reflect, 1));\n\n    // sosal\n    vec2 noisyUV = reflectedUV + vec2(noise * noiseValue, noise * noiseValue);\n\n    vec4 reflectedColor = texture(inputSampler, noisyUV);\n\n   vec4 blurredColor = blur(noisyUV);\n\n    fragColor = vec4(blurredColor.rgb, vertexColor.a);\n}\n\n";
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\list\Glass.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */