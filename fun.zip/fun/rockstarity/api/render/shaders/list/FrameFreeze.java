/*    */ package fun.rockstarity.api.render.shaders.list;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import com.mojang.blaze3d.platform.GlStateManager;
/*    */ import fun.rockstarity.api.helpers.render.Render;
/*    */ import fun.rockstarity.api.render.shaders.Shader;
/*    */ import fun.rockstarity.api.render.ui.mainmenu.Page;
/*    */ import fun.rockstarity.api.render.ui.mainmenu.screens.MainPageScreen;
/*    */ import net.minecraft.client.shader.Framebuffer;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import org.lwjgl.opengl.GL13;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FrameFreeze
/*    */   extends Shader
/*    */ {
/* 26 */   private static final FrameFreeze shader = new FrameFreeze();
/*    */   private static Framebuffer framebuffer;
/*    */   
/*    */   public static void save() {
/* 30 */     ((MainPageScreen)Page.MAIN.getScreen()).getBgAnim().setForward(false);
/*    */     
/* 32 */     framebuffer = Shader.createFrameBuffer(framebuffer);
/* 33 */     framebuffer.framebufferClear();
/* 34 */     framebuffer.bindFramebuffer(true);
/*    */     
/* 36 */     int currentTexture = GL11.glGetInteger(32873);
/*    */     
/* 38 */     GL13.glBindTexture(3553, (mc.getFramebuffer()).framebufferTexture);
/* 39 */     Shader.drawQuads();
/*    */     
/* 41 */     framebuffer.unbindFramebuffer();
/* 42 */     mc.getFramebuffer().bindFramebuffer(true);
/*    */     
/* 44 */     GL13.glBindTexture(3553, currentTexture);
/*    */   }
/*    */   
/*    */   public static void draw(MatrixStack ms, float alpha) {
/* 48 */     if (framebuffer != null) {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 56 */       GlStateManager.enableBlend();
/* 57 */       GL11.glBlendFunc(770, 771);
/* 58 */       Render.setAlphaLimit(0.0F);
/*    */       
/* 60 */       Render.bindTexture(framebuffer.framebufferTexture);
/* 61 */       shader.start();
/* 62 */       shader.setFloat("alpha", new float[] { 1.0F });
/* 63 */       drawQuads();
/* 64 */       shader.finish();
/*    */       
/* 66 */       GlStateManager.disableBlend();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getCode() {
/* 73 */     return "#version 120\n\nuniform sampler2D textureIn;\nuniform float alpha;\nvarying vec2 uv;\n\nvoid main() {\n    vec4 color = texture2D(textureIn, uv);\n    color.a *= alpha;\n    gl_FragColor = color;\n}\n";
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\list\FrameFreeze.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */