/*    */ package fun.rockstarity.api.render.shaders.list;
/*    */ 
/*    */ import fun.rockstarity.api.render.shaders.Shader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends Shader
/*    */ {
/*    */   public String getCode() {
/* 24 */     return readShader("kawaseUpBloom");
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\list\Bloom$2.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */