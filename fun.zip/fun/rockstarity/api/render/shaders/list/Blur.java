/*     */ package fun.rockstarity.api.render.shaders.list;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.helpers.render.Render;
/*     */ import fun.rockstarity.api.helpers.render.Stencil;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.shaders.Shader;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.shader.Framebuffer;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import org.lwjgl.opengl.GL13;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Blur
/*     */   implements IAccess
/*     */ {
/*     */   private Blur() {
/*  28 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*     */   }
/*  30 */   public static Framebuffer stencilFramebuffer = new Framebuffer(1, 1, false);
/*     */   public static long renderTicks;
/*     */   
/*  33 */   private static Shader kawaseDown = new Shader() {
/*     */       public String getCode() {
/*  35 */         return "#version 330 core\n\nin vec2 texCoord;\nout vec4 fragColor;\n\nuniform sampler2D inTexture;\nuniform vec2 halfpixel;\nuniform vec2 offset;\n\nvoid main() {\n    vec2 uv = texCoord;\n    vec4 sum = texture(inTexture, uv) * 4.0;\n    sum += texture(inTexture, uv - halfpixel * offset.x);\n    sum += texture(inTexture, uv + halfpixel * offset.x);\n    sum += texture(inTexture, uv + vec2(halfpixel.x, -halfpixel.y) * offset.x);\n    sum += texture(inTexture, uv - vec2(halfpixel.x, -halfpixel.y) * offset.x);\n    fragColor = sum / 8.0;\n}\n";
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   private static Shader kawaseUp = new Shader() { public String getCode() {
/*  60 */         return "#version 330 core\n\nin vec2 texCoord;\nout vec4 fragColor;\n\nuniform sampler2D inTexture;\nuniform vec2 halfpixel;\nuniform vec2 offset;\n\nvoid main() {\n    vec2 uv = texCoord;\n    vec4 sum = texture(inTexture, uv) * 4.0;\n    sum += texture(inTexture, uv - halfpixel * offset.x);\n    sum += texture(inTexture, uv + halfpixel * offset.x);\n    sum += texture(inTexture, uv + vec2(halfpixel.x, -halfpixel.y) * offset.x);\n    sum += texture(inTexture, uv - vec2(halfpixel.x, -halfpixel.y) * offset.x);\n    fragColor = sum / 8.0;\n}\n";
/*     */       } }
/*     */   ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   private static Framebuffer framebuffer = new Framebuffer(1, 1, false);
/*     */   
/*     */   private static int currentIterations;
/*     */   
/*  87 */   private static final List<Framebuffer> framebufferList = new ArrayList<>();
/*     */   
/*     */   private static void initFramebuffers(float iterations) {
/*  90 */     for (Framebuffer framebuffer : framebufferList) {
/*  91 */       framebuffer.deleteFramebuffer();
/*     */     }
/*  93 */     framebufferList.clear();
/*     */     
/*  95 */     framebufferList.add(Blur.framebuffer = Shader.createFrameBuffer(Blur.framebuffer));
/*     */     
/*  97 */     for (int i = 1; i <= iterations; i++) {
/*  98 */       Framebuffer currentBuffer = new Framebuffer((int)(sr.getScaledWidth() / Math.pow(2.0D, i)), (int)(sr.getScaledHeight() / Math.pow(2.0D, i)), false);
/*  99 */       currentBuffer.setFramebufferFilter(9729);
/* 100 */       GlStateManager.bindTexture(currentBuffer.framebufferTexture);
/* 101 */       GL11.glTexParameteri(3553, 10242, 33648);
/* 102 */       GL11.glTexParameteri(3553, 10243, 33648);
/* 103 */       GlStateManager.bindTexture(0);
/*     */       
/* 105 */       framebufferList.add(currentBuffer);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void renderBlur(MatrixStack ms, int stencilFrameBufferTexture, int iterations, int offset) {
/* 110 */     if (framebuffer.framebufferWidth != sr.getFramebufferWidth() || framebuffer.framebufferHeight != sr.getFramebufferHeight()) {
/* 111 */       initFramebuffers(5.0F);
/* 112 */       currentIterations = iterations;
/*     */     } 
/*     */     
/* 115 */     renderFBO(ms, framebufferList.get(1), (mc.getFramebuffer()).framebufferTexture, kawaseDown, offset);
/*     */     
/*     */     int i;
/* 118 */     for (i = 1; i < iterations; i++) {
/* 119 */       renderFBO(ms, framebufferList.get(i + 1), ((Framebuffer)framebufferList.get(i)).framebufferTexture, kawaseDown, offset);
/*     */     }
/*     */ 
/*     */     
/* 123 */     for (i = iterations; i > 1; i--) {
/* 124 */       renderFBO(ms, framebufferList.get(i - 1), ((Framebuffer)framebufferList.get(i)).framebufferTexture, kawaseUp, offset);
/*     */     }
/*     */     
/* 127 */     Framebuffer lastBuffer = framebufferList.get(0);
/* 128 */     lastBuffer.framebufferClear();
/* 129 */     lastBuffer.bindFramebuffer(false);
/* 130 */     kawaseUp.start();
/* 131 */     kawaseUp.setFloat("offset", new float[] { offset, offset });
/* 132 */     kawaseUp.setInt("inTexture", new int[] { 0 });
/* 133 */     kawaseUp.setInt("check", new int[] { 1 });
/* 134 */     kawaseUp.setInt("textureToCheck", new int[] { 16 });
/* 135 */     kawaseUp.setFloat("halfpixel", new float[] { 1.0F / lastBuffer.framebufferWidth, 1.0F / lastBuffer.framebufferHeight });
/* 136 */     kawaseUp.setFloat("iResolution", new float[] { lastBuffer.framebufferWidth, lastBuffer.framebufferHeight });
/* 137 */     GL13.glActiveTexture(34000);
/* 138 */     Render.bindTexture(stencilFrameBufferTexture);
/* 139 */     GL13.glActiveTexture(33984);
/* 140 */     Render.bindTexture(((Framebuffer)framebufferList.get(1)).framebufferTexture);
/* 141 */     Shader.drawQuads(ms);
/* 142 */     kawaseUp.finish();
/*     */     
/* 144 */     mc.getFramebuffer().bindFramebuffer(true);
/* 145 */     Render.bindTexture(((Framebuffer)framebufferList.get(0)).framebufferTexture);
/* 146 */     Render.setAlphaLimit(0.0F);
/* 147 */     GlStateManager.enableBlend();
/* 148 */     Shader.drawQuads(ms);
/* 149 */     GlStateManager.bindTexture(0);
/*     */   }
/*     */   
/*     */   public static void renderOld(MatrixStack ms) {
/* 153 */     if (framebufferList.isEmpty())
/*     */       return; 
/* 155 */     mc.getFramebuffer().bindFramebuffer(true);
/* 156 */     Render.bindTexture(((Framebuffer)framebufferList.get(0)).framebufferTexture);
/* 157 */     Render.setAlphaLimit(0.0F);
/* 158 */     GlStateManager.enableBlend();
/* 159 */     Shader.drawQuads(ms);
/* 160 */     GlStateManager.bindTexture(0);
/*     */   }
/*     */   
/*     */   private static void renderFBO(MatrixStack ms, Framebuffer framebuffer, int framebufferTexture, Shader shader, float offset) {
/* 164 */     framebuffer.framebufferClear();
/* 165 */     framebuffer.bindFramebuffer(false);
/* 166 */     shader.start();
/* 167 */     Render.bindTexture(framebufferTexture);
/* 168 */     shader.setFloat("offset", new float[] { offset, offset });
/* 169 */     shader.setInt("inTexture", new int[] { 0 });
/* 170 */     shader.setInt("check", new int[] { 0 });
/* 171 */     shader.setFloat("halfpixel", new float[] { 1.0F / framebuffer.framebufferWidth, 1.0F / framebuffer.framebufferHeight });
/* 172 */     shader.setFloat("iResolution", new float[] { framebuffer.framebufferWidth, framebuffer.framebufferHeight });
/* 173 */     Shader.drawQuads(ms);
/* 174 */     shader.finish();
/*     */   }
/*     */ 
/*     */   
/*     */   public static void renderBlur(MatrixStack ms, int radius) {
/* 179 */     stencilFramebuffer = Shader.createFrameBuffer(stencilFramebuffer);
/*     */     
/* 181 */     stencilFramebuffer.framebufferClear();
/* 182 */     stencilFramebuffer.bindFramebuffer(false);
/* 183 */     Round.draw(ms, new Rect(0.0F, 0.0F, sr.getScaledWidth(), sr.getScaledHeight()), 0.0F, FixColor.WHITE);
/* 184 */     stencilFramebuffer.unbindFramebuffer();
/* 185 */     renderBlur(ms, stencilFramebuffer.framebufferTexture, radius * 2 - 1, 1);
/*     */   }
/*     */   
/*     */   public static void renderBlur(MatrixStack ms, int radius, Runnable data) {
/* 189 */     Stencil.init();
/* 190 */     data.run();
/* 191 */     Stencil.read(1);
/* 192 */     renderBlur(ms, radius);
/* 193 */     Stencil.finish();
/*     */   }
/*     */   
/*     */   public static void drawBlurredRect(MatrixStack ms, float x, float y, float width, float height, int radius) {
/* 197 */     Stencil.init();
/* 198 */     Round.draw(ms, new Rect(x, y, width, height), radius, FixColor.WHITE);
/* 199 */     Stencil.read(1);
/* 200 */     renderBlur(ms, radius);
/* 201 */     Stencil.finish();
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\list\Blur.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */