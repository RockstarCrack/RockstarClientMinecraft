/*    */ package fun.rockstarity.api.render.shaders.list;
/*    */ 
/*    */ import com.mojang.blaze3d.platform.GlStateManager;
/*    */ import fun.rockstarity.api.helpers.render.Render;
/*    */ import fun.rockstarity.api.render.shaders.Shader;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import org.lwjgl.opengl.GL13;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Gray
/*    */   extends Shader
/*    */ {
/* 26 */   private static final Gray shader = new Gray();
/*    */   
/*    */   private static final int TEXTURE_UNIT_INDEX = 0;
/*    */   
/*    */   public static void render(float radius) {
/* 31 */     Render.resetColor();
/* 32 */     GlStateManager.enableBlend();
/* 33 */     GL11.glBlendFunc(770, 771);
/* 34 */     Render.setAlphaLimit(0.0F);
/*    */     
/* 36 */     GL13.glBindTexture(3553, (mc.getFramebuffer()).framebufferTexture);
/* 37 */     shader.start();
/* 38 */     shader.setInt("textureIn", new int[] { 0 });
/* 39 */     shader.setFloat("grayAmount", new float[] { radius });
/*    */     
/* 41 */     Shader.drawQuads();
/* 42 */     shader.finish();
/*    */     
/* 44 */     GlStateManager.disableBlend();
/* 45 */     GlStateManager.bindTexture(0);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getCode() {
/* 50 */     return "#version 120\n\n\nuniform sampler2D textureIn;\nuniform float grayAmount;\n\n\nvarying vec2 uv;\n\nvoid main() {\n\n    vec4 texColor = texture2D(textureIn, uv);\n\n\n    float gray = dot(texColor.rgb, vec3(0.299, 0.587, 0.114));\n\n\n    vec3 finalColor = mix(texColor.rgb, vec3(gray), grayAmount);\n\n\n    gl_FragColor = vec4(finalColor, texColor.a);\n}\n";
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\list\Gray.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */