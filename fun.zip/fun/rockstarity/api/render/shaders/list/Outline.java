/*    */ package fun.rockstarity.api.render.shaders.list;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import com.mojang.blaze3d.platform.GlStateManager;
/*    */ import fun.rockstarity.api.helpers.render.Render;
/*    */ import fun.rockstarity.api.render.color.FixColor;
/*    */ import fun.rockstarity.api.render.shaders.Shader;
/*    */ import fun.rockstarity.api.render.ui.rect.Rect;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Outline
/*    */   extends Shader
/*    */ {
/* 22 */   private static Outline shader = new Outline();
/*    */   
/*    */   public static void draw(MatrixStack matrixStack, Rect rect, float round, float width, FixColor color) {
/* 25 */     draw(matrixStack, rect, round, width, color, color, color, color);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void draw(MatrixStack matrixStack, Rect rect, float round, float width, FixColor color1, FixColor color2, FixColor color3, FixColor color4) {
/* 31 */     float off = 1.0F;
/*    */     
/* 33 */     Render.resetColor();
/*    */     
/* 35 */     GlStateManager.enableBlend();
/* 36 */     GL11.glBlendFunc(770, 771);
/*    */     
/* 38 */     Render.setAlphaLimit(0.0F);
/*    */     
/* 40 */     shader.start();
/*    */     
/* 42 */     shader.setFloat("location", new float[] { rect.getX() * sr.getGuiScaleFactorF(), sr
/* 43 */           .getScaledHeight() * sr.getGuiScaleFactorF() - rect.getHeight() * sr.getGuiScaleFactorF() - rect.getY() * sr.getGuiScaleFactorF() });
/* 44 */     shader.setFloat("rectSize", new float[] { rect.getWidth() * sr.getGuiScaleFactorF(), rect.getHeight() * sr.getGuiScaleFactorF() });
/* 45 */     shader.setFloat("radius", new float[] { round * sr.getGuiScaleFactorF() });
/* 46 */     shader.setFloat("outline", new float[] { width * sr.getGuiScaleFactorF() });
/*    */     
/* 48 */     shader.setFloat("color1", new float[] { color1.getRed() / 255.0F, color1.getGreen() / 255.0F, color1.getBlue() / 255.0F, color1.getAlpha() / 255.0F });
/* 49 */     shader.setFloat("color2", new float[] { color2.getRed() / 255.0F, color2.getGreen() / 255.0F, color2.getBlue() / 255.0F, color2.getAlpha() / 255.0F });
/* 50 */     shader.setFloat("color3", new float[] { color3.getRed() / 255.0F, color3.getGreen() / 255.0F, color3.getBlue() / 255.0F, color3.getAlpha() / 255.0F });
/* 51 */     shader.setFloat("color4", new float[] { color4.getRed() / 255.0F, color4.getGreen() / 255.0F, color4.getBlue() / 255.0F, color4.getAlpha() / 255.0F });
/*    */     
/* 53 */     rect = rect.size(-0.25F);
/* 54 */     drawQuads(matrixStack, rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight());
/*    */     
/* 56 */     shader.finish();
/*    */     
/* 58 */     GlStateManager.disableBlend();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getCode() {
/* 64 */     return "#version 120\n\nuniform vec2 rectSize;\nuniform vec4 color1;\nuniform vec4 color2;\nuniform vec4 color3;\nuniform vec4 color4;\nuniform float radius, outline;\n\nfloat roundedSDF(vec2 centerPos, vec2 size, float radius) {\n    return length(max(abs(centerPos) - size, 0.0)) - radius;\n}\n\nvec4 createGradient(vec2 pos) {\n    return mix(mix(color1, color2, pos.y), mix(color3, color4, pos.y), pos.x);\n}\n\nvoid main() {\n    vec2 texCoord = gl_TexCoord[0].st;\n    vec2 centerPos = (rectSize * 0.5) - (texCoord * rectSize);\n    vec2 size = (rectSize * 0.5) - radius - 1.0;\n\n    float distance = roundedSDF(centerPos, size, radius);\n    float blendAmount = abs(distance) - (outline * 0.5);\n\n    vec4 gradient = createGradient(texCoord);\n    vec4 insideColor = vec4(0.0, 0.0, 0.0, 0.0);\n\n    gl_FragColor = mix(gradient, insideColor, blendAmount);\n}\n\n\n";
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\shaders\list\Outline.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */