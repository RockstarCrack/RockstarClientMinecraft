/*    */ package fun.rockstarity.api.render.scannable.shader;
/*    */ 
/*    */ import net.minecraft.client.shader.ShaderDefault;
/*    */ import net.minecraft.util.math.vector.Matrix4f;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ScanResultShader
/*    */   extends AbstractShader
/*    */ {
/* 12 */   public static ScanResultShader INSTANCE = new ScanResultShader();
/*    */   private static ShaderDefault projMatUniform;
/*    */   private static ShaderDefault viewMatUniform;
/*    */   
/*    */   public static void setProjectionMatrix(Matrix4f matrix) {
/* 17 */     projMatUniform.set(matrix);
/*    */   }
/*    */   
/*    */   public static void setViewMatrix(Matrix4f matrix) {
/* 21 */     viewMatUniform.set(matrix);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShaderName() {
/* 26 */     return "scan_result";
/*    */   }
/*    */ 
/*    */   
/*    */   public AbstractShader.Shader shader() {
/* 31 */     return AbstractShader.Shader.SCAN_RESULT;
/*    */   }
/*    */ 
/*    */   
/*    */   public void handleShaderLoad() {
/* 36 */     super.handleShaderLoad();
/* 37 */     projMatUniform = this.shaderInstance.safeGetUniform("projMat");
/* 38 */     viewMatUniform = this.shaderInstance.safeGetUniform("viewMat");
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\scannable\shader\ScanResultShader.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */