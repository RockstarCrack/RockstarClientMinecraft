/*    */ package fun.rockstarity.api.render.scannable.shader;
/*    */ 
/*    */ import net.minecraft.client.shader.ShaderDefault;
/*    */ import net.minecraft.util.math.vector.Matrix4f;
/*    */ import net.minecraft.util.math.vector.Vector3d;
/*    */ import net.minecraft.util.math.vector.Vector4f;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ScanEffectShader
/*    */   extends AbstractShader
/*    */ {
/* 14 */   public static final ScanEffectShader INSTANCE = new ScanEffectShader();
/*    */   private ShaderDefault inverseViewMatrixUniform;
/*    */   private ShaderDefault inverseProjectionMatrixUniform;
/*    */   private ShaderDefault positionUniform;
/*    */   private ShaderDefault centerUniform;
/*    */   private ShaderDefault outerColorUniform;
/*    */   private ShaderDefault midColorUniform;
/*    */   private ShaderDefault innerColorUniform;
/*    */   private ShaderDefault scanlineColorUniform;
/*    */   private ShaderDefault radiusUniform;
/*    */   
/*    */   public void setInverseViewMatrix(Matrix4f value) {
/* 26 */     this.inverseViewMatrixUniform.set(value);
/*    */   }
/*    */   
/*    */   public void setInverseProjectionMatrix(Matrix4f value) {
/* 30 */     this.inverseProjectionMatrixUniform.set(value);
/*    */   }
/*    */   
/*    */   public void setPosition(Vector3d value) {
/* 34 */     this.positionUniform.set((float)value.x, (float)value.y, (float)value.z);
/*    */   }
/*    */   
/*    */   public void setCenter(Vector3d value) {
/* 38 */     this.centerUniform.set((float)value.x, (float)value.y, (float)value.z);
/*    */   }
/*    */   
/*    */   public void setOuterColor(Vector4f value) {
/* 42 */     this.outerColorUniform.set(value.getX(), value.getY(), value.getZ(), value.getW());
/*    */   }
/*    */   
/*    */   public void setMidColor(Vector4f value) {
/* 46 */     this.midColorUniform.set(value.getX(), value.getY(), value.getZ(), value.getW());
/*    */   }
/*    */   
/*    */   public void setInnerColor(Vector4f value) {
/* 50 */     this.innerColorUniform.set(value.getX(), value.getY(), value.getZ(), value.getW());
/*    */   }
/*    */   
/*    */   public void setScanlineColor(Vector4f value) {
/* 54 */     this.scanlineColorUniform.set(value.getX(), value.getY(), value.getZ(), value.getW());
/*    */   }
/*    */   
/*    */   public void setRadius(float value) {
/* 58 */     this.radiusUniform.set(value);
/*    */   }
/*    */   
/*    */   public void setDepthBuffer(int buffer) {
/* 62 */     this.shaderInstance.setSampler("depthTex", () -> buffer);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getShaderName() {
/* 67 */     return "scan_effect";
/*    */   }
/*    */ 
/*    */   
/*    */   public AbstractShader.Shader shader() {
/* 72 */     return AbstractShader.Shader.SCAN_EFFECT;
/*    */   }
/*    */ 
/*    */   
/*    */   public void handleShaderLoad() {
/* 77 */     super.handleShaderLoad();
/* 78 */     this.inverseViewMatrixUniform = this.shaderInstance.safeGetUniform("invViewMat");
/* 79 */     this.inverseProjectionMatrixUniform = this.shaderInstance.safeGetUniform("invProjMat");
/* 80 */     this.positionUniform = this.shaderInstance.safeGetUniform("pos");
/* 81 */     this.centerUniform = this.shaderInstance.safeGetUniform("center");
/* 82 */     this.outerColorUniform = this.shaderInstance.safeGetUniform("outerColor");
/* 83 */     this.midColorUniform = this.shaderInstance.safeGetUniform("midColor");
/* 84 */     this.innerColorUniform = this.shaderInstance.safeGetUniform("innerColor");
/* 85 */     this.scanlineColorUniform = this.shaderInstance.safeGetUniform("scanlineColor");
/* 86 */     this.radiusUniform = this.shaderInstance.safeGetUniform("radius");
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\scannable\shader\ScanEffectShader.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */