package fun.rockstarity.api.render.scannable;

public final class Constants {
  public static final int SCAN_INITIAL_RADIUS = 10;
  
  public static final int SCAN_TIME_OFFSET = 200;
  
  public static final int SCAN_GROWTH_DURATION = 2000;
  
  public static final int REFERENCE_RENDER_DISTANCE = 12;
  
  public static final int CHUNK_SIZE = 16;
}


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\scannable\Constants.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */