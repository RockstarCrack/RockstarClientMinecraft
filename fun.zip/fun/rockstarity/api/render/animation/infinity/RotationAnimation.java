/*    */ package fun.rockstarity.api.render.animation.infinity;
/*    */ 
/*    */ import fun.rockstarity.api.render.animation.Easing;
/*    */ import net.minecraft.util.math.vector.Vector2f;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RotationAnimation
/*    */ {
/* 18 */   private final InfinityAnimation yaw = new InfinityAnimation();
/* 19 */   private final InfinityAnimation pitch = new InfinityAnimation();
/*    */   
/*    */   public Vector2f animate(Vector2f rotation, int yawSpeed, int pitchSpeed) {
/* 22 */     return new Vector2f(this.yaw
/* 23 */         .animate(rotation.x, yawSpeed), this.pitch
/* 24 */         .animate(rotation.y, pitchSpeed));
/*    */   }
/*    */ 
/*    */   
/*    */   public float getYaw() {
/* 29 */     return this.yaw.get();
/*    */   }
/*    */   
/*    */   public float getPitch() {
/* 33 */     return this.pitch.get();
/*    */   }
/*    */   
/*    */   public RotationAnimation easing(Easing easing) {
/* 37 */     this.yaw.easing(easing);
/* 38 */     this.yaw.easing(easing);
/*    */     
/* 40 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\animation\infinity\RotationAnimation.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */