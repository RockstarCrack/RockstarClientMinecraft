/*    */ package fun.rockstarity.api.render.animation.infinity;
/*    */ 
/*    */ import fun.rockstarity.api.render.animation.Animation;
/*    */ import fun.rockstarity.api.render.animation.Easing;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InfinityAnimation
/*    */ {
/*    */   private float output;
/*    */   private float endpoint;
/* 15 */   private Easing easing = Easing.LINEAR;
/*    */   
/* 17 */   public Animation getAnimation() { return this.animation; } private Animation animation = (new Animation())
/* 18 */     .setSize(0.0F).setSpeed(0).setForward(false).setEasing(this.easing);
/*    */   
/*    */   public float animate(float destination, int ms) {
/* 21 */     ms = Math.max(1, ms);
/* 22 */     this.output = this.endpoint - this.animation.get();
/* 23 */     this.endpoint = destination;
/* 24 */     if (this.output != this.endpoint - destination) {
/* 25 */       this.animation = (new Animation()).setSize(this.endpoint - this.output).setSpeed(ms).setForward(false).setEasing(this.easing);
/*    */     }
/* 27 */     return this.output;
/*    */   }
/*    */   
/*    */   public boolean finished() {
/* 31 */     return (this.output == this.endpoint || this.animation.finished() || this.animation.finished(false));
/*    */   }
/*    */   
/*    */   public float get() {
/* 35 */     this.output = this.endpoint - this.animation.get();
/* 36 */     return this.output;
/*    */   }
/*    */   
/*    */   public InfinityAnimation easing(Easing easing) {
/* 40 */     this.easing = easing;
/*    */     
/* 42 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\animation\infinity\InfinityAnimation.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */