/*    */ package fun.rockstarity.api.render.animation.infinity;
/*    */ 
/*    */ import fun.rockstarity.api.render.color.FixColor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ColorAnimation
/*    */ {
/* 13 */   private final InfinityAnimation r = new InfinityAnimation();
/* 14 */   private final InfinityAnimation g = new InfinityAnimation();
/* 15 */   private final InfinityAnimation b = new InfinityAnimation();
/*    */   
/*    */   public FixColor animate(FixColor destination, int ms) {
/* 18 */     return new FixColor(this.r
/* 19 */         .animate(destination.getRed(), ms), this.g
/* 20 */         .animate(destination.getGreen(), ms), this.b
/* 21 */         .animate(destination.getBlue(), ms));
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\animation\infinity\ColorAnimation.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */