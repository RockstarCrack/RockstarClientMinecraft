/*    */ package fun.rockstarity.api.render.animation;
/*    */ 
/*    */ import fun.rockstarity.api.helpers.math.TimerUtility;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Animation
/*    */ {
/* 12 */   private final TimerUtility timer = new TimerUtility(); private int speed; public TimerUtility getTimer() { return this.timer; } public int getSpeed() {
/* 13 */     return this.speed;
/* 14 */   } private boolean forward; private double size = 1.0D; private Easing easing; public double getSize() { return this.size; } public boolean isForward() {
/* 15 */     return this.forward;
/*    */   } public Easing getEasing() {
/* 17 */     return this.easing;
/*    */   }
/*    */   public boolean finished(boolean forward) {
/* 20 */     return (this.timer.passed(this.speed) && (forward ? this.forward : !this.forward));
/*    */   }
/*    */   
/*    */   public boolean finished() {
/* 24 */     return (this.timer.passed(this.speed) && this.forward);
/*    */   }
/*    */   
/*    */   public Animation setForward(boolean forward) {
/* 28 */     if (this.forward != forward) {
/* 29 */       this.forward = forward;
/* 30 */       this.timer.setStartTime((long)(System.currentTimeMillis() - this.size - Math.min(this.size, this.timer.getElapsed())));
/*    */     } 
/* 32 */     return this;
/*    */   }
/*    */   
/*    */   public Animation finish() {
/* 36 */     this.timer.setStartTime(System.currentTimeMillis() - this.speed);
/* 37 */     return this;
/*    */   }
/*    */   
/*    */   public Animation setEasing(Easing easing) {
/* 41 */     this.easing = easing;
/* 42 */     return this;
/*    */   }
/*    */   
/*    */   public Animation setSpeed(int speed) {
/* 46 */     this.speed = speed;
/* 47 */     return this;
/*    */   }
/*    */   
/*    */   public Animation setSize(float size) {
/* 51 */     this.size = size;
/* 52 */     return this;
/*    */   }
/*    */   
/*    */   public float getLinear() {
/* 56 */     if (this.forward) {
/* 57 */       if (this.timer.passed(this.speed)) {
/* 58 */         return (float)this.size;
/*    */       }
/*    */       
/* 61 */       return (float)(this.timer.getElapsed() / this.speed * this.size);
/*    */     } 
/* 63 */     if (this.timer.passed(this.speed)) {
/* 64 */       return 0.0F;
/*    */     }
/*    */     
/* 67 */     return (float)((1.0D - this.timer.getElapsed() / this.speed) * this.size);
/*    */   }
/*    */ 
/*    */   
/*    */   public float get() {
/* 72 */     if (this.forward) {
/* 73 */       if (this.timer.passed(this.speed)) {
/* 74 */         return (float)this.size;
/*    */       }
/*    */       
/* 77 */       return (float)(this.easing.apply(this.timer.getElapsed() / this.speed) * this.size);
/*    */     } 
/* 79 */     if (this.timer.passed(this.speed)) {
/* 80 */       return 0.0F;
/*    */     }
/*    */     
/* 83 */     return (float)((1.0D - this.easing.apply(this.timer.getElapsed() / this.speed)) * this.size);
/*    */   }
/*    */ 
/*    */   
/*    */   public float reversed() {
/* 88 */     return 1.0F - get();
/*    */   }
/*    */   
/*    */   public void reset() {
/* 92 */     this.timer.reset();
/*    */   }
/*    */   
/*    */   public void kuni() {
/* 96 */     if (finished()) {
/* 97 */       setForward(false);
/* 98 */     } else if (finished(false)) {
/* 99 */       setForward(true);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\animation\Animation.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */