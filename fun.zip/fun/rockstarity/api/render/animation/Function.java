package fun.rockstarity.api.render.animation;

public interface Function {
  double apply(double paramDouble);
}


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\animation\Function.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */