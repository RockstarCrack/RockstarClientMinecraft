/*    */ package fun.rockstarity.api.render.cursor;
/*    */ 
/*    */ public final class CursorUtility
/*    */ {
/*    */   private static boolean aimedHand;
/*    */   
/*    */   private CursorUtility() {
/*  8 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated"); }
/*  9 */   public static void setAimedHand(boolean aimedHand) { CursorUtility.aimedHand = aimedHand; } public static boolean isAimedHand() { return aimedHand; }
/*    */   
/* 11 */   private static CursorType current = CursorType.DEFAULT;
/*    */   
/*    */   public static void setType(CursorType type) {
/* 14 */     current = type;
/*    */   }
/*    */   
/*    */   public static CursorType getType() {
/* 18 */     return current;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\cursor\CursorUtility.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */