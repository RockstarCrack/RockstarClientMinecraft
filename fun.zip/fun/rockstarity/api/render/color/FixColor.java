/*     */ package fun.rockstarity.api.render.color;
/*     */ 
/*     */ import fun.rockstarity.api.helpers.math.MathUtility;
/*     */ import fun.rockstarity.api.render.animation.Animation;
/*     */ import fun.rockstarity.api.render.animation.Easing;
/*     */ import fun.rockstarity.api.scripts.wrappers.base.ColorBase;
/*     */ import java.awt.Color;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FixColor
/*     */   extends Color
/*     */ {
/*  19 */   public static final FixColor BLACK = new FixColor(0.0D, 0.0D, 0.0D);
/*  20 */   public static final FixColor WHITE = new FixColor(255.0D, 255.0D, 255.0D);
/*  21 */   public static final FixColor CYAN = new FixColor(0.0D, 255.0D, 255.0D);
/*  22 */   public static final FixColor RED = new FixColor(255.0D, 0.0D, 0.0D);
/*  23 */   public static final FixColor BLUE = new FixColor(0.0D, 0.0D, 255.0D);
/*  24 */   public static final FixColor YELLOW = new FixColor(255.0D, 255.0D, 0.0D);
/*  25 */   public static final FixColor GREEN = new FixColor(0.0D, 255.0D, 0.0D);
/*  26 */   public static final FixColor ORANGE = new FixColor(255.0D, 165.0D, 0.0D);
/*  27 */   public static final FixColor GRAY = new FixColor(128.0D, 128.0D, 128.0D);
/*  28 */   public static final FixColor TRANSPARENT = new FixColor(0.0D, 0.0D, 0.0D, 0.0D);
/*     */   
/*  30 */   public Animation getSelectAnim() { return this.selectAnim; } private final Animation selectAnim = (new Animation())
/*  31 */     .setEasing(Easing.BOTH_SINE).setSpeed(300);
/*     */   
/*     */   public FixColor(double r, double g, double b, double a) {
/*  34 */     super(fix(r), fix(g), fix(b), fix(a));
/*     */   }
/*     */   
/*     */   public FixColor(double r, double g, double b) {
/*  38 */     super(fix(r), fix(g), fix(b));
/*     */   }
/*     */   
/*     */   public FixColor(int hex) {
/*  42 */     super(hex);
/*     */   }
/*     */   
/*     */   public FixColor(ColorBase base) {
/*  46 */     super(base.getRed(), base.getGreen(), base.getBlue(), base.getAlpha());
/*     */   }
/*     */   
/*     */   public FixColor(Color color) {
/*  50 */     super(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
/*     */   }
/*     */   
/*     */   private static int fix(double val) {
/*  54 */     return (int)Math.max(0.0D, Math.min(255.0D, val));
/*     */   }
/*     */   
/*     */   public FixColor alpha(double alpha) {
/*  58 */     return new FixColor(getRed(), getGreen(), getBlue(), getAlpha() * alpha);
/*     */   }
/*     */   
/*     */   public FixColor darker(float FACTOR) {
/*  62 */     return new FixColor(fix((int)(getRed() - FACTOR * 255.0F)), 
/*  63 */         fix((int)(getGreen() - FACTOR * 255.0F)), 
/*  64 */         fix((int)(getBlue() - FACTOR * 255.0F)), 
/*  65 */         getAlpha());
/*     */   }
/*     */   
/*     */   public FixColor move(Color color2, float amount) {
/*  69 */     amount = Math.min(1.0F, Math.max(0.0F, amount));
/*  70 */     return new FixColor(MathUtility.interpolate(getRed(), color2.getRed(), amount), 
/*  71 */         MathUtility.interpolate(getGreen(), color2.getGreen(), amount), 
/*  72 */         MathUtility.interpolate(getBlue(), color2.getBlue(), amount), 
/*  73 */         MathUtility.interpolate(getAlpha(), color2.getAlpha(), amount));
/*     */   }
/*     */   
/*     */   public Color getColor() {
/*  77 */     return new Color(getRed(), getGreen(), getBlue(), getAlpha());
/*     */   }
/*     */   
/*     */   public FixColor brighter(float factor) {
/*  81 */     int r = getRed();
/*  82 */     int g = getGreen();
/*  83 */     int b = getBlue();
/*  84 */     int alpha = getAlpha();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  91 */     int i = (int)(1.0D / (1.0D - factor));
/*  92 */     if (r == 0 && g == 0 && b == 0) {
/*  93 */       return new FixColor(i, i, i, alpha);
/*     */     }
/*  95 */     if (r > 0 && r < i) r = i; 
/*  96 */     if (g > 0 && g < i) g = i; 
/*  97 */     if (b > 0 && b < i) b = i;
/*     */     
/*  99 */     return new FixColor(
/* 100 */         Math.min((int)(r / factor), 255), 
/* 101 */         Math.min((int)(g / factor), 255), 
/* 102 */         Math.min((int)(b / factor), 255), alpha);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float[] getRGBAf() {
/* 108 */     int r = getRed();
/* 109 */     int g = getGreen();
/* 110 */     int b = getBlue();
/* 111 */     int alpha = getAlpha();
/* 112 */     return new float[] { r / 255.0F, g / 255.0F, b / 255.0F, alpha / 255.0F };
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\color\FixColor.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */