/*    */ package fun.rockstarity.api.render.color.themes;
/*    */ 
/*    */ import fun.rockstarity.api.render.animation.Animation;
/*    */ import fun.rockstarity.api.render.animation.Easing;
/*    */ import fun.rockstarity.api.render.color.FixColor;
/*    */ 
/*    */ 
/*    */ public class Theme
/*    */ {
/*    */   private final String name;
/*    */   private final FixColor firstColor;
/*    */   private final FixColor secondColor;
/*    */   private final FixColor thirdColor;
/*    */   private final FixColor foursColor;
/*    */   private final FixColor textFirstColor;
/*    */   private final FixColor textSecondColor;
/*    */   
/*    */   public String getName() {
/* 19 */     return this.name;
/* 20 */   } public FixColor getFirstColor() { return this.firstColor; } public FixColor getSecondColor() { return this.secondColor; } public FixColor getThirdColor() { return this.thirdColor; } public FixColor getFoursColor() { return this.foursColor; } public FixColor getTextFirstColor() { return this.textFirstColor; } public FixColor getTextSecondColor() { return this.textSecondColor; }
/* 21 */    private final int id; private Animation selectAnimation = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); static int lastID; public Animation getSelectAnimation() { return this.selectAnimation; } public int getId() {
/* 22 */     return this.id;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Theme(String name, FixColor firstColor, FixColor secondColor, FixColor thirdColor, FixColor foursColor, FixColor textFirstColor, FixColor textSecondColor) {
/* 32 */     this.name = name;
/* 33 */     this.firstColor = firstColor;
/* 34 */     this.secondColor = secondColor;
/* 35 */     this.thirdColor = thirdColor;
/* 36 */     this.foursColor = foursColor;
/* 37 */     this.textFirstColor = textFirstColor;
/* 38 */     this.textSecondColor = textSecondColor;
/* 39 */     this.id = lastID++;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\color\themes\Theme.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */