/*    */ package fun.rockstarity.api.render.color.themes.list;
/*    */ 
/*    */ import fun.rockstarity.api.render.color.FixColor;
/*    */ import fun.rockstarity.api.render.color.themes.Theme;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LightTheme
/*    */   extends Theme
/*    */ {
/*    */   public LightTheme() {
/* 14 */     super("Светлая", new FixColor(246.0D, 249.0D, 255.0D), new FixColor(235.0D, 241.0D, 255.0D), new FixColor(230.0D, 236.0D, 246.0D), new FixColor(201.0D, 207.0D, 217.0D), FixColor.BLACK, new FixColor(104.0D, 104.0D, 104.0D));
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\color\themes\list\LightTheme.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */