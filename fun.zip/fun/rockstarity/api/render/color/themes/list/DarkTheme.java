/*    */ package fun.rockstarity.api.render.color.themes.list;
/*    */ 
/*    */ import fun.rockstarity.api.render.color.FixColor;
/*    */ import fun.rockstarity.api.render.color.themes.Theme;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DarkTheme
/*    */   extends Theme
/*    */ {
/*    */   public DarkTheme() {
/* 14 */     super("Темная", new FixColor(14.0D, 17.0D, 21.0D), new FixColor(19.0D, 21.0D, 27.0D), new FixColor(25.0D, 29.0D, 36.0D), new FixColor(68.0D, 65.0D, 77.0D), new FixColor(255.0D, 255.0D, 255.0D), new FixColor(184.0D, 184.0D, 184.0D));
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\color\themes\list\DarkTheme.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */