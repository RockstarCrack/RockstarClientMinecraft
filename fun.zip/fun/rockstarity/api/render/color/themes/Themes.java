/*    */ package fun.rockstarity.api.render.color.themes;
/*    */ 
/*    */ import fun.rockstarity.api.render.animation.infinity.ColorAnimation;
/*    */ import fun.rockstarity.api.render.color.FixColor;
/*    */ import fun.rockstarity.api.render.color.themes.list.DarkTheme;
/*    */ import fun.rockstarity.api.render.color.themes.list.LightTheme;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Themes
/*    */   extends ArrayList<Theme>
/*    */ {
/* 27 */   private Theme lightTheme = (Theme)new LightTheme(); public Theme getLightTheme() { return this.lightTheme; }
/* 28 */    private Theme darkTheme = (Theme)new DarkTheme(); public Theme getDarkTheme() { return this.darkTheme; }
/*    */   
/* 30 */   private static final int SPEED = 50; public Theme current = this.darkTheme; public void setCurrent(Theme current) { this.current = current; } public Theme getCurrent() {
/* 31 */     return this.current;
/*    */   }
/*    */ 
/*    */   
/* 35 */   private final ColorAnimation firstColor = new ColorAnimation();
/* 36 */   private final ColorAnimation secondColor = new ColorAnimation();
/* 37 */   private final ColorAnimation thirdColor = new ColorAnimation();
/* 38 */   private final ColorAnimation foursColor = new ColorAnimation();
/* 39 */   private final ColorAnimation textFirstColor = new ColorAnimation();
/* 40 */   private final ColorAnimation textSecondColor = new ColorAnimation();
/*    */   
/*    */   public Themes() {
/* 43 */     Arrays.<Theme>stream(new Theme[] { this.lightTheme, this.darkTheme
/*    */ 
/*    */         
/* 46 */         }).forEach(this::add);
/*    */   }
/*    */   
/*    */   public String getName() {
/* 50 */     return this.current.getName();
/*    */   }
/*    */   
/*    */   public FixColor getFirstColor() {
/* 54 */     return this.firstColor.animate(this.current.getFirstColor(), 50);
/*    */   }
/*    */   
/*    */   public FixColor getSecondColor() {
/* 58 */     return this.secondColor.animate(this.current.getSecondColor(), 50);
/*    */   }
/*    */   
/*    */   public FixColor getThirdColor() {
/* 62 */     return this.thirdColor.animate(this.current.getThirdColor(), 50);
/*    */   }
/*    */   public FixColor getFoursColor() {
/* 65 */     return this.foursColor.animate(this.current.getFoursColor(), 50);
/*    */   }
/*    */   
/*    */   public FixColor getTextFirstColor() {
/* 69 */     return this.textFirstColor.animate(this.current.getTextFirstColor(), 250);
/*    */   }
/*    */   
/*    */   public FixColor getTextSecondColor() {
/* 73 */     return this.textSecondColor.animate(this.current.getTextSecondColor(), 250);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\color\themes\Themes.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */