/*    */ package fun.rockstarity.api.render.color.themes;
/*    */ 
/*    */ import fun.rockstarity.Rockstar;
/*    */ import fun.rockstarity.api.helpers.render.ColorUtility;
/*    */ import fun.rockstarity.api.render.animation.Animation;
/*    */ import fun.rockstarity.api.render.animation.Easing;
/*    */ import fun.rockstarity.api.render.animation.infinity.InfinityAnimation;
/*    */ import fun.rockstarity.api.render.color.FixColor;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Style
/*    */ {
/*    */   public static Style getCurrent() {
/* 31 */     return current; } public static void setCurrent(Style current) { Style.current = current; }
/* 32 */    public static Style current = new Style("Loading", new FixColor[] { new FixColor(124.0D, 146.0D, 223.0D), new FixColor(86.0D, 102.0D, 220.0D) });
/*    */   public static ArrayList<Style> getStyles() {
/* 34 */     return styles;
/* 35 */   } private static ArrayList<Style> styles = new ArrayList<>();
/*    */   
/*    */   public static ArrayList<Style> values() {
/* 38 */     return styles;
/*    */   }
/*    */   
/*    */   public static FixColor getMain() {
/* 42 */     return ColorUtility.gradient(10, 1, current.getColors());
/*    */   }
/*    */   
/*    */   public static FixColor getSecond() {
/* 46 */     return ColorUtility.gradient(10, 50, current.getColors());
/*    */   }
/*    */   
/*    */   public static FixColor getPoint(int point) {
/* 50 */     return ColorUtility.gradient(10, point, current.getColors());
/*    */   }
/*    */   
/*    */   public static FixColor getOutlinePoint(int point) {
/* 54 */     return ColorUtility.gradient(10, point, new FixColor[] { current
/* 55 */           .getColors()[0], 
/* 56 */           Rockstar.getInstance().getThemes().getFirstColor(), current
/* 57 */           .getColors()[1], 
/* 58 */           Rockstar.getInstance().getThemes().getFirstColor() });
/*    */   }
/*    */ 
/*    */   
/* 62 */   private static InfinityAnimation circleAnim = new InfinityAnimation(); private final String name; private final FixColor[] colors;
/*    */   
/*    */   public static FixColor[] getCircle() {
/* 65 */     return getCircle(1.0F);
/*    */   }
/*    */   
/*    */   public static FixColor[] getCircle(float alpha) {
/* 69 */     circleAnim.animate((float)System.currentTimeMillis() / 1000.0F, 50);
/* 70 */     int val = (int)circleAnim.get();
/* 71 */     return new FixColor[] {
/* 72 */         getPoint(val).alpha(alpha), 
/* 73 */         getPoint(val + 90).alpha(alpha), 
/* 74 */         getPoint(val + 180).alpha(alpha), 
/* 75 */         getPoint(val + 270).alpha(alpha) };
/*    */   }
/*    */   
/*    */   public String getName() {
/* 79 */     return this.name; } public FixColor[] getColors() {
/* 80 */     return this.colors;
/* 81 */   } private Animation selectAnimation = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); public Animation getSelectAnimation() { return this.selectAnimation; }
/*    */   
/*    */   public Style(String name, FixColor[] colors) {
/* 84 */     this.name = name;
/* 85 */     this.colors = colors;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\color\themes\Style.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */