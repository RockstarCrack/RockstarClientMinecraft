/*     */ package fun.rockstarity.api.render.menufilter;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.helpers.render.Render;
/*     */ import fun.rockstarity.api.render.animation.Animation;
/*     */ import fun.rockstarity.api.render.animation.Easing;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.color.themes.Style;
/*     */ import net.minecraft.client.renderer.BufferBuilder;
/*     */ import net.minecraft.util.math.vector.Matrix4f;
/*     */ import net.minecraft.util.math.vector.Vector3d;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Quad
/*     */ {
/*     */   Vector3d pos;
/*     */   final Animation showing;
/*     */   
/*     */   public Quad(Vector3d pos) {
/* 153 */     this.showing = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300);
/*     */     this.pos = pos;
/*     */   } void draw(MatrixStack ms, BufferBuilder builder) {
/* 156 */     float place = 20.0F * MenuFilter.showing.get();
/* 157 */     double dist = IAccess.mc.player.getPositionVec().distanceTo(this.pos);
/* 158 */     this.showing.setForward((MenuFilter.showing.isForward() && !MenuFilter.showing.finished() && dist + 3.0D > place && dist + 2.0D < place));
/*     */     
/* 160 */     if (this.showing.finished(false))
/*     */       return; 
/* 162 */     FixColor color = Style.getPoint(MenuFilter.quads.indexOf(this) * 50).alpha((this.showing.get() * (1.0F - MenuFilter.showing.get() * MenuFilter.showing.get())));
/*     */ 
/*     */     
/* 165 */     ms.push();
/* 166 */     Matrix4f matrix = ms.getLast().getMatrix();
/* 167 */     float size = 1.0F;
/*     */     
/* 169 */     ms.translate(this.pos.sub(Render.cameraPos()));
/*     */     
/* 171 */     builder.pos(matrix, 0.0F, 0.0F, 0.0F).color(color).endVertex();
/* 172 */     builder.pos(matrix, 0.0F, 0.0F, size).color(color).endVertex();
/* 173 */     builder.pos(matrix, size, 0.0F, size).color(color).endVertex();
/* 174 */     builder.pos(matrix, size, 0.0F, 0.0F).color(color).endVertex();
/*     */     
/* 176 */     ms.pop();
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\menufilter\MenuFilter$Quad.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */