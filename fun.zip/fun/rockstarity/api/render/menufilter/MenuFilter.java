/*     */ package fun.rockstarity.api.render.menufilter;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.events.Event;
/*     */ import fun.rockstarity.api.events.list.render.EventRender3D;
/*     */ import fun.rockstarity.api.events.list.render.world.EventFogColor;
/*     */ import fun.rockstarity.api.events.list.render.world.EventFogDistance;
/*     */ import fun.rockstarity.api.events.list.render.world.EventFov;
/*     */ import fun.rockstarity.api.events.list.render.world.EventStarsColor;
/*     */ import fun.rockstarity.api.helpers.math.MathUtility;
/*     */ import fun.rockstarity.api.helpers.render.Render;
/*     */ import fun.rockstarity.api.render.animation.Animation;
/*     */ import fun.rockstarity.api.render.animation.Easing;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.color.themes.Style;
/*     */ import fun.rockstarity.client.modules.render.ClickGui;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Blocks;
/*     */ import net.minecraft.client.renderer.BufferBuilder;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*     */ import net.minecraft.util.math.vector.Matrix4f;
/*     */ import net.minecraft.util.math.vector.Vector3d;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MenuFilter
/*     */   implements IAccess
/*     */ {
/*     */   private MenuFilter() {
/*  42 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*     */   }
/*  44 */   private static final Animation showing = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300);
/*  45 */   private static final List<Quad> quads = new ArrayList<>();
/*     */   
/*     */   public static void onEvent(Event event) {
/*  48 */     if (showing.finished(false))
/*     */       return; 
/*  50 */     if (event instanceof EventRender3D) { EventRender3D e = (EventRender3D)event;
/*  51 */       GL11.glPushAttrib(1048575);
/*  52 */       GL11.glPushMatrix();
/*     */       
/*  54 */       MatrixStack ms = e.getMatrixStack();
/*     */       
/*  56 */       RenderSystem.enableBlend();
/*  57 */       RenderSystem.disableTexture();
/*  58 */       GlStateManager.blendFunc(770, 1);
/*     */       
/*  60 */       GL11.glDepthMask(false);
/*  61 */       GlStateManager.enableBlend();
/*  62 */       GlStateManager.blendFunc(770, 1);
/*  63 */       GL11.glShadeModel(7425);
/*  64 */       GL11.glAlphaFunc(516, 0.0F);
/*     */       
/*  66 */       Tessellator tessellator = Tessellator.getInstance();
/*  67 */       BufferBuilder builder = tessellator.getBuffer();
/*  68 */       builder.begin(7, DefaultVertexFormats.POSITION_COLOR);
/*     */       
/*  70 */       Matrix4f matrix = ms.getLast().getMatrix();
/*     */       
/*  72 */       for (Quad quad : quads) {
/*  73 */         quad.draw(e.getMatrixStack(), builder);
/*     */       }
/*     */       
/*  76 */       tessellator.draw();
/*     */       
/*  78 */       GL11.glPopMatrix();
/*  79 */       GL11.glPopAttrib();
/*     */       
/*  81 */       RenderSystem.disableBlend();
/*  82 */       RenderSystem.enableTexture();
/*  83 */       Render.resetColor(); }
/*     */ 
/*     */ 
/*     */     
/*  87 */     if (event instanceof EventStarsColor) { EventStarsColor e = (EventStarsColor)event;
/*  88 */       e.setColor(e.getColor().move((Color)FixColor.WHITE.alpha(0.10000000149011612D), showing.get()));
/*  89 */       e.cancel(); }
/*     */ 
/*     */     
/*  92 */     if (event instanceof EventFov) { EventFov e = (EventFov)event;
/*  93 */       e.setFov(Math.max(1.0F, e.getFov() - showing.get() * ((ClickGui)rock.getModules().get(ClickGui.class)).getZoom().get()));
/*  94 */       e.setCancel(true); }
/*     */ 
/*     */     
/*  97 */     if (event instanceof EventFogColor) { EventFogColor e = (EventFogColor)event;
/*  98 */       e.setColor(e.getColor().move((Color)FixColor.BLACK, showing.get())); }
/*     */ 
/*     */     
/* 101 */     if (event instanceof EventFogDistance) { EventFogDistance e = (EventFogDistance)event;
/* 102 */       e.setInner(MathUtility.interpolate(e.getInner(), 0.0D, showing.get()));
/* 103 */       e.setOuter(MathUtility.interpolate(e.getOuter(), 5.0D, showing.get())); }
/*     */   
/*     */   }
/*     */   
/*     */   public static void show(boolean show) {
/* 108 */     showing.setForward(show);
/*     */     
/* 110 */     if (show) {
/* 111 */       showing.setSpeed(500);
/* 112 */       showing.setEasing(Easing.EASE_OUT_CIRC);
/*     */       
/* 114 */       quads.clear();
/*     */       
/* 116 */       float place = 30.0F;
/* 117 */       float size = 1.0F;
/* 118 */       float gap = 0.1F;
/*     */       
/* 120 */       float yOffset = (float)(mc.player.getPositionVec()).y;
/*     */       
/* 122 */       for (int i = 0; i < 5; i++) {
/* 123 */         if (mc.world.getBlock(mc.player.getPosition().add(0, -i, 0)) != Blocks.AIR) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 129 */           yOffset = i;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */       float x;
/* 134 */       for (x = -place; x < place; x += size + gap) {
/* 135 */         float z; for (z = -place; z < place; z += size + gap) {
/* 136 */           Vector3d pos = mc.player.getPositionVec().add(x, (-yOffset + 1.001F), z);
/* 137 */           Quad quad = new Quad(pos);
/* 138 */           quads.add(quad);
/* 139 */           quad.showing.finish();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean active() {
/* 146 */     return showing.isForward();
/*     */   }
/*     */   
/*     */   static class Quad { Vector3d pos;
/*     */     final Animation showing;
/*     */     
/*     */     public Quad(Vector3d pos) {
/* 153 */       this.showing = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300);
/*     */       this.pos = pos;
/*     */     } void draw(MatrixStack ms, BufferBuilder builder) {
/* 156 */       float place = 20.0F * MenuFilter.showing.get();
/* 157 */       double dist = IAccess.mc.player.getPositionVec().distanceTo(this.pos);
/* 158 */       this.showing.setForward((MenuFilter.showing.isForward() && !MenuFilter.showing.finished() && dist + 3.0D > place && dist + 2.0D < place));
/*     */       
/* 160 */       if (this.showing.finished(false))
/*     */         return; 
/* 162 */       FixColor color = Style.getPoint(MenuFilter.quads.indexOf(this) * 50).alpha((this.showing.get() * (1.0F - MenuFilter.showing.get() * MenuFilter.showing.get())));
/*     */ 
/*     */       
/* 165 */       ms.push();
/* 166 */       Matrix4f matrix = ms.getLast().getMatrix();
/* 167 */       float size = 1.0F;
/*     */       
/* 169 */       ms.translate(this.pos.sub(Render.cameraPos()));
/*     */       
/* 171 */       builder.pos(matrix, 0.0F, 0.0F, 0.0F).color(color).endVertex();
/* 172 */       builder.pos(matrix, 0.0F, 0.0F, size).color(color).endVertex();
/* 173 */       builder.pos(matrix, size, 0.0F, size).color(color).endVertex();
/* 174 */       builder.pos(matrix, size, 0.0F, 0.0F).color(color).endVertex();
/*     */       
/* 176 */       ms.pop();
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\menufilter\MenuFilter.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */