/*     */ package fun.rockstarity.api.render.models.taksa;
/*     */ 
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.helpers.game.Chat;
/*     */ import fun.rockstarity.api.helpers.player.Move;
/*     */ import fun.rockstarity.api.helpers.system.ThreadManager;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import org.apache.http.HttpEntity;
/*     */ import org.apache.http.client.methods.CloseableHttpResponse;
/*     */ import org.apache.http.client.methods.HttpPost;
/*     */ import org.apache.http.client.methods.HttpUriRequest;
/*     */ import org.apache.http.entity.StringEntity;
/*     */ import org.apache.http.impl.client.CloseableHttpClient;
/*     */ import org.apache.http.impl.client.HttpClients;
/*     */ import org.json.JSONArray;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TaksaAI
/*     */   implements IAccess
/*     */ {
/*     */   static String lastMsg;
/*     */   
/*     */   private TaksaAI() {
/*  32 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*     */   } public static void setLastMsg(String lastMsg) {
/*  34 */     TaksaAI.lastMsg = lastMsg;
/*  35 */   } static String apiKey = "tHrnYE2zr5kcMQ4zzzo7qTslTD9vrjcS";
/*     */   public static String gen(String args) {
/*     */     
/*  38 */     try { CloseableHttpClient httpClient = HttpClients.createDefault(); 
/*  39 */       try { HttpPost postRequest = new HttpPost("https://api.mistral.ai/v1/agents/completions");
/*     */ 
/*     */         
/*  42 */         postRequest.setHeader("Content-Type", "application/json; charset=UTF-8");
/*  43 */         postRequest.setHeader("Accept", "application/json; charset=UTF-8");
/*  44 */         postRequest.setHeader("Authorization", "Bearer " + apiKey);
/*     */ 
/*     */         
/*  47 */         JSONObject requestBody = new JSONObject();
/*  48 */         requestBody.put("agent_id", "ag:5a868f4e:20250423:taksa-ai:840782a8");
/*     */         
/*  50 */         JSONArray messages = new JSONArray();
/*  51 */         JSONObject message = new JSONObject();
/*     */ 
/*     */         
/*  54 */         String userContent = (args != null) ? args : "";
/*  55 */         message.put("role", "user");
/*  56 */         message.put("content", userContent);
/*     */         
/*  58 */         messages.put(message);
/*  59 */         requestBody.put("messages", messages);
/*     */ 
/*     */         
/*  62 */         postRequest.setEntity((HttpEntity)new StringEntity(requestBody.toString(), StandardCharsets.UTF_8));
/*     */ 
/*     */         
/*  65 */         CloseableHttpResponse response = httpClient.execute((HttpUriRequest)postRequest); 
/*  66 */         try { InputStream content = response.getEntity().getContent();
/*  67 */           String result = (new BufferedReader(new InputStreamReader(content))).lines().collect(Collectors.joining("\n"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  73 */           String answer = (new JSONObject(result)).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content");
/*     */           
/*  75 */           String str1 = answer;
/*  76 */           if (response != null) response.close(); 
/*  77 */           if (httpClient != null) httpClient.close();  return str1; } catch (Throwable throwable) { if (response != null) try { response.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Throwable throwable) { if (httpClient != null) try { httpClient.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Exception e)
/*  78 */     { e.printStackTrace();
/*     */ 
/*     */       
/*  81 */       return ""; }
/*     */   
/*     */   }
/*     */   public static String args() {
/*  85 */     List<String> args = new ArrayList<>();
/*     */     
/*  87 */     if (mc.player.isSneaking()) {
/*  88 */       args.add("Игрок на шифте");
/*     */     }
/*  90 */     if (Move.isMoving()) {
/*  91 */       args.add("Игрок двигается");
/*     */     } else {
/*  93 */       args.add("Игрок стоит");
/*     */     } 
/*  95 */     if (mc.player.hurtTime > 0) {
/*  96 */       args.add("Игрок получает урон");
/*     */     }
/*  98 */     if (mc.player.isSwimming()) {
/*  99 */       args.add("Игрок плавает");
/*     */     }
/* 101 */     if (mc.player.isElytraFlying()) {
/* 102 */       args.add("Игрок летит на элитрах");
/*     */     }
/* 104 */     if (mc.player.isOnGround()) {
/* 105 */       args.add("Игрок на земле");
/*     */     }
/* 107 */     if (mc.player.isHandActive()) {
/* 108 */       args.add("Игрок использует " + mc.player.getHeldItem(mc.player.getActiveHand()).getDisplayName().getString());
/*     */     }
/* 110 */     if (lastMsg != null && !lastMsg.isEmpty()) {
/* 111 */       args.add("Последнее сообщение от хозяина: " + lastMsg);
/*     */     }
/* 113 */     return String.join("\n", (Iterable)args);
/*     */   }
/*     */   
/*     */   public static void update() {
/* 117 */     TaksaScheduler.getUpdateTimer().reset();
/*     */     
/* 119 */     ThreadManager.run(() -> {
/*     */           Chat.msg("Такса", gen(args()));
/*     */           lastMsg = "";
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\models\taksa\TaksaAI.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */