/*     */ package fun.rockstarity.api.render.models.taksa;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import com.mojang.blaze3d.vertex.IVertexBuilder;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.events.list.render.world.EventRenderWorldEntities;
/*     */ import java.util.function.Function;
/*     */ import net.minecraft.client.renderer.RenderType;
/*     */ import net.minecraft.client.renderer.entity.PlayerRenderer;
/*     */ import net.minecraft.client.renderer.entity.model.IHasArm;
/*     */ import net.minecraft.client.renderer.entity.model.IHasHead;
/*     */ import net.minecraft.client.renderer.model.Model;
/*     */ import net.minecraft.client.renderer.model.ModelRenderer;
/*     */ import net.minecraft.client.renderer.texture.OverlayTexture;
/*     */ import net.minecraft.util.HandSide;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.vector.Vector3f;
/*     */ import net.optifine.DynamicLights;
/*     */ 
/*     */ 
/*     */ public class TaksaModel
/*     */   extends Model
/*     */   implements IHasArm, IHasHead, IAccess
/*     */ {
/*     */   public ModelRenderer head;
/*     */   public ModelRenderer body;
/*     */   public ModelRenderer neck;
/*     */   public ModelRenderer chest;
/*     */   public ModelRenderer back;
/*     */   public ModelRenderer frontLeftLeg;
/*     */   public ModelRenderer frontRightLeg;
/*     */   public ModelRenderer leftBackLeg;
/*     */   public ModelRenderer rightBackLeg;
/*     */   public ModelRenderer tail;
/*     */   public ModelRenderer leftEar;
/*     */   public ModelRenderer rightEar;
/*     */   
/*     */   public TaksaModel(Function<ResourceLocation, RenderType> renderTypeIn) {
/*  40 */     super(renderTypeIn);
/*  41 */     this.textureWidth = 60;
/*  42 */     this.textureHeight = 36;
/*     */ 
/*     */     
/*  45 */     this.head = new ModelRenderer(this);
/*  46 */     this.head.setRotationPoint(0.0F, 10.5F, -6.8F);
/*  47 */     this.head.setTextureOffset(0, 0).addBox(-3.0F, -3.0F, -4.0F, 6.0F, 6.0F, 4.0F, 0.0F);
/*  48 */     this.head.setTextureOffset(21, 0).addBox(-1.5F, 0.0F, -7.0F, 3.0F, 3.0F, 3.0F, 0.0F);
/*     */ 
/*     */     
/*  51 */     this.leftEar = new ModelRenderer(this);
/*  52 */     this.leftEar.setRotationPoint(3.0F, 3.0F, -2.0F);
/*  53 */     this.leftEar.setTextureOffset(32, 4).addBox(0.0F, -5.0F, -1.5F, 1.0F, 3.0F, 3.0F, 0.0F);
/*  54 */     this.leftEar.setTextureOffset(34, 1).addBox(0.0F, -5.5F, -0.75F, 1.0F, 1.0F, 1.5F, 0.0F);
/*  55 */     this.head.addChild(this.leftEar);
/*     */ 
/*     */     
/*  58 */     this.rightEar = new ModelRenderer(this);
/*  59 */     this.rightEar.setRotationPoint(-3.0F, 3.0F, -2.0F);
/*  60 */     this.rightEar.setTextureOffset(32, 4).addBox(-1.0F, -5.0F, -1.5F, 1.0F, 3.0F, 3.0F, 0.0F);
/*  61 */     this.rightEar.setTextureOffset(34, 1).addBox(-1.0F, -5.5F, -0.75F, 1.0F, 1.0F, 1.5F, 0.0F);
/*  62 */     this.head.addChild(this.rightEar);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  69 */     this.neck = new ModelRenderer(this);
/*  70 */     this.neck.setRotationPoint(0.0F, 10.5F, -5.0F);
/*  71 */     this.neck.rotateAngleX = -0.43633232F;
/*  72 */     this.neck.setTextureOffset(15, 7).addBox(-2.95F, -1.0F, -4.0F, 5.9F, 5.0F, 6.0F, 0.0F);
/*     */ 
/*     */     
/*  75 */     this.body = new ModelRenderer(this);
/*  76 */     this.body.setRotationPoint(0.0F, 13.5F, -5.0F);
/*     */ 
/*     */     
/*  79 */     this.chest = new ModelRenderer(this);
/*  80 */     this.chest.setRotationPoint(0.0F, 0.0F, 3.0F);
/*  81 */     this.chest.setTextureOffset(32, 13).addBox(-4.0F, -3.5F, -3.0F, 8.0F, 7.0F, 6.0F, 0.0F);
/*  82 */     this.body.addChild(this.chest);
/*     */ 
/*     */     
/*  85 */     this.back = new ModelRenderer(this);
/*  86 */     this.back.setRotationPoint(0.0F, -0.5F, 5.5F);
/*  87 */     this.back.setTextureOffset(3, 19).addBox(-3.0F, -3.0F, -0.5F, 6.0F, 6.0F, 11.0F, 0.0F);
/*  88 */     this.body.addChild(this.back);
/*     */ 
/*     */     
/*  91 */     this.frontLeftLeg = new ModelRenderer(this);
/*  92 */     this.frontLeftLeg.setRotationPoint(1.5F, 16.0F, -3.0F);
/*  93 */     this.frontLeftLeg.setTextureOffset(42, 0).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 5.0F, 2.0F, 0.0F);
/*     */ 
/*     */     
/*  96 */     this.frontRightLeg = new ModelRenderer(this);
/*  97 */     this.frontRightLeg.setRotationPoint(-1.5F, 16.0F, -3.0F);
/*  98 */     this.frontRightLeg.setTextureOffset(42, 0).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 5.0F, 2.0F, 0.0F);
/*  99 */     this.frontRightLeg.mirror = true;
/*     */ 
/*     */     
/* 102 */     this.leftBackLeg = new ModelRenderer(this);
/* 103 */     this.leftBackLeg.setRotationPoint(1.5F, 16.0F, 9.0F);
/* 104 */     this.leftBackLeg.setTextureOffset(52, 0).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 5.0F, 2.0F, 0.0F);
/*     */ 
/*     */     
/* 107 */     this.rightBackLeg = new ModelRenderer(this);
/* 108 */     this.rightBackLeg.setRotationPoint(-1.5F, 16.0F, 9.0F);
/* 109 */     this.rightBackLeg.setTextureOffset(52, 0).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 5.0F, 2.0F, 0.0F);
/* 110 */     this.rightBackLeg.mirror = true;
/*     */ 
/*     */     
/* 113 */     this.tail = new ModelRenderer(this);
/* 114 */     this.tail.setRotationPoint(0.0F, 9.0F, 10.0F);
/* 115 */     this.tail.rotateAngleX = 0.3926991F;
/* 116 */     this.tail.setTextureOffset(2, 12).addBox(-1.0F, 2.0F, -1.0F, 2.0F, 8.0F, 2.0F, 0.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRotationAngles(float ageInTicks, TaksaBrain brain) {
/* 177 */     this.head.rotateAngleY = brain.getYaw() * 0.017453292F;
/* 178 */     this.head.rotateAngleX = brain.getPitch() * 0.017453292F;
/*     */ 
/*     */     
/* 181 */     this.frontLeftLeg.rotateAngleX = (float)Math.cos((brain.limbSwing * 0.6662F)) * 1.4F * brain.limbSwingAmount;
/* 182 */     this.frontRightLeg.rotateAngleX = (float)Math.cos((brain.limbSwing * 0.6662F + 3.1415927F)) * 1.4F * brain.limbSwingAmount;
/* 183 */     this.leftBackLeg.rotateAngleX = (float)Math.cos((brain.limbSwing * 0.6662F + 3.1415927F)) * 1.4F * brain.limbSwingAmount;
/* 184 */     this.rightBackLeg.rotateAngleX = (float)Math.cos((brain.limbSwing * 0.6662F)) * 1.4F * brain.limbSwingAmount;
/*     */     
/* 186 */     if (brain.isLay()) {
/* 187 */       this.frontLeftLeg.rotateAngleX = (float)Math.toRadians(-90.0D);
/* 188 */       this.frontRightLeg.rotateAngleX = (float)Math.toRadians(-90.0D);
/* 189 */       this.leftBackLeg.rotateAngleX = (float)Math.toRadians(90.0D);
/* 190 */       this.rightBackLeg.rotateAngleX = (float)Math.toRadians(90.0D);
/*     */       
/* 192 */       this.frontLeftLeg.rotateAngleY = (float)Math.toRadians(-22.0D);
/* 193 */       this.frontRightLeg.rotateAngleY = (float)Math.toRadians(22.0D);
/* 194 */       this.leftBackLeg.rotateAngleY = (float)Math.toRadians(22.0D);
/* 195 */       this.rightBackLeg.rotateAngleY = (float)Math.toRadians(-22.0D);
/*     */     } else {
/* 197 */       this.frontLeftLeg.rotateAngleY = (float)Math.toRadians(0.0D);
/* 198 */       this.frontRightLeg.rotateAngleY = (float)Math.toRadians(0.0D);
/* 199 */       this.leftBackLeg.rotateAngleY = (float)Math.toRadians(0.0D);
/* 200 */       this.rightBackLeg.rotateAngleY = (float)Math.toRadians(0.0D);
/*     */     } 
/*     */     
/* 203 */     this.tail.rotateAngleX = (float)Math.toRadians(brain.isLay() ? 45.0D : 22.0D);
/*     */ 
/*     */     
/* 206 */     this.tail.rotateAngleZ = (float)(Math.toRadians(-22.5D) + 0.39269909262657166D + ((float)Math.cos((ageInTicks * 0.15F)) * 0.3F));
/*     */   }
/*     */ 
/*     */   
/*     */   public ModelRenderer getModelHead() {
/* 211 */     return this.head;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void translateHand(HandSide sideIn, MatrixStack matrixStackIn) {}
/*     */ 
/*     */   
/*     */   public void render(MatrixStack matrixStackIn, EventRenderWorldEntities e, TaksaBrain brain) {
/* 220 */     IVertexBuilder bufferIn = e.getVertex().getBuffer(RenderType.getEntityTranslucent(PlayerRenderer.taksaTexture));
/* 221 */     int packedLightIn = DynamicLights.getCombinedLight(new BlockPos(brain.getPos()), 999);
/* 222 */     int packedOverlayIn = OverlayTexture.NO_OVERLAY;
/*     */     
/* 224 */     matrixStackIn.push();
/* 225 */     matrixStackIn.translate(0.0D, (1.2F - (brain.isLay() ? 0.3F : 0.0F)), 0.0D);
/* 226 */     matrixStackIn.rotate(Vector3f.XP.rotationDegrees(180.0F));
/* 227 */     matrixStackIn.rotate(Vector3f.YP.rotationDegrees(brain.getBody()));
/* 228 */     this.head.render(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn);
/* 229 */     this.neck.render(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn);
/* 230 */     this.body.render(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn);
/* 231 */     this.frontLeftLeg.render(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn);
/* 232 */     this.frontRightLeg.render(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn);
/* 233 */     this.leftBackLeg.render(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn);
/* 234 */     this.rightBackLeg.render(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn);
/* 235 */     this.tail.render(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn);
/* 236 */     matrixStackIn.pop();
/*     */   }
/*     */   
/*     */   public void render(MatrixStack matrixStackIn, IVertexBuilder bufferIn, int packedLightIn, int packedOverlayIn, float red, float green, float blue, float alpha) {}
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\models\taksa\TaksaModel.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */