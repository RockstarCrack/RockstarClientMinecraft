/*     */ package fun.rockstarity.api.render.models.taksa;
/*     */ 
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.events.Event;
/*     */ import fun.rockstarity.api.helpers.math.MathUtility;
/*     */ import fun.rockstarity.api.helpers.math.TimerUtility;
/*     */ import fun.rockstarity.api.helpers.math.aura.Rotation;
/*     */ import fun.rockstarity.api.helpers.player.Player;
/*     */ import fun.rockstarity.api.render.animation.infinity.InfinityAnimation;
/*     */ import fun.rockstarity.client.modules.combat.Aura;
/*     */ import net.minecraft.entity.LivingEntity;
/*     */ import net.minecraft.entity.player.PlayerEntity;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.vector.Vector2f;
/*     */ import net.minecraft.util.math.vector.Vector3d;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TaksaBrain
/*     */   implements IAccess
/*     */ {
/*     */   private Vector3d pos;
/*  34 */   private Vector3d motion = Vector3d.ZERO;
/*  35 */   private float direction = MathUtility.random(0.0D, 360.0D); private float yaw;
/*     */   private float body;
/*  37 */   private int speed = 50;
/*     */   
/*  39 */   private final InfinityAnimation x = new InfinityAnimation();
/*  40 */   private final InfinityAnimation y = new InfinityAnimation();
/*  41 */   private final InfinityAnimation z = new InfinityAnimation();
/*     */   
/*  43 */   private final InfinityAnimation bodyAnim = new InfinityAnimation();
/*  44 */   private final InfinityAnimation yawAnim = new InfinityAnimation(); private boolean lay;
/*  45 */   private final InfinityAnimation pitchAnim = new InfinityAnimation();
/*     */   public boolean isLay() {
/*  47 */     return this.lay;
/*     */   }
/*  49 */   private final TimerUtility staying = new TimerUtility(); public float prevLimbSwingAmount;
/*     */   public float limbSwingAmount;
/*     */   public float limbSwing;
/*     */   private PlayerEntity entity;
/*     */   
/*     */   public void setEntity(PlayerEntity entity) {
/*  55 */     this.entity = entity;
/*     */   }
/*     */   
/*     */   public void onEvent(Event event) {
/*  59 */     if (this.entity == null)
/*     */       return; 
/*  61 */     if (event instanceof fun.rockstarity.api.events.list.player.EventUpdate) {
/*  62 */       Vector3d playerPos = this.entity.getPositionVec();
/*     */       
/*  64 */       if (this.pos == null || this.pos.distanceTo(playerPos) > 10.0D) {
/*  65 */         this.pos = playerPos;
/*  66 */         this.x.animate((float)this.pos.x, 1);
/*  67 */         this.y.animate((float)this.pos.y, 1);
/*  68 */         this.z.animate((float)this.pos.z, 1);
/*     */       } 
/*     */ 
/*     */       
/*  72 */       this.motion = this.motion.add(0.0D, -0.20000000298023224D, 0.0D);
/*     */       
/*  74 */       Vector3d newPos = this.pos.add(this.motion);
/*     */ 
/*     */       
/*  77 */       if (Player.isBlockSolid(newPos.x, newPos.y, newPos.z)) {
/*  78 */         int blockY = (int)newPos.y;
/*  79 */         double correctedY = (blockY + 1) + 0.1D;
/*  80 */         newPos = new Vector3d(newPos.x, correctedY, newPos.z);
/*  81 */         this.motion = new Vector3d(this.motion.x, 0.0D, this.motion.z);
/*     */       } 
/*     */ 
/*     */       
/*  85 */       this.motion = new Vector3d(this.motion.x, 0.0D, this.motion.z);
/*     */       
/*  87 */       LivingEntity target = ((Aura)rock.getModules().get(Aura.class)).getTarget();
/*  88 */       if (target != null && this.entity instanceof net.minecraft.client.entity.player.ClientPlayerEntity) {
/*  89 */         if (Player.isBlockSolid(newPos.x, newPos.y - 0.10000000149011612D, newPos.z)) {
/*  90 */           this.motion.y = 0.6200000047683716D;
/*     */         }
/*     */         
/*  93 */         AxisAlignedBB box = new AxisAlignedBB(getPos().sub(new Vector3d(0.4D, 0.0D, 0.4D)), getPos().add(0.4D, 0.4D, 0.4D));
/*  94 */         AxisAlignedBB targetbox = target.getBoundingBox().expand(-0.10000000149011612D, 0.0D, -0.10000000149011612D);
/*     */         
/*  96 */         this.motion = this.motion.add(target.getPositionVec().subtract(newPos).normalize());
/*     */         
/*  98 */         if (box.maxX > targetbox.minX && box.maxY > targetbox.minY && box.maxZ > targetbox.minZ && box.minX < targetbox.maxX && box.minY < targetbox.maxY && box.minZ < targetbox.maxZ)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 104 */           this.motion = this.motion.mul(-1.0D, 1.0D, -1.0D);
/*     */         }
/*     */       }
/* 107 */       else if (newPos.distanceTo(playerPos) > 2.0D) {
/* 108 */         this.motion = this.motion.add(playerPos.subtract(newPos).normalize());
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 113 */       handleRotation();
/*     */ 
/*     */       
/* 116 */       this.pos = newPos;
/*     */       
/* 118 */       if (this.pos.distanceTo(playerPos) < 0.10000000149011612D) {
/* 119 */         this.direction = MathUtility.random(0.0D, 360.0D);
/* 120 */         double xMot = -Math.sin(Math.toRadians(this.direction)) * 0.1D;
/* 121 */         double zMot = Math.cos(Math.toRadians(this.direction)) * 0.1D;
/* 122 */         this.motion = this.motion.add(xMot, 0.0D, zMot);
/*     */       } 
/*     */       
/* 125 */       this.motion = this.motion.scale(0.5D);
/*     */       
/* 127 */       this.speed = 150;
/* 128 */       this.x.animate((float)this.pos.x, this.speed);
/* 129 */       this.y.animate((float)this.pos.y, this.speed);
/* 130 */       this.z.animate((float)this.pos.z, this.speed);
/*     */       
/* 132 */       limbTick();
/*     */       
/* 134 */       if (Math.abs(this.pos.x - this.x.get()) > 0.10000000149011612D || Math.abs(this.pos.z - this.z.get()) > 0.10000000149011612D) {
/* 135 */         this.staying.reset();
/*     */       }
/*     */       
/* 138 */       this.lay = this.staying.passed(1000L);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void handleRotation() {
/* 143 */     if (this.motion.x != 0.0D || this.motion.z != 0.0D) {
/* 144 */       double angle = Math.atan2(this.motion.z, this.motion.x);
/* 145 */       this.yaw = (float)Math.toDegrees(angle) - 90.0F;
/* 146 */       this.yaw %= 360.0F;
/* 147 */       if (this.yaw < 0.0F) this.yaw += 360.0F;
/*     */     
/*     */     } 
/* 150 */     Vector2f rotation = Rotation.get(this.pos, this.entity.getEyePosition(0.0F));
/*     */     
/* 152 */     LivingEntity target = ((Aura)rock.getModules().get(Aura.class)).getTarget();
/* 153 */     if (target != null && this.entity instanceof net.minecraft.client.entity.player.ClientPlayerEntity) {
/* 154 */       rotation = Rotation.get(this.pos, target.getPositionVec());
/*     */     }
/*     */     
/* 157 */     float gradus = this.lay ? 200.0F : 150.0F;
/* 158 */     float gradus1 = this.lay ? 100.0F : 50.0F;
/* 159 */     if (rotation.x - this.yaw < -gradus || rotation.x - this.yaw > gradus) {
/* 160 */       this.yaw = rotation.x;
/*     */     }
/*     */     
/* 163 */     float shortestYawPath = ((this.yaw - this.body) % 360.0F + 540.0F) % 360.0F - 180.0F;
/*     */     
/* 165 */     if (!this.lay)
/* 166 */       this.bodyAnim.animate(this.body + shortestYawPath, 150); 
/* 167 */     this.yawAnim.animate(MathHelper.clamp(rotation.x - this.yaw, -gradus1, gradus1), 150);
/* 168 */     this.pitchAnim.animate(rotation.y, 150);
/*     */     
/* 170 */     this.body += shortestYawPath;
/*     */   }
/*     */   
/*     */   public void limbTick() {
/* 174 */     this.prevLimbSwingAmount = this.limbSwingAmount;
/* 175 */     double d0 = this.x.get() - this.pos.x;
/* 176 */     double d1 = 0.0D;
/* 177 */     double d2 = this.z.get() - this.pos.z;
/* 178 */     float f = MathHelper.sqrt(d0 * d0 + d1 * d1 + d2 * d2) * 4.0F;
/*     */     
/* 180 */     if (f > 1.0F)
/*     */     {
/* 182 */       f = 1.0F;
/*     */     }
/*     */     
/* 185 */     this.limbSwingAmount += (f - this.limbSwingAmount) * 0.4F;
/* 186 */     this.limbSwing += this.limbSwingAmount;
/*     */   }
/*     */   
/*     */   public float getBody() {
/* 190 */     return this.bodyAnim.get();
/*     */   }
/*     */   
/*     */   public float getYaw() {
/* 194 */     return this.yawAnim.get();
/*     */   }
/*     */   
/*     */   public float getPitch() {
/* 198 */     return this.pitchAnim.get();
/*     */   }
/*     */   
/*     */   public Vector3d getPos() {
/* 202 */     return new Vector3d(this.x.get(), this.y.get(), this.z.get());
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\models\taksa\TaksaBrain.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */