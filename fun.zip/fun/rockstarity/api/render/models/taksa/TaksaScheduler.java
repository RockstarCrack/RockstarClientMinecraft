/*    */ package fun.rockstarity.api.render.models.taksa;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.events.list.player.EventMessage;
/*    */ import fun.rockstarity.api.helpers.math.TimerUtility;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TaksaScheduler
/*    */ {
/*    */   private TaksaScheduler() {
/* 16 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*    */   } public static TimerUtility getUpdateTimer() {
/* 18 */     return updateTimer;
/* 19 */   } private static final TimerUtility updateTimer = new TimerUtility();
/*    */   
/*    */   public static void onEvent(Event event) {
/* 22 */     if (event instanceof fun.rockstarity.api.events.list.player.EventUpdate && 
/* 23 */       updateTimer.passed(60000L)) {
/* 24 */       TaksaAI.update();
/*    */     }
/*    */ 
/*    */     
/* 28 */     if (event instanceof EventMessage) { EventMessage e = (EventMessage)event;
/* 29 */       TaksaAI.setLastMsg(e.getMessage());
/* 30 */       TaksaAI.update(); }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\models\taksa\TaksaScheduler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */