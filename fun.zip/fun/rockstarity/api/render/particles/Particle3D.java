/*     */ package fun.rockstarity.api.render.particles;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.events.list.render.EventRender3D;
/*     */ import fun.rockstarity.api.helpers.render.PositionTracker;
/*     */ import fun.rockstarity.api.helpers.render.Render;
/*     */ import fun.rockstarity.api.render.color.themes.Style;
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.vector.Vector3d;
/*     */ import net.minecraft.util.math.vector.Vector4f;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Particle3D
/*     */   implements IAccess
/*     */ {
/*     */   private Vector3d position;
/*  26 */   private Vector3d prevPosition = Vector3d.ZERO; private Vector3d motion; public Vector3d getPosition() {
/*  27 */     return this.position; } public Vector3d getMotion() { return this.motion; } public void setPosition(Vector3d position) { this.position = position; } public void setMotion(Vector3d motion) { this.motion = motion; }
/*     */   
/*  29 */   private final ArrayList<Vector4f> tail = new ArrayList<>();
/*  30 */   private float alpha = 1.0F; private final float size; public float getAlpha() { return this.alpha; } public void setAlpha(float alpha) { this.alpha = alpha; }
/*     */ 
/*     */ 
/*     */   
/*     */   public Particle3D(Vector3d position, Vector3d motion) {
/*  35 */     this(position, motion, 0.8F);
/*     */   }
/*     */   
/*     */   public Particle3D(Vector3d position, Vector3d motion, float size) {
/*  39 */     this.position = position;
/*  40 */     this.motion = motion;
/*  41 */     this.size = size;
/*     */   }
/*     */   
/*     */   public void render(EventRender3D e) {
/*  45 */     this.prevPosition = new Vector3d(this.position.x, this.position.y, this.position.z);
/*  46 */     this.position = this.position.add(this.motion);
/*     */     
/*  48 */     MatrixStack ms = e.getMatrixStack();
/*  49 */     float size = this.size;
/*  50 */     float length = 30.0F;
/*     */     
/*  52 */     double x = this.position.x;
/*  53 */     double y = this.position.y;
/*  54 */     double z = this.position.z;
/*     */     
/*  56 */     double dx = x - this.prevPosition.x;
/*  57 */     double dy = y - this.prevPosition.y;
/*  58 */     double dz = z - this.prevPosition.z;
/*  59 */     double entitySpeed = Math.sqrt(dx * dx + dy * dy + dz * dz);
/*  60 */     int countMax = MathHelper.clamp((int)(entitySpeed / 0.045D), 1, 16);
/*  61 */     int count = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     this.tail.add(new Vector4f((float)x, (float)y + 0.7F, (float)z, length));
/*     */ 
/*     */     
/*  69 */     ArrayList<Vector4f> vec4f = new ArrayList<>();
/*  70 */     for (Vector4f vec : this.tail) {
/*  71 */       if (vec.getW() > 0.0F) {
/*  72 */         float miniSize = size * vec.getW() / length;
/*     */         
/*  74 */         double posX = vec.getX() - ((mc.getRenderManager()).info.getProjectedView()).x;
/*  75 */         double posY = vec.getY() - ((mc.getRenderManager()).info.getProjectedView()).y;
/*  76 */         double posZ = vec.getZ() - ((mc.getRenderManager()).info.getProjectedView()).z;
/*     */         
/*  78 */         if (PositionTracker.isInView(new Vector3d(vec.getX(), vec.getY(), vec.getZ()))) {
/*  79 */           ms.push();
/*  80 */           ms.translate(posX, posY, posZ);
/*  81 */           ms.rotate((mc.getRenderManager()).info.getRotation());
/*     */           
/*  83 */           Render.drawCleanImage(ms, (-miniSize / 2.0F), (-miniSize / 2.0F), (-miniSize / 2.0F), miniSize, miniSize, Style.getPoint((int)(12.0F * vec.getW())).alpha((vec.getW() / length * this.alpha)));
/*  84 */           ms.pop();
/*     */         } 
/*     */         
/*  87 */         vec.set(vec.getX(), vec.getY() + 0.004F / Math.max(Minecraft.debugFPS, 5.0F) * 300.0F, vec.getZ(), vec.getW() - 0.3F / Math.max(Minecraft.debugFPS, 5.0F) * 300.0F);
/*  88 */         if (vec.getW() <= 0.0F) {
/*  89 */           vec4f.add(vec);
/*     */         }
/*     */       } 
/*     */     } 
/*  93 */     if (this.alpha < 0.0F);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     for (Vector4f vec : vec4f) {
/*  99 */       this.tail.remove(vec);
/*     */     }
/*     */   }
/*     */   
/*     */   public void update() {
/* 104 */     this.alpha = (float)(this.alpha - 0.001D / Math.max(Minecraft.debugFPS, 5.0F) * 300.0D);
/* 105 */     this.motion = this.motion.mul(0.95D / Math.max(Minecraft.debugFPS, 5.0F) * 300.0D, 0.95D / Math.max(Minecraft.debugFPS, 5.0F) * 300.0D, 0.95D / Math.max(Minecraft.debugFPS, 5.0F) * 300.0D);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\particles\Particle3D.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */