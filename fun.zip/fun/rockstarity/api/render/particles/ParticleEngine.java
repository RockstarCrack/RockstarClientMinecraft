/*    */ package fun.rockstarity.api.render.particles;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.helpers.math.TimerUtility;
/*    */ import fun.rockstarity.api.render.color.FixColor;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParticleEngine
/*    */   implements IAccess
/*    */ {
/* 20 */   private final ArrayList<Particle2D> particles = new ArrayList<>();
/* 21 */   private final TimerUtility timer = new TimerUtility();
/*    */   
/*    */   public void render(MatrixStack matrixStack) {
/* 24 */     Particle2D removed = null;
/*    */     
/* 26 */     for (Particle2D particle : this.particles) {
/* 27 */       particle.render(matrixStack);
/* 28 */       if (particle.getAlpha() <= 0.0F) {
/* 29 */         removed = particle;
/*    */       }
/*    */     } 
/*    */     
/* 33 */     if (removed != null) {
/* 34 */       this.particles.remove(removed);
/*    */     }
/*    */   }
/*    */   
/*    */   public void spawn(float x, float y, float motionX, float motionY, FixColor color) {
/* 39 */     if (this.timer.passed(5L)) {
/* 40 */       this.particles.add(new Particle2D(x, y, motionX, motionY, color));
/* 41 */       this.timer.reset();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\particles\ParticleEngine.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */