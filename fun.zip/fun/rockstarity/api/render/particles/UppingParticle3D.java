/*    */ package fun.rockstarity.api.render.particles;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.events.list.render.EventRender3D;
/*    */ import fun.rockstarity.api.helpers.render.PositionTracker;
/*    */ import fun.rockstarity.api.helpers.render.Render;
/*    */ import fun.rockstarity.api.render.color.FixColor;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.util.math.vector.Vector3d;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UppingParticle3D
/*    */   implements IAccess
/*    */ {
/*    */   private Vector3d position;
/*    */   private Vector3d motion;
/*    */   
/*    */   public Vector3d getPosition() {
/* 26 */     return this.position; } public Vector3d getMotion() { return this.motion; } public void setPosition(Vector3d position) { this.position = position; } public void setMotion(Vector3d motion) { this.motion = motion; }
/*    */   
/* 28 */   private final float size; private float alpha = 1.0F; private FixColor color; public float getAlpha() { return this.alpha; } public void setAlpha(float alpha) { this.alpha = alpha; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public UppingParticle3D(Vector3d position, Vector3d motion, FixColor color) {
/* 34 */     this(position, motion, color, 0.8F);
/*    */   }
/*    */   
/*    */   public UppingParticle3D(Vector3d position, Vector3d motion, FixColor color, float size) {
/* 38 */     this.position = position;
/* 39 */     this.motion = motion;
/* 40 */     this.size = size;
/* 41 */     this.color = color;
/*    */   }
/*    */   
/*    */   public void render(EventRender3D e) {
/* 45 */     this.position = this.position.add(this.motion);
/*    */     
/* 47 */     MatrixStack ms = e.getMatrixStack();
/* 48 */     float size = this.size;
/* 49 */     float miniSize = 0.05F;
/* 50 */     float length = 30.0F;
/*    */     
/* 52 */     double x = this.position.x;
/* 53 */     double y = this.position.y;
/* 54 */     double z = this.position.z;
/*    */     
/* 56 */     if (PositionTracker.isInView(new Vector3d(x, y, z))) {
/* 57 */       double posX = x - ((mc.getRenderManager()).info.getProjectedView()).x;
/* 58 */       double posY = y - ((mc.getRenderManager()).info.getProjectedView()).y;
/* 59 */       double posZ = z - ((mc.getRenderManager()).info.getProjectedView()).z;
/*    */       
/* 61 */       ms.push();
/* 62 */       ms.translate(posX, posY, posZ);
/* 63 */       ms.rotate((mc.getRenderManager()).info.getRotation());
/*    */       
/* 65 */       Render.drawCleanImage(ms, (-size / 2.0F), (-size / 2.0F), (-size / 2.0F), size, size, this.color.alpha((this.alpha / 2.0F)));
/* 66 */       Render.drawCleanImage(ms, (-miniSize / 2.0F), (-miniSize / 2.0F), (-size / 2.0F), miniSize, miniSize, this.color.alpha(this.alpha));
/* 67 */       Render.drawCleanImage(ms, (-size / 2.0F), (-size / 2.0F), (-size / 2.0F), size, size, this.color.alpha((this.alpha / 2.0F)));
/* 68 */       Render.drawCleanImage(ms, (-miniSize / 2.0F), (-miniSize / 2.0F), (-size / 2.0F), miniSize, miniSize, this.color.alpha(this.alpha));
/* 69 */       Render.drawCleanImage(ms, (-size / 2.0F), (-size / 2.0F), (-size / 2.0F), size, size, this.color.alpha((this.alpha / 2.0F)));
/* 70 */       Render.drawCleanImage(ms, (-miniSize / 2.0F), (-miniSize / 2.0F), (-size / 2.0F), miniSize, miniSize, this.color.alpha(this.alpha));
/* 71 */       ms.pop();
/*    */     } 
/*    */   }
/*    */   
/*    */   public void update() {
/* 76 */     this.alpha = (float)(this.alpha - 0.001D / Math.max(Minecraft.debugFPS, 5.0F) * 100.0D);
/* 77 */     this.motion.y = (0.001F / Math.max(Minecraft.debugFPS, 5.0F) * 500.0F);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\particles\UppingParticle3D.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */