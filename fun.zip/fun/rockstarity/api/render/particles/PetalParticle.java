/*    */ package fun.rockstarity.api.render.particles;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.events.list.render.EventRender3D;
/*    */ import fun.rockstarity.api.helpers.math.MathUtility;
/*    */ import fun.rockstarity.api.helpers.render.Render;
/*    */ import fun.rockstarity.api.render.animation.Animation;
/*    */ import fun.rockstarity.api.render.animation.Easing;
/*    */ import fun.rockstarity.api.render.animation.infinity.InfinityAnimation;
/*    */ import fun.rockstarity.api.render.color.themes.Style;
/*    */ import fun.rockstarity.api.render.shaders.fog.Vector2d;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.util.math.vector.Vector3d;
/*    */ 
/*    */ public class PetalParticle implements IAccess {
/*    */   private final Vector3d startPosition;
/*    */   private Vector3d position;
/*    */   private Vector3d motion;
/*    */   private float alpha;
/*    */   private float rotation;
/*    */   private final int type;
/*    */   private final int point;
/*    */   private final float size;
/*    */   private int direction;
/*    */   private boolean falling;
/*    */   
/* 28 */   public Vector3d getPosition() { return this.position; } public Vector3d getMotion() { return this.motion; } public float getAlpha() {
/* 29 */     return this.alpha;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 35 */   private final InfinityAnimation fallingAnim = new InfinityAnimation();
/* 36 */   private final Animation swingAnim = (new Animation()).setEasing(Easing.EASE_IN_OUT_QUART).setSpeed(1500).setSize(2.0F);
/*    */   
/*    */   public PetalParticle(Vector3d pos) {
/* 39 */     this.position = this.startPosition = pos;
/* 40 */     this.motion = new Vector3d(MathUtility.random(-0.30000001192092896D, 0.30000001192092896D), MathUtility.random(1.0D, 2.0D), MathUtility.random(-0.30000001192092896D, 0.30000001192092896D));
/*    */     
/* 42 */     this.type = MathUtility.randomInt(0, 3);
/* 43 */     this.point = MathUtility.randomInt(0, 150);
/* 44 */     this.rotation = MathUtility.randomInt(0, 360);
/* 45 */     this.direction = MathUtility.randomInt(0, 360);
/* 46 */     this.size = 0.3F;
/* 47 */     this.alpha = 1.0F;
/*    */   }
/*    */   
/*    */   public void render(EventRender3D e) {
/* 51 */     MatrixStack ms = e.getMatrixStack();
/*    */     
/* 53 */     this.position = this.position.add(this.motion.mul(Vector3d.copy(0.029999999329447746D)));
/* 54 */     Vector3d renderPos = this.position.subtract((mc.getRenderManager()).info.getProjectedView());
/* 55 */     if (this.position.distanceTo(this.startPosition) > 0.0D || this.falling) {
/* 56 */       if (this.motion.y > 0.10000000149011612D) {
/* 57 */         this.motion.y *= 0.9900000095367432D;
/* 58 */       } else if (this.motion.y > 0.0D) {
/* 59 */         this.motion.y = this.fallingAnim.animate(0.0F, 150);
/*    */       } else {
/* 61 */         this.motion.y = this.fallingAnim.animate(-0.05F, 150);
/*    */         
/* 63 */         if (this.motion.y < -0.04500000178813934D) {
/* 64 */           if (Math.abs(this.motion.x) < 0.05000000074505806D && Math.abs(this.motion.z) < 0.05000000074505806D)
/* 65 */           { Vector2d directionMotions = MathUtility.circleCords(this.direction, 0.07F);
/* 66 */             this.motion.x = directionMotions.x * (this.swingAnim.get() - 1.0F);
/* 67 */             this.motion.z = directionMotions.y * (this.swingAnim.get() - 1.0F);
/* 68 */             this.alpha -= 0.01F / Math.max(Minecraft.debugFPS, 5.0F) * 30.0F;
/*    */             
/* 70 */             if (this.swingAnim.finished()) {
/* 71 */               this.swingAnim.setForward(false);
/* 72 */             } else if (this.swingAnim.finished(false)) {
/* 73 */               this.swingAnim.setForward(true);
/*    */             }  }
/* 75 */           else { this.motion.x *= 0.9900000095367432D;
/* 76 */             this.motion.z *= 0.9900000095367432D; }
/*    */         
/*    */         }
/*    */       } 
/* 80 */       this.falling = true;
/*    */     } else {
/* 82 */       this.motion = this.motion.mul(Vector3d.copy(0.9998999834060669D));
/*    */     } 
/*    */     
/* 85 */     ms.push();
/* 86 */     ms.translate(renderPos.x, renderPos.y, renderPos.z);
/* 87 */     ms.rotate((mc.getRenderManager()).info.getRotation());
/* 88 */     ms.rotate(Vector3f.ZN.rotation(this.rotation));
/*    */     
/* 90 */     Render.drawImage(ms, "masks/petals/petal" + this.type + ".png", (-this.size / 2.0F), (-this.size / 2.0F), (-this.size / 2.0F), this.size, this.size, Style.getPoint(this.point).alpha(this.alpha));
/*    */     
/* 92 */     ms.pop();
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\particles\PetalParticle.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */