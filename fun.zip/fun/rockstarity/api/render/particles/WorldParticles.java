/*    */ package fun.rockstarity.api.render.particles;
/*    */ 
/*    */ import fun.rockstarity.api.binds.Bindable;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.helpers.math.TimerUtility;
/*    */ import fun.rockstarity.api.modules.Module;
/*    */ import fun.rockstarity.api.modules.settings.list.CheckBox;
/*    */ import fun.rockstarity.api.render.animation.infinity.InfinityAnimation;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WorldParticles
/*    */   extends CheckBox
/*    */ {
/* 28 */   private final TimerUtility addingTimer = new TimerUtility();
/* 29 */   private final ArrayList<Particle3D> particles = new ArrayList<>();
/* 30 */   private final InfinityAnimation rotating = new InfinityAnimation();
/*    */   
/* 32 */   private int mode = 1;
/*    */   
/* 34 */   private final ArrayList<UppingParticle3D> uppingParticles = new ArrayList<>();
/*    */   
/*    */   public WorldParticles(Module parent) {
/* 37 */     super((Bindable)parent, "Частицы");
/*    */   }
/*    */   
/*    */   public void onEvent(Event event) {}
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\particles\WorldParticles.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */