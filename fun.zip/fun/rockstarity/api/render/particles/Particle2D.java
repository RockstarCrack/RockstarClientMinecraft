/*    */ package fun.rockstarity.api.render.particles;
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import com.mojang.blaze3d.platform.GlStateManager;
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.helpers.math.MathUtility;
/*    */ import fun.rockstarity.api.helpers.render.Render;
/*    */ import fun.rockstarity.api.render.animation.infinity.InfinityAnimation;
/*    */ import fun.rockstarity.api.render.color.FixColor;
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ public class Particle2D implements IAccess {
/*    */   private float x;
/*    */   private float y;
/*    */   private float motionX;
/*    */   private float motionY;
/*    */   private FixColor color;
/* 17 */   private float alpha = 1.0F; public float getX() { return this.x; } public float getY() { return this.y; } public float getMotionX() { return this.motionX; } public float getMotionY() { return this.motionY; } public float getAlpha() { return this.alpha; }
/*    */ 
/*    */   
/* 20 */   private final InfinityAnimation deviation = new InfinityAnimation(); public InfinityAnimation getDeviation() { return this.deviation; }
/*    */   
/* 22 */   private float deviateValue = 0.0F;
/*    */   
/*    */   public Particle2D(float x, float y, float motionX, float motionY, FixColor color) {
/* 25 */     this.x = x;
/* 26 */     this.y = y;
/*    */     
/* 28 */     float angle = MathUtility.random(0.0D, 360.0D);
/* 29 */     float rand = MathUtility.random(0.0D, 1.0D);
/*    */     
/* 31 */     this.motionX = motionX;
/* 32 */     this.motionY = motionY;
/*    */     
/* 34 */     this.color = color;
/*    */   }
/*    */   
/*    */   public void render(MatrixStack ms) {
/* 38 */     this.x += this.motionX / Math.max(Minecraft.debugFPS, 5.0F) * 5.0F;
/* 39 */     this.y += this.motionY / Math.max(Minecraft.debugFPS, 5.0F) * 5.0F;
/*    */     
/* 41 */     float slowingSpeed = 0.99F;
/* 42 */     this.motionX *= slowingSpeed;
/* 43 */     this.motionY *= slowingSpeed;
/*    */     
/* 45 */     float size = 10.0F;
/* 46 */     float miniSize = 2.0F;
/*    */     
/* 48 */     FixColor color = this.color;
/*    */     
/* 50 */     if (this.deviation.get() >= this.deviateValue) {
/* 51 */       this.deviateValue = MathUtility.random(20.0D, 50.0D);
/* 52 */       this.deviation.animate(this.deviateValue, (int)MathUtility.random(1550.0D, 300.0D));
/* 53 */     } else if (this.deviation.get() <= this.deviateValue) {
/* 54 */       this.deviateValue = MathUtility.random(20.0D, 50.0D);
/* 55 */       this.deviation.animate(this.deviateValue, (int)MathUtility.random(1550.0D, 300.0D));
/*    */     } 
/*    */     
/* 58 */     ms.push();
/* 59 */     GlStateManager.depthMask(false);
/* 60 */     ms.translate(this.x, this.y, 0.0D);
/* 61 */     Render.drawImage(ms, "masks/glow.png", (-size / 2.0F), (-size / 2.0F), 0.0D, size, size, color.alpha((this.alpha / 2.0F)));
/* 62 */     Render.drawImage(ms, "masks/glow.png", (-miniSize / 2.0F), (-miniSize / 2.0F), 0.0D, miniSize, miniSize, color.alpha(this.alpha));
/* 63 */     GlStateManager.depthMask(true);
/* 64 */     ms.pop();
/*    */     
/* 66 */     this.alpha -= 0.035F / Math.max(Minecraft.debugFPS, 5.0F) * 15.0F;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\render\particles\Particle2D.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */