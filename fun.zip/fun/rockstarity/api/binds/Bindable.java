/*    */ package fun.rockstarity.api.binds;
/*    */ 
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.events.list.game.inputs.EventKey;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Optional;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Bindable
/*    */   implements IAccess
/*    */ {
/*    */   protected boolean toggled;
/* 18 */   private final ArrayList<Bind> binds = new ArrayList<>(); public ArrayList<Bind> getBinds() { return this.binds; }
/*    */    public boolean isToggled() {
/* 20 */     return this.toggled;
/*    */   }
/*    */   
/*    */   public Optional<Bind> getBindByKey(EventKey event) {
/* 24 */     if (event.getKey() == -1) {
/* 25 */       return Optional.empty();
/*    */     }
/* 27 */     return getBinds().stream()
/* 28 */       .filter(bind -> ((bind.getKey() == -1 && bind.getScancode() == event.getScancode() && bind.getScancode() == event.getKey()) || (bind.getKey() == event.getKey() && event.getScancode() == event.getScancode())))
/* 29 */       .findFirst();
/*    */   }
/*    */   
/*    */   public void toggleWithBind(Optional<Bind> opt) {
/* 33 */     Bind bind = opt.get();
/*    */     
/* 35 */     this.toggled = !this.toggled;
/*    */     
/* 37 */     if (bind.getType() != BindType.HOLD || bind.isHolding()) {
/* 38 */       if (this.toggled);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     }
/* 44 */     else if (bind.getAlert() != null) {
/* 45 */       bind.getAlert().hide();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\binds\Bindable.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */