/*    */ package fun.rockstarity.api.binds;
/*    */ 
/*    */ import fun.rockstarity.api.render.animation.Animation;
/*    */ import fun.rockstarity.api.render.animation.Easing;
/*    */ import fun.rockstarity.api.render.ui.alerts.Alert;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Bind
/*    */ {
/*    */   private boolean enabled;
/*    */   private String text;
/*    */   private Bindable parent;
/*    */   
/*    */   public void setEnabled(boolean enabled) {
/* 16 */     this.enabled = enabled; } public void setText(String text) { this.text = text; } public void setParent(Bindable parent) { this.parent = parent; } public void setKey(int key) { this.key = key; } public void setScancode(int scancode) { this.scancode = scancode; } public void setHolding(boolean holding) { this.holding = holding; } public void setType(BindType type) { this.type = type; } public void setAlert(Alert alert) { this.alert = alert; } public Bind(boolean enabled, String text, Bindable parent, int key, int scancode, boolean holding, BindType type, Alert alert) {
/* 17 */     this.enabled = enabled; this.text = text; this.parent = parent; this.key = key; this.scancode = scancode; this.holding = holding; this.type = type; this.alert = alert;
/*    */   }
/*    */   
/* 20 */   public boolean isEnabled() { return this.enabled; }
/* 21 */   public String getText() { return this.text; } public Bindable getParent() {
/* 22 */     return this.parent;
/* 23 */   } private final Animation showingAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); private int key; private int scancode; private boolean holding; private final Animation secondAnim = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(300); private BindType type; private Alert alert; public Animation getShowingAnim() { return this.showingAnim; } public Animation getSecondAnim() { return this.secondAnim; }
/* 24 */   public int getKey() { return this.key; } public int getScancode() { return this.scancode; }
/* 25 */   public boolean isHolding() { return this.holding; }
/* 26 */   public BindType getType() { return this.type; } public Alert getAlert() {
/* 27 */     return this.alert;
/*    */   }
/*    */   public Bind(int key) {
/* 30 */     this.key = key;
/* 31 */     this.scancode = -1;
/* 32 */     this.type = BindType.TOGGLE;
/*    */   }
/*    */   
/*    */   public Bind(int key, BindType type) {
/* 36 */     this.key = key;
/* 37 */     this.scancode = -1;
/* 38 */     this.type = type;
/*    */   }
/*    */   
/*    */   public Bind(int key, int scancode, BindType type) {
/* 42 */     this.key = key;
/* 43 */     this.scancode = scancode;
/* 44 */     this.type = type;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\binds\Bind.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */