/*    */ package fun.rockstarity.api;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Reacher
/*    */ {
/* 10 */   public static float ENTITY_ALPHA = 1.0F;
/* 11 */   public static float ITEMS_ALPHA = 1.0F;
/*    */   public static boolean SILENT;
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\Reacher.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */