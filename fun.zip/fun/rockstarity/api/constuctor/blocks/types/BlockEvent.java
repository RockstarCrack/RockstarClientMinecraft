/*    */ package fun.rockstarity.api.constuctor.blocks.types;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.constuctor.blocks.Block;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockEvent
/*    */   extends Block
/*    */ {
/*    */   private final Class event;
/*    */   
/*    */   public Class getEvent() {
/* 15 */     return this.event;
/*    */   }
/*    */   
/*    */   public BlockEvent(String name, float x, float y, float width, float height, Class event) {
/* 19 */     super(name, x, y, width, height);
/* 20 */     this.event = event;
/*    */   }
/*    */ 
/*    */   
/*    */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/* 25 */     super.render(matrixStack, mouseX, mouseY, partialTicks);
/*    */   }
/*    */   
/*    */   public boolean clicked(double mouseX, double mouseY, int button) {
/* 29 */     super.clicked(mouseX, mouseY, button);
/*    */     
/* 31 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\constuctor\blocks\types\BlockEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */