/*    */ package fun.rockstarity.api.constuctor.blocks.types;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.constuctor.ConstructorScreen;
/*    */ import fun.rockstarity.api.constuctor.blocks.Block;
/*    */ import fun.rockstarity.api.constuctor.interfaces.IPlayerAction;
/*    */ import fun.rockstarity.api.render.shaders.list.Round;
/*    */ import fun.rockstarity.api.render.ui.rect.Rect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockAction
/*    */   extends Block
/*    */ {
/*    */   private final IPlayerAction action;
/*    */   
/*    */   public IPlayerAction getAction() {
/* 19 */     return this.action;
/*    */   }
/*    */   
/*    */   public BlockAction(String name, float x, float y, float width, float height, IPlayerAction action) {
/* 23 */     super(name, x, y, width, height);
/* 24 */     this.action = action;
/*    */   }
/*    */ 
/*    */   
/*    */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/* 29 */     super.render(matrixStack, mouseX, mouseY, partialTicks);
/*    */     
/* 31 */     Round.draw(matrixStack, new Rect(this.x + 5.0F, this.y + this.height - 15.0F, 10.0F, 10.0F), 5.0F, this.bgColor.alpha(ConstructorScreen.opening.get()).darker(0.1F));
/* 32 */     if (this.parent != null)
/* 33 */       Round.draw(matrixStack, new Rect(this.x + 5.0F, this.y + this.height - 15.0F, 10.0F, 10.0F), 5.0F, this.clientColor.alpha(ConstructorScreen.opening.get())); 
/*    */   }
/*    */   
/*    */   public boolean clicked(double mouseX, double mouseY, int button) {
/* 37 */     super.clicked(mouseX, mouseY, button);
/*    */     
/* 39 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\constuctor\blocks\types\BlockAction.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */