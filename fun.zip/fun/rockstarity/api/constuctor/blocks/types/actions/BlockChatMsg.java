/*    */ package fun.rockstarity.api.constuctor.blocks.types.actions;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.constuctor.ConstructorScreen;
/*    */ import fun.rockstarity.api.constuctor.blocks.types.BlockAction;
/*    */ import fun.rockstarity.api.constuctor.interfaces.IPlayerAction;
/*    */ import fun.rockstarity.api.render.shaders.list.Round;
/*    */ import fun.rockstarity.api.render.ui.rect.Rect;
/*    */ import fun.rockstarity.api.render.ui.widgets.InputWidget;
/*    */ import net.minecraft.util.text.ITextComponent;
/*    */ import net.minecraft.util.text.TranslationTextComponent;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockChatMsg
/*    */   extends BlockAction
/*    */ {
/*    */   private final InputWidget input;
/*    */   
/*    */   public InputWidget getInput() {
/* 21 */     return this.input;
/*    */   }
/*    */   
/*    */   public BlockChatMsg(String name, float x, float y, float width, float height, IPlayerAction action) {
/* 25 */     super(name, x, y, width, height, action);
/* 26 */     this.input = new InputWidget(bold.get(14), 0, 0, 90, 20, (ITextComponent)new TranslationTextComponent(""), false);
/*    */   }
/*    */ 
/*    */   
/*    */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/* 31 */     super.render(matrixStack, mouseX, mouseY, partialTicks);
/* 32 */     this.input.x = (int)this.x + 2;
/* 33 */     this.input.y = (int)this.y + 15;
/* 34 */     Round.draw(matrixStack, new Rect(this.x + 5.0F, this.y + 18.0F, 90.0F, 10.0F), 2.0F, this.bgColor.alpha(ConstructorScreen.opening.get()).darker(0.1F));
/* 35 */     this.input.setMaxStringLength(2147483647);
/* 36 */     this.input.renderButton(matrixStack, mouseX, mouseY, partialTicks, ConstructorScreen.opening.get());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean clicked(double mouseX, double mouseY, int button) {
/* 41 */     this.input.mouseClicked(mouseX, mouseY, button);
/* 42 */     return super.clicked(mouseX, mouseY, button);
/*    */   }
/*    */ 
/*    */   
/*    */   public void pressed(int keyCode, int scanCode, int modifiers) {
/* 47 */     this.input.keyPressed(keyCode, scanCode, modifiers);
/* 48 */     super.pressed(keyCode, scanCode, modifiers);
/*    */   }
/*    */ 
/*    */   
/*    */   public void charTyped(char codePoint, int modifiers) {
/* 53 */     this.input.charTyped(codePoint, modifiers);
/* 54 */     super.charTyped(codePoint, modifiers);
/*    */   }
/*    */ 
/*    */   
/*    */   public void tick() {
/* 59 */     this.input.tick();
/* 60 */     super.tick();
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\constuctor\blocks\types\actions\BlockChatMsg.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */