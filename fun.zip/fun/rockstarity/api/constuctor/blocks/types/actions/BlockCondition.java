/*    */ package fun.rockstarity.api.constuctor.blocks.types.actions;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.constuctor.blocks.Block;
/*    */ import fun.rockstarity.api.constuctor.interfaces.ICondition;
/*    */ import fun.rockstarity.api.helpers.math.Hover;
/*    */ import fun.rockstarity.api.render.shaders.list.Round;
/*    */ import fun.rockstarity.api.render.ui.rect.Rect;
/*    */ 
/*    */ public class BlockCondition extends Block {
/*    */   private ICondition condition;
/*    */   
/*    */   public ICondition getCondition() {
/* 14 */     return this.condition;
/*    */   }
/*    */   private boolean inverted;
/*    */   
/*    */   public BlockCondition(String name, float x, float y, float width, float height, ICondition condition) {
/* 19 */     super(name, x, y, width, height);
/* 20 */     this.condition = condition;
/* 21 */     this.inverted = false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/* 26 */     super.render(matrixStack, mouseX, mouseY, partialTicks);
/*    */     
/* 28 */     String conditionStatus = this.inverted ? " (Не)" : "";
/* 29 */     bold.get(14).draw(matrixStack, this.name + this.name, this.x + 4.0F, this.y + 3.0F, rock.getThemes().getTextFirstColor());
/*    */     
/* 31 */     Round.draw(matrixStack, new Rect(this.x + 5.0F, this.y + this.height - 15.0F, 10.0F, 10.0F), 5.0F, this.bgColor.darker(0.1F));
/* 32 */     if (this.parent != null) {
/* 33 */       Round.draw(matrixStack, new Rect(this.x + 5.0F, this.y + this.height - 15.0F, 10.0F, 10.0F), 5.0F, this.clientColor);
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean clicked(double mouseX, double mouseY, int button) {
/* 38 */     if (Hover.isHovered((this.x + 5.0F), (this.y + this.height - 15.0F), 10.0D, 10.0D, mouseX, mouseY)) {
/* 39 */       this.inverted = !this.inverted;
/* 40 */       this.condition = this.condition.invert();
/* 41 */       return true;
/*    */     } 
/* 43 */     return super.clicked(mouseX, mouseY, button);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\constuctor\blocks\types\actions\BlockCondition.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */