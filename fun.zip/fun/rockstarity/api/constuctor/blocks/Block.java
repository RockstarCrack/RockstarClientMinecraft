/*     */ package fun.rockstarity.api.constuctor.blocks;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.constuctor.ConstructorScreen;
/*     */ import fun.rockstarity.api.helpers.math.Hover;
/*     */ import fun.rockstarity.api.helpers.render.Render;
/*     */ import fun.rockstarity.api.helpers.render.Stencil;
/*     */ import fun.rockstarity.api.render.animation.Animation;
/*     */ import fun.rockstarity.api.render.animation.Easing;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.color.themes.Style;
/*     */ import fun.rockstarity.api.render.shaders.list.Round;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import java.awt.Color;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class Block
/*     */   extends Rect
/*     */   implements IAccess
/*     */ {
/*     */   private float dragX;
/*     */   private float dragY;
/*     */   protected FixColor black;
/*     */   protected FixColor bgColor;
/*     */   protected FixColor actionsColor;
/*     */   protected FixColor clientColor;
/*     */   
/*     */   public float getDragX() {
/*  30 */     return this.dragX; } public float getDragY() { return this.dragY; } public void setDragX(float dragX) { this.dragX = dragX; } public void setDragY(float dragY) { this.dragY = dragY; }
/*     */ 
/*     */   
/*  33 */   public Animation getOpening() { return this.opening; } protected final Animation opening = (new Animation())
/*  34 */     .setEasing(Easing.BOTH_SINE).setSpeed(300).setSize(1.0F);
/*     */   protected final String name; protected Rect umbilical; protected boolean drag; protected Block child;
/*     */   protected Block parent;
/*     */   
/*  38 */   public void setChild(Block child) { this.child = child; } public void setParent(Block parent) { this.parent = parent; } public Block getChild() { return this.child; } public Block getParent() { return this.parent; }
/*     */ 
/*     */   
/*     */   public Block(String name, float x, float y, float width, float height) {
/*  42 */     super(x, y, width, height);
/*  43 */     this.name = name;
/*  44 */     this.opening.setForward(true);
/*  45 */     this.umbilical = new Rect(x + width - 15.0F, y + height - 15.0F, 10.0F, 10.0F);
/*     */   }
/*     */   
/*     */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/*  49 */     this.black = FixColor.BLACK.alpha(this.opening.get());
/*  50 */     this.bgColor = rock.getThemes().getFirstColor().alpha(this.opening.get());
/*  51 */     this.actionsColor = (new FixColor(230.0D, 236.0D, 246.0D)).alpha(this.opening.get());
/*  52 */     this.clientColor = Style.getMain().alpha(this.opening.get());
/*     */     
/*  54 */     Round.draw(matrixStack, width(this.width * this.opening.get()).height(this.height * this.opening.get()), 3.0F, this.bgColor.alpha(ConstructorScreen.opening.get()));
/*     */     
/*  56 */     Stencil.init();
/*  57 */     Round.draw(matrixStack, width(this.width * this.opening.get()).height(this.height * this.opening.get()), 3.0F, this.bgColor.alpha(ConstructorScreen.opening.get()));
/*  58 */     Stencil.read(1);
/*     */     
/*  60 */     Round.draw(matrixStack, width(this.width * this.opening.get()).height(this.height * this.opening.get() - this.height - 15.0F), 3.0F, 3.0F, 0.0F, 0.0F, this.bgColor.darker(0.1F).alpha(ConstructorScreen.opening.get()));
/*  61 */     Render.image("icons/close.png", this.x + this.width - 10.0F, this.y + 5.0F, 6.0F, 6.0F, (Color)rock.getThemes().getTextFirstColor().alpha(ConstructorScreen.opening.get()));
/*  62 */     bold.get(14).draw(matrixStack, this.name, this.x + 4.0F, this.y + 3.0F, rock.getThemes().getTextFirstColor().alpha(ConstructorScreen.opening.get()));
/*     */     
/*  64 */     Round.draw(matrixStack, new Rect(this.x + this.width - 15.0F, this.y + this.height - 15.0F, 10.0F, 10.0F), 5.0F, this.bgColor.darker(0.1F).alpha(ConstructorScreen.opening.get()));
/*     */     
/*  66 */     Stencil.finish();
/*     */     
/*  68 */     float tMiddle = 0.5F;
/*     */     
/*  70 */     float startX = this.x + this.width - 15.0F;
/*  71 */     float startY = this.y + this.height - 15.0F;
/*     */     
/*  73 */     float endX = this.umbilical.getX();
/*  74 */     float endY = this.umbilical.getY();
/*     */     
/*  76 */     float control1X = (startX + endX) / 2.0F + (startY - endY) / 2.0F;
/*  77 */     float control1Y = (startY + endY) / 2.0F + (endX - startX) / 10.0F;
/*     */     
/*  79 */     float control2X = (startX + endX) / 2.0F - (startY - endY) / 2.0F;
/*  80 */     float control2Y = (startY + endY) / 2.0F - (endX - startX) / 10.0F;
/*     */     
/*  82 */     drawBezierLine(this.x + this.width - 10.0F, this.y + this.height - 10.0F, this.umbilical.getX() + 5.0F, this.umbilical.getY() + 5.0F, control1X, control1Y, control2X, control2Y);
/*  83 */     Round.draw(matrixStack, this.umbilical, 5.0F, this.clientColor.alpha(ConstructorScreen.opening.get()));
/*     */     
/*  85 */     this.width = Math.max(100.0F, bold.get(14).getWidth(this.name) + 20.0F);
/*     */     
/*  87 */     if (!rock.getScriptConstructor().getBlocks().contains(this.child)) this.child = null; 
/*  88 */     if (!rock.getScriptConstructor().getBlocks().contains(this.parent)) this.parent = null;
/*     */     
/*  90 */     if (this.child != null) {
/*  91 */       this.umbilical = this.umbilical.x(this.child.x + 5.0F).y(this.child.y + this.child.getHeight() - 15.0F);
/*     */     }
/*     */     
/*  94 */     if (this.drag) {
/*  95 */       this.umbilical = this.umbilical.x((mouseX - 5)).y((mouseY - 5));
/*     */     }
/*     */     
/*  98 */     if (this.child == null && !this.drag) {
/*  99 */       this.umbilical = new Rect(this.x + this.width - 15.0F, this.y + this.height - 15.0F, 10.0F, 10.0F);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean clicked(double mouseX, double mouseY, int button) {
/* 104 */     if (Hover.isHovered((this.x + this.width - 15.0F), this.y, 15.0D, 15.0D, mouseX, mouseY)) {
/* 105 */       this.opening.setForward(false);
/* 106 */       return true;
/*     */     } 
/*     */     
/* 109 */     if (Hover.isHovered(this.umbilical, mouseX, mouseY)) {
/* 110 */       this.drag = true;
/*     */     }
/*     */     
/* 113 */     return false;
/*     */   }
/*     */   
/*     */   public boolean dragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
/* 117 */     if (Hover.isHovered(height(15.0F), mouseX, mouseY)) {
/* 118 */       boolean dragUmbilical = false;
/* 119 */       if (this.umbilical.getX() == this.x + this.width - 15.0F && this.umbilical.getY() == this.y + this.height - 15.0F) dragUmbilical = true; 
/* 120 */       this.x = (float)(this.x + dragX);
/* 121 */       this.y = (float)(this.y + dragY);
/* 122 */       return true;
/*     */     } 
/*     */     
/* 125 */     return false;
/*     */   }
/*     */   
/*     */   private static void drawBezierLine(float startX, float startY, float endX, float endY, float control1X, float control1Y, float control2X, float control2Y) {
/* 129 */     GL11.glEnable(2848);
/* 130 */     GL11.glHint(3154, 4354);
/* 131 */     GL11.glEnable(3042);
/* 132 */     GL11.glBlendFunc(770, 771);
/* 133 */     Render.color(rock.getThemes().getFirstColor().alpha(ConstructorScreen.opening.get()));
/*     */     
/* 135 */     GL11.glLineWidth(3.0F);
/* 136 */     GL11.glBegin(3); float t;
/* 137 */     for (t = 0.0F; t <= 1.0F; t = (float)(t + 0.01D)) {
/*     */       
/* 139 */       float x = (float)(Math.pow((1.0F - t), 3.0D) * startX + 3.0D * Math.pow((1.0F - t), 2.0D) * t * control1X + (3.0F * (1.0F - t)) * Math.pow(t, 2.0D) * control2X + Math.pow(t, 3.0D) * endX);
/*     */ 
/*     */       
/* 142 */       float y = (float)(Math.pow((1.0F - t), 3.0D) * startY + 3.0D * Math.pow((1.0F - t), 2.0D) * t * control1Y + (3.0F * (1.0F - t)) * Math.pow(t, 2.0D) * control2Y + Math.pow(t, 3.0D) * endY);
/*     */       
/* 144 */       GL11.glVertex2f(x, y);
/*     */     } 
/* 146 */     GL11.glEnd();
/* 147 */     GL11.glHint(3154, 4352);
/* 148 */     GL11.glDisable(2848);
/*     */   }
/*     */   
/*     */   public boolean released(double mouseX, double mouseY, int button) {
/* 152 */     this.drag = false;
/* 153 */     for (Block block : rock.getScriptConstructor().getBlocks()) {
/* 154 */       if (Hover.isHovered(block, this.umbilical.getX(), this.umbilical.getY()) && block != this && (block instanceof fun.rockstarity.api.constuctor.blocks.types.BlockAction || block instanceof fun.rockstarity.api.constuctor.blocks.types.actions.BlockCondition)) {
/* 155 */         block.setParent(this);
/* 156 */         this.child = block;
/* 157 */         return false;
/*     */       } 
/*     */     } 
/*     */     
/* 161 */     if (this.child != null) {
/* 162 */       this.child.setParent((Block)null);
/* 163 */       this.child = null;
/*     */     } 
/* 165 */     this.umbilical = new Rect(this.x + this.width - 15.0F, this.y + this.height - 15.0F, 10.0F, 10.0F);
/*     */     
/* 167 */     return false;
/*     */   }
/*     */   
/*     */   public void tick() {}
/*     */   
/*     */   public void pressed(int keyCode, int scanCode, int modifiers) {}
/*     */   
/*     */   public void charTyped(char codePoint, int modifiers) {}
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\constuctor\blocks\Block.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */