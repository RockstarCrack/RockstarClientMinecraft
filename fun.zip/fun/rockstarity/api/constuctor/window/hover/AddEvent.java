/*    */ package fun.rockstarity.api.constuctor.window.hover;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.constuctor.blocks.types.BlockEvent;
/*    */ import fun.rockstarity.api.constuctor.window.Window;
/*    */ import fun.rockstarity.api.helpers.math.Hover;
/*    */ import fun.rockstarity.api.helpers.render.Stencil;
/*    */ import fun.rockstarity.api.render.shaders.list.Round;
/*    */ import fun.rockstarity.api.render.ui.rect.Rect;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AddEvent
/*    */   extends Window
/*    */   implements IAccess
/*    */ {
/* 24 */   private final HashMap<String, Runnable> actions = new HashMap<>();
/*    */   
/*    */   public AddEvent(float x, float y, float width, float height) {
/* 27 */     super(x, y, width, height);
/* 28 */     this.opening.setForward(true);
/*    */     
/* 30 */     for (Map.Entry<String, Class<?>> action : (Iterable<Map.Entry<String, Class<?>>>)rock.getScriptConstructor().getEvents().entrySet()) {
/* 31 */       this.actions.put(action.getKey(), () -> rock.getScriptConstructor().getBlocks().add(new BlockEvent((String)action.getKey(), x, y, 100.0F, 35.0F, (Class)action.getValue())));
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/* 38 */     this.black = rock.getThemes().getTextFirstColor().alpha(this.opening.get());
/* 39 */     this.bgColor = rock.getThemes().getFirstColor().alpha(this.opening.get());
/* 40 */     this.actionsColor = rock.getThemes().getFirstColor().alpha(this.opening.get());
/*    */     
/* 42 */     Round.draw(matrixStack, new Rect(this.x, this.y, this.width, this.height * this.opening.get()), 3.0F, this.bgColor);
/*    */     
/* 44 */     Stencil.init();
/* 45 */     Round.draw(matrixStack, new Rect(this.x, this.y, this.width, this.height * this.opening.get()), 3.0F, this.bgColor);
/* 46 */     Stencil.read(1);
/*    */     
/* 48 */     bold.get(14).draw(matrixStack, "Событие при", this.x + 5.0F, this.y + 4.0F, this.black);
/* 49 */     float yOff = 0.0F;
/* 50 */     for (Map.Entry<String, Runnable> action : this.actions.entrySet()) {
/* 51 */       Rect rect = new Rect(this.x + 5.0F, this.y + 17.0F + yOff, this.width - 10.0F, 15.0F);
/* 52 */       Round.draw(matrixStack, rect, 2.0F, this.actionsColor.darker(Hover.isHovered(rect, mouseX, mouseY) ? 0.05F : 0.0F));
/* 53 */       bold.get(16).draw(matrixStack, action.getKey(), this.x + 8.0F, this.y + 19.0F + yOff, this.black);
/*    */       
/* 55 */       yOff += 17.0F;
/*    */     } 
/*    */     
/* 58 */     Stencil.finish();
/*    */     
/* 60 */     this.height = yOff + 21.0F;
/*    */   }
/*    */   
/*    */   public boolean clicked(double mouseX, double mouseY, int button) {
/* 64 */     if (!Hover.isHovered((Rect)this, mouseX, mouseY)) {
/* 65 */       this.opening.setForward(false);
/*    */     } else {
/* 67 */       float yOff = 0.0F;
/* 68 */       for (Map.Entry<String, Runnable> action : this.actions.entrySet()) {
/* 69 */         Rect rect = new Rect(this.x + 5.0F, this.y + 17.0F + yOff, this.width - 10.0F, 15.0F);
/* 70 */         if (Hover.isHovered(rect, mouseX, mouseY)) {
/* 71 */           ((Runnable)action.getValue()).run();
/* 72 */           this.opening.setForward(false);
/* 73 */           return true;
/*    */         } 
/*    */         
/* 76 */         yOff += 17.0F;
/*    */       } 
/*    */     } 
/*    */     
/* 80 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\constuctor\window\hover\AddEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */