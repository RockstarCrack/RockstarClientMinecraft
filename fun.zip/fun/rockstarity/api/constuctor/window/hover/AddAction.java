/*    */ package fun.rockstarity.api.constuctor.window.hover;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.constuctor.blocks.types.actions.BlockChatMsg;
/*    */ import fun.rockstarity.api.constuctor.interfaces.IPlayerAction;
/*    */ import fun.rockstarity.api.constuctor.window.Window;
/*    */ import fun.rockstarity.api.helpers.math.Hover;
/*    */ import fun.rockstarity.api.helpers.render.Stencil;
/*    */ import fun.rockstarity.api.render.shaders.list.Round;
/*    */ import fun.rockstarity.api.render.ui.rect.Rect;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AddAction
/*    */   extends Window
/*    */   implements IAccess
/*    */ {
/*    */   private final String name;
/* 26 */   private final HashMap<String, Runnable> actions = new HashMap<>();
/*    */   
/*    */   public AddAction(String name, float x, float y, float width, float height) {
/* 29 */     super(x, y, width, height);
/* 30 */     this.name = name;
/* 31 */     this.opening.setForward(true);
/*    */     
/* 33 */     if (name.equals("Игрок")) {
/* 34 */       for (Map.Entry<String, IPlayerAction> action : (Iterable<Map.Entry<String, IPlayerAction>>)rock.getScriptConstructor().getPlayerActions().entrySet()) {
/* 35 */         this.actions.put(action.getKey(), () -> rock.getScriptConstructor().getBlocks().add(new BlockChatMsg("Игрок." + (String)action.getKey(), x, y, 100.0F, 45.0F, (IPlayerAction)action.getValue())));
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/* 42 */     this.black = rock.getThemes().getTextFirstColor().alpha(this.opening.get());
/* 43 */     this.bgColor = rock.getThemes().getFirstColor().alpha(this.opening.get());
/* 44 */     this.actionsColor = rock.getThemes().getFirstColor().alpha(this.opening.get());
/*    */     
/* 46 */     Round.draw(matrixStack, new Rect(this.x, this.y, this.width, this.height * this.opening.get()), 3.0F, this.bgColor);
/*    */     
/* 48 */     Stencil.init();
/* 49 */     Round.draw(matrixStack, new Rect(this.x, this.y, this.width, this.height * this.opening.get()), 3.0F, this.bgColor);
/* 50 */     Stencil.read(1);
/*    */     
/* 52 */     bold.get(14).draw(matrixStack, this.name, this.x + 5.0F, this.y + 4.0F, this.black);
/* 53 */     float yOff = 0.0F;
/* 54 */     for (Map.Entry<String, Runnable> action : this.actions.entrySet()) {
/* 55 */       Rect rect = new Rect(this.x + 5.0F, this.y + 17.0F + yOff, this.width - 10.0F, 15.0F);
/* 56 */       Round.draw(matrixStack, rect, 2.0F, this.actionsColor.darker(Hover.isHovered(rect, mouseX, mouseY) ? 0.05F : 0.0F));
/* 57 */       bold.get(16).draw(matrixStack, action.getKey(), this.x + 8.0F, this.y + 19.0F + yOff, this.black);
/*    */       
/* 59 */       yOff += 17.0F;
/*    */     } 
/*    */     
/* 62 */     Stencil.finish();
/*    */     
/* 64 */     this.height = yOff + 21.0F;
/*    */   }
/*    */   
/*    */   public boolean clicked(double mouseX, double mouseY, int button) {
/* 68 */     if (!Hover.isHovered((Rect)this, mouseX, mouseY)) {
/* 69 */       this.opening.setForward(false);
/*    */     } else {
/* 71 */       float yOff = 0.0F;
/* 72 */       for (Map.Entry<String, Runnable> action : this.actions.entrySet()) {
/* 73 */         Rect rect = new Rect(this.x + 5.0F, this.y + 17.0F + yOff, this.width - 10.0F, 15.0F);
/* 74 */         if (Hover.isHovered(rect, mouseX, mouseY)) {
/* 75 */           ((Runnable)action.getValue()).run();
/* 76 */           this.opening.setForward(false);
/* 77 */           return true;
/*    */         } 
/*    */         
/* 80 */         yOff += 17.0F;
/*    */       } 
/*    */     } 
/*    */     
/* 84 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\constuctor\window\hover\AddAction.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */