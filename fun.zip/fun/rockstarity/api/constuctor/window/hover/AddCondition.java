/*    */ package fun.rockstarity.api.constuctor.window.hover;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.constuctor.blocks.types.actions.BlockCondition;
/*    */ import fun.rockstarity.api.constuctor.interfaces.ICondition;
/*    */ import fun.rockstarity.api.constuctor.window.Window;
/*    */ import fun.rockstarity.api.helpers.math.Hover;
/*    */ import fun.rockstarity.api.helpers.render.Stencil;
/*    */ import fun.rockstarity.api.render.shaders.list.Round;
/*    */ import fun.rockstarity.api.render.ui.rect.Rect;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class AddCondition
/*    */   extends Window
/*    */   implements IAccess {
/* 19 */   private final HashMap<String, Runnable> actions = new HashMap<>();
/*    */   
/*    */   public AddCondition(float x, float y, float width, float height) {
/* 22 */     super(x, y, width, height);
/*    */     
/* 24 */     this.opening.setForward(true);
/*    */     
/* 26 */     for (Iterator<Map.Entry<String, ICondition>> iterator = rock.getScriptConstructor().getConditions().entrySet().iterator(); iterator.hasNext(); ) { Map.Entry<String, ICondition> conditionEntry = iterator.next();
/* 27 */       String conditionName = conditionEntry.getKey();
/* 28 */       this.actions.put(conditionName, () -> {
/*    */             ICondition condition = (ICondition)conditionEntry.getValue();
/*    */             BlockCondition blockCondition = new BlockCondition(conditionName, x, y, 150.0F, 30.0F, condition);
/*    */             rock.getScriptConstructor().getBlocks().add(blockCondition);
/*    */             this.opening.setForward(false);
/*    */           }); }
/*    */   
/*    */   }
/*    */ 
/*    */   
/*    */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/* 39 */     this.black = rock.getThemes().getTextFirstColor().alpha(this.opening.get());
/* 40 */     this.bgColor = rock.getThemes().getFirstColor().alpha(this.opening.get());
/* 41 */     this.actionsColor = rock.getThemes().getFirstColor().alpha(this.opening.get());
/*    */     
/* 43 */     Round.draw(matrixStack, new Rect(this.x, this.y, this.width, this.height * this.opening.get()), 3.0F, this.bgColor);
/*    */     
/* 45 */     Stencil.init();
/* 46 */     Round.draw(matrixStack, new Rect(this.x, this.y, this.width, this.height * this.opening.get()), 3.0F, this.bgColor);
/* 47 */     Stencil.read(1);
/*    */     
/* 49 */     bold.get(14).draw(matrixStack, "Добавить условие", this.x + 5.0F, this.y + 4.0F, this.black);
/*    */     
/* 51 */     float yOff = 0.0F;
/* 52 */     for (Map.Entry<String, Runnable> action : this.actions.entrySet()) {
/* 53 */       Rect rect = new Rect(this.x + 5.0F, this.y + 17.0F + yOff, this.width - 10.0F, 15.0F);
/* 54 */       Round.draw(matrixStack, rect, 2.0F, this.actionsColor.darker(Hover.isHovered(rect, mouseX, mouseY) ? 0.05F : 0.0F));
/* 55 */       bold.get(16).draw(matrixStack, action.getKey(), this.x + 8.0F, this.y + 19.0F + yOff, this.black);
/*    */       
/* 57 */       yOff += 17.0F;
/*    */     } 
/*    */     
/* 60 */     Stencil.finish();
/*    */     
/* 62 */     this.height = yOff + 21.0F;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean clicked(double mouseX, double mouseY, int button) {
/* 67 */     if (!Hover.isHovered((Rect)this, mouseX, mouseY)) {
/* 68 */       this.opening.setForward(false);
/*    */     } else {
/* 70 */       float yOff = 0.0F;
/* 71 */       for (Map.Entry<String, Runnable> action : this.actions.entrySet()) {
/* 72 */         Rect rect = new Rect(this.x + 5.0F, this.y + 17.0F + yOff, this.width - 10.0F, 15.0F);
/* 73 */         if (Hover.isHovered(rect, mouseX, mouseY)) {
/* 74 */           ((Runnable)action.getValue()).run();
/* 75 */           this.opening.setForward(false);
/* 76 */           return true;
/*    */         } 
/*    */         
/* 79 */         yOff += 17.0F;
/*    */       } 
/*    */     } 
/*    */     
/* 83 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\constuctor\window\hover\AddCondition.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */