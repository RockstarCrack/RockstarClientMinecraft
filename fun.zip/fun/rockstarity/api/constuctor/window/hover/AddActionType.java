/*    */ package fun.rockstarity.api.constuctor.window.hover;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.constuctor.window.Window;
/*    */ import fun.rockstarity.api.helpers.math.Hover;
/*    */ import fun.rockstarity.api.helpers.render.Stencil;
/*    */ import fun.rockstarity.api.render.shaders.list.Round;
/*    */ import fun.rockstarity.api.render.ui.rect.Rect;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AddActionType
/*    */   extends Window
/*    */   implements IAccess
/*    */ {
/* 25 */   private final HashMap<String, Runnable> actions = new HashMap<>();
/*    */   
/*    */   public AddActionType(float x, float y, float width, float height) {
/* 28 */     super(x, y, width, height);
/* 29 */     this.opening.setForward(true);
/*    */     
/* 31 */     for (Map.Entry<String, HashMap> action : (Iterable<Map.Entry<String, HashMap>>)rock.getScriptConstructor().getActionTypes().entrySet()) {
/* 32 */       this.actions.put(action.getKey(), () -> rock.getScriptConstructor().getScreen().getWindows().add(new AddAction((String)action.getKey(), x + width + 5.0F, y, 125.0F, 100.0F)));
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/* 39 */     this.black = rock.getThemes().getTextFirstColor().alpha(this.opening.get());
/* 40 */     this.bgColor = rock.getThemes().getFirstColor().alpha(this.opening.get());
/* 41 */     this.actionsColor = rock.getThemes().getFirstColor().alpha(this.opening.get());
/*    */     
/* 43 */     Round.draw(matrixStack, new Rect(this.x, this.y, this.width, this.height * this.opening.get()), 3.0F, this.bgColor);
/*    */     
/* 45 */     Stencil.init();
/* 46 */     Round.draw(matrixStack, new Rect(this.x, this.y, this.width, this.height * this.opening.get()), 3.0F, this.bgColor);
/* 47 */     Stencil.read(1);
/*    */     
/* 49 */     bold.get(14).draw(matrixStack, "Событие", this.x + 5.0F, this.y + 4.0F, this.black);
/* 50 */     float yOff = 0.0F;
/* 51 */     for (Map.Entry<String, Runnable> action : this.actions.entrySet()) {
/* 52 */       Rect rect = new Rect(this.x + 5.0F, this.y + 17.0F + yOff, this.width - 10.0F, 15.0F);
/* 53 */       Round.draw(matrixStack, rect, 2.0F, this.actionsColor.darker(Hover.isHovered(rect, mouseX, mouseY) ? 0.05F : 0.0F));
/* 54 */       bold.get(16).draw(matrixStack, action.getKey(), this.x + 8.0F, this.y + 19.0F + yOff, this.black);
/*    */       
/* 56 */       yOff += 17.0F;
/*    */     } 
/*    */     
/* 59 */     Stencil.finish();
/*    */     
/* 61 */     this.height = yOff + 21.0F;
/*    */   }
/*    */   
/*    */   public boolean clicked(double mouseX, double mouseY, int button) {
/* 65 */     if (!Hover.isHovered((Rect)this, mouseX, mouseY)) {
/* 66 */       this.opening.setForward(false);
/*    */     } else {
/* 68 */       float yOff = 0.0F;
/* 69 */       for (Map.Entry<String, Runnable> action : this.actions.entrySet()) {
/* 70 */         Rect rect = new Rect(this.x + 5.0F, this.y + 17.0F + yOff, this.width - 10.0F, 15.0F);
/* 71 */         if (Hover.isHovered(rect, mouseX, mouseY)) {
/* 72 */           ((Runnable)action.getValue()).run();
/* 73 */           this.opening.setForward(false);
/* 74 */           return true;
/*    */         } 
/*    */         
/* 77 */         yOff += 17.0F;
/*    */       } 
/*    */     } 
/*    */     
/* 81 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\constuctor\window\hover\AddActionType.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */