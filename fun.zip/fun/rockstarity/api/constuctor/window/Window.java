/*    */ package fun.rockstarity.api.constuctor.window;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.render.animation.Animation;
/*    */ import fun.rockstarity.api.render.animation.Easing;
/*    */ import fun.rockstarity.api.render.color.FixColor;
/*    */ import fun.rockstarity.api.render.ui.rect.Rect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Window
/*    */   extends Rect
/*    */ {
/*    */   public Animation getOpening() {
/* 18 */     return this.opening; } protected final Animation opening = (new Animation())
/* 19 */     .setEasing(Easing.BOTH_SINE).setSpeed(300).setSize(1.0F); protected FixColor black; protected FixColor bgColor;
/*    */   protected FixColor actionsColor;
/*    */   
/*    */   public Window(float x, float y, float width, float height) {
/* 23 */     super(x, y, width, height);
/*    */   }
/*    */ 
/*    */   
/*    */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {}
/*    */ 
/*    */   
/*    */   public boolean clicked(double mouseX, double mouseY, int button) {
/* 31 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\constuctor\window\Window.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */