/*    */ package fun.rockstarity.api.constuctor.window;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.constuctor.window.hover.AddActionType;
/*    */ import fun.rockstarity.api.constuctor.window.hover.AddCondition;
/*    */ import fun.rockstarity.api.constuctor.window.hover.AddEvent;
/*    */ import fun.rockstarity.api.helpers.math.Hover;
/*    */ import fun.rockstarity.api.helpers.render.Stencil;
/*    */ import fun.rockstarity.api.render.shaders.list.Round;
/*    */ import fun.rockstarity.api.render.ui.rect.Rect;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AddWindow
/*    */   extends Window
/*    */   implements IAccess
/*    */ {
/* 24 */   private final HashMap<String, Runnable> actions = new HashMap<>();
/*    */   
/*    */   public AddWindow(float x, float y, float width, float height) {
/* 27 */     super(x, y, width, height);
/* 28 */     this.opening.setForward(true);
/*    */     
/* 30 */     this.actions.put("Событие", () -> rock.getScriptConstructor().getScreen().getWindows().add(new AddEvent(x + width + 5.0F, y, 125.0F, 100.0F)));
/*    */ 
/*    */ 
/*    */     
/* 34 */     this.actions.put("Действие", () -> rock.getScriptConstructor().getScreen().getWindows().add(new AddActionType(x + width + 5.0F, y, 125.0F, 100.0F)));
/*    */ 
/*    */ 
/*    */     
/* 38 */     this.actions.put("Условие", () -> rock.getScriptConstructor().getScreen().getWindows().add(new AddCondition(x + width + 5.0F, y, 200.0F, 150.0F)));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/* 44 */     this.black = rock.getThemes().getFirstColor().alpha(this.opening.get());
/* 45 */     this.bgColor = rock.getThemes().getFirstColor().alpha(this.opening.get());
/* 46 */     this.actionsColor = rock.getThemes().getFirstColor().alpha(this.opening.get());
/*    */     
/* 48 */     Round.draw(matrixStack, new Rect(this.x, this.y, this.width, this.height), 3.0F, this.bgColor);
/*    */     
/* 50 */     Stencil.init();
/* 51 */     Round.draw(matrixStack, new Rect(this.x, this.y, this.width, this.height * this.opening.get()), 3.0F, this.bgColor);
/* 52 */     Stencil.read(1);
/*    */     
/* 54 */     bold.get(14).draw(matrixStack, "Добавить", this.x + 5.0F, this.y + 4.0F, rock.getThemes().getTextFirstColor().alpha(this.opening.get()));
/* 55 */     float yOff = 0.0F;
/* 56 */     for (Map.Entry<String, Runnable> action : this.actions.entrySet()) {
/* 57 */       Rect rect = new Rect(this.x + 5.0F, this.y + 17.0F + yOff, this.width - 10.0F, 15.0F);
/* 58 */       Round.draw(matrixStack, rect, 2.0F, this.actionsColor.darker(Hover.isHovered(rect, mouseX, mouseY) ? 0.05F : 0.0F));
/* 59 */       bold.get(16).draw(matrixStack, action.getKey(), this.x + 8.0F, this.y + 19.0F + yOff, rock.getThemes().getTextFirstColor().alpha(this.opening.get()));
/*    */       
/* 61 */       yOff += 17.0F;
/*    */     } 
/*    */     
/* 64 */     Stencil.finish();
/*    */     
/* 66 */     this.height = yOff + 21.0F;
/*    */   }
/*    */   
/*    */   public boolean clicked(double mouseX, double mouseY, int button) {
/* 70 */     if (!Hover.isHovered(this, mouseX, mouseY)) {
/* 71 */       this.opening.setForward(false);
/*    */     } else {
/* 73 */       float yOff = 0.0F;
/* 74 */       for (Map.Entry<String, Runnable> action : this.actions.entrySet()) {
/* 75 */         Rect rect = new Rect(this.x + 5.0F, this.y + 17.0F + yOff, this.width - 10.0F, 15.0F);
/* 76 */         if (Hover.isHovered(rect, mouseX, mouseY)) {
/* 77 */           ((Runnable)action.getValue()).run();
/* 78 */           this.opening.setForward(false);
/* 79 */           return true;
/*    */         } 
/*    */         
/* 82 */         yOff += 17.0F;
/*    */       } 
/*    */     } 
/*    */     
/* 86 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\constuctor\window\AddWindow.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */