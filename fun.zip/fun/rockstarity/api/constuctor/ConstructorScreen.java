/*     */ package fun.rockstarity.api.constuctor;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.constuctor.blocks.Block;
/*     */ import fun.rockstarity.api.constuctor.window.AddWindow;
/*     */ import fun.rockstarity.api.constuctor.window.Window;
/*     */ import fun.rockstarity.api.helpers.math.Hover;
/*     */ import fun.rockstarity.api.render.animation.Animation;
/*     */ import fun.rockstarity.api.render.animation.Easing;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.shaders.list.Round;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import fun.rockstarity.client.modules.render.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.client.gui.screen.Screen;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TranslationTextComponent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConstructorScreen
/*     */   extends Screen
/*     */   implements IAccess
/*     */ {
/*     */   private boolean drag;
/*  34 */   private final ArrayList<Window> windows = new ArrayList<>(); public ArrayList<Window> getWindows() { return this.windows; }
/*     */   
/*     */   private int mouseX;
/*     */   private int mouseY;
/*  38 */   public static Animation opening = (new Animation()).setEasing(Easing.BOTH_SINE).setSpeed(200);
/*     */   
/*     */   public ConstructorScreen() {
/*  41 */     super((ITextComponent)new TranslationTextComponent(""));
/*  42 */     opening.getTimer().reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
/*  47 */     Round.draw(matrixStack, new Rect(0.0F, 0.0F, sr.getScaledWidth(), sr.getScaledHeight()), 0.0F, FixColor.BLACK.alpha(0.4D * opening.get()));
/*     */     
/*  49 */     this.mouseX = mouseX;
/*  50 */     this.mouseY = mouseY;
/*     */     
/*  52 */     for (Window window : this.windows) {
/*  53 */       if (window.getOpening().finished(false)) {
/*  54 */         this.windows.remove(window);
/*     */         break;
/*     */       } 
/*  57 */       window.render(matrixStack, mouseX, mouseY, partialTicks);
/*     */     } 
/*     */     
/*  60 */     for (Block block : rock.getScriptConstructor().getBlocks()) {
/*  61 */       if (block.getOpening().finished(false)) {
/*  62 */         rock.getScriptConstructor().getBlocks().remove(block);
/*     */         break;
/*     */       } 
/*  65 */       block.render(matrixStack, mouseX, mouseY, partialTicks);
/*     */     } 
/*     */     
/*  68 */     if (this.drag) {
/*  69 */       for (Block block : rock.getScriptConstructor().getBlocks()) {
/*  70 */         block.setX(mouseX + block.getDragX());
/*  71 */         block.setY(mouseY + block.getDragY());
/*     */       } 
/*     */     }
/*     */     
/*  75 */     super.render(matrixStack, mouseX, mouseY, partialTicks);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean mouseClicked(double mouseX, double mouseY, int button) {
/*  80 */     boolean canDrag = true;
/*     */     
/*  82 */     for (Window window : this.windows) {
/*  83 */       if (window.clicked(mouseX, mouseY, button))
/*     */         break; 
/*     */     } 
/*  86 */     for (Block block : rock.getScriptConstructor().getBlocks()) {
/*  87 */       if (Hover.isHovered((Rect)block, mouseX, mouseY)) {
/*  88 */         canDrag = false;
/*     */       }
/*  90 */       if (block.clicked(mouseX, mouseY, button))
/*     */         break; 
/*     */     } 
/*  93 */     if (canDrag) {
/*  94 */       for (Block block : rock.getScriptConstructor().getBlocks()) {
/*  95 */         block.setDragX((float)(block.getX() - mouseX));
/*  96 */         block.setDragY((float)(block.getY() - mouseY));
/*     */       } 
/*  98 */       this.drag = true;
/*     */     } 
/*     */     
/* 101 */     if (button == 1) this.windows.add(new AddWindow((float)mouseX, (float)mouseY, 75.0F, 100.0F)); 
/* 102 */     return super.mouseClicked(mouseX, mouseY, button);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean mouseReleased(double mouseX, double mouseY, int button) {
/* 107 */     for (Block block : rock.getScriptConstructor().getBlocks()) {
/* 108 */       if (block.released(mouseX, mouseY, button))
/*     */         break; 
/* 110 */     }  this.drag = false;
/* 111 */     return super.mouseClicked(mouseX, mouseY, button);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
/* 116 */     boolean canDrag = true;
/*     */     
/* 118 */     for (Block block : rock.getScriptConstructor().getBlocks()) {
/* 119 */       if (block.dragged(mouseX, mouseY, button, dragX, dragY)) {
/*     */         break;
/*     */       }
/* 122 */       if (Hover.isHovered((Rect)block, mouseX, mouseY)) {
/* 123 */         canDrag = false;
/*     */       }
/*     */     } 
/*     */     
/* 127 */     return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
/* 132 */     if (keyCode == 256 && opening.finished()) {
/* 133 */       mc.displayGuiScreen(null);
/* 134 */       opening.setForward(false);
/* 135 */       ((Constructor)rock.getModules().get(Constructor.class)).toggle();
/*     */     } 
/*     */     
/* 138 */     if (keyCode == 261) {
/* 139 */       for (Block block : rock.getScriptConstructor().getBlocks()) {
/* 140 */         if (Hover.isHovered((Rect)block, this.mouseX, this.mouseY)) {
/* 141 */           block.getOpening().setForward(false);
/* 142 */           return true;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 147 */     for (Block block : rock.getScriptConstructor().getBlocks()) {
/* 148 */       block.pressed(keyCode, scanCode, modifiers);
/*     */     }
/*     */     
/* 151 */     return super.keyPressed(keyCode, scanCode, modifiers);
/*     */   }
/*     */ 
/*     */   
/*     */   public void tick() {
/* 156 */     for (Block block : rock.getScriptConstructor().getBlocks()) {
/* 157 */       block.tick();
/*     */     }
/* 159 */     super.tick();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean charTyped(char codePoint, int modifiers) {
/* 164 */     for (Block block : rock.getScriptConstructor().getBlocks()) {
/* 165 */       block.charTyped(codePoint, modifiers);
/*     */     }
/* 167 */     return super.charTyped(codePoint, modifiers);
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\constuctor\ConstructorScreen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */