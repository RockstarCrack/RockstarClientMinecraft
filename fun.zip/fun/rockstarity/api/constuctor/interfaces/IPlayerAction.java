package fun.rockstarity.api.constuctor.interfaces;

@FunctionalInterface
public interface IPlayerAction {
  void performAction(Object... paramVarArgs);
}


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\constuctor\interfaces\IPlayerAction.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */