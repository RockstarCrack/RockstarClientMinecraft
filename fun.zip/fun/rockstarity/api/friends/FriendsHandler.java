/*     */ package fun.rockstarity.api.friends;
/*     */ 
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.helpers.game.Chat;
/*     */ import fun.rockstarity.api.render.ui.alerts.AlertType;
/*     */ import fun.rockstarity.api.secure.Debugger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.text.TextFormatting;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FriendsHandler
/*     */   implements IAccess
/*     */ {
/*  22 */   private final ArrayList<Friend> friends = new ArrayList<>(); public ArrayList<Friend> getFriends() { return this.friends; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(String friendName, String hiddenName) {
/*  32 */     if (friendName.length() <= 2) {
/*  33 */       rock.getAlertHandler().alert("Имя друга слишком короткое", AlertType.ERROR);
/*     */       
/*     */       return;
/*     */     } 
/*  37 */     if (get(friendName) != null) {
/*  38 */       rock.getAlertHandler().alert("Друг с именем" + friendName + " уже существует", AlertType.ERROR);
/*     */       
/*     */       return;
/*     */     } 
/*  42 */     this.friends.add(new Friend(friendName, hiddenName));
/*  43 */     rock.getAlertHandler().alert("Друг " + friendName + " добавлен", AlertType.INFO);
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(String name) {
/*  48 */     add(name, "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(String name) {
/*  55 */     Friend friendToRemove = this.friends.stream().filter(friend -> friend.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
/*     */     
/*  57 */     if (friendToRemove != null) {
/*  58 */       rock.getAlertHandler().alert("Друг " + name + " удален", AlertType.INFO);
/*  59 */       this.friends.remove(friendToRemove);
/*     */     } else {
/*  61 */       rock.getAlertHandler().alert("Друг с именем " + name + " не найден", AlertType.ERROR);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void clear() {
/*  66 */     this.friends.clear();
/*  67 */     rock.getAlertHandler().alert("Список друзей очищен", AlertType.INFO);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Friend get(String name) {
/*  76 */     return this.friends.stream()
/*  77 */       .filter(friend -> friend.getName().equalsIgnoreCase(name))
/*  78 */       .findFirst()
/*  79 */       .orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Friend get(Entity entity) {
/*  88 */     return get(entity.getName().getString());
/*     */   }
/*     */   
/*     */   public void list() {
/*  92 */     if (this.friends.isEmpty()) {
/*  93 */       Chat.msg("Список друзей пуст!");
/*     */     } else {
/*  95 */       Chat.msg("Список друзей:");
/*     */       try {
/*  97 */         for (Iterator<Friend> iterator = this.friends.iterator(); iterator.hasNext(); ) { Friend friend = iterator.next();
/*  98 */           String friendName = friend.getName();
/*  99 */           Chat.msg(String.valueOf(TextFormatting.AQUA) + "[Rockstar] " + String.valueOf(TextFormatting.AQUA) + "[" + String.valueOf(TextFormatting.GRAY) + "] " + this.friends.indexOf(friend) + 1 + String.valueOf(TextFormatting.WHITE), "Удалить " + String.valueOf(TextFormatting.GRAY) + String.valueOf(friend), () -> {
/*     */                 this.friends.remove(friend);
/*     */                 
/*     */                 Chat.msg("Друг " + friendName + " удален. Обновляю список");
/*     */                 rock.getCommands().execute("friend list");
/*     */               }); }
/*     */       
/* 106 */       } catch (Exception e) {
/* 107 */         Debugger.print(e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isFriend(String friendName) {
/* 113 */     return this.friends
/* 114 */       .stream()
/* 115 */       .anyMatch(friend -> friend.getName().equalsIgnoreCase(friendName));
/*     */   }
/*     */   
/*     */   public boolean isFriend(Entity ent) {
/* 119 */     if (ent == null) return false;
/*     */     
/* 121 */     return isFriend(ent.getName().getString());
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\friends\FriendsHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */