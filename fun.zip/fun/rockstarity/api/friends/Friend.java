/*    */ package fun.rockstarity.api.friends;
/*    */ 
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import fun.rockstarity.api.interfaces.Jsonable;
/*    */ 
/*    */ 
/*    */ public class Friend
/*    */   implements Jsonable
/*    */ {
/*    */   private String name;
/*    */   private String hiddenName;
/*    */   
/*    */   public void setName(String name) {
/* 15 */     this.name = name; } public void setHiddenName(String hiddenName) { this.hiddenName = hiddenName; }
/*    */ 
/*    */   
/*    */   public Friend(String name, String hiddenName) {
/* 19 */     this.name = name;
/* 20 */     this.hiddenName = hiddenName;
/*    */   }
/*    */   
/*    */   public Friend(String name) {
/* 24 */     this.name = name;
/* 25 */     this.hiddenName = "";
/*    */   }
/*    */   public String getName() {
/* 28 */     return this.name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void load(JsonElement element) {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JsonElement save() {
/* 43 */     JsonObject jsonObject = new JsonObject();
/* 44 */     jsonObject.addProperty("originalName", this.name);
/* 45 */     jsonObject.addProperty("hiddenName", this.hiddenName);
/* 46 */     return (JsonElement)jsonObject;
/*    */   }
/*    */   
/*    */   public boolean haveHiddenName() {
/* 50 */     return !this.hiddenName.isEmpty();
/*    */   }
/*    */   
/*    */   public String getHiddenName(String alternative) {
/* 54 */     return this.hiddenName.isEmpty() ? alternative : this.hiddenName;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 59 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\friends\Friend.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */