/*    */ package fun.rockstarity.api.commands;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommandParameter
/*    */ {
/*    */   private final Command command;
/*    */   private final String[] names;
/*    */   
/*    */   public Command getCommand() {
/* 13 */     return this.command; } public String[] getNames() {
/* 14 */     return this.names;
/*    */   }
/*    */   public CommandParameter(Command cmd, String... names) {
/* 17 */     this.command = cmd;
/* 18 */     this.names = names;
/*    */     
/* 20 */     cmd.getParameters().add(this);
/*    */     
/* 22 */     if (names.length == 0) {
/* 23 */       throw new IllegalArgumentException("Parameter must have at least one name");
/*    */     }
/*    */   }
/*    */   
/*    */   public String getPrimaryName() {
/* 28 */     return this.names[0];
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\commands\CommandParameter.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */