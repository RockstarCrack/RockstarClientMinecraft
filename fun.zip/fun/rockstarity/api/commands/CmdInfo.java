package fun.rockstarity.api.commands;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface CmdInfo {
  String[] names();
  
  String desc();
}


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\commands\CmdInfo.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */