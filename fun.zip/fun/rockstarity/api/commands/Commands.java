/*     */ package fun.rockstarity.api.commands;
/*     */ 
/*     */ import fun.rockstarity.api.helpers.game.Chat;
/*     */ import fun.rockstarity.api.helpers.system.TextUtility;
/*     */ import fun.rockstarity.api.secure.Debugger;
/*     */ import fun.rockstarity.client.commands.BindCommand;
/*     */ import fun.rockstarity.client.commands.BotCommand;
/*     */ import fun.rockstarity.client.commands.BugCommand;
/*     */ import fun.rockstarity.client.commands.ClanInvestCommand;
/*     */ import fun.rockstarity.client.commands.ConfigsCommand;
/*     */ import fun.rockstarity.client.commands.FakePlayerCommand;
/*     */ import fun.rockstarity.client.commands.FriendsCommand;
/*     */ import fun.rockstarity.client.commands.HClipCommand;
/*     */ import fun.rockstarity.client.commands.HelpCommand;
/*     */ import fun.rockstarity.client.commands.InventoryCommand;
/*     */ import fun.rockstarity.client.commands.InvseeCommand;
/*     */ import fun.rockstarity.client.commands.LuaCommand;
/*     */ import fun.rockstarity.client.commands.MacroCommand;
/*     */ import fun.rockstarity.client.commands.PrefixCommand;
/*     */ import fun.rockstarity.client.commands.ReHubCommand;
/*     */ import fun.rockstarity.client.commands.ReconCommand;
/*     */ import fun.rockstarity.client.commands.ScoreCommand;
/*     */ import fun.rockstarity.client.commands.TaksaCommand;
/*     */ import fun.rockstarity.client.commands.TargetCommand;
/*     */ import fun.rockstarity.client.commands.TeleportCommand;
/*     */ import fun.rockstarity.client.commands.VClipCommand;
/*     */ import fun.rockstarity.client.commands.WayCommand;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import ru.kotopushka.antiautistleak.obfuscator.includes.annotations.compile.ReleaseCompileToNativeCalls;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Commands
/*     */   extends HashMap<Class, Command>
/*     */ {
/*  45 */   private String prefix = "."; public void setPrefix(String prefix) { this.prefix = prefix; } public String getPrefix() {
/*  46 */     return this.prefix;
/*     */   }
/*     */   public Commands() {
/*  49 */     Arrays.<Command>stream(new Command[] { (Command)new ConfigsCommand(), (Command)new FakePlayerCommand(), (Command)new VClipCommand(), (Command)new HClipCommand(), (Command)new ReHubCommand(), (Command)new FriendsCommand(), (Command)new MacroCommand(), (Command)new BindCommand(), (Command)new PrefixCommand(), (Command)new ReconCommand(), (Command)new WayCommand(), (Command)new BotCommand(), (Command)new BugCommand(), (Command)new HelpCommand(), (Command)new TargetCommand(), (Command)new ClanInvestCommand(), (Command)new TeleportCommand(), (Command)new InventoryCommand(), (Command)new InvseeCommand(), (Command)new ScoreCommand(), (Command)new LuaCommand(), (Command)new TaksaCommand()
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  73 */         }).forEach(this::add);
/*     */   }
/*     */   @ReleaseCompileToNativeCalls
/*     */   public boolean execute(String msg) {
/*  77 */     if (!msg.startsWith(this.prefix)) {
/*  78 */       msg = this.prefix + this.prefix;
/*     */     }
/*  80 */     return executeInternal(msg);
/*     */   }
/*     */   @ReleaseCompileToNativeCalls
/*     */   public boolean executeRaw(String msg) {
/*  84 */     return executeInternal(msg);
/*     */   }
/*     */   
/*     */   @ReleaseCompileToNativeCalls
/*     */   private boolean executeInternal(String msg) {
/*  89 */     if (!msg.startsWith(this.prefix)) return false;
/*     */     
/*  91 */     String[] m = msg.substring(this.prefix.length()).trim().split(" ");
/*  92 */     if (m.length == 0 || m[0].isEmpty()) {
/*  93 */       Chat.msg("Команда введена неверно. Используйте " + this.prefix + "help для получения списка команд.");
/*  94 */       return true;
/*     */     } 
/*     */     
/*  97 */     String inputCmd = m[0];
/*     */     
/*  99 */     List<Command> sorted = new ArrayList<>(values());
/* 100 */     sorted.sort((a, b) -> {
/*     */           int lenA = Arrays.<String>stream(a.getInfo().names()).mapToInt(String::length).max().orElse(0);
/*     */           
/*     */           int lenB = Arrays.<String>stream(b.getInfo().names()).mapToInt(String::length).max().orElse(0);
/*     */           return Integer.compare(lenB, lenA);
/*     */         });
/* 106 */     for (Command cmd : sorted) {
/* 107 */       for (String name : cmd.getInfo().names()) {
/* 108 */         if (inputCmd.equalsIgnoreCase(name)) {
/* 109 */           String[] args = Arrays.<String>copyOfRange(m, 1, m.length);
/*     */           try {
/* 111 */             cmd.execute(args);
/* 112 */           } catch (Exception e) {
/* 113 */             Debugger.print(e);
/*     */           } 
/* 115 */           return true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 120 */     String suggestion = getCorrection(inputCmd);
/* 121 */     if (suggestion != null) {
/* 122 */       Chat.msg("Команда введена неверно. Возможно, вы имели в виду: " + this.prefix + suggestion);
/*     */     } else {
/* 124 */       Chat.msg("Команда введена неверно. Используйте " + this.prefix + "help для получения списка команд.");
/*     */     } 
/*     */     
/* 127 */     return true;
/*     */   }
/*     */   @ReleaseCompileToNativeCalls
/*     */   private String getCorrection(String input) {
/* 131 */     String closest = null;
/* 132 */     int minDistance = Integer.MAX_VALUE;
/*     */     
/* 134 */     for (Command cmd : values()) {
/* 135 */       for (String name : cmd.getInfo().names()) {
/* 136 */         if (name.toLowerCase().startsWith(input.toLowerCase())) {
/* 137 */           return name;
/*     */         }
/*     */         
/* 140 */         int distance = TextUtility.levenshteinDistance(input.toLowerCase(), name.toLowerCase());
/* 141 */         if (distance < minDistance) {
/* 142 */           minDistance = distance;
/* 143 */           closest = name;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 148 */     return (minDistance <= input.length()) ? closest : null;
/*     */   }
/*     */   @ReleaseCompileToNativeCalls
/*     */   public void add(Command cmd) {
/* 152 */     if (cmd.getClass().isAnnotationPresent((Class)CmdInfo.class)) {
/* 153 */       cmd.setInfo(cmd.getClass().<CmdInfo>getAnnotation(CmdInfo.class));
/*     */     }
/* 155 */     put(cmd.getClass(), cmd);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends Command> T get(Class<T> moduleClass) {
/* 160 */     return moduleClass.cast(get(moduleClass));
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\commands\Commands.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */