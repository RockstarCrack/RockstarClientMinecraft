/*    */ package fun.rockstarity.api.commands;
/*    */ 
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.helpers.game.Chat;
/*    */ import fun.rockstarity.api.render.ui.alerts.AlertType;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Command
/*    */   implements IAccess
/*    */ {
/*    */   private CmdInfo info;
/*    */   
/*    */   public CmdInfo getInfo() {
/* 21 */     return this.info; } public void setInfo(CmdInfo info) { this.info = info; }
/*    */   
/* 23 */   private final List<CommandParameter> parameters = new ArrayList<>(); public List<CommandParameter> getParameters() { return this.parameters; }
/*    */ 
/*    */   
/*    */   public void execute(String[] args) {}
/*    */   
/*    */   protected boolean contains(String arg, String... texts) {
/* 29 */     return Arrays.<String>asList(texts).contains(arg.toLowerCase());
/*    */   }
/*    */   
/*    */   protected boolean contains(String arg, CommandParameter cmd) {
/* 33 */     return Arrays.<String>asList(cmd.getNames()).contains(arg.toLowerCase());
/*    */   }
/*    */   
/*    */   public void onEvent(Event event) {}
/*    */   
/*    */   public void error() {
/* 39 */     rock.getAlertHandler().alert("Неверное использование команды", AlertType.ERROR);
/*    */   }
/*    */   
/*    */   public void msg(Object object) {
/* 43 */     Chat.msg(object);
/*    */   }
/*    */   
/*    */   public ArrayList<String> getSuggestions(String[] args, String full) {
/* 47 */     return new ArrayList<>();
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\commands\Command.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */