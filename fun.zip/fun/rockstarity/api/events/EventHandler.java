/*     */ package fun.rockstarity.api.events;
/*     */ 
/*     */ import com.mojang.blaze3d.matrix.MatrixStack;
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.autobuy.ui.AutoBuyScreen;
/*     */ import fun.rockstarity.api.binds.Bind;
/*     */ import fun.rockstarity.api.binds.BindType;
/*     */ import fun.rockstarity.api.commands.Command;
/*     */ import fun.rockstarity.api.constuctor.ConstructorScreen;
/*     */ import fun.rockstarity.api.events.list.game.inputs.EventKey;
/*     */ import fun.rockstarity.api.events.list.game.packet.EventReceivePacket;
/*     */ import fun.rockstarity.api.events.list.player.EventAttack;
/*     */ import fun.rockstarity.api.events.list.player.EventMessage;
/*     */ import fun.rockstarity.api.events.list.render.EventRender2D;
/*     */ import fun.rockstarity.api.events.list.render.ui.shaders.EventBlur;
/*     */ import fun.rockstarity.api.events.list.render.world.EventUpdateCamera;
/*     */ import fun.rockstarity.api.helpers.game.BoostUtility;
/*     */ import fun.rockstarity.api.helpers.game.Chat;
/*     */ import fun.rockstarity.api.helpers.game.Server;
/*     */ import fun.rockstarity.api.helpers.math.TimerUtility;
/*     */ import fun.rockstarity.api.helpers.math.aura.ai.AIPredictor;
/*     */ import fun.rockstarity.api.helpers.player.InvUtility;
/*     */ import fun.rockstarity.api.helpers.player.Player;
/*     */ import fun.rockstarity.api.helpers.render.Render;
/*     */ import fun.rockstarity.api.helpers.render.Stencil;
/*     */ import fun.rockstarity.api.helpers.system.ThreadManager;
/*     */ import fun.rockstarity.api.modules.Module;
/*     */ import fun.rockstarity.api.modules.settings.Setting;
/*     */ import fun.rockstarity.api.modules.settings.list.CheckBox;
/*     */ import fun.rockstarity.api.modules.settings.list.Select;
/*     */ import fun.rockstarity.api.render.animation.Easing;
/*     */ import fun.rockstarity.api.render.color.FixColor;
/*     */ import fun.rockstarity.api.render.globals.marks.MarkManager;
/*     */ import fun.rockstarity.api.render.menufilter.MenuFilter;
/*     */ import fun.rockstarity.api.render.optimize.culling.processor.CullingProcessor;
/*     */ import fun.rockstarity.api.render.shaders.list.Blur;
/*     */ import fun.rockstarity.api.render.shaders.list.FrameFreeze;
/*     */ import fun.rockstarity.api.render.shaders.list.KawaseBlur;
/*     */ import fun.rockstarity.api.render.shaders.list.Round;
/*     */ import fun.rockstarity.api.render.ui.clickgui.ClickGuiRenderer;
/*     */ import fun.rockstarity.api.render.ui.clickgui.ClickGuiScreen;
/*     */ import fun.rockstarity.api.render.ui.clickgui.ClickGuiWindow;
/*     */ import fun.rockstarity.api.render.ui.mainmenu.Page;
/*     */ import fun.rockstarity.api.render.ui.mainmenu.alt.BanProcessor;
/*     */ import fun.rockstarity.api.render.ui.rect.Rect;
/*     */ import fun.rockstarity.api.scripts.Script;
/*     */ import fun.rockstarity.api.scripts.wrappers.Render;
/*     */ import fun.rockstarity.api.sounds.Sound;
/*     */ import fun.rockstarity.api.via.ViaFixer;
/*     */ import fun.rockstarity.client.modules.other.AutoBuy;
/*     */ import fun.rockstarity.client.modules.other.Panic;
/*     */ import fun.rockstarity.client.modules.player.FreeCam;
/*     */ import fun.rockstarity.client.modules.render.Beautifully;
/*     */ import fun.rockstarity.client.modules.render.ClickGui;
/*     */ import fun.rockstarity.client.modules.render.Interface;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import net.minecraft.client.gui.screen.Screen;
/*     */ import net.minecraft.client.settings.PointOfView;
/*     */ import net.minecraft.entity.LivingEntity;
/*     */ import net.minecraft.network.IPacket;
/*     */ import net.minecraft.network.play.server.SChatPacket;
/*     */ import net.minecraft.potion.EffectInstance;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.vector.Vector3d;
/*     */ import net.minecraft.util.math.vector.Vector3f;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EventHandler
/*     */   implements IAccess
/*     */ {
/*     */   static LivingEntity currentTarget;
/*     */   private static boolean lateInit;
/*     */   private static boolean resourcesLoaded;
/*     */   
/*     */   private EventHandler() {
/*  90 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*     */   } public static LivingEntity getCurrentTarget() {
/*  92 */     return currentTarget;
/*     */   }
/*     */   
/*     */   private static boolean resetCfg = true;
/*  96 */   private static TimerUtility lastBlur = new TimerUtility();
/*     */   
/*     */   public static void handleEvent(Event event) {
/*  99 */     if (!Player.isInGame())
/*     */       return; 
/* 101 */     if (event instanceof fun.rockstarity.api.events.list.player.EventUpdate) {
/*     */       try {
/* 103 */         for (EffectInstance effect : mc.player.getActivePotionEffects()) {
/* 104 */           if (effect.getDuration() <= 0) {
/* 105 */             mc.player.removePotionEffect(effect.getPotion());
/*     */           }
/*     */         } 
/* 108 */       } catch (Exception exception) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 113 */     if (rock.isPanic()) {
/* 114 */       ((Panic)rock.getModules().get(Panic.class)).onAllEvent(event);
/*     */     }
/*     */     
/* 117 */     if (rock.isPanic())
/*     */       return; 
/* 119 */     if (event instanceof EventAttack) { EventAttack e = (EventAttack)event;
/* 120 */       currentTarget = e.getTarget(); }
/*     */ 
/*     */ 
/*     */     
/* 124 */     if (event instanceof fun.rockstarity.api.events.list.game.EventWorldChange) mc.ingameGUI.resetTitle();
/*     */     
/* 126 */     handleEvents(event);
/* 127 */     handleCalls(event);
/* 128 */     handleMenus(event);
/* 129 */     rock.getScriptConstructor().execute(event);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 135 */     if (event instanceof EventBlur) { EventBlur e = (EventBlur)event; if (Interface.blur()) {
/* 136 */         if (mc.currentScreen instanceof net.optifine.shaders.gui.GuiShaders) {
/* 137 */           Round.draw(e.getMatrixStack(), new Rect(0.0F, (sr.getScaledHeight() - 50), sr.getScaledWidth(), 50.0F), 0.0F, FixColor.WHITE);
/* 138 */         } else if (mc.currentScreen instanceof net.minecraft.client.gui.screen.PackScreen) {
/*     */ 
/*     */           
/* 141 */           Round.draw(e.getMatrixStack(), new Rect(0.0F, 0.0F, sr.getScaledWidth(), sr.getScaledHeight()), 0.0F, FixColor.WHITE);
/*     */         } 
/*     */       } }
/*     */     
/* 145 */     if (event instanceof EventRender2D) { EventRender2D e = (EventRender2D)event;
/* 146 */       if (mc.currentScreen instanceof net.optifine.shaders.gui.GuiShaders) {
/* 147 */         Round.draw(e.getMatrixStack(), new Rect(0.0F, (sr.getScaledHeight() - 50), sr.getScaledWidth(), 50.0F), 0.0F, FixColor.BLACK.alpha(0.30000001192092896D));
/* 148 */       } else if (mc.currentScreen instanceof net.minecraft.client.gui.screen.PackScreen) {
/* 149 */         Round.draw(e.getMatrixStack(), new Rect(0.0F, 0.0F, sr.getScaledWidth(), sr.getScaledHeight()), 0.0F, FixColor.BLACK.alpha(0.30000001192092896D));
/*     */       }  }
/*     */ 
/*     */     
/* 153 */     if (event instanceof EventRender2D && !lateInit && mc.currentScreen == null) {
/*     */ 
/*     */       
/* 156 */       rock.setClickGui(new ClickGuiScreen());
/*     */       
/* 158 */       lateInit = true;
/*     */       
/* 160 */       if (rock.getUser().getStarts() == 0L) {
/* 161 */         Chat.msg("Подсказка", "Чтобы открыть меню рокстара, нажми Правый Shift");
/* 162 */         (new Sound("nastya/rshift")).play();
/*     */       } 
/*     */     } 
/*     */     
/* 166 */     if (event instanceof EventRender2D && resetCfg && mc.currentScreen == null) {
/* 167 */       GL11.glPushMatrix();
/* 168 */       GL11.glTranslated(10000.0D, 10000.0D, 0.0D);
/* 169 */       rock.getClickGui().getWindow().getEspSettings().renderPage(new MatrixStack(), 0, 0, 0.0F);
/* 170 */       GL11.glPopMatrix();
/* 171 */       resetCfg = false;
/*     */     } 
/*     */     
/* 174 */     if (event instanceof EventReceivePacket) { EventReceivePacket e = (EventReceivePacket)event; IPacket iPacket = e.getPacket(); if (iPacket instanceof SChatPacket) { SChatPacket packet = (SChatPacket)iPacket;
/* 175 */         String message = packet.getChatComponent().getString().toLowerCase();
/*     */         
/* 177 */         if (message.contains("пока")) {
/* 178 */           Objects.requireNonNull(rock); ThreadManager.run(rock::save);
/*     */         }  }
/*     */        }
/*     */     
/* 182 */     if (event instanceof EventRender2D) { EventRender2D e = (EventRender2D)event; if (!Screen.DIRT_ANIM.finished(false)) {
/* 183 */         Screen.DIRT_ANIM.setForward(false);
/*     */         
/* 185 */         rock.getMenuManager().drawBackground(e.getMatrixStack(), 0, 0, 0.0F);
/*     */         
/* 187 */         if (!Screen.DIRT_ANIM.isForward() && mc.currentScreen == null) {
/* 188 */           Screen.DIRT_ANIM.setEasing(Easing.EASE_OUT_BACK);
/*     */           
/* 190 */           Render.initRotate(sr.getScaledWidth() / 2.0F, sr.getScaledHeight() / 2.0F, 45.0F * Screen.DIRT_ANIM.get());
/* 191 */           Render.scale(sr.getScaledWidth() / 2.0F, sr.getScaledHeight() / 2.0F, 1.0F - Screen.DIRT_ANIM.get() * 1.0F);
/* 192 */           FrameFreeze.draw(e.getMatrixStack(), 1.0F);
/* 193 */           Render.end();
/* 194 */           Render.endRotate();
/*     */         } 
/*     */       }  }
/*     */ 
/*     */     
/* 199 */     MenuFilter.onEvent(event);
/*     */   }
/*     */   
/*     */   private static void handleEvents(Event event) {
/* 203 */     if (event instanceof EventRender2D) { EventRender2D e = (EventRender2D)event;
/* 204 */       MatrixStack ms = e.getMatrixStack();
/*     */       
/* 206 */       boolean blur = Interface.blur();
/* 207 */       if (blur) {
/* 208 */         Interface ui = (Interface)rock.getModules().get(Interface.class);
/*     */         
/* 210 */         Blur.renderTicks++;
/*     */         
/* 212 */         Stencil.init();
/* 213 */         (new EventBlur(ms, e.getPartialTicks())).hook();
/*     */ 
/*     */         
/* 216 */         Stencil.read(1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 222 */         KawaseBlur.renderBlur(ms, 2, (int)ui.getBlurOffset().get());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 229 */         Stencil.finish();
/*     */       } else {
/* 231 */         (new EventBlur(ms, e.getPartialTicks())).hook();
/*     */       }  }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void handleCalls(Event event) {
/* 247 */     if (event instanceof EventReceivePacket) { EventReceivePacket e = (EventReceivePacket)event; if (Server.isBravo()) {
/* 248 */         IPacket iPacket = e.getPacket(); if (iPacket instanceof SChatPacket) { SChatPacket packet = (SChatPacket)iPacket;
/* 249 */           if (packet.getChatComponent().getString().contains(mc.player.getNameClear()) && (packet.getChatComponent().getString().contains("какой чит") || packet
/* 250 */             .getChatComponent().getString().contains("какой софт") || packet
/* 251 */             .getChatComponent().getString().contains("что за чит") || packet
/* 252 */             .getChatComponent().getString().contains("что за софт"))) {
/* 253 */             mc.player.sendChatMessage("!Rockstar Client");
/*     */           } }
/*     */       
/*     */       }  }
/*     */     
/* 258 */     if (event instanceof EventRender2D) { EventRender2D e = (EventRender2D)event;
/* 259 */       Render.setStack(e.getMatrixStack()); }
/*     */ 
/*     */     
/* 262 */     if (rock.getScriptHandler() != null) {
/* 263 */       for (Script script : rock.getScriptHandler().getEnabledScripts()) {
/* 264 */         script.onEvent(event);
/*     */       }
/*     */     }
/* 267 */     if (event instanceof fun.rockstarity.api.events.list.player.EventUpdate) {
/* 268 */       for (Page page : Page.values()) {
/* 269 */         page.getShowing().setForward(false);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 274 */     if (event instanceof EventAttack);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 280 */     AIPredictor.onEvent(event);
/*     */     
/* 282 */     rock.getBotsHandler().onEvent(event);
/* 283 */     rock.getAutoBuy().onEvent(event);
/* 284 */     rock.getTpsHandler().onEvent(event);
/* 285 */     rock.getScheduleManager().onEvent(event);
/* 286 */     rock.getConfigHandler().getWindow().onEvent(event);
/*     */     
/* 288 */     CullingProcessor.onEvent(event);
/* 289 */     InvUtility.onEvent(event);
/* 290 */     MarkManager.onEvent(event);
/* 291 */     BoostUtility.onEvent(event);
/* 292 */     ViaFixer.onEvent(event);
/*     */     
/* 294 */     for (Command command : rock.getCommands().values()) {
/* 295 */       command.onEvent(event);
/*     */     }
/*     */     
/* 298 */     if (event instanceof EventKey) { EventKey e = (EventKey)event; if (mc.currentScreen == null || e.isReleased()) handleKeys(e);  }
/*     */     
/* 300 */     if (event instanceof EventMessage) { EventMessage e = (EventMessage)event; handleCommands(e); }
/*     */     
/* 302 */     if (event instanceof EventReceivePacket) { EventReceivePacket e = (EventReceivePacket)event; IPacket iPacket = e.getPacket(); if (iPacket instanceof SChatPacket) { SChatPacket packet = (SChatPacket)iPacket;
/* 303 */         String message = packet.getChatComponent().getString().toLowerCase();
/* 304 */         if (message.contains("вы забанены") && Server.isFT()) {
/* 305 */           BanProcessor.updateBan(Server.getIP(), message);
/*     */         }
/* 307 */         if (message.toLowerCase().contains("вас забанили на сервере") && Server.isRW()) {
/* 308 */           BanProcessor.updateBan(Server.getIP(), message);
/*     */         } }
/*     */        }
/*     */     
/* 312 */     for (Iterator<Module> iterator = rock.getModules().getModules().iterator(); iterator.hasNext(); ) { Module module = iterator.next();
/* 313 */       if (event instanceof EventBlur || event instanceof fun.rockstarity.api.events.list.render.EventRender3D || event instanceof EventRender2D) {
/* 314 */         RenderSystem.runAsFancy(() -> {
/*     */               module.onAllEvent(event);
/*     */               
/*     */               if (module.get()) {
/*     */                 if (module instanceof fun.rockstarity.api.modules.PremiumModule && !rock.isPremium() && module.get()) {
/*     */                   Chat.msg("Этот модуль доступен только для премиум пользователей");
/*     */                   
/*     */                   module.set(false);
/*     */                 } 
/*     */                 
/*     */                 module.onEvent(event);
/*     */               } 
/*     */             });
/*     */         continue;
/*     */       } 
/* 329 */       module.onAllEvent(event);
/*     */       
/* 331 */       if (!module.get())
/*     */         continue; 
/* 333 */       if (module instanceof fun.rockstarity.api.modules.PremiumModule && !rock.isPremium() && module.get()) {
/* 334 */         Chat.msg("Этот модуль доступен только для премиум пользователей");
/* 335 */         module.set(false);
/*     */       } 
/*     */       
/* 338 */       module.onEvent(event); }
/*     */ 
/*     */     
/* 341 */     rock.getEmotions().onEvent(event);
/*     */     
/* 343 */     if (event instanceof EventRender2D && mc.currentScreen == null) {
/* 344 */       FrameFreeze.save();
/*     */     }
/*     */   }
/*     */   
/*     */   private static void handleMenus(Event event) {
/* 349 */     if (event instanceof EventRender2D) { EventRender2D e = (EventRender2D)event; if (mc.currentScreen != rock.getClickGui() && rock.getClickGui() != null && 
/* 350 */         !ClickGuiRenderer.opening.isForward() && !ClickGuiRenderer.opening.finished(false) && (!((ClickGui)rock.getModules().get(ClickGui.class)).getTech().get() || ((FreeCam)rock.getModules().get(FreeCam.class)).get() || mc.getGameSettings().getPointOfView() == PointOfView.THIRD_PERSON_FRONT))
/*     */       {
/*     */ 
/*     */         
/* 354 */         rock.getClickGui().getWindow().getRenderer().render(e.getMatrixStack(), 0, 0, e.getPartialTicks());
/*     */       } }
/*     */ 
/*     */     
/* 358 */     if (event instanceof EventUpdateCamera) { EventUpdateCamera e = (EventUpdateCamera)event; if (mc.currentScreen != rock.getClickGui() && rock.getClickGui() != null && 
/* 359 */         !ClickGuiRenderer.opening.isForward() && !ClickGuiRenderer.opening.finished(false) && ((ClickGui)rock.getModules().get(ClickGui.class)).getTech().get() && !((FreeCam)rock.getModules().get(FreeCam.class)).get() && mc.getGameSettings().getPointOfView() != PointOfView.THIRD_PERSON_FRONT) {
/* 360 */         ClickGuiWindow window = rock.getClickGui().getWindow();
/*     */ 
/*     */         
/* 363 */         MatrixStack ms = e.getMatrixStack();
/*     */         
/* 365 */         if (window != null) {
/* 366 */           GL11.glPushMatrix();
/* 367 */           ms.push();
/* 368 */           Beautifully cam = (Beautifully)rock.getModules().get(Beautifully.class);
/* 369 */           GL11.glRotated(mc.player.rotationPitch, 1.0D, 0.0D, 0.0D);
/* 370 */           GL11.glRotated((mc.player.rotationYaw + 180.0F), 0.0D, 1.0D, 0.0D);
/* 371 */           ms.rotate(Vector3f.YN.rotationDegrees(mc.player.rotationYaw + 180.0F));
/* 372 */           ms.rotate(Vector3f.XN.rotationDegrees(mc.player.rotationPitch));
/* 373 */           RenderSystem.disableDepthTest();
/* 374 */           RenderSystem.depthMask(true);
/* 375 */           RenderSystem.disableCull();
/* 376 */           GlStateManager.enableBlend();
/* 377 */           Vector3d pos = window.getRenderer().getClosePos();
/* 378 */           GL11.glTranslated(pos.x - (mc.getRenderManager()).info.getProjectedView().getX(), pos.y - 
/* 379 */               (mc.getRenderManager()).info.getProjectedView().getY(), pos.z - 
/* 380 */               (mc.getRenderManager()).info.getProjectedView().getZ());
/*     */           
/* 382 */           GL11.glRotated((-window.getRenderer().getYaw() / 4.0F + 180.0F), 0.0D, 1.0D, 0.0D);
/* 383 */           GL11.glRotated((-window.getRenderer().getPitch() / 4.0F), 1.0D, 0.0D, 0.0D);
/* 384 */           float xRotate = -(window.getRenderer().getYaw() - mc.player.rotationYaw * 4.0F) / 10.0F;
/* 385 */           float yRotate = -(window.getRenderer().getPitch() - mc.player.rotationPitch * 4.0F) / 10.0F;
/*     */ 
/*     */ 
/*     */           
/* 389 */           GL11.glScalef(1.0F, -1.0F, 1.0F);
/* 390 */           float scale = 0.01F;
/* 391 */           GL11.glScalef(scale, scale, scale);
/* 392 */           GL11.glTranslatef(-window.getWidth() + 10.0F, -window.getHeight() / 1.2F + 10.0F, -175.0F);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 397 */           if (cam.get() && cam.getRealCamera().get()) {
/* 398 */             ms.rotate(Vector3f.ZP.rotationDegrees(-(MathHelper.clamp(cam.getCamera().getPitch(), -20.0F, 20.0F) + MathHelper.clamp((mc.player.rotationYaw - cam.getCamera().getYaw()) / 2.0F, -10.0F, 10.0F))));
/*     */           }
/*     */           
/* 401 */           float fov = (float)mc.gameSettings.fov;
/* 402 */           Render.scale(window.getX() + window.getWidth() / 2.0F, window.getY() + window.getHeight() / 2.0F, fov / 110.0F);
/*     */           
/* 404 */           Render.scale(window.getX() + window.getWidth() / 2.0F, window.getY() + window.getHeight() / 2.0F, fov - 110.0F, 0.5F + ClickGuiRenderer.opening.get() * 0.5F);
/*     */ 
/*     */           
/* 407 */           window.getRenderer().renderWindow(ms, 0, 0, 1.0F);
/* 408 */           Render.end();
/* 409 */           Render.end();
/*     */ 
/*     */           
/* 412 */           RenderSystem.enableCull();
/* 413 */           RenderSystem.depthMask(true);
/* 414 */           RenderSystem.enableDepthTest();
/*     */           
/* 416 */           ms.pop();
/* 417 */           GL11.glPopMatrix();
/*     */         } 
/*     */       }  }
/*     */ 
/*     */     
/* 422 */     if (event instanceof EventRender2D) { EventRender2D e = (EventRender2D)event; if (mc.currentScreen != rock.getConstructor() && rock.getConstructor() != null && 
/* 423 */         !ConstructorScreen.opening.isForward() && !ConstructorScreen.opening.finished(false)) {
/* 424 */         rock.getConstructor().render(e.getMatrixStack(), 0, 0, e.getPartialTicks());
/*     */       } }
/*     */ 
/*     */     
/* 428 */     if (event instanceof EventRender2D) { EventRender2D e = (EventRender2D)event; if (rock.getModules().get(AutoBuy.class) != null) {
/* 429 */         AutoBuyScreen autoBuyScreen = ((AutoBuy)rock.getModules().get(AutoBuy.class)).getScreen();
/* 430 */         if (mc.currentScreen != autoBuyScreen && autoBuyScreen != null && (
/* 431 */           autoBuyScreen.getRenderer().getOpening().isForward() || !autoBuyScreen.getRenderer().getOpening().finished(false))) {
/* 432 */           autoBuyScreen.getRenderer().render(e.getMatrixStack(), 0, 0, e.getPartialTicks());
/*     */         }
/*     */       }  }
/*     */     
/* 436 */     if (mc.currentScreen != null && mc.currentScreen != rock.getClickGui()) ClickGuiRenderer.opening.setForward(false);
/*     */   
/*     */   }
/*     */   
/*     */   private static void handleCommands(EventMessage event) {
/* 441 */     String msg = event.getMessage();
/*     */     
/* 443 */     if (rock.getCommands().executeRaw(msg)) event.cancel(); 
/*     */   }
/*     */   
/*     */   private static void handleKeys(EventKey event) {
/* 447 */     List<Module> modules = new ArrayList<>();
/*     */     
/* 449 */     rock.getModules().values().forEach(mod -> modules.add(mod));
/* 450 */     for (Script script : rock.getScriptHandler().getEnabledScripts()) {
/* 451 */       script.getScriptModules().forEach(mod -> modules.add(mod));
/*     */     }
/*     */     
/* 454 */     modules.stream()
/* 455 */       .forEach(module -> {
/*     */           if (module.getBindByKey(event).isPresent() && (((Bind)module.getBindByKey(event).get()).getType() == BindType.HOLD || !event.isReleased())) {
/*     */             if (event.isReleased() && !module.get()) {
/*     */               return;
/*     */             }
/*     */             ((Bind)module.getBindByKey(event).get()).setHolding(!event.isReleased());
/*     */             module.toggleWithBind(module.getBindByKey(event));
/*     */           } 
/*     */           module.getSettings().forEach(());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resetConfig() {
/* 485 */     resetCfg = true;
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\EventHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */