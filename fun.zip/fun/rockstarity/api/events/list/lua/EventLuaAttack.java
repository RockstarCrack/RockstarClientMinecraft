/*    */ package fun.rockstarity.api.events.list.lua;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.scripts.wrappers.base.LivingEntityBase;
/*    */ 
/*    */ public class EventLuaAttack extends Event {
/*    */   private final LivingEntityBase target;
/*    */   
/*    */   public EventLuaAttack(LivingEntityBase target) {
/* 10 */     this.target = target;
/*    */   }
/*    */   public LivingEntityBase getTarget() {
/* 13 */     return this.target;
/*    */   }
/*    */   public LivingEntityBase target() {
/* 16 */     return this.target;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\lua\EventLuaAttack.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */