/*    */ package fun.rockstarity.api.events.list.lua;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.scripts.wrappers.base.MatrixBase;
/*    */ 
/*    */ public class EventLuaItem extends Event {
/*    */   private final boolean right;
/*    */   private final float progress;
/*    */   private final MatrixBase matrixStack;
/*    */   
/*    */   public EventLuaItem(boolean right, float progress, MatrixBase matrixStack) {
/* 11 */     this.right = right; this.progress = progress; this.matrixStack = matrixStack;
/*    */   }
/*    */   
/* 14 */   public boolean isRight() { return this.right; }
/* 15 */   public float getProgress() { return this.progress; } public MatrixBase getMatrixStack() {
/* 16 */     return this.matrixStack;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\lua\EventLuaItem.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */