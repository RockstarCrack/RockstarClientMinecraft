/*    */ package fun.rockstarity.api.events.list.lua;
/*    */ import fun.rockstarity.api.scripts.wrappers.base.LivingEntityBase;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class EventLuaTotem extends Event {
/*    */   private final LivingEntityBase entity;
/*    */   
/*    */   public EventLuaTotem(LivingEntityBase entity, ItemStack item) {
/*  9 */     this.entity = entity; this.item = item;
/*    */   } private final ItemStack item;
/*    */   public LivingEntityBase getEntity() {
/* 12 */     return this.entity; } public ItemStack getItem() {
/* 13 */     return this.item;
/*    */   }
/*    */   public LivingEntityBase target() {
/* 16 */     return this.entity;
/*    */   }
/*    */   
/*    */   public LivingEntityBase entity() {
/* 20 */     return this.entity;
/*    */   }
/*    */   
/*    */   public String nick() {
/* 24 */     return this.entity.getEntity().getName().getString();
/*    */   }
/*    */   
/*    */   public String totemName() {
/* 28 */     return this.item.getDisplayName().getString();
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\lua\EventLuaTotem.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */