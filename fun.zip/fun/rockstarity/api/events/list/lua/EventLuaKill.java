/*    */ package fun.rockstarity.api.events.list.lua;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.scripts.wrappers.base.LivingEntityBase;
/*    */ 
/*    */ public class EventLuaKill
/*    */   extends Event {
/*    */   public EventLuaKill(LivingEntityBase target) {
/*  9 */     this.target = target;
/*    */   } private final LivingEntityBase target;
/*    */   public LivingEntityBase getTarget() {
/* 12 */     return this.target;
/*    */   }
/*    */   public LivingEntityBase target() {
/* 15 */     return this.target;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\lua\EventLuaKill.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */