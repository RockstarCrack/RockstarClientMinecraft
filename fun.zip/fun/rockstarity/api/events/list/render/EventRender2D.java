/*    */ package fun.rockstarity.api.events.list.render;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.events.list.render.ui.AEventRender2D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventRender2D
/*    */   extends AEventRender2D
/*    */ {
/*    */   public EventRender2D(MatrixStack matrixStack, float partialTicks) {
/* 18 */     super(matrixStack, partialTicks);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\EventRender2D.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */