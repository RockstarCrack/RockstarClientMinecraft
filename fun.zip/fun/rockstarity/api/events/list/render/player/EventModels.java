/*    */ package fun.rockstarity.api.events.list.render.player;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import net.minecraft.client.renderer.model.ModelRenderer;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ 
/*    */ public class EventModels extends Event {
/*    */   private LivingEntity owner;
/*    */   public ModelRenderer bipedHead;
/*    */   public ModelRenderer bipedHeadwear;
/*    */   public ModelRenderer bipedBody;
/*    */   
/*    */   public EventModels(LivingEntity owner, ModelRenderer bipedHead, ModelRenderer bipedHeadwear, ModelRenderer bipedBody, ModelRenderer bipedRightArm, ModelRenderer bipedLeftArm, ModelRenderer bipedRightLeg, ModelRenderer bipedLeftLeg, float limbSwingAmount) {
/* 14 */     this.owner = owner; this.bipedHead = bipedHead; this.bipedHeadwear = bipedHeadwear; this.bipedBody = bipedBody; this.bipedRightArm = bipedRightArm; this.bipedLeftArm = bipedLeftArm; this.bipedRightLeg = bipedRightLeg; this.bipedLeftLeg = bipedLeftLeg; this.limbSwingAmount = limbSwingAmount;
/*    */   } public ModelRenderer bipedRightArm; public ModelRenderer bipedLeftArm; public ModelRenderer bipedRightLeg; public ModelRenderer bipedLeftLeg; public float limbSwingAmount;
/*    */   public LivingEntity getOwner() {
/* 17 */     return this.owner;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public <T extends Event> EventModels hook() {
/* 29 */     return (EventModels)super.hook();
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\player\EventModels.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */