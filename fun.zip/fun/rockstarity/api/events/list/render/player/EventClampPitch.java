package fun.rockstarity.api.events.list.render.player;

import fun.rockstarity.api.events.Event;

public class EventClampPitch extends Event {}


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\player\EventClampPitch.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */