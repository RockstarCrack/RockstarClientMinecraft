/*    */ package fun.rockstarity.api.events.list.render.player;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventRotationChange
/*    */   extends Event
/*    */ {
/*    */   private double yaw;
/*    */   private double pitch;
/*    */   
/*    */   public void setYaw(double yaw) {
/* 16 */     this.yaw = yaw; } public void setPitch(double pitch) { this.pitch = pitch; } public EventRotationChange(double yaw, double pitch) {
/* 17 */     this.yaw = yaw; this.pitch = pitch;
/*    */   }
/*    */   
/* 20 */   public double getYaw() { return this.yaw; } public double getPitch() { return this.pitch; }
/*    */   
/*    */   public EventRotationChange hook() {
/* 23 */     return (EventRotationChange)super.hook();
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\player\EventRotationChange.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */