/*    */ package fun.rockstarity.api.events.list.render.player;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ 
/*    */ public class EventRenderHand extends Event {
/*    */   private final boolean pre;
/*    */   
/*    */   public EventRenderHand(boolean pre) {
/*  8 */     this.pre = pre;
/*    */   } public boolean isPre() {
/* 10 */     return this.pre;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\player\EventRenderHand.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */