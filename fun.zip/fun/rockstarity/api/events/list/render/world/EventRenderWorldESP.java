/*    */ package fun.rockstarity.api.events.list.render.world;
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import net.minecraft.client.renderer.ActiveRenderInfo;
/*    */ 
/*    */ public class EventRenderWorldESP extends Event {
/*    */   private final MatrixStack matrixStack;
/*    */   private final ActiveRenderInfo activeRenderInfo;
/*    */   private final float partialTicks;
/*    */   
/*    */   public EventRenderWorldESP(MatrixStack matrixStack, ActiveRenderInfo activeRenderInfo, float partialTicks) {
/* 12 */     this.matrixStack = matrixStack; this.activeRenderInfo = activeRenderInfo; this.partialTicks = partialTicks;
/*    */   }
/*    */   
/* 15 */   public MatrixStack getMatrixStack() { return this.matrixStack; }
/* 16 */   public ActiveRenderInfo getActiveRenderInfo() { return this.activeRenderInfo; } public float getPartialTicks() {
/* 17 */     return this.partialTicks;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\world\EventRenderWorldESP.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */