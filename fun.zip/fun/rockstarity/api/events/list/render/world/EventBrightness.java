/*    */ package fun.rockstarity.api.events.list.render.world;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ 
/*    */ public class EventBrightness
/*    */   extends Event {
/*    */   private float percent;
/*    */   
/*    */   public void setPercent(float percent) {
/* 10 */     this.percent = percent; } public EventBrightness(float percent) {
/* 11 */     this.percent = percent;
/*    */   }
/*    */   public float getPercent() {
/* 14 */     return this.percent;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\world\EventBrightness.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */