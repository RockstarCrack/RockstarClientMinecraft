/*    */ package fun.rockstarity.api.events.list.render.world;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import net.minecraft.client.renderer.ActiveRenderInfo;
/*    */ import net.minecraft.client.renderer.GameRenderer;
/*    */ import net.minecraft.client.renderer.LightTexture;
/*    */ import net.minecraft.util.math.vector.Matrix4f;
/*    */ 
/*    */ public class EventPreUpdateRender extends Event {
/*    */   private MatrixStack matrixStackIn;
/*    */   private float partialTicks;
/*    */   private long finishTimeNano;
/*    */   private boolean drawBlockOutline;
/*    */   
/* 16 */   public void setMatrixStackIn(MatrixStack matrixStackIn) { this.matrixStackIn = matrixStackIn; } private ActiveRenderInfo activerenderinfo; private GameRenderer gameRenderer; private LightTexture lightmapTexture; private Matrix4f matrix4f; public void setPartialTicks(float partialTicks) { this.partialTicks = partialTicks; } public void setFinishTimeNano(long finishTimeNano) { this.finishTimeNano = finishTimeNano; } public void setDrawBlockOutline(boolean drawBlockOutline) { this.drawBlockOutline = drawBlockOutline; } public void setActiverenderinfo(ActiveRenderInfo activerenderinfo) { this.activerenderinfo = activerenderinfo; } public void setGameRenderer(GameRenderer gameRenderer) { this.gameRenderer = gameRenderer; } public void setLightmapTexture(LightTexture lightmapTexture) { this.lightmapTexture = lightmapTexture; } public void setMatrix4f(Matrix4f matrix4f) { this.matrix4f = matrix4f; } public EventPreUpdateRender(MatrixStack matrixStackIn, float partialTicks, long finishTimeNano, boolean drawBlockOutline, ActiveRenderInfo activerenderinfo, GameRenderer gameRenderer, LightTexture lightmapTexture, Matrix4f matrix4f) {
/* 17 */     this.matrixStackIn = matrixStackIn; this.partialTicks = partialTicks; this.finishTimeNano = finishTimeNano; this.drawBlockOutline = drawBlockOutline; this.activerenderinfo = activerenderinfo; this.gameRenderer = gameRenderer; this.lightmapTexture = lightmapTexture; this.matrix4f = matrix4f;
/*    */   }
/* 19 */   public MatrixStack getMatrixStackIn() { return this.matrixStackIn; }
/* 20 */   public float getPartialTicks() { return this.partialTicks; }
/* 21 */   public long getFinishTimeNano() { return this.finishTimeNano; }
/* 22 */   public boolean isDrawBlockOutline() { return this.drawBlockOutline; }
/* 23 */   public ActiveRenderInfo getActiverenderinfo() { return this.activerenderinfo; }
/* 24 */   public GameRenderer getGameRenderer() { return this.gameRenderer; }
/* 25 */   public LightTexture getLightmapTexture() { return this.lightmapTexture; } public Matrix4f getMatrix4f() {
/* 26 */     return this.matrix4f;
/*    */   }
/*    */   public void set(MatrixStack matrixStackIn, float partialTicks, long finishTimeNano, boolean drawBlockOutline, ActiveRenderInfo activerenderinfo, GameRenderer gameRenderer, LightTexture lightmapTexture, Matrix4f matrix4f) {
/* 29 */     this.matrixStackIn = matrixStackIn;
/* 30 */     this.partialTicks = partialTicks;
/* 31 */     this.finishTimeNano = finishTimeNano;
/* 32 */     this.drawBlockOutline = drawBlockOutline;
/* 33 */     this.activerenderinfo = activerenderinfo;
/* 34 */     this.gameRenderer = gameRenderer;
/* 35 */     this.lightmapTexture = lightmapTexture;
/* 36 */     this.matrix4f = matrix4f;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\world\EventPreUpdateRender.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */