/*    */ package fun.rockstarity.api.events.list.render.world;
/*    */ 
/*    */ 
/*    */ public class EventFogDistance extends Event {
/*    */   private float inner;
/*    */   private float outer;
/*    */   
/*  8 */   public void setInner(float inner) { this.inner = inner; } public void setOuter(float outer) { this.outer = outer; } public EventFogDistance(float inner, float outer) {
/*  9 */     this.inner = inner; this.outer = outer;
/*    */   }
/*    */   
/* 12 */   public float getInner() { return this.inner; } public float getOuter() { return this.outer; }
/*    */ 
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\world\EventFogDistance.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */