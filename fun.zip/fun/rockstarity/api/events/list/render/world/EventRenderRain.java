/*    */ package fun.rockstarity.api.events.list.render.world;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import net.minecraft.world.biome.Biome;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventRenderRain
/*    */   extends Event
/*    */ {
/*    */   private Biome.RainType type;
/*    */   
/*    */   public void setType(Biome.RainType type) {
/* 14 */     this.type = type; } public EventRenderRain(Biome.RainType type) {
/* 15 */     this.type = type;
/*    */   }
/*    */   
/*    */   public Biome.RainType getType() {
/* 19 */     return this.type;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\world\EventRenderRain.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */