/*    */ package fun.rockstarity.api.events.list.render.world;
/*    */ 
/*    */ import net.minecraft.util.math.vector.Vector2f;
/*    */ import net.minecraft.util.math.vector.Vector3d;
/*    */ 
/*    */ public class EventCameraPosition extends Event {
/*    */   private Vector3d position;
/*    */   private Vector2f rotation;
/*    */   
/* 10 */   public void setPosition(Vector3d position) { this.position = position; } public void setRotation(Vector2f rotation) { this.rotation = rotation; } public EventCameraPosition(Vector3d position, Vector2f rotation) {
/* 11 */     this.position = position; this.rotation = rotation;
/*    */   }
/*    */   
/* 14 */   public Vector3d getPosition() { return this.position; } public Vector2f getRotation() {
/* 15 */     return this.rotation;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\world\EventCameraPosition.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */