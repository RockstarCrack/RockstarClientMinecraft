/*    */ package fun.rockstarity.api.events.list.render.world;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import net.minecraft.client.renderer.ActiveRenderInfo;
/*    */ import net.minecraft.client.renderer.WorldRenderer;
/*    */ import net.minecraft.util.math.vector.Matrix4f;
/*    */ 
/*    */ public final class EventRender3DPosed extends Event {
/*    */   private MatrixStack matrix;
/*    */   private Matrix4f projectionMatrix;
/*    */   private ActiveRenderInfo activeRenderInfo;
/*    */   private WorldRenderer context;
/*    */   
/* 15 */   public void setMatrix(MatrixStack matrix) { this.matrix = matrix; } private float partialTicks; private long finishTimeNano; private double x; private double y; private double z; public void setProjectionMatrix(Matrix4f projectionMatrix) { this.projectionMatrix = projectionMatrix; } public void setActiveRenderInfo(ActiveRenderInfo activeRenderInfo) { this.activeRenderInfo = activeRenderInfo; } public void setContext(WorldRenderer context) { this.context = context; } public void setPartialTicks(float partialTicks) { this.partialTicks = partialTicks; } public void setFinishTimeNano(long finishTimeNano) { this.finishTimeNano = finishTimeNano; } public void setX(double x) { this.x = x; } public void setY(double y) { this.y = y; } public void setZ(double z) { this.z = z; } public EventRender3DPosed(MatrixStack matrix, Matrix4f projectionMatrix, ActiveRenderInfo activeRenderInfo, WorldRenderer context, float partialTicks, long finishTimeNano, double x, double y, double z) {
/* 16 */     this.matrix = matrix; this.projectionMatrix = projectionMatrix; this.activeRenderInfo = activeRenderInfo; this.context = context; this.partialTicks = partialTicks; this.finishTimeNano = finishTimeNano; this.x = x; this.y = y; this.z = z;
/*    */   }
/* 18 */   public MatrixStack getMatrix() { return this.matrix; }
/* 19 */   public Matrix4f getProjectionMatrix() { return this.projectionMatrix; }
/* 20 */   public ActiveRenderInfo getActiveRenderInfo() { return this.activeRenderInfo; }
/* 21 */   public WorldRenderer getContext() { return this.context; }
/* 22 */   public float getPartialTicks() { return this.partialTicks; }
/* 23 */   public long getFinishTimeNano() { return this.finishTimeNano; }
/* 24 */   public double getX() { return this.x; } public double getY() { return this.y; } public double getZ() { return this.z; }
/*    */ 
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\world\EventRender3DPosed.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */