/*    */ package fun.rockstarity.api.events.list.render.world;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ 
/*    */ public class EventCameraDistance
/*    */   extends Event {
/*    */   private double distance;
/*    */   
/*    */   public void setDistance(double distance) {
/* 10 */     this.distance = distance; } public EventCameraDistance(double distance) {
/* 11 */     this.distance = distance;
/*    */   }
/*    */   public double getDistance() {
/* 14 */     return this.distance;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\world\EventCameraDistance.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */