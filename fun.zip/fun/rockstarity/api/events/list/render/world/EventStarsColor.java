/*    */ package fun.rockstarity.api.events.list.render.world;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.render.color.FixColor;
/*    */ 
/*    */ public class EventStarsColor extends Event {
/*    */   private FixColor color;
/*    */   
/*  9 */   public void setColor(FixColor color) { this.color = color; } public EventStarsColor(FixColor color) {
/* 10 */     this.color = color;
/*    */   }
/*    */   public FixColor getColor() {
/* 13 */     return this.color;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\world\EventStarsColor.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */