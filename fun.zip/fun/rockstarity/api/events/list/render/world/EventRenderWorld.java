/*    */ package fun.rockstarity.api.events.list.render.world;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ 
/*    */ public class EventRenderWorld extends Event {
/*    */   private MatrixStack stack;
/*    */   private float partialTicks;
/*    */   
/* 10 */   public void setStack(MatrixStack stack) { this.stack = stack; } public void setPartialTicks(float partialTicks) { this.partialTicks = partialTicks; } public EventRenderWorld(MatrixStack stack, float partialTicks) {
/* 11 */     this.stack = stack; this.partialTicks = partialTicks;
/*    */   }
/*    */   
/* 14 */   public MatrixStack getStack() { return this.stack; } public float getPartialTicks() {
/* 15 */     return this.partialTicks;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\world\EventRenderWorld.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */