/*    */ package fun.rockstarity.api.events.list.render.world;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ public class EventSkybox
/*    */   extends Event {
/*    */   private ResourceLocation texture;
/*    */   
/*    */   public void setTexture(ResourceLocation texture) {
/* 11 */     this.texture = texture; } public EventSkybox(ResourceLocation texture) {
/* 12 */     this.texture = texture;
/*    */   }
/*    */   public ResourceLocation getTexture() {
/* 15 */     return this.texture;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\world\EventSkybox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */