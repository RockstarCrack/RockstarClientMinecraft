/*    */ package fun.rockstarity.api.events.list.render.world;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ 
/*    */ public class EventFov extends Event {
/*    */   private float fov;
/*    */   
/*  8 */   public void setFov(float fov) { this.fov = fov; } public EventFov(float fov) {
/*  9 */     this.fov = fov;
/*    */   }
/*    */   public float getFov() {
/* 12 */     return this.fov;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\world\EventFov.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */