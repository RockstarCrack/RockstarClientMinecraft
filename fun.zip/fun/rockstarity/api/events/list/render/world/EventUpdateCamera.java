/*    */ package fun.rockstarity.api.events.list.render.world;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ 
/*    */ public class EventUpdateCamera
/*    */   extends Event
/*    */ {
/*    */   private final MatrixStack matrixStack;
/*    */   
/*    */   public EventUpdateCamera(MatrixStack matrixStack) {
/* 12 */     this.matrixStack = matrixStack;
/*    */   }
/*    */   public MatrixStack getMatrixStack() {
/* 15 */     return this.matrixStack;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\world\EventUpdateCamera.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */