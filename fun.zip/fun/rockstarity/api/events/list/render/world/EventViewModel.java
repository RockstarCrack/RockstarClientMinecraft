/*    */ package fun.rockstarity.api.events.list.render.world;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventViewModel
/*    */   extends Event
/*    */ {
/*    */   private final boolean right;
/*    */   private final MatrixStack matrixStack;
/*    */   
/*    */   public EventViewModel(boolean right, MatrixStack matrixStack) {
/* 16 */     this.right = right; this.matrixStack = matrixStack;
/*    */   }
/*    */   
/* 19 */   public boolean isRight() { return this.right; } public MatrixStack getMatrixStack() {
/* 20 */     return this.matrixStack;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\world\EventViewModel.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */