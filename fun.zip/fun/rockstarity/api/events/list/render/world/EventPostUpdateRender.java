/*    */ package fun.rockstarity.api.events.list.render.world;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import net.minecraft.client.renderer.WorldRenderer;
/*    */ import net.minecraft.util.math.vector.Matrix4f;
/*    */ 
/*    */ public final class EventPostUpdateRender extends Event {
/*    */   private WorldRenderer context;
/*    */   private MatrixStack matrix;
/*    */   private Matrix4f projectionMatrix;
/*    */   private ActiveRenderInfo activeRenderInfo;
/*    */   private float partialTicks;
/*    */   private long finishTimeNano;
/*    */   
/* 15 */   public void setContext(WorldRenderer context) { this.context = context; } public void setMatrix(MatrixStack matrix) { this.matrix = matrix; } public void setProjectionMatrix(Matrix4f projectionMatrix) { this.projectionMatrix = projectionMatrix; } public void setActiveRenderInfo(ActiveRenderInfo activeRenderInfo) { this.activeRenderInfo = activeRenderInfo; } public void setPartialTicks(float partialTicks) { this.partialTicks = partialTicks; } public void setFinishTimeNano(long finishTimeNano) { this.finishTimeNano = finishTimeNano; } public EventPostUpdateRender(WorldRenderer context, MatrixStack matrix, Matrix4f projectionMatrix, ActiveRenderInfo activeRenderInfo, float partialTicks, long finishTimeNano) {
/* 16 */     this.context = context; this.matrix = matrix; this.projectionMatrix = projectionMatrix; this.activeRenderInfo = activeRenderInfo; this.partialTicks = partialTicks; this.finishTimeNano = finishTimeNano;
/*    */   }
/* 18 */   public WorldRenderer getContext() { return this.context; }
/* 19 */   public MatrixStack getMatrix() { return this.matrix; }
/* 20 */   public Matrix4f getProjectionMatrix() { return this.projectionMatrix; }
/* 21 */   public ActiveRenderInfo getActiveRenderInfo() { return this.activeRenderInfo; }
/* 22 */   public float getPartialTicks() { return this.partialTicks; } public long getFinishTimeNano() {
/* 23 */     return this.finishTimeNano;
/*    */   }
/*    */   public void set(WorldRenderer context, MatrixStack matrix, Matrix4f projectionMatrix, ActiveRenderInfo activeRenderInfo, float partialTicks, long finishTimeNano) {
/* 26 */     this.context = context;
/* 27 */     this.matrix = matrix;
/* 28 */     this.projectionMatrix = projectionMatrix;
/* 29 */     this.activeRenderInfo = activeRenderInfo;
/* 30 */     this.partialTicks = partialTicks;
/* 31 */     this.finishTimeNano = finishTimeNano;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\world\EventPostUpdateRender.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */