/*    */ package fun.rockstarity.api.events.list.render.world;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import net.minecraft.client.renderer.ActiveRenderInfo;
/*    */ 
/*    */ public class EventRenderWorldLast extends Event {
/*    */   private boolean shadersRender;
/*    */   private final MatrixStack matrixStack;
/*    */   
/* 11 */   public void setShadersRender(boolean shadersRender) { this.shadersRender = shadersRender; } private final ActiveRenderInfo activeRenderInfo; private final float partialTicks; public EventRenderWorldLast(boolean shadersRender, MatrixStack matrixStack, ActiveRenderInfo activeRenderInfo, float partialTicks) {
/* 12 */     this.shadersRender = shadersRender; this.matrixStack = matrixStack; this.activeRenderInfo = activeRenderInfo; this.partialTicks = partialTicks;
/*    */   }
/*    */   
/* 15 */   public boolean isShadersRender() { return this.shadersRender; }
/* 16 */   public MatrixStack getMatrixStack() { return this.matrixStack; }
/* 17 */   public ActiveRenderInfo getActiveRenderInfo() { return this.activeRenderInfo; } public float getPartialTicks() {
/* 18 */     return this.partialTicks;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\world\EventRenderWorldLast.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */