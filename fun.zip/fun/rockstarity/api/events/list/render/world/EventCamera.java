/*    */ package fun.rockstarity.api.events.list.render.world;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ 
/*    */ public class EventCamera extends Event {
/*    */   private MatrixStack stack;
/*    */   
/*    */   public void setStack(MatrixStack stack) {
/* 10 */     this.stack = stack; } public EventCamera(MatrixStack stack) {
/* 11 */     this.stack = stack;
/*    */   }
/*    */   public MatrixStack getStack() {
/* 14 */     return this.stack;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\world\EventCamera.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */