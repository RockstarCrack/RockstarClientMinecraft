/*    */ package fun.rockstarity.api.events.list.render.entity;
/*    */ import net.minecraft.entity.Entity;
/*    */ 
/*    */ public class EventRenderTag extends Event {
/*    */   private final String tag;
/*    */   private final Entity entity;
/*    */   
/*    */   public EventRenderTag(String tag, Entity entity) {
/*  9 */     this.tag = tag; this.entity = entity;
/*    */   }
/*    */   
/* 12 */   public String getTag() { return this.tag; } public Entity getEntity() {
/* 13 */     return this.entity;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\entity\EventRenderTag.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */