/*    */ package fun.rockstarity.api.events.list.render.entity;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventRenderItem
/*    */   extends Event
/*    */ {
/*    */   private final boolean right;
/*    */   private final float progress;
/*    */   private final MatrixStack matrixStack;
/*    */   
/*    */   public EventRenderItem(boolean right, float progress, MatrixStack matrixStack) {
/* 16 */     this.right = right; this.progress = progress; this.matrixStack = matrixStack;
/*    */   }
/*    */   
/* 19 */   public boolean isRight() { return this.right; }
/* 20 */   public float getProgress() { return this.progress; } public MatrixStack getMatrixStack() {
/* 21 */     return this.matrixStack;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\entity\EventRenderItem.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */