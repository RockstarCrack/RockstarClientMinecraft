/*    */ package fun.rockstarity.api.events.list.render.entity;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import net.minecraft.entity.Entity;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventRenderEntity
/*    */   extends Event
/*    */ {
/*    */   private final Entity entity;
/*    */   private final boolean pre;
/*    */   
/*    */   public EventRenderEntity(Entity entity, boolean pre) {
/* 15 */     this.entity = entity; this.pre = pre;
/*    */   }
/* 17 */   public Entity getEntity() { return this.entity; } public boolean isPre() {
/* 18 */     return this.pre;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\entity\EventRenderEntity.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */