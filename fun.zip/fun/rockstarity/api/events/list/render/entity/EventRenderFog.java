/*    */ package fun.rockstarity.api.events.list.render.entity;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventRenderFog
/*    */   extends Event
/*    */ {
/*    */   private final boolean pre;
/*    */   
/*    */   public EventRenderFog(boolean pre) {
/* 16 */     this.pre = pre;
/*    */   }
/*    */   public boolean isPre() {
/* 19 */     return this.pre;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\entity\EventRenderFog.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */