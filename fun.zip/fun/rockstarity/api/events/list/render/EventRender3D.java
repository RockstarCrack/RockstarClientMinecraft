/*    */ package fun.rockstarity.api.events.list.render;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import net.minecraft.client.renderer.ActiveRenderInfo;
/*    */ 
/*    */ 
/*    */ public class EventRender3D
/*    */   extends Event
/*    */ {
/*    */   private final MatrixStack matrixStack;
/*    */   private final float partialTicks;
/*    */   private final ActiveRenderInfo renderInfo;
/*    */   
/*    */   public EventRender3D(MatrixStack matrixStack, float partialTicks, ActiveRenderInfo renderInfo) {
/* 16 */     this.matrixStack = matrixStack; this.partialTicks = partialTicks; this.renderInfo = renderInfo;
/*    */   }
/*    */   public MatrixStack getMatrixStack() {
/* 19 */     return this.matrixStack;
/*    */   } public float getPartialTicks() {
/* 21 */     return this.partialTicks;
/*    */   } public ActiveRenderInfo getRenderInfo() {
/* 23 */     return this.renderInfo;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\render\EventRender3D.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */