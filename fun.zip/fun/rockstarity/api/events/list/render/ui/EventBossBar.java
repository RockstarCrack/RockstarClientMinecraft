/*    */ package fun.rockstarity.api.events.list.render.ui;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventBossBar
/*    */   extends Event
/*    */ {
/*    */   private final String text;
/*    */   
/*    */   public EventBossBar(String text) {
/* 13 */     this.text = text;
/*    */   }
/*    */   public String getText() {
/* 16 */     return this.text;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\rende\\ui\EventBossBar.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */