/*    */ package fun.rockstarity.api.events.list.render.ui.shaders;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventBloom
/*    */   extends Event
/*    */ {
/*    */   private final MatrixStack matrixStack;
/*    */   private final float partialTicks;
/*    */   
/*    */   public EventBloom(MatrixStack matrixStack, float partialTicks) {
/* 15 */     this.matrixStack = matrixStack; this.partialTicks = partialTicks;
/*    */   }
/*    */   public MatrixStack getMatrixStack() {
/* 18 */     return this.matrixStack;
/*    */   } public float getPartialTicks() {
/* 20 */     return this.partialTicks;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\rende\\ui\shaders\EventBloom.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */