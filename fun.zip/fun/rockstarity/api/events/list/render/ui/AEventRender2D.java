/*    */ package fun.rockstarity.api.events.list.render.ui;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AEventRender2D
/*    */   extends Event
/*    */ {
/*    */   private final MatrixStack matrixStack;
/*    */   private final float partialTicks;
/*    */   
/*    */   public AEventRender2D(MatrixStack matrixStack, float partialTicks) {
/* 15 */     this.matrixStack = matrixStack; this.partialTicks = partialTicks;
/*    */   }
/*    */   
/* 18 */   public MatrixStack getMatrixStack() { return this.matrixStack; } public float getPartialTicks() {
/* 19 */     return this.partialTicks;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\rende\\ui\AEventRender2D.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */