/*    */ package fun.rockstarity.api.events.list.render.ui;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ 
/*    */ public class EventHotbarSlot
/*    */   extends Event {
/*    */   private final MatrixStack matrixStack;
/*    */   private final float partialTicks;
/*    */   private final int x;
/*    */   private final int y;
/*    */   private final int slot;
/*    */   
/*    */   public EventHotbarSlot(MatrixStack matrixStack, float partialTicks, int x, int y, int slot) {
/* 15 */     this.matrixStack = matrixStack; this.partialTicks = partialTicks; this.x = x; this.y = y; this.slot = slot;
/*    */   }
/*    */   
/* 18 */   public MatrixStack getMatrixStack() { return this.matrixStack; }
/* 19 */   public float getPartialTicks() { return this.partialTicks; }
/* 20 */   public int getX() { return this.x; } public int getY() { return this.y; } public int getSlot() { return this.slot; }
/*    */ 
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\rende\\ui\EventHotbarSlot.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */