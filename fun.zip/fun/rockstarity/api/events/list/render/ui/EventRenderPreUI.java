/*    */ package fun.rockstarity.api.events.list.render.ui;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventRenderPreUI
/*    */   extends AEventRender2D
/*    */ {
/*    */   public EventRenderPreUI(MatrixStack matrixStack, float partialTicks) {
/* 17 */     super(matrixStack, partialTicks);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\rende\\ui\EventRenderPreUI.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */