/*    */ package fun.rockstarity.api.events.list.game;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import net.minecraft.entity.Entity;
/*    */ 
/*    */ public class EventSpawn
/*    */   extends Event
/*    */ {
/*    */   private final Entity entity;
/*    */   
/*    */   public EventSpawn(Entity entity) {
/* 12 */     this.entity = entity;
/*    */   } public Entity getEntity() {
/* 14 */     return this.entity;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\game\EventSpawn.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */