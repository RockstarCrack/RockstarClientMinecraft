/*    */ package fun.rockstarity.api.events.list.game;
/*    */ import net.minecraft.client.gui.screen.Screen;
/*    */ 
/*    */ public class EventCloseScreen extends Event {
/*    */   private Screen screen;
/*    */   private int windowId;
/*    */   
/*    */   public EventCloseScreen(Screen screen, int windowId) {
/*  9 */     this.screen = screen; this.windowId = windowId;
/*    */   }
/* 11 */   public Screen getScreen() { return this.screen; } public int getWindowId() {
/* 12 */     return this.windowId;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\game\EventCloseScreen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */