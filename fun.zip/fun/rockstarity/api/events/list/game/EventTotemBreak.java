/*    */ package fun.rockstarity.api.events.list.game;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventTotemBreak
/*    */   extends Event
/*    */ {
/*    */   private final LivingEntity entity;
/*    */   private final ItemStack totemItem;
/*    */   
/*    */   public EventTotemBreak(LivingEntity entity, ItemStack totemItem) {
/* 16 */     this.entity = entity; this.totemItem = totemItem;
/*    */   }
/*    */   
/* 19 */   public LivingEntity getEntity() { return this.entity; } public ItemStack getTotemItem() {
/* 20 */     return this.totemItem;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\game\EventTotemBreak.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */