/*    */ package fun.rockstarity.api.events.list.game;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ import net.minecraft.entity.projectile.TridentEntity;
/*    */ 
/*    */ 
/*    */ public class EventTridentHitted
/*    */   extends Event
/*    */ {
/*    */   private final TridentEntity trident;
/*    */   private final LivingEntity hitted;
/*    */   
/*    */   public EventTridentHitted(TridentEntity trident, LivingEntity hitted) {
/* 15 */     this.trident = trident; this.hitted = hitted;
/*    */   }
/*    */   
/* 18 */   public TridentEntity getTrident() { return this.trident; } public LivingEntity getHitted() {
/* 19 */     return this.hitted;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\game\EventTridentHitted.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */