/*    */ package fun.rockstarity.api.events.list.game.inputs;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventMouseMove
/*    */   extends Event
/*    */ {
/*    */   private double xVelocity;
/*    */   private double yVelocity;
/*    */   
/*    */   public void setXVelocity(double xVelocity) {
/* 16 */     this.xVelocity = xVelocity; } public void setYVelocity(double yVelocity) { this.yVelocity = yVelocity; } public EventMouseMove(double xVelocity, double yVelocity) {
/* 17 */     this.xVelocity = xVelocity; this.yVelocity = yVelocity;
/*    */   }
/*    */   
/* 20 */   public double getXVelocity() { return this.xVelocity; } public double getYVelocity() { return this.yVelocity; }
/*    */   
/*    */   public EventMouseMove hook() {
/* 23 */     return (EventMouseMove)super.hook();
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\game\inputs\EventMouseMove.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */