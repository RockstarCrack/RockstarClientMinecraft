/*    */ package fun.rockstarity.api.events.list.game.inputs;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.helpers.player.Move;
/*    */ import fun.rockstarity.client.modules.render.FreeLook;
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ 
/*    */ public class EventInput extends Event {
/*    */   private float forward;
/*    */   private float strafe;
/*    */   private boolean jump;
/*    */   private boolean sneak;
/*    */   private double sneakSlowDownMultiplier;
/*    */   
/*    */   public void setForward(float forward) {
/* 16 */     this.forward = forward; } public void setStrafe(float strafe) { this.strafe = strafe; } public void setJump(boolean jump) { this.jump = jump; } public void setSneak(boolean sneak) { this.sneak = sneak; } public void setSneakSlowDownMultiplier(double sneakSlowDownMultiplier) { this.sneakSlowDownMultiplier = sneakSlowDownMultiplier; }
/*    */   
/* 18 */   public float getForward() { return this.forward; } public float getStrafe() { return this.strafe; }
/* 19 */   public boolean isJump() { return this.jump; } public boolean isSneak() { return this.sneak; } public double getSneakSlowDownMultiplier() {
/* 20 */     return this.sneakSlowDownMultiplier;
/*    */   }
/*    */   public EventInput(float moveForward, float moveStrafe, boolean jump, boolean sneak) {
/* 23 */     this.forward = moveForward;
/* 24 */     this.strafe = moveStrafe;
/* 25 */     this.jump = jump;
/* 26 */     this.sneak = sneak;
/* 27 */     this.sneakSlowDownMultiplier = 0.3D;
/*    */   }
/*    */   
/*    */   public EventInput hook() {
/* 31 */     return (EventInput)super.hook();
/*    */   }
/*    */   
/*    */   public void setYaw(float yaw, float direction) {
/* 35 */     FreeLook freelook = (FreeLook)rock.getModules().get(FreeLook.class);
/* 36 */     float forward = getForward();
/* 37 */     float strafe = getStrafe();
/*    */     
/* 39 */     double angle = MathHelper.wrapDegrees(Math.toDegrees(Move.direction(freelook.get() ? (freelook.getRotation()).x : direction, forward, strafe)));
/*    */     
/* 41 */     if (forward == 0.0F && strafe == 0.0F) {
/*    */       return;
/*    */     }
/*    */     
/* 45 */     float closestForward = 0.0F, closestStrafe = 0.0F, closestDifference = Float.MAX_VALUE;
/*    */     float predictedForward;
/* 47 */     for (predictedForward = -1.0F; predictedForward <= 1.0F; predictedForward++) {
/* 48 */       float predictedStrafe; for (predictedStrafe = -1.0F; predictedStrafe <= 1.0F; predictedStrafe++) {
/* 49 */         if (predictedStrafe != 0.0F || predictedForward != 0.0F) {
/*    */           
/* 51 */           double predictedAngle = MathHelper.wrapDegrees(Math.toDegrees(Move.direction(yaw, predictedForward, predictedStrafe)));
/* 52 */           double difference = Math.abs(angle - predictedAngle);
/*    */           
/* 54 */           if (difference < closestDifference) {
/* 55 */             closestDifference = (float)difference;
/* 56 */             closestForward = predictedForward;
/* 57 */             closestStrafe = predictedStrafe;
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/* 62 */     setForward(closestForward);
/* 63 */     setStrafe(closestStrafe);
/*    */   }
/*    */   
/*    */   public void setYaw(float yaw) {
/* 67 */     setYaw(yaw, mc.player.rotationYaw);
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\game\inputs\EventInput.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */