/*    */ package fun.rockstarity.api.events.list.game.inputs;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ 
/*    */ 
/*    */ public class EventKey
/*    */   extends Event
/*    */ {
/*    */   private final int key;
/*    */   private final int scancode;
/*    */   private final boolean released;
/*    */   
/*    */   public EventKey(int key, int scancode, boolean released) {
/* 14 */     this.key = key; this.scancode = scancode; this.released = released;
/*    */   }
/*    */   
/* 17 */   public int getKey() { return this.key; } public int getScancode() { return this.scancode; } public boolean isReleased() {
/* 18 */     return this.released;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\game\inputs\EventKey.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */