/*    */ package fun.rockstarity.api.events.list.game;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ import net.minecraft.entity.item.ItemEntity;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class EventPickupItem extends Event {
/*    */   private final ItemStack itemStack;
/*    */   
/*    */   public EventPickupItem(ItemStack itemStack, LivingEntity livingEntity, ItemEntity itemEntity) {
/* 11 */     this.itemStack = itemStack; this.livingEntity = livingEntity; this.itemEntity = itemEntity;
/*    */   } private final LivingEntity livingEntity; private final ItemEntity itemEntity;
/*    */   public ItemStack getItemStack() {
/* 14 */     return this.itemStack; }
/* 15 */   public LivingEntity getLivingEntity() { return this.livingEntity; } public ItemEntity getItemEntity() {
/* 16 */     return this.itemEntity;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\game\EventPickupItem.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */