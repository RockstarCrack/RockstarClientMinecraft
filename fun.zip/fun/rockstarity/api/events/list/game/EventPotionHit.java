/*    */ package fun.rockstarity.api.events.list.game;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.projectile.PotionEntity;
/*    */ import net.minecraft.potion.EffectInstance;
/*    */ 
/*    */ public class EventPotionHit
/*    */   extends Event {
/*    */   private final PotionEntity potion;
/*    */   private final List<EffectInstance> effects;
/*    */   private final Entity target;
/*    */   private final double duration;
/*    */   
/*    */   public EventPotionHit(PotionEntity potion, List<EffectInstance> effects, Entity target, double duration) {
/* 17 */     this.potion = potion; this.effects = effects; this.target = target; this.duration = duration;
/*    */   }
/*    */   
/*    */   public PotionEntity getPotion() {
/* 21 */     return this.potion;
/* 22 */   } public List<EffectInstance> getEffects() { return this.effects; }
/* 23 */   public Entity getTarget() { return this.target; } public double getDuration() {
/* 24 */     return this.duration;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\game\EventPotionHit.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */