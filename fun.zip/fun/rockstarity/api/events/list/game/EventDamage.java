/*    */ package fun.rockstarity.api.events.list.game;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventDamage
/*    */   extends Event
/*    */ {
/*    */   private final LivingEntity target;
/*    */   
/*    */   public EventDamage(LivingEntity target) {
/* 14 */     this.target = target;
/*    */   }
/*    */   public LivingEntity getTarget() {
/* 17 */     return this.target;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\game\EventDamage.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */