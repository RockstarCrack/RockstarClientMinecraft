/*    */ package fun.rockstarity.api.events.list.game.packet;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import net.minecraft.network.IPacket;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventReceivePacket
/*    */   extends Event
/*    */ {
/*    */   private final IPacket packet;
/*    */   
/*    */   public EventReceivePacket(IPacket packet) {
/* 15 */     this.packet = packet;
/*    */   }
/*    */   public IPacket getPacket() {
/* 18 */     return this.packet;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\game\packet\EventReceivePacket.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */