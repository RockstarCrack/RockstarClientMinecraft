/*    */ package fun.rockstarity.api.events.list.game.client;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import fun.rockstarity.api.modules.Module;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventToggle
/*    */   extends Event
/*    */ {
/*    */   private final Module module;
/*    */   private final boolean value;
/*    */   
/*    */   public EventToggle(Module module, boolean value) {
/* 16 */     this.module = module; this.value = value;
/*    */   }
/*    */   
/*    */   public Module getModule() {
/* 20 */     return this.module; } public boolean isValue() {
/* 21 */     return this.value;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\game\client\EventToggle.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */