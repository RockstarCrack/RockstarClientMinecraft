/*    */ package fun.rockstarity.api.events.list.game.client;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventAlert
/*    */   extends Event
/*    */ {
/*    */   private final String text;
/*    */   private final String type;
/*    */   
/*    */   public EventAlert(String text, String type) {
/* 15 */     this.text = text; this.type = type;
/*    */   }
/*    */   
/*    */   public String getType() {
/* 19 */     return this.type; } public String getText() { return this.text; }
/*    */ 
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\game\client\EventAlert.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */