/*    */ package fun.rockstarity.api.events.list.game;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventUsePearl
/*    */   extends Event
/*    */ {
/*    */   private final LivingEntity thrower;
/*    */   private final Entity pearl;
/*    */   
/*    */   public EventUsePearl(LivingEntity thrower, Entity pearl) {
/* 16 */     this.thrower = thrower; this.pearl = pearl;
/*    */   }
/*    */   
/* 19 */   public LivingEntity getThrower() { return this.thrower; } public Entity getPearl() {
/* 20 */     return this.pearl;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\game\EventUsePearl.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */