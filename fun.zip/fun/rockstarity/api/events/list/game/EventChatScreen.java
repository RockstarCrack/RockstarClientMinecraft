/*    */ package fun.rockstarity.api.events.list.game;
/*    */ 
/*    */ import com.mojang.blaze3d.matrix.MatrixStack;
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import net.minecraft.client.gui.widget.TextFieldWidget;
/*    */ 
/*    */ public class EventChatScreen extends Event {
/*    */   private final TextFieldWidget field;
/*    */   private final MatrixStack matrixStack;
/*    */   
/*    */   public EventChatScreen(TextFieldWidget field, MatrixStack matrixStack) {
/* 12 */     this.field = field; this.matrixStack = matrixStack;
/*    */   }
/* 14 */   public TextFieldWidget getField() { return this.field; } public MatrixStack getMatrixStack() {
/* 15 */     return this.matrixStack;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\game\EventChatScreen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */