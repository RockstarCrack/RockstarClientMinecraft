/*    */ package fun.rockstarity.api.events.list.game;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventChat
/*    */   extends Event
/*    */ {
/*    */   private String message;
/*    */   
/*    */   public void setMessage(String message) {
/* 13 */     this.message = message; } public EventChat(String message) {
/* 14 */     this.message = message;
/*    */   } public String getMessage() {
/* 16 */     return this.message;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\game\EventChat.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */