/*    */ package fun.rockstarity.api.events.list.game;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import net.minecraft.item.Item;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventSetCooldown
/*    */   extends Event
/*    */ {
/*    */   private Item item;
/*    */   private int cooldown;
/*    */   
/*    */   public EventSetCooldown(Item item, int cooldown) {
/* 15 */     this.item = item; this.cooldown = cooldown; } public void setItem(Item item) { this.item = item; } public void setCooldown(int cooldown) { this.cooldown = cooldown; }
/*    */ 
/*    */   
/* 18 */   public Item getItem() { return this.item; } public int getCooldown() {
/* 19 */     return this.cooldown;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\game\EventSetCooldown.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */