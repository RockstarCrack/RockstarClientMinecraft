package fun.rockstarity.api.events.list.game;

import fun.rockstarity.api.events.Event;

public class EventSafeWalk extends Event {}


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\game\EventSafeWalk.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */