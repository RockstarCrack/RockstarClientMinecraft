/*    */ package fun.rockstarity.api.events.list.player;
/*    */ 
/*    */ 
/*    */ public class EventTrace extends Event {
/*    */   private float yaw;
/*    */   private float pitch;
/*    */   
/*  8 */   public void setYaw(float yaw) { this.yaw = yaw; } public void setPitch(float pitch) { this.pitch = pitch; } public EventTrace(float yaw, float pitch) {
/*  9 */     this.yaw = yaw; this.pitch = pitch;
/*    */   }
/*    */   
/* 12 */   public float getYaw() { return this.yaw; } public float getPitch() { return this.pitch; }
/*    */ 
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\player\EventTrace.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */