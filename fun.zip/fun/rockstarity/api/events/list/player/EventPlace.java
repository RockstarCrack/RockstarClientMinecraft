/*    */ package fun.rockstarity.api.events.list.player;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventPlace
/*    */   extends Event
/*    */ {
/*    */   private final Block block;
/*    */   private final BlockPos pos;
/*    */   
/*    */   public EventPlace(Block block, BlockPos pos) {
/* 17 */     this.block = block; this.pos = pos;
/*    */   }
/* 19 */   public Block getBlock() { return this.block; } public BlockPos getPos() {
/* 20 */     return this.pos;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\player\EventPlace.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */