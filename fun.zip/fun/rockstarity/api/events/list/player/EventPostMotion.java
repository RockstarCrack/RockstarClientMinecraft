/*    */ package fun.rockstarity.api.events.list.player;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventPostMotion
/*    */   extends Event
/*    */ {
/*    */   private boolean packetSended;
/*    */   
/*    */   public void setPacketSended(boolean packetSended) {
/* 16 */     this.packetSended = packetSended; } public EventPostMotion(boolean packetSended) {
/* 17 */     this.packetSended = packetSended;
/*    */   }
/*    */   public boolean isPacketSended() {
/* 20 */     return this.packetSended;
/*    */   }
/*    */   public EventPostMotion hook() {
/* 23 */     return (EventPostMotion)super.hook();
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\player\EventPostMotion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */