/*    */ package fun.rockstarity.api.events.list.player;
/*    */ 
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraft.util.math.vector.Vector3d;
/*    */ 
/*    */ public class EventMotionMove extends Event {
/*    */   private Vector3d from;
/*    */   private Vector3d to;
/*    */   private Vector3d motion;
/*    */   private boolean toGround;
/*    */   private AxisAlignedBB aabbFrom;
/*    */   private boolean ignoreHorizontal;
/*    */   private boolean ignoreVertical;
/*    */   private boolean collidedHorizontal;
/*    */   private boolean collidedVertical;
/*    */   
/* 17 */   public void setFrom(Vector3d from) { this.from = from; } public void setTo(Vector3d to) { this.to = to; } public void setMotion(Vector3d motion) { this.motion = motion; } public void setToGround(boolean toGround) { this.toGround = toGround; } public void setAabbFrom(AxisAlignedBB aabbFrom) { this.aabbFrom = aabbFrom; } public void setIgnoreHorizontal(boolean ignoreHorizontal) { this.ignoreHorizontal = ignoreHorizontal; } public void setIgnoreVertical(boolean ignoreVertical) { this.ignoreVertical = ignoreVertical; } public void setCollidedHorizontal(boolean collidedHorizontal) { this.collidedHorizontal = collidedHorizontal; } public void setCollidedVertical(boolean collidedVertical) { this.collidedVertical = collidedVertical; }
/*    */   
/* 19 */   public Vector3d getFrom() { return this.from; } public Vector3d getTo() { return this.to; } public Vector3d getMotion() { return this.motion; }
/* 20 */   public boolean isToGround() { return this.toGround; }
/* 21 */   public AxisAlignedBB getAabbFrom() { return this.aabbFrom; }
/* 22 */   public boolean isIgnoreHorizontal() { return this.ignoreHorizontal; } public boolean isIgnoreVertical() { return this.ignoreVertical; } public boolean isCollidedHorizontal() { return this.collidedHorizontal; } public boolean isCollidedVertical() { return this.collidedVertical; }
/*    */ 
/*    */   
/*    */   public EventMotionMove(Vector3d from, Vector3d to, Vector3d motion, boolean toGround, boolean isCollidedHorizontal, boolean isCollidedVertical, AxisAlignedBB aabbFrom) {
/* 26 */     this.from = from;
/* 27 */     this.to = to;
/* 28 */     this.motion = motion;
/* 29 */     this.toGround = toGround;
/* 30 */     this.collidedHorizontal = isCollidedHorizontal;
/* 31 */     this.collidedVertical = isCollidedVertical;
/* 32 */     this.aabbFrom = aabbFrom;
/*    */   }
/*    */   
/*    */   public EventMotionMove hook() {
/* 36 */     super.hook();
/* 37 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\player\EventMotionMove.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */