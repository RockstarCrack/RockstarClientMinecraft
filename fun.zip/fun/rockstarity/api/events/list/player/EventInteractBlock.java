/*    */ package fun.rockstarity.api.events.list.player;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import net.minecraft.util.Direction;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventInteractBlock
/*    */   extends Event
/*    */ {
/*    */   private BlockPos pos;
/*    */   private Direction face;
/*    */   
/*    */   public EventInteractBlock(BlockPos pos, Direction face) {
/* 17 */     this.pos = pos; this.face = face;
/*    */   }
/* 19 */   public void setPos(BlockPos pos) { this.pos = pos; } public void setFace(Direction face) { this.face = face; }
/*    */   
/* 21 */   public BlockPos getPos() { return this.pos; } public Direction getFace() {
/* 22 */     return this.face;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\player\EventInteractBlock.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */