/*    */ package fun.rockstarity.api.events.list.player;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventMotion
/*    */   extends Event
/*    */ {
/*    */   public static float LAST_YAW;
/*    */   public static float LAST_PITCH;
/*    */   private float yaw;
/*    */   private float pitch;
/*    */   private boolean ground;
/*    */   
/*    */   public float getYaw() {
/* 23 */     return this.yaw; } public float getPitch() { return this.pitch; }
/* 24 */   public void setGround(boolean ground) { this.ground = ground; } public boolean isGround() {
/* 25 */     return this.ground;
/*    */   }
/*    */   public EventMotion(float yaw, float pitch, boolean ground) {
/* 28 */     this.yaw = yaw;
/* 29 */     this.pitch = pitch;
/* 30 */     this.ground = ground;
/*    */   }
/*    */   
/*    */   public void setYaw(float yaw) {
/* 34 */     this.yaw = yaw;
/*    */     
/* 36 */     if (Math.abs(LAST_YAW - yaw) > 90.0F);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setPitch(float pitch) {
/* 42 */     this.pitch = pitch;
/* 43 */     LAST_PITCH = pitch;
/*    */   }
/*    */   
/*    */   public EventMotion hook() {
/* 47 */     return (EventMotion)super.hook();
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\player\EventMotion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */