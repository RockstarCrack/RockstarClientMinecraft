/*    */ package fun.rockstarity.api.events.list.player;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventPostAttack
/*    */   extends Event
/*    */ {
/*    */   private final LivingEntity target;
/*    */   
/*    */   public EventPostAttack(LivingEntity target) {
/* 17 */     this.target = target;
/*    */   }
/*    */   public LivingEntity getTarget() {
/* 20 */     return this.target;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\player\EventPostAttack.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */