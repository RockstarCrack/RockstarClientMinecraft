/*    */ package fun.rockstarity.api.events.list.player;
/*    */ 
/*    */ public class EventThrowPearl extends Event {
/*    */   private int x;
/*    */   private int y;
/*    */   
/*    */   public EventThrowPearl(int x, int y, int z, float yaw, float pitch) {
/*  8 */     this.x = x; this.y = y; this.z = z; this.yaw = yaw; this.pitch = pitch;
/*    */   } private int z; private float yaw; private float pitch; public int getX() {
/* 10 */     return this.x; } public int getY() { return this.y; } public int getZ() { return this.z; }
/*    */   
/* 12 */   public float getYaw() { return this.yaw; } public float getPitch() { return this.pitch; }
/*    */ 
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\player\EventThrowPearl.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */