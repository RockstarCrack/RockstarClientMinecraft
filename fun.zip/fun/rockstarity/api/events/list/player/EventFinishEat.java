/*    */ package fun.rockstarity.api.events.list.player;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ import net.minecraft.item.Item;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventFinishEat
/*    */   extends Event
/*    */ {
/*    */   private final LivingEntity entity;
/*    */   private final Item item;
/*    */   
/*    */   public EventFinishEat(LivingEntity entity, Item item) {
/* 16 */     this.entity = entity; this.item = item;
/*    */   }
/*    */   
/* 19 */   public LivingEntity getEntity() { return this.entity; } public Item getItem() {
/* 20 */     return this.item;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\player\EventFinishEat.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */