/*    */ package fun.rockstarity.api.events.list.player;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventMove
/*    */   extends Event
/*    */ {
/*    */   private float yaw;
/*    */   private float pitch;
/*    */   
/*    */   public void setYaw(float yaw) {
/* 14 */     this.yaw = yaw; } public void setPitch(float pitch) { this.pitch = pitch; } public EventMove(float yaw, float pitch) {
/* 15 */     this.yaw = yaw; this.pitch = pitch;
/*    */   }
/*    */   
/* 18 */   public float getYaw() { return this.yaw; } public float getPitch() { return this.pitch; }
/*    */   
/*    */   public EventMove hook() {
/* 21 */     return (EventMove)super.hook();
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\player\EventMove.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */