/*    */ package fun.rockstarity.api.events.list.player;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventCollision
/*    */   extends Event
/*    */ {
/*    */   private final BlockPos blockPos;
/*    */   
/*    */   public EventCollision(BlockPos blockPos) {
/* 16 */     this.blockPos = blockPos;
/*    */   } public BlockPos getBlockPos() {
/* 18 */     return this.blockPos;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\player\EventCollision.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */