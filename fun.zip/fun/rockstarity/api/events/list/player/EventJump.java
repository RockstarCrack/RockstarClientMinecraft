/*   */ package fun.rockstarity.api.events.list.player;
/*   */ 
/*   */ public class EventJump extends Event {
/*   */   private float motion;
/*   */   
/* 6 */   public void setMotion(float motion) { this.motion = motion; } private float yaw; public void setYaw(float yaw) { this.yaw = yaw; } public EventJump(float motion, float yaw) {
/* 7 */     this.motion = motion; this.yaw = yaw;
/*   */   }
/* 9 */   public float getMotion() { return this.motion; } public float getYaw() { return this.yaw; }
/*   */ 
/*   */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\player\EventJump.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */