/*    */ package fun.rockstarity.api.events.list.player;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventAction
/*    */   extends Event
/*    */ {
/*    */   private boolean sprintState;
/*    */   
/*    */   public void setSprintState(boolean sprintState) {
/* 14 */     this.sprintState = sprintState; } public EventAction(boolean sprintState) {
/* 15 */     this.sprintState = sprintState;
/*    */   }
/*    */   public boolean isSprintState() {
/* 18 */     return this.sprintState;
/*    */   }
/*    */   public EventAction hook() {
/* 21 */     return (EventAction)super.hook();
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\player\EventAction.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */