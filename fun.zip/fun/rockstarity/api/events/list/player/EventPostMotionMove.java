/*    */ package fun.rockstarity.api.events.list.player;
/*    */ 
/*    */ import fun.rockstarity.api.events.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventPostMotionMove
/*    */   extends Event
/*    */ {
/*    */   private double speed;
/*    */   
/*    */   public void setSpeed(double speed) {
/* 19 */     this.speed = speed; } public EventPostMotionMove(double speed) {
/* 20 */     this.speed = speed;
/*    */   }
/*    */   public double getSpeed() {
/* 23 */     return this.speed;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\list\player\EventPostMotionMove.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */