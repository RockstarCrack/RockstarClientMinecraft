/*    */ package fun.rockstarity.api.events;
/*    */ 
/*    */ import fun.rockstarity.api.IAccess;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Event
/*    */   implements IAccess
/*    */ {
/*    */   private boolean cancel;
/*    */   
/*    */   public boolean isCancel() {
/* 17 */     return this.cancel; } public void setCancel(boolean cancel) { this.cancel = cancel; }
/*    */   
/*    */   public void cancel() {
/* 20 */     this.cancel = true;
/*    */   }
/*    */   
/*    */   public <T extends Event> Event hook() {
/* 24 */     EventHandler.handleEvent(this);
/*    */     
/* 26 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\events\Event.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */