/*    */ package fun.rockstarity.api.connection;
/*    */ 
/*    */ import fun.rockstarity.api.render.color.FixColor;
/*    */ import fun.rockstarity.api.secure.Debugger;
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import ru.kotopushka.antiautistleak.obfuscator.includes.annotations.compile.ReleaseCompileToNativeCalls;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ReleaseCompileToNativeCalls
/*    */ public final class WebHookControl
/*    */ {
/*    */   private static WebHook webhooks;
/*    */   
/*    */   private WebHookControl() {
/* 18 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*    */   }
/*    */   
/*    */   public static void logs(String title, String desc, FixColor color, Map<String, String> params) {
/* 22 */     if (webhooks == null) {
/* 23 */       webhooks = new WebHook("");
/*    */     }
/*    */     try {
/* 26 */       WebHook.EmbedObject embed = null;
/* 27 */       webhooks.clearEmbeds();
/* 28 */       webhooks.addEmbed(embed = (new WebHook.EmbedObject()).setTitle(title).setDescription(desc).setColor(color));
/*    */       
/* 30 */       for (String str : params.keySet()) {
/* 31 */         if (str.equals("avatar")) {
/* 32 */           embed.setImage(params.get(str)); continue;
/*    */         } 
/* 34 */         embed.addField(str, params.get(str), true);
/*    */       } 
/*    */       
/* 37 */       webhooks.execute();
/* 38 */     } catch (IOException e) {
/* 39 */       Debugger.print(e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\connection\WebHookControl.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */