/*     */ package fun.rockstarity.api.connection.globals;
/*     */ 
/*     */ import fun.rockstarity.api.IAccess;
/*     */ import fun.rockstarity.api.helpers.math.TimerUtility;
/*     */ import fun.rockstarity.api.helpers.player.Player;
/*     */ import fun.rockstarity.api.render.globals.marks.MarkServer;
/*     */ import fun.rockstarity.api.schedules.ScheduleServer;
/*     */ import fun.rockstarity.client.modules.other.Globals;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GlobalsThread
/*     */   implements IAccess
/*     */ {
/*     */   private GlobalsThread() {
/*  21 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*     */   }
/*  23 */   private static final TimerUtility timer = new TimerUtility();
/*     */   private static boolean init;
/*  25 */   public static boolean isInit() { return init; } public static void setInit(boolean init) { GlobalsThread.init = init; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void start() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void marksTick() {
/*     */     try {
/*  49 */       if (!canNext())
/*  50 */         return;  if (!init) {
/*  51 */         SyncServer.init();
/*  52 */         sleep();
/*  53 */         MarkServer.init();
/*  54 */         sleep();
/*  55 */         ServerAPI.init();
/*  56 */         sleep();
/*  57 */         ServerAPI.updateName();
/*  58 */         ClientAPI.update(ServerAPI.getClients());
/*  59 */         init = true;
/*     */       } 
/*  61 */       MarkServer.update();
/*  62 */     } catch (Exception e) {
/*  63 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void emoteTick() {
/*     */     try {
/*  69 */       if (!canNext())
/*  70 */         return;  SyncServer.update();
/*  71 */     } catch (Exception e) {
/*  72 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void scheduleTick() {
/*     */     try {
/*  78 */       if (!canNext())
/*  79 */         return;  ScheduleServer.update();
/*  80 */     } catch (Exception e) {
/*  81 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void globalsTick() {
/*     */     try {
/*  87 */       if (!canNext())
/*  88 */         return;  String data = ServerAPI.getClients();
/*  89 */       if (data != null)
/*  90 */         ClientAPI.update(data); 
/*  91 */     } catch (Exception e) {
/*  92 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean canNext() {
/*  97 */     if (rock.getModules() == null || !((Globals)rock.getModules().get(Globals.class)).get()) {
/*  98 */       return false;
/*     */     }
/* 100 */     if (!Player.isInGame()) return false;
/*     */     
/* 102 */     return true;
/*     */   }
/*     */   
/*     */   private static void sleep() {
/*     */     try {
/* 107 */       Thread.sleep(50L);
/* 108 */     } catch (InterruptedException e) {
/* 109 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\connection\globals\GlobalsThread.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */