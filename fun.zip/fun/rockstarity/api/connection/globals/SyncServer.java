/*    */ package fun.rockstarity.api.connection.globals;
/*    */ 
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.helpers.system.ThreadManager;
/*    */ import fun.rockstarity.api.render.globals.emotions.instance.EmotionType;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.OutputStream;
/*    */ import java.io.PrintWriter;
/*    */ import java.net.Socket;
/*    */ import net.minecraft.entity.LivingEntity;
/*    */ import net.minecraft.entity.player.PlayerEntity;
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SyncServer
/*    */   implements IAccess
/*    */ {
/*    */   static Socket socket;
/*    */   static OutputStream output;
/*    */   static InputStream input;
/*    */   static PrintWriter writer;
/*    */   static BufferedReader reader;
/*    */   
/*    */   private SyncServer() {
/* 28 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void init() {
/*    */     try {
/* 38 */       socket = new Socket("85.192.24.174", 14251);
/* 39 */       OutputStream output = socket.getOutputStream();
/* 40 */       InputStream input = socket.getInputStream();
/*    */       
/* 42 */       writer = new PrintWriter(output, true);
/* 43 */       reader = new BufferedReader(new InputStreamReader(input));
/*    */     }
/* 45 */     catch (Exception exception) {}
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void finish() {
/*    */     try {
/* 53 */       if (output != null)
/* 54 */         output.close(); 
/* 55 */       if (input != null)
/* 56 */         input.close(); 
/* 57 */       if (writer != null)
/* 58 */         writer.close(); 
/* 59 */       if (reader != null)
/* 60 */         reader.close(); 
/* 61 */       if (socket != null)
/* 62 */         socket.close(); 
/* 63 */     } catch (IOException iOException) {}
/*    */   }
/*    */ 
/*    */   
/*    */   public static void send(EmotionType type) {
/* 68 */     if (writer != null) {
/* 69 */       writer.println(mc.getSession().getUsername() + "/" + mc.getSession().getUsername());
/*    */     }
/*    */   }
/*    */   
/*    */   public static void update() {
/* 74 */     if (mc.world == null) {
/*    */       return;
/*    */     }
/*    */     
/* 78 */     ThreadManager.run(() -> {
/*    */           if (reader == null) {
/*    */             init();
/*    */ 
/*    */             
/*    */             return;
/*    */           } 
/*    */           
/*    */           try {
/*    */             String message = null;
/*    */             
/*    */             if ((message = reader.readLine()) != null && message.contains("/")) {
/*    */               String[] splitted = message.split("/");
/*    */               
/*    */               if (mc.world == null) {
/*    */                 return;
/*    */               }
/*    */               
/*    */               for (PlayerEntity player : mc.world.getPlayers()) {
/*    */                 if (player.getName().getString().equals(splitted[0]) && player != mc.player) {
/*    */                   rock.getEmotions().playEmotion((LivingEntity)player, EmotionType.getFromName(splitted[1]));
/*    */                   
/*    */                   break;
/*    */                 } 
/*    */               } 
/*    */             } 
/* :4 */           } catch (Exception e) {
/*    */             e.printStackTrace();
/*    */ 
/*    */             
/*    */             init();
/* :9 */           } catch (Exception e) {
/*    */             e.printStackTrace();
/*    */           } 
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\connection\globals\SyncServer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */