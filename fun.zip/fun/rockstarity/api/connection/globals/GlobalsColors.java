/*    */ package fun.rockstarity.api.connection.globals;
/*    */ 
/*    */ import fun.rockstarity.api.render.color.FixColor;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GlobalsColors
/*    */ {
/*    */   private GlobalsColors() {
/* 15 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*    */   }
/* 17 */   private static final HashMap<String, FixColor> colors = new HashMap<>();
/*    */   
/*    */   static {
/* 20 */     colors.put("rockstar", FixColor.CYAN);
/* 21 */     colors.put("delight", FixColor.CYAN);
/* 22 */     colors.put("minced", FixColor.BLACK);
/* 23 */     colors.put("carbonara", FixColor.YELLOW);
/* 24 */     colors.put("excellent", FixColor.CYAN);
/*    */   }
/*    */   
/*    */   public static FixColor getColor(String client) {
/* 28 */     return colors.containsKey(client) ? colors.get(client) : FixColor.WHITE;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\connection\globals\GlobalsColors.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */