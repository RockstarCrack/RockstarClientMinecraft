/*    */ package fun.rockstarity.api.connection.globals;
/*    */ 
/*    */ import fun.rockstarity.api.ClientInfo;
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.client.modules.render.Cosmetics;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.OutputStream;
/*    */ import java.io.PrintWriter;
/*    */ import java.net.Socket;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ServerAPI
/*    */   implements IAccess
/*    */ {
/*    */   static Socket socket;
/*    */   static OutputStream output;
/*    */   static InputStream input;
/*    */   static PrintWriter writer;
/*    */   static BufferedReader reader;
/*    */   
/*    */   private ServerAPI() {
/* 27 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void init() {
/*    */     try {
/* 37 */       socket = new Socket("85.192.24.174", 25565);
/* 38 */       OutputStream output = socket.getOutputStream();
/* 39 */       InputStream input = socket.getInputStream();
/*    */       
/* 41 */       writer = new PrintWriter(output, true);
/* 42 */       reader = new BufferedReader(new InputStreamReader(input));
/*    */ 
/*    */       
/* 45 */       writer.println(mc.getSession().getUsername() + "/" + mc.getSession().getUsername() + "/" + ClientInfo.NAME.toString().toLowerCase() + "/" + ((Cosmetics)rock.getModules().get(Cosmetics.class)).getLocal());
/*    */     }
/* 47 */     catch (Exception ex) {
/* 48 */       ex.printStackTrace();
/*    */     } 
/*    */   }
/*    */   
/*    */   public static void finish() {
/*    */     try {
/* 54 */       if (output != null) output.close(); 
/* 55 */       if (input != null) input.close(); 
/* 56 */       if (writer != null) writer.close(); 
/* 57 */       if (reader != null) reader.close(); 
/* 58 */       if (socket != null) socket.close(); 
/* 59 */     } catch (IOException iOException) {}
/*    */   }
/*    */ 
/*    */   
/*    */   public static void updateName() {
/* 64 */     updateName(mc.getSession().getUsername());
/*    */   }
/*    */   
/*    */   public static void updateName(String name) {
/* 68 */     if (writer != null)
/* 69 */       writer.println(name + "/" + name + "/" + ClientInfo.NAME.toString().toLowerCase() + "/" + ((Cosmetics)rock.getModules().get(Cosmetics.class)).getLocal()); 
/*    */   }
/*    */   
/*    */   public static String getClients() {
/* 73 */     if (writer == null || reader == null) {
/* 74 */       init();
/* 75 */       return null;
/*    */     } 
/*    */     
/*    */     try {
/* 79 */       writer.println("/getClients");
/* 80 */       return reader.readLine();
/* 81 */     } catch (Exception e) {
/* 82 */       init();
/* 83 */       e.printStackTrace();
/* 84 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\connection\globals\ServerAPI.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */