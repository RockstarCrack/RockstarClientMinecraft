/*    */ package fun.rockstarity.api.connection.globals;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ClientAPI
/*    */ {
/*    */   private ClientAPI() {
/* 15 */     throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
/*    */   }
/* 17 */   public static final HashMap<String, GlobalsUser> USERS = new HashMap<>();
/*    */   
/*    */   public static void update(String data) {
/* 20 */     if (data == null)
/* 21 */       return;  USERS.clear();
/* 22 */     String[] userDatas = data.split("&");
/* 23 */     for (String userData : userDatas) {
/* 24 */       String[] parts = userData.split("/");
/* 25 */       if (parts.length >= 2) {
/* 26 */         String name = parts[0];
/* 27 */         String client = parts[1];
/* 28 */         int model = (parts.length >= 3) ? Integer.parseInt(parts[2]) : 0;
/* 29 */         String taksa = (parts.length >= 4) ? parts[3] : "0";
/* 30 */         USERS.put(name, new GlobalsUser(name, client, model, taksa));
/*    */       } 
/*    */     } 
/*    */   }
/*    */   public static GlobalsUser getUser(String nick) {
/*    */     try {
/* 36 */       for (Map.Entry<String, GlobalsUser> entry : USERS.entrySet()) {
/* 37 */         if (nick.contains(((GlobalsUser)entry.getValue()).getClient())) {
/* 38 */           return entry.getValue();
/*    */         }
/*    */       } 
/* 41 */     } catch (Exception exception) {}
/*    */     
/* 43 */     GlobalsUser user = USERS.get(nick);
/* 44 */     return user;
/*    */   }
/*    */   
/*    */   public static String getClient(String nick) {
/* 48 */     GlobalsUser user = getUser(nick);
/* 49 */     if (user == null) return null; 
/* 50 */     return user.getClient();
/*    */   }
/*    */   
/*    */   public static boolean isRockstar(String nick) {
/* 54 */     GlobalsUser user = getUser(nick);
/* 55 */     if (user == null) return false; 
/* 56 */     return user.getClient().equals("rockstar");
/*    */   }
/*    */   
/*    */   public static int getModel(String nick) {
/* 60 */     GlobalsUser user = getUser(nick);
/* 61 */     if (user == null) return 0; 
/* 62 */     return user.getModel();
/*    */   }
/*    */   
/*    */   public static String getTaksa(String nick) {
/* 66 */     GlobalsUser user = getUser(nick);
/* 67 */     if (user == null) return "0"; 
/* 68 */     return user.getTaksa();
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\connection\globals\ClientAPI.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */