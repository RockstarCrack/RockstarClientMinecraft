/*    */ package fun.rockstarity.api.connection.globals;
/*    */ public class GlobalsUser {
/*    */   private final String name;
/*    */   private final String client;
/*    */   private final int model;
/*    */   private final String taksa;
/*    */   
/*    */   public GlobalsUser(String name, String client, int model, String taksa) {
/*  9 */     this.name = name; this.client = client; this.model = model; this.taksa = taksa;
/*    */   }
/*    */   
/* 12 */   public String getName() { return this.name; }
/* 13 */   public String getClient() { return this.client; }
/* 14 */   public int getModel() { return this.model; } public String getTaksa() {
/* 15 */     return this.taksa;
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\connection\globals\GlobalsUser.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */