/*    */ package fun.rockstarity.api.connection;
/*    */ 
/*    */ import com.jagrosh.discordipc.IPCClient;
/*    */ import com.jagrosh.discordipc.entities.RichPresence;
/*    */ import fun.rockstarity.api.ClientInfo;
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.secure.users.User;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DiscordRPCHandler
/*    */   implements IAccess
/*    */ {
/*    */   private IPCClient client;
/*    */   
/*    */   public IPCClient getClient() {
/* 21 */     return this.client;
/*    */   }
/*    */   
/*    */   private RichPresence.Builder getBuilder() {
/* 25 */     RichPresence.Builder builder = new RichPresence.Builder();
/*    */     
/* 27 */     User user = rock.getUser();
/*    */     
/* 29 */     return builder.setDetails(String.format("Build: %s %s", new Object[] { ClientInfo.ACCESS, ClientInfo.VERSION
/* 30 */           })).setState("UID: " + user.getUid())
/* 31 */       .setStartTimestamp((new Date()).getTime())
/* 32 */       .setLargeImage("http://localhost/api/v1/files/premium/gifs/animlogo.gif", "vk.com/rockstarclient")
/* 33 */       .setSmallImage(user.getAvatar(), user.getName());
/*    */   }
/*    */   
/*    */   public void update() {}
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\connection\DiscordRPCHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */