/*    */ package fun.rockstarity.api.connection;
/*    */ 
/*    */ import fun.rockstarity.api.IAccess;
/*    */ import fun.rockstarity.api.helpers.game.Chat;
/*    */ import fun.rockstarity.api.render.ui.alerts.AlertType;
/*    */ import fun.rockstarity.api.secure.Debugger;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.util.text.TextFormatting;
/*    */ 
/*    */ public class TargetHandler
/*    */   implements IAccess
/*    */ {
/* 16 */   private final List<String> target = new ArrayList<>(); public List<String> getTarget() { return this.target; }
/*    */ 
/*    */   
/*    */   public void add(String name) {
/* 20 */     if (name.length() > 2) {
/* 21 */       this.target.add(name);
/* 22 */       rock.getAlertHandler().alert("Таргет " + name + " добавлен", AlertType.INFO);
/*    */     } else {
/* 24 */       rock.getAlertHandler().alert("Ник таргета слишком короткий", AlertType.ERROR);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void remove(String name) {
/* 29 */     this.target.remove(name);
/* 30 */     rock.getAlertHandler().alert("Таргет " + name + " удален", AlertType.INFO);
/*    */   }
/*    */   
/*    */   public void clear() {
/* 34 */     this.target.clear();
/* 35 */     rock.getAlertHandler().alert("Список таргетов очищен", AlertType.INFO);
/*    */   }
/*    */   
/*    */   public void list() {
/* 39 */     if (this.target.isEmpty()) {
/* 40 */       Chat.msg("Список таргетов пуст!");
/*    */     } else {
/* 42 */       Chat.msg("Список таргетов:");
/*    */       try {
/* 44 */         for (Iterator<String> iterator = this.target.iterator(); iterator.hasNext(); ) { String friend = iterator.next();
/* 45 */           Chat.msg(String.valueOf(TextFormatting.AQUA) + "[Rockstar] " + String.valueOf(TextFormatting.AQUA) + "[" + String.valueOf(TextFormatting.GRAY) + "] " + this.target.indexOf(friend) + 1 + String.valueOf(TextFormatting.WHITE), "Удалить " + String.valueOf(TextFormatting.GRAY) + friend, () -> {
/*    */                 this.target.remove(friend);
/*    */                 Chat.msg("таргет " + friend + " удален. Обновляю список");
/*    */                 rock.getCommands().execute("target list");
/*    */               }); }
/*    */       
/* 51 */       } catch (Exception e) {
/* 52 */         Debugger.print(e);
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public boolean isTarget(String text) {
/* 58 */     return this.target.contains(text);
/*    */   }
/*    */   
/*    */   public boolean isTarget(Entity ent) {
/* 62 */     return isTarget(ent.getName().getString());
/*    */   }
/*    */ }


/* Location:              C:\Users\pavel\OneDrive\Рабочий стол\Rockstar\1.16.5\1.16.5.jar!\fun\rockstarity\api\connection\TargetHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */